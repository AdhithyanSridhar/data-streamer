# TraceIQ Backend

AI-powered Root Cause Analysis (RCA) system with ELK integration, LangGraph4j orchestration, and LLM-driven analysis.

## Project Structure

```
traceiq-backend/
├── pom.xml                      # Parent POM with dependency management
├── traceiq-models/              # Shared domain models and DTOs (Java records)
├── traceiq-utils/               # Shared utilities (retry, JSON, correlation ID)
├── traceiq-llm-adapter/         # LLM integration with jtoon support
├── traceiq-tools-service/       # External tool adapters (ELK, Jira, Dynatrace, etc.)
├── traceiq-ingest-service/      # Nightly ELK → Cassandra ingest job
├── traceiq-core-service/        # Core orchestration with LangGraph4j
└── trace-iq-ms/                 # Main Spring Boot application
```

## Tech Stack

- **Java 17** (Maven build)
- **Spring Boot 3.2.0** (synchronous, blocking I/O)
- **LangChain4j/LangGraph4j** for AI orchestration
- **Spring AI** for tool calling
- **Cassandra** for data storage
- **SLF4J** for logging
- **OpenAPI/Swagger** for API documentation
- **Prometheus** metrics support

## Key Features

1. **TraceID Search**: Search errors by trace ID from Cassandra
2. **RCA Analysis**: LLM-driven root cause analysis using internal GPT 4.1
3. **Code Spot**: Vectorized codebase search for code location identification
4. **Implementation Plans**: Curated GitHub Copilot prompts for fixes
5. **Tool Integration**: ELK, Dynatrace, Jira, GitHub, Jenkins, K8s
6. **Nightly Ingest**: Scheduled ELK → Cassandra error ingestion
7. **GodMode**: Run all analysis (RCA + Code Spot) in one click

## Environment Variables

### Required Variables

```bash
# Cassandra
export CASSANDRA_URL=localhost
export CASSANDRA_PORT=9042
export CASSANDRA_KEYSPACE=traceiq
export CASSANDRA_DATACENTER=datacenter1

# ELK/Elasticsearch
export ELK_API_URL=http://elasticsearch:9200
export ELK_API_TOKEN=your-elk-token

# LLM APIs
export LLM_API_URL=http://internal-llm:8000
export LLM_API_TOKEN=your-llm-token
export LLM_MODEL=gpt-4.1
export LLM_MAX_TOKENS=4096
export LLM_TEMPERATURE=0.7

# Vector Search (Code LLM)
export VECTOR_API_URL=http://vector-llm:8001
export VECTOR_API_TOKEN=your-vector-token

# jtoon (optional token optimization)
export JTOON_ENABLED=false
export JTOON_URL=http://jtoon:8002

# Jira
export JIRA_API_URL=https://your-company.atlassian.net
export JIRA_API_TOKEN=your-jira-token

# Dynatrace
export DYNATRACE_API_URL=https://your-env.dynatrace.com
export DYNATRACE_API_TOKEN=your-dynatrace-token

# GitHub
export GITHUB_TOKEN=your-github-token

# Jenkins
export JENKINS_URL=http://jenkins:8080
export JENKINS_TOKEN=your-jenkins-token

# Kubernetes
export K8S_API_URL=https://kubernetes.default.svc
export K8S_API_TOKEN=your-k8s-token

# Spring Profile
export SPRING_PROFILE=dev  # or prod
```

### Environment Files

See `.env.dev.example` and `.env.prod.example` for full configuration templates.

## Build & Run

### Prerequisites

- Java 17 JDK
- Maven 3.8+
- Cassandra 4.x running
- Access to ELK, LLM APIs, and other tools

### Build

```bash
# Build all modules
mvn clean install

# Build specific module
cd traceiq-core-service
mvn clean install
```

### Run Locally

```bash
# Set environment variables
source .env.dev

# Run the application
cd trace-iq-ms
mvn spring-boot:run

# Or run the JAR
java -jar trace-iq-ms/target/trace-iq-ms-1.0.0-SNAPSHOT.jar
```

The application will start on `http://localhost:8080`

## API Endpoints

### Health & Metrics

- `GET /api/health` - Application health check
- `GET /actuator/health` - Spring Boot actuator health
- `GET /actuator/prometheus` - Prometheus metrics
- `GET /swagger-ui.html` - Swagger UI documentation
- `GET /api-docs` - OpenAPI JSON specification

### Trace API

- `POST /api/trace/search` - Search by trace ID with optional RCA/Code Spot
- `GET /api/trace/{traceId}` - Get trace details

**Request Example:**
```json
{
  "traceId": "abc123-def456",
  "includeRca": true,
  "includeCodeSpot": true,
  "godMode": false
}
```

**Response Example:**
```json
{
  "traceId": "abc123-def456",
  "confidenceScore": 0.85,
  "errorCount": 3,
  "errors": [...],
  "timeline": [...],
  "flowDiagram": {...},
  "rcaResult": {
    "analysis": "Root cause: NullPointerException in UserService...",
    "rootCause": "Unhandled null check",
    "impactedServices": ["user-service", "auth-service"],
    "recommendations": ["Add null check", "Implement defensive programming"],
    "llmModel": "gpt-4.1",
    "confidence": 0.9
  },
  "codeSpotResult": {
    "codeLocations": [
      {
        "repository": "backend-services",
        "filePath": "src/main/java/com/example/UserService.java",
        "lineNumber": 142,
        "snippet": "user.getName().trim()",
        "reason": "Potential NPE - user can be null"
      }
    ],
    "implementationPlan": "...",
    "affectedFiles": [...]
  }
}
```

### Errors API

- `GET /api/errors?page=0&size=50` - List all errors from Cassandra

### Jobs API

- `GET /api/jobs` - List all job runs
- `POST /api/jobs/ingest/run?timeRange=now-24h` - Manually trigger ingest

## LangGraph4j Orchestration

The system uses LangGraph4j for AI workflow orchestration:

### RCA Flow Nodes

1. **ELK Node** - Fetch logs by trace ID
2. **Dynatrace Node** - Fetch telemetry and service flow
3. **RCA LLM Node** - Perform root cause analysis
4. **Code Search Node** - Find code locations via vector search
5. **Jira Node** - Create tickets (optional)
6. **Notify Node** - Send notifications (optional)

See `RcaGraphBuilder.java` for implementation details.

## Prompt Templates

Professional, rich prompt templates are centralized in `PromptTemplateService.java`:

- **RCA System Prompt** - Expert SRE persona for root cause analysis
- **RCA User Prompt** - Structured prompt with ELK/Dynatrace data
- **Code Search Prompt** - Implementation plan generation
- **Curated Copilot Prompt** - High-quality prompts for GitHub Copilot

### Example Curated Prompt

```java
// Fix: NullPointerException in UserService
// Context: User object can be null when fetching from cache
// File: src/main/java/com/example/UserService.java
// Line: 142
//
// Problem: Missing null check before calling getName()
// Solution: Add defensive null check with Optional pattern
// Requirements:
// - Add null check before dereferencing user
// - Log warning when user is null
// - Return default value or throw checked exception
// Test cases:
// - Test with null user
// - Test with valid user
// - Test with user having null name
```

## Cassandra Schema

```cql
CREATE KEYSPACE IF NOT EXISTS traceiq 
WITH replication = {'class': 'SimpleStrategy', 'replication_factor': 3};

USE traceiq;

CREATE TABLE IF NOT EXISTS errors (
    trace_id text,
    message text,
    service text,
    severity text,
    stack_trace text,
    owner_email text,
    team_name text,
    timestamp timestamp,
    ingested_at timestamp,
    PRIMARY KEY (trace_id, timestamp)
) WITH CLUSTERING ORDER BY (timestamp DESC);

CREATE TABLE IF NOT EXISTS job_runs (
    job_id text PRIMARY KEY,
    job_name text,
    status text,
    start_time timestamp,
    end_time timestamp,
    records_processed bigint,
    error_message text
);

CREATE INDEX IF NOT EXISTS idx_errors_service ON errors (service);
CREATE INDEX IF NOT EXISTS idx_job_runs_name ON job_runs (job_name);
```

## Configuration

### AI Call Optimization

- **jtoon Integration**: Enable with `JTOON_ENABLED=true` to reduce token usage
- **Configurable AI Calls**: Set flags to enable/disable AI per feature
- **Caching**: Cache RCA results by trace ID (implementation recommended)
- **Rate Limiting**: Implement rate limiting for LLM calls (production)

### Retry & Error Handling

- **Retry Logic**: Exponential backoff with configurable attempts
- **Circuit Breaker**: Comment-based strategy (implement in production)
- **Error Logging**: Correlation ID tracked throughout request lifecycle

## Development

### Code Standards

- ✅ No Lombok - Use Java records for DTOs
- ✅ Java 17 compatible
- ✅ SLF4J logging with correlation IDs
- ✅ SOLID, DRY, YAGNI principles
- ✅ Comprehensive comments and documentation
- ✅ Builder pattern for complex objects

### Extending

1. **Add New Tool Adapter**: Create adapter in `traceiq-tools-service/adapter/`
2. **Add New LangGraph Node**: Update `RcaGraphBuilder.java`
3. **Add New Prompt**: Update `PromptTemplateService.java`
4. **Add New API**: Create controller in `traceiq-core-service/controller/`

## Deployment

### Docker Build

```bash
# Build JAR
mvn clean package

# Create Docker image
docker build -t traceiq-backend:1.0.0 -f Dockerfile .
```

### Kubernetes

See `k8s/` directory for manifests:
- `deployment.yaml` - Application deployment
- `service.yaml` - Service definition
- `configmap.yaml` - Configuration
- `secret.yaml` - Secrets template
- `cronjob.yaml` - Nightly ingest job

### CI/CD

See `Jenkinsfile` for CI/CD pipeline:
1. Checkout
2. Build (`mvn clean install`)
3. Test (placeholder)
4. Docker build
5. Push to registry
6. Deploy to K8s

## Monitoring

- **Metrics**: Prometheus endpoints at `/actuator/prometheus`
- **Health**: `/api/health` and `/actuator/health`
- **Logging**: SLF4J with correlation IDs
- **Tracing**: Use correlation ID for distributed tracing

## Troubleshooting

### Build Issues

```bash
# Clean and rebuild
mvn clean install -U

# Skip tests
mvn clean install -DskipTests

# Check Java version
java -version  # Should be 17

# Check Maven version
mvn -version  # Should be 3.8+
```

### Runtime Issues

```bash
# Check Cassandra connection
cqlsh -u cassandra -p cassandra

# Check application logs
tail -f trace-iq-ms/logs/application.log

# Test health endpoint
curl http://localhost:8080/api/health

# Check Swagger UI
open http://localhost:8080/swagger-ui.html
```

## License

Proprietary - Internal Use Only

## Support

For issues or questions, contact the TraceIQ team.
