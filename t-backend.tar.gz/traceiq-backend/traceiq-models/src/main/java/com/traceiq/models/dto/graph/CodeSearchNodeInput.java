package com.traceiq.models.dto.graph;

/**
 * Input schema for Code Search node (vectorized codebase LLM)
 */
public record CodeSearchNodeInput(
        String traceId,
        String rcaContext,
        String errorMessage,
        String stackTrace,
        String correlationId
) {}
