package com.example.demo.graph;

import com.example.demo.tools.ElkTool;
import org.springframework.stereotype.Component;

@Component
public class GetLogsNode implements Node {

    public static final String NAME = "getLogs";
    private final ElkTool elkTool;

    public GetLogsNode(ElkTool elkTool) {
        this.elkTool = elkTool;
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public GraphState apply(GraphState state) {
        try {
            String traceId = state.get("traceId");
            ElkTool.LogSearchResponse response = elkTool.searchLogs(new ElkTool.LogSearchRequest(traceId));
            state.set("logs", response.logs());
        } catch (Exception e) {
            state.set(NAME + "_error", "Failed to get logs: " + e.getMessage());
        }
        return state;
    }
}
