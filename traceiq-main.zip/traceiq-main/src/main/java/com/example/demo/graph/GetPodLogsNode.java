package com.example.demo.graph;

import com.example.demo.tools.KubernetesTool;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class GetPodLogsNode implements Node {

    public static final String NAME = "getPodLogs";
    private final KubernetesTool kubernetesTool;

    public GetPodLogsNode(KubernetesTool kubernetesTool) {
        this.kubernetesTool = kubernetesTool;
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public GraphState apply(GraphState state) {
        try {
            List<String> pods = state.get("restartingPods"); // Assumes this is set by another node
            if (pods != null && !pods.isEmpty()) {
                // For simplicity, getting logs from the first restarting pod.
                KubernetesTool.PodLogsResponse response = kubernetesTool.getPodLogs(new KubernetesTool.PodLogsRequest(pods.get(0)));
                state.set("podLogs", response.logs());
            } else {
                state.set(NAME + "_info", "No restarting pods found to get logs from.");
            }
        } catch (Exception e) {
            state.set(NAME + "_error", "Failed to get pod logs: " + e.getMessage());
        }
        return state;
    }
}
