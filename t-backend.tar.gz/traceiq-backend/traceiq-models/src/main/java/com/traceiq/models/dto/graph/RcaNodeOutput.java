package com.traceiq.models.dto.graph;

import java.util.List;

/**
 * Output schema for RCA LLM node
 */
public record RcaNodeOutput(
        String traceId,
        String rootCauseAnalysis,
        List<String> impactedServices,
        List<String> recommendations,
        Double confidence,
        boolean success,
        String errorMessage
) {}
