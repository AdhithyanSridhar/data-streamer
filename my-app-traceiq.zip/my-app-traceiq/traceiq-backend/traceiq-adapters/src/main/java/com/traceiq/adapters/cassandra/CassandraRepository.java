package com.traceiq.adapters.cassandra;

import com.traceiq.adapters.config.AdapterConfiguration;
import com.traceiq.models.domain.ErrorLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Repository for Cassandra operations.
 * Supports mock mode for testing without actual database connection.
 */
@Repository
public class CassandraRepository {
    
    private static final Logger logger = LoggerFactory.getLogger(CassandraRepository.class);
    private final AdapterConfiguration config;
    
    public CassandraRepository(AdapterConfiguration config) {
        this.config = config;
    }
    
    public List<ErrorLog> findByTraceId(String traceId) {
        if (config.isCassandraMockEnabled()) {
            logger.info("Mock mode: Returning mock errors for traceId: {}", traceId);
            return getMockErrors(traceId);
        }
        
        logger.info("Querying Cassandra for traceId: {}", traceId);
        // Real Cassandra query would go here
        return getMockErrors(traceId);
    }
    
    public List<ErrorLog> findAll(int pageNumber, int pageSize) {
        if (config.isCassandraMockEnabled()) {
            logger.info("Mock mode: Returning mock errors list");
            return getAllMockErrors();
        }
        
        logger.info("Querying Cassandra for all errors");
        return getAllMockErrors();
    }
    
    public void save(ErrorLog errorLog) {
        if (config.isCassandraMockEnabled()) {
            logger.info("Mock mode: Skipping save for traceId: {}", errorLog.traceId());
            return;
        }
        
        logger.info("Saving error log to Cassandra: {}", errorLog.traceId());
        // Real Cassandra insert would go here
    }
    
    public void saveAll(List<ErrorLog> errorLogs) {
        if (config.isCassandraMockEnabled()) {
            logger.info("Mock mode: Skipping batch save of {} logs", errorLogs.size());
            return;
        }
        
        logger.info("Saving {} error logs to Cassandra", errorLogs.size());
        // Real Cassandra batch insert would go here
    }
    
    private List<ErrorLog> getMockErrors(String traceId) {
        List<ErrorLog> errors = new ArrayList<>();
        
        errors.add(ErrorLog.builder()
            .traceId(traceId)
            .message("NullPointerException in PaymentService")
            .level("ERROR")
            .serviceName("payment-service")
            .microserviceTeam("payments-team")
            .ownerEmail("payments-team@example.com")
            .timestamp(Instant.now().minusSeconds(300))
            .environment("production")
            .stackTrace("NPE at PaymentService.java:145")
            .additionalFields(Map.of())
            .tags(List.of("payment", "error"))
            .build());
        
        return errors;
    }
    
    private List<ErrorLog> getAllMockErrors() {
        List<ErrorLog> errors = new ArrayList<>();
        
        for (int i = 1; i <= 10; i++) {
            errors.add(ErrorLog.builder()
                .traceId("TRACE-" + String.format("%03d", i))
                .message("Sample error message " + i)
                .level("ERROR")
                .serviceName("service-" + (i % 3 + 1))
                .microserviceTeam("team-" + (i % 2 + 1))
                .ownerEmail("team" + (i % 2 + 1) + "@example.com")
                .timestamp(Instant.now().minusSeconds(i * 100L))
                .environment("production")
                .stackTrace("Stack trace for error " + i)
                .additionalFields(Map.of())
                .tags(List.of("error", "auto-detected"))
                .build());
        }
        
        return errors;
    }
}
