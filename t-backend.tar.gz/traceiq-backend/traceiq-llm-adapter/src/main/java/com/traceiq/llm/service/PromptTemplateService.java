package com.traceiq.llm.service;

import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * Service managing professional prompt templates for LLM interactions
 * Centralized versioned prompts for consistency and maintainability
 */
@Service
public class PromptTemplateService {

    /**
     * System prompt for RCA analysis
     * Version: 1.0
     */
    public String getRcaSystemPrompt() {
        return """
                You are an expert Site Reliability Engineer (SRE) and software architect with deep expertise in:
                - Distributed systems debugging and root cause analysis
                - Microservices architecture patterns and anti-patterns
                - Production incident management and postmortem analysis
                - Log analysis, tracing, and observability best practices
                
                Your task is to perform thorough Root Cause Analysis (RCA) on production errors.
                Analyze the provided logs, traces, metrics, and context to identify:
                1. The ROOT CAUSE of the issue (not just symptoms)
                2. All impacted services and dependencies
                3. Specific, actionable recommendations for fixes
                4. Confidence level in your analysis (0.0 to 1.0)
                
                Provide your analysis in JSON format with these fields:
                {
                  "root_cause_analysis": "Detailed analysis of the root cause",
                  "impacted_services": ["service1", "service2"],
                  "recommendations": ["specific actionable recommendation 1", "recommendation 2"],
                  "confidence": 0.85
                }
                
                Be specific, technical, and focus on actionable insights.
                """;
    }

    /**
     * Build comprehensive RCA prompt from context and data
     */
    public String buildRcaPrompt(
            String context,
            Map<String, Object> elkData,
            Map<String, Object> dynatraceData
    ) {
        StringBuilder prompt = new StringBuilder();
        prompt.append("## Production Error Analysis Request\n\n");
        
        if (context != null && !context.isEmpty()) {
            prompt.append("### Context\n");
            prompt.append(context).append("\n\n");
        }
        
        if (elkData != null && !elkData.isEmpty()) {
            prompt.append("### ELK/Kibana Logs\n");
            prompt.append("```json\n");
            prompt.append(com.traceiq.utils.JsonUtil.toPrettyJson(elkData));
            prompt.append("\n```\n\n");
        }
        
        if (dynatraceData != null && !dynatraceData.isEmpty()) {
            prompt.append("### Dynatrace Telemetry\n");
            prompt.append("```json\n");
            prompt.append(com.traceiq.utils.JsonUtil.toPrettyJson(dynatraceData));
            prompt.append("\n```\n\n");
        }
        
        prompt.append("### Analysis Instructions\n");
        prompt.append("""
                1. Review all logs, traces, and metrics carefully
                2. Identify patterns, anomalies, and correlations
                3. Determine the root cause (not just symptoms)
                4. List all impacted services with reasoning
                5. Provide specific, prioritized recommendations
                6. Assess your confidence level based on available data
                
                Focus on:
                - Exception stack traces and error messages
                - Service dependencies and call chains
                - Timing anomalies and latency spikes
                - Resource constraints (memory, CPU, connections)
                - Configuration issues and environment differences
                - Known anti-patterns and common failure modes
                
                Provide detailed, technical analysis suitable for senior engineers.
                """);
        
        return prompt.toString();
    }

    /**
     * System prompt for code search and implementation planning
     * Version: 1.0
     */
    public String getCodeSearchSystemPrompt() {
        return """
                You are an expert software engineer with deep knowledge of:
                - Software design patterns and best practices
                - Bug fixing and code remediation strategies
                - Legacy code analysis and refactoring
                - Test-driven development and quality assurance
                
                Your task is to analyze identified code locations and RCA context to:
                1. Create a detailed implementation plan for fixing the issue
                2. Generate a curated, high-quality prompt for GitHub Copilot or similar AI coding assistants
                3. Provide step-by-step instructions that follow SDLC best practices
                4. Include testing strategies and rollback considerations
                
                Your output will be used by developers with GitHub Copilot in their IDE.
                Make the implementation plan clear, specific, and actionable.
                """;
    }

    /**
     * Build implementation plan prompt
     */
    public String buildImplementationPlanPrompt(
            String rcaContext,
            String codeLocations
    ) {
        return String.format("""
                ## Implementation Plan Request
                
                ### Root Cause Analysis
                %s
                
                ### Identified Code Locations
                %s
                
                ### Required Outputs
                
                1. **Implementation Plan**: A step-by-step plan for fixing the issue including:
                   - Files to modify
                   - Specific changes required
                   - Testing strategy
                   - Rollback plan
                   - Deployment considerations
                
                2. **Curated GitHub Copilot Prompt**: A professional, detailed prompt that developers can use in their IDE with GitHub Copilot to implement the fix. The prompt should:
                   - Clearly describe the bug/issue
                   - Specify the desired behavior
                   - Include relevant context and constraints
                   - Reference specific files and line numbers
                   - Suggest test cases to add
                   - Follow best practices and design patterns
                
                Example Curated Prompt Format:
                ```
                // Fix: [Brief description of the issue]
                // Context: [RCA summary]
                // File: [path/to/file.java]
                // Line: [line number]
                //
                // Problem: [Detailed problem description]
                // Solution: [Proposed solution approach]
                // Requirements:
                // - [Requirement 1]
                // - [Requirement 2]
                // Test cases to add:
                // - [Test case 1]
                // - [Test case 2]
                ```
                
                Provide a comprehensive plan that developers can follow with confidence.
                """, rcaContext, codeLocations);
    }

    /**
     * Build curated GitHub Copilot prompt for implementation
     * This is the high-quality prompt developers will use in their IDE
     */
    public String buildCuratedCopilotPrompt(
            String issue,
            String rootCause,
            String filePath,
            Integer lineNumber,
            String proposedFix,
            String testStrategy
    ) {
        return String.format("""
                // ========================================
                // IMPLEMENTATION TASK: %s
                // ========================================
                //
                // ROOT CAUSE:
                // %s
                //
                // FILE: %s
                // LINE: %s
                //
                // CURRENT ISSUE:
                // The current implementation has a critical flaw that causes production errors.
                // This needs to be fixed following best practices and defensive programming principles.
                //
                // PROPOSED FIX:
                // %s
                //
                // REQUIREMENTS:
                // 1. Fix must be backward compatible
                // 2. Add appropriate error handling and logging
                // 3. Follow existing code style and patterns
                // 4. Add defensive checks for edge cases
                // 5. Update related documentation/comments
                //
                // TESTING STRATEGY:
                // %s
                //
                // IMPLEMENTATION CHECKLIST:
                // [ ] Apply the proposed fix
                // [ ] Add error handling
                // [ ] Add logging for debugging
                // [ ] Write unit tests
                // [ ] Write integration tests
                // [ ] Update documentation
                // [ ] Test edge cases
                // [ ] Verify backward compatibility
                //
                // Please implement this fix with high code quality, proper error handling,
                // and comprehensive tests. Follow SOLID principles and existing patterns.
                """,
                issue,
                rootCause,
                filePath,
                lineNumber,
                proposedFix,
                testStrategy
        );
    }
}
