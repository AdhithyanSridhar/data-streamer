<template>
  <div class="hover-card-wrapper" @mouseenter="showCard" @mouseleave="hideCard">
    <slot></slot>
    
    <Teleport to="body">
      <Transition name="hover-card">
        <div 
          v-if="isVisible" 
          class="hover-card"
          :style="{ top: position.y + 'px', left: position.x + 'px' }"
          @mouseenter="showCard"
          @mouseleave="hideCard"
        >
          <div class="hover-card-header">
            <v-icon :icon="icon" size="18" class="mr-2"></v-icon>
            <span class="hover-card-title">{{ title }}</span>
          </div>
          
          <div class="hover-card-content">
            <slot name="content">
              <div v-if="data" class="hover-data">
                <div v-for="(value, key) in data" :key="key" class="hover-data-item">
                  <span class="data-label">{{ key }}</span>
                  <span class="data-value">{{ value }}</span>
                </div>
              </div>
            </slot>
          </div>
          
          <div class="hover-card-footer" v-if="$slots.footer">
            <slot name="footer"></slot>
          </div>
        </div>
      </Transition>
    </Teleport>
  </div>
</template>

<script setup>
import { ref } from 'vue'

defineProps({
  title: {
    type: String,
    default: 'Preview'
  },
  icon: {
    type: String,
    default: 'mdi-information-outline'
  },
  data: {
    type: Object,
    default: null
  },
  delay: {
    type: Number,
    default: 300
  }
})

const isVisible = ref(false)
const position = ref({ x: 0, y: 0 })
let showTimeout = null
let hideTimeout = null

const showCard = (e) => {
  clearTimeout(hideTimeout)
  
  if (!isVisible.value) {
    showTimeout = setTimeout(() => {
      const rect = e.target.getBoundingClientRect()
      position.value = {
        x: rect.left,
        y: rect.bottom + 8
      }
      isVisible.value = true
    }, 300)
  }
}

const hideCard = () => {
  clearTimeout(showTimeout)
  hideTimeout = setTimeout(() => {
    isVisible.value = false
  }, 100)
}
</script>

<style scoped>
.hover-card-wrapper {
  display: inline-block;
}

.hover-card {
  position: fixed;
  z-index: 10000;
  min-width: 280px;
  max-width: 400px;
  background: #ffffff;
  border: 1px solid #e5e5e5;
  border-radius: 12px;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
  overflow: hidden;
}

.hover-card-header {
  display: flex;
  align-items: center;
  padding: 12px 16px;
  background: #f5f5f5;
  border-bottom: 1px solid #e5e5e5;
}

.hover-card-title {
  font-size: 0.9rem;
  font-weight: 600;
  color: #1a1a1a;
}

.hover-card-content {
  padding: 16px;
}

.hover-data {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.hover-data-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.data-label {
  font-size: 0.8rem;
  color: #666666;
}

.data-value {
  font-size: 0.85rem;
  font-weight: 500;
  color: #1a1a1a;
}

.hover-card-footer {
  padding: 12px 16px;
  border-top: 1px solid #e5e5e5;
  background: #fafafa;
}

/* Transition */
.hover-card-enter-active,
.hover-card-leave-active {
  transition: opacity 0.2s ease, transform 0.2s ease;
}

.hover-card-enter-from,
.hover-card-leave-to {
  opacity: 0;
  transform: translateY(-10px);
}
</style>
