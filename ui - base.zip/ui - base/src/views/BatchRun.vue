<template>
  <v-container fluid class="pa-6">
    <div class="page-header mb-6">
      <h1 class="page-title">Batch Runs</h1>
      <p class="page-subtitle">Monitor execution history of batch jobs</p>
    </div>

    <!-- Filters -->
    <div class="glass-card pa-5 mb-6">
      <v-row align="center">
        <v-col cols="12" md="3">
          <v-select v-model="selectedApp" :items="apps" label="Application" variant="outlined" density="comfortable" prepend-inner-icon="mdi-application-outline" clearable></v-select>
        </v-col>
        <v-col cols="12" md="3">
          <v-select v-model="selectedStatus" :items="statuses" label="Status" variant="outlined" density="comfortable" prepend-inner-icon="mdi-filter-outline" clearable></v-select>
        </v-col>
        <v-col cols="12" md="3">
          <v-text-field v-model="dateRange" label="Date Range" variant="outlined" density="comfortable" prepend-inner-icon="mdi-calendar-outline" placeholder="Last 7 days"></v-text-field>
        </v-col>
        <v-col cols="12" md="3">
          <v-btn color="primary" size="large" rounded="lg" block><v-icon icon="mdi-refresh" class="mr-2"></v-icon>Refresh</v-btn>
        </v-col>
      </v-row>
    </div>

    <!-- Stats -->
    <v-row class="mb-6">
      <v-col cols="12" sm="6" md="3" v-for="stat in stats" :key="stat.title">
        <div class="glass-card pa-4 stat-card">
          <div class="stat-icon">
            <v-icon :icon="stat.icon" size="24"></v-icon>
          </div>
          <div class="stat-content">
            <span class="stat-value">{{ stat.value }}</span>
            <span class="stat-label">{{ stat.title }}</span>
          </div>
        </div>
      </v-col>
    </v-row>

    <!-- Runs Table -->
    <div class="glass-card pa-5">
      <div class="section-header mb-4">
        <div class="section-header__icon">
          <v-icon icon="mdi-play-circle-outline" size="20"></v-icon>
        </div>
        <span class="section-header__title">Execution History</span>
        <v-spacer></v-spacer>
        <v-chip variant="outlined" size="small">{{ runs.length }} runs</v-chip>
      </div>

      <v-data-table :headers="headers" :items="runs" class="runs-table" density="comfortable">
        <template v-slot:item.appName="{ item }">
          <v-chip variant="outlined" size="small">{{ item.appName }}</v-chip>
        </template>
        <template v-slot:item.status="{ item }">
          <v-chip :color="getStatusColor(item.status)" variant="flat" size="small">
            <v-icon :icon="getStatusIcon(item.status)" size="14" class="mr-1"></v-icon>
            {{ item.status }}
          </v-chip>
        </template>
        <template v-slot:item.startTime="{ item }">
          <span class="timestamp">{{ formatDate(item.startTime) }}</span>
        </template>
        <template v-slot:item.duration="{ item }">
          <span class="duration">{{ item.duration }}</span>
        </template>
        <template v-slot:item.actions="{ item }">
          <v-btn icon variant="text" size="small" title="View Logs"><v-icon icon="mdi-text-box-outline" size="18"></v-icon></v-btn>
          <v-btn icon variant="text" size="small" title="Rerun" :disabled="item.status === 'running'"><v-icon icon="mdi-refresh" size="18"></v-icon></v-btn>
        </template>
      </v-data-table>
    </div>
  </v-container>
</template>

<script setup>
import { ref } from 'vue'

const selectedApp = ref(null)
const selectedStatus = ref(null)
const dateRange = ref('Last 7 days')

const apps = ['payment-service', 'billing-service', 'order-service', 'sync-service', 'auth-service']
const statuses = ['Success', 'Failed', 'Running', 'Cancelled']

const stats = [
  { title: 'Total Runs', value: '1,247', icon: 'mdi-play-circle-outline' },
  { title: 'Successful', value: '1,198', icon: 'mdi-check-circle-outline' },
  { title: 'Failed', value: '42', icon: 'mdi-close-circle-outline' },
  { title: 'Running', value: '7', icon: 'mdi-loading' }
]

const headers = [
  { title: 'Application', key: 'appName' },
  { title: 'Job Name', key: 'jobName' },
  { title: 'Run ID', key: 'runId' },
  { title: 'Start Time', key: 'startTime' },
  { title: 'Duration', key: 'duration' },
  { title: 'Status', key: 'status', align: 'center' },
  { title: 'Actions', key: 'actions', align: 'center', sortable: false }
]

const runs = ref([
  { id: 1, appName: 'payment-service', jobName: 'ProcessPendingPayments', runId: 'run-12345', startTime: '2024-12-10T14:30:00Z', duration: '2m 15s', status: 'Success' },
  { id: 2, appName: 'billing-service', jobName: 'GenerateInvoices', runId: 'run-12344', startTime: '2024-12-10T14:15:00Z', duration: '5m 42s', status: 'Success' },
  { id: 3, appName: 'order-service', jobName: 'CleanupExpiredOrders', runId: 'run-12343', startTime: '2024-12-10T14:00:00Z', duration: '1m 08s', status: 'Failed' },
  { id: 4, appName: 'sync-service', jobName: 'SyncExternalData', runId: 'run-12342', startTime: '2024-12-10T13:45:00Z', duration: '-', status: 'Running' },
  { id: 5, appName: 'auth-service', jobName: 'RefreshTokens', runId: 'run-12341', startTime: '2024-12-10T13:30:00Z', duration: '45s', status: 'Success' }
])

const formatDate = (date) => new Date(date).toLocaleString()
const getStatusColor = (status) => ({ 'Success': 'success', 'Failed': 'error', 'Running': 'info', 'Cancelled': 'warning' }[status] || 'grey')
const getStatusIcon = (status) => ({ 'Success': 'mdi-check', 'Failed': 'mdi-close', 'Running': 'mdi-loading', 'Cancelled': 'mdi-cancel' }[status] || 'mdi-help')
</script>

<style scoped>
.page-header { text-align: center; padding: 20px 0; }
.page-title { font-size: 1.75rem; font-weight: 700; color: #1a1a1a; margin-bottom: 8px; }
.page-subtitle { font-size: 0.95rem; color: #666666; }
.stat-card { display: flex; flex-direction: column; gap: 12px; }
.stat-icon { width: 44px; height: 44px; border-radius: 10px; display: flex; align-items: center; justify-content: center; background: #f5f5f5; color: #1a1a1a; }
.stat-content { display: flex; flex-direction: column; gap: 4px; }
.stat-value { font-size: 1.5rem; font-weight: 700; color: #1a1a1a; }
.stat-label { font-size: 0.8rem; color: #666666; }
.runs-table { background: transparent !important; }
.timestamp { font-size: 0.8rem; color: #666666; }
.duration { font-family: monospace; color: #1a1a1a; }
</style>
