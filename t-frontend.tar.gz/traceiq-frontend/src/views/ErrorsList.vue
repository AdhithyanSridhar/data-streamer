<template>
  <div>
    <h2 class="text-3xl font-bold mb-6">Error List</h2>
    
    <div class="bg-white rounded-lg shadow">
      <div class="p-6">
        <div class="flex justify-between items-center mb-4">
          <p class="text-gray-600">Total Errors: <span class="font-bold">{{ totalCount }}</span></p>
          <button @click="loadErrors" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
            <i class="fas fa-sync-alt mr-2"></i>Refresh
          </button>
        </div>
        
        <div class="overflow-x-auto">
          <table class="w-full">
            <thead class="bg-gray-50">
              <tr>
                <th class="px-4 py-3 text-left">Trace ID</th>
                <th class="px-4 py-3 text-left">Service</th>
                <th class="px-4 py-3 text-left">Message</th>
                <th class="px-4 py-3 text-left">Severity</th>
                <th class="px-4 py-3 text-left">Timestamp</th>
                <th class="px-4 py-3 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="error in errors" :key="error.traceId" class="border-t hover:bg-gray-50">
                <td class="px-4 py-3 font-mono text-sm">{{ error.traceId }}</td>
                <td class="px-4 py-3">{{ error.service }}</td>
                <td class="px-4 py-3 max-w-md truncate">{{ error.message }}</td>
                <td class="px-4 py-3">
                  <span :class="severityClass(error.severity)" class="px-2 py-1 rounded text-xs font-semibold">
                    {{ error.severity }}
                  </span>
                </td>
                <td class="px-4 py-3 text-sm">{{ formatDate(error.timestamp) }}</td>
                <td class="px-4 py-3">
                  <router-link :to="{ path: '/', query: { traceId: error.traceId } }" class="text-blue-600 hover:underline">
                    View
                  </router-link>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import api from '../api/traceiq'

const errors = ref([])
const totalCount = ref(0)

const loadErrors = async () => {
  try {
    const res = await api.getErrors()
    errors.value = res.data.errors
    totalCount.value = res.data.totalCount
  } catch (error) {
    console.error('Failed to load errors:', error)
  }
}

const severityClass = (severity) => {
  const classes = {
    CRITICAL: 'bg-red-600 text-white',
    HIGH: 'bg-orange-600 text-white',
    MEDIUM: 'bg-yellow-600 text-white',
    LOW: 'bg-blue-600 text-white',
    INFO: 'bg-gray-600 text-white'
  }
  return classes[severity] || 'bg-gray-600 text-white'
}

const formatDate = (timestamp) => {
  return new Date(timestamp).toLocaleString()
}

onMounted(() => {
  loadErrors()
})
</script>
