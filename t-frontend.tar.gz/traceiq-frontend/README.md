# TraceIQ Frontend

Vue.js frontend for TraceIQ - AI-powered Root Cause Analysis system.

## Tech Stack

- **Vue 3** with Composition API
- **Vue Router** for navigation
- **Pinia** for state management
- **Axios** for HTTP requests
- **Tailwind CSS** for styling
- **Font Awesome** for icons
- **Vite** for build tooling

## Project Structure

```
traceiq-frontend/
├── src/
│   ├── views/           # Page components (4 screens)
│   │   ├── TraceSearch.vue    # Trace ID search with RCA/Code Spot
│   │   ├── ErrorsList.vue     # List all errors from Cassandra
│   │   ├── Jobs.vue            # Job runs and manual ingest
│   │   └── Help.vue           # Team info, vision, FAQ
│   ├── components/       # Reusable components
│   ├── api/             # API client (axios)
│   ├── App.vue          # Root component
│   ├── router.js        # Vue Router configuration
│   └── main.js          # Application entry point
├── public/              # Static assets
├── index.html           # HTML template
├── vite.config.js       # Vite configuration
└── package.json         # Dependencies
```

## Setup

### Prerequisites

- Node.js 16+ and npm
- Backend running on `http://localhost:8080`

### Install Dependencies

```bash
npm install
```

### Development Server

```bash
npm run dev
```

The app will be available at `http://localhost:3000`

### Build for Production

```bash
npm run build
```

Output will be in `dist/` directory.

### Preview Production Build

```bash
npm run preview
```

## Features

### Screen 1: Trace Search

- **Trace ID input** - Search by trace ID
- **4 Action buttons**:
  - **Search** - Basic trace details
  - **RCA Analysis** - LLM-driven root cause analysis
  - **Code Spot** - Find code locations with implementation plans
  - **GodMode** - Run both RCA + Code Spot
- **Trace Summary** - Trace ID, error count, confidence score
- **Timeline View** - Chronological events
- **Flow Diagram** - Services involved
- **RCA Results** - Root cause, recommendations, impacted services
- **Code Locations** - File paths, line numbers, code snippets, implementation plans

### Screen 2: Errors List

- **Table view** of all errors from Cassandra
- **Columns**: Trace ID, Service, Message, Severity, Timestamp
- **Severity badges** with color coding (Critical, High, Medium, Low, Info)
- **Clickable trace IDs** - Navigate to Screen 1
- **Refresh button** - Reload errors

### Screen 3: Jobs

- **Job runs table** - View all scheduled and manual jobs
- **Run Ingest Job** button - Manually trigger ELK ingest
- **Status badges** - Completed, Running, Failed, Scheduled
- **Job details** - Start time, end time, records processed

### Screen 4: Help

- **Vision** - Project goals and value proposition
- **Team Members** - Team information
- **FAQ** - Common questions and answers
- **Feedback** - Contact form/email

## API Integration

The frontend communicates with the backend via REST APIs:

```javascript
// Example API calls
import api from '@/api/traceiq'

// Search trace
const result = await api.searchTrace(traceId, includeRca, includeCodeSpot, godMode)

// Get errors
const errors = await api.getErrors(page, size)

// Get jobs
const jobs = await api.getJobs()

// Run ingest job
await api.runIngestJob(timeRange)
```

## Configuration

### API Proxy

Vite is configured to proxy API requests to the backend:

```javascript
// vite.config.js
server: {
  proxy: {
    '/api': {
      target: 'http://localhost:8080',
      changeOrigin: true
    }
  }
}
```

Update the `target` URL if your backend runs on a different port.

## Deployment

### Build for Production

```bash
npm run build
```

### Deploy to Static Hosting

The `dist/` folder can be deployed to:
- **Nginx** - Serve as static files
- **Apache** - Configure as SPA
- **Cloudflare Pages** - Connect GitHub repo
- **Netlify** - Drag & drop dist folder
- **Vercel** - Import GitHub repo

### Nginx Configuration Example

```nginx
server {
    listen 80;
    server_name traceiq.company.com;
    root /var/www/traceiq-frontend/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api/ {
        proxy_pass http://backend:8080/api/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## Development

### Adding New Features

1. **New View**: Create `.vue` file in `src/views/`
2. **New Component**: Create `.vue` file in `src/components/`
3. **New API**: Add methods to `src/api/traceiq.js`
4. **New Route**: Update `src/router.js`

### Code Style

- Use **Composition API** with `<script setup>`
- Use **Tailwind CSS** for styling
- Use **Font Awesome** icons with `<i class="fas fa-..."></i>`
- Keep components small and focused
- Use async/await for API calls

### State Management

Currently using local component state with `ref()` and `reactive()`.
For complex state, use Pinia store:

```javascript
// src/store/trace.js
import { defineStore } from 'pinia'

export const useTraceStore = defineStore('trace', {
  state: () => ({
    currentTrace: null,
    errors: []
  }),
  actions: {
    async loadTrace(traceId) {
      // API call
    }
  }
})
```

## Troubleshooting

### Build Errors

```bash
# Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install

# Clear Vite cache
rm -rf node_modules/.vite
npm run dev
```

### API Connection Issues

- Verify backend is running on `http://localhost:8080`
- Check browser console for CORS errors
- Verify proxy configuration in `vite.config.js`

### Hot Module Replacement (HMR) Issues

```bash
# Restart dev server
npm run dev
```

## License

Proprietary - Internal Use Only
