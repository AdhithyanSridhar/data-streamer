<template>
  <span class="animated-counter" :class="{ 'counting': isCounting }">
    {{ displayValue }}{{ suffix }}
  </span>
</template>

<script setup>
import { ref, watch, onMounted } from 'vue'

const props = defineProps({
  value: {
    type: Number,
    required: true
  },
  duration: {
    type: Number,
    default: 1500
  },
  suffix: {
    type: String,
    default: ''
  },
  prefix: {
    type: String,
    default: ''
  },
  decimals: {
    type: Number,
    default: 0
  },
  autoStart: {
    type: Boolean,
    default: true
  }
})

const displayValue = ref(0)
const isCounting = ref(false)
let animationFrame = null

const formatNumber = (num) => {
  if (props.decimals > 0) {
    return num.toFixed(props.decimals)
  }
  return Math.floor(num).toLocaleString()
}

const animateValue = (start, end, duration) => {
  isCounting.value = true
  const startTime = performance.now()
  
  const step = (currentTime) => {
    const elapsed = currentTime - startTime
    const progress = Math.min(elapsed / duration, 1)
    
    // Easing function (ease-out-expo)
    const easeOutExpo = 1 - Math.pow(2, -10 * progress)
    
    const currentValue = start + (end - start) * easeOutExpo
    displayValue.value = formatNumber(currentValue)
    
    if (progress < 1) {
      animationFrame = requestAnimationFrame(step)
    } else {
      isCounting.value = false
    }
  }
  
  animationFrame = requestAnimationFrame(step)
}

const startCounting = () => {
  if (animationFrame) {
    cancelAnimationFrame(animationFrame)
  }
  animateValue(0, props.value, props.duration)
}

watch(() => props.value, (newVal, oldVal) => {
  animateValue(oldVal || 0, newVal, props.duration)
})

onMounted(() => {
  if (props.autoStart) {
    startCounting()
  }
})

defineExpose({ startCounting })
</script>

<style scoped>
.animated-counter {
  font-variant-numeric: tabular-nums;
  transition: color 0.3s ease;
}

.counting {
  color: inherit;
}
</style>
