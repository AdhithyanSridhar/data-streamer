package com.traceiq.tools.adapter;

import com.traceiq.tools.config.ToolsConfig;
import com.traceiq.utils.JsonUtil;
import com.traceiq.utils.RetryUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

/**
 * Adapter for Kubernetes API integration
 * Fetch pod info, service info, deployment status
 */
@Component
public class KubernetesAdapter {
    private static final Logger logger = LoggerFactory.getLogger(KubernetesAdapter.class);

    private final RestTemplate restTemplate;
    private final ToolsConfig toolsConfig;

    public KubernetesAdapter(RestTemplate restTemplate, ToolsConfig toolsConfig) {
        this.restTemplate = restTemplate;
        this.toolsConfig = toolsConfig;
    }

    /**
     * Get pod information
     */
    public Map<String, Object> getPodInfo(String namespace, String podName, String correlationId) {
        return RetryUtil.executeWithDefaultRetry(() -> {
            logger.info("[{}] Fetching pod info: {}/{}", correlationId, namespace, podName);

            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + toolsConfig.getK8sApiToken());
            headers.set("X-Correlation-Id", correlationId);

            HttpEntity<Void> entity = new HttpEntity<>(headers);

            ResponseEntity<String> response = restTemplate.exchange(
                    toolsConfig.getK8sApiUrl() + "/api/v1/namespaces/" + namespace + "/pods/" + podName,
                    HttpMethod.GET,
                    entity,
                    String.class
            );

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                logger.info("[{}] Pod info fetched successfully", correlationId);
                return JsonUtil.fromJson(response.getBody(), Map.class);
            }

            throw new RuntimeException("Failed to fetch pod info");

        }, "K8s-Get-Pod-Info");
    }

    /**
     * Get deployment status
     */
    public Map<String, Object> getDeploymentStatus(String namespace, String deploymentName, String correlationId) {
        return RetryUtil.executeWithDefaultRetry(() -> {
            logger.info("[{}] Fetching deployment status: {}/{}", correlationId, namespace, deploymentName);

            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + toolsConfig.getK8sApiToken());
            headers.set("X-Correlation-Id", correlationId);

            HttpEntity<Void> entity = new HttpEntity<>(headers);

            ResponseEntity<String> response = restTemplate.exchange(
                    toolsConfig.getK8sApiUrl() + "/apis/apps/v1/namespaces/" + namespace + "/deployments/" + deploymentName,
                    HttpMethod.GET,
                    entity,
                    String.class
            );

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                logger.info("[{}] Deployment status fetched successfully", correlationId);
                return JsonUtil.fromJson(response.getBody(), Map.class);
            }

            throw new RuntimeException("Failed to fetch deployment status");

        }, "K8s-Get-Deployment-Status");
    }

    /**
     * Get service information
     */
    public Map<String, Object> getServiceInfo(String namespace, String serviceName, String correlationId) {
        return RetryUtil.executeWithDefaultRetry(() -> {
            logger.info("[{}] Fetching service info: {}/{}", correlationId, namespace, serviceName);

            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + toolsConfig.getK8sApiToken());
            headers.set("X-Correlation-Id", correlationId);

            HttpEntity<Void> entity = new HttpEntity<>(headers);

            ResponseEntity<String> response = restTemplate.exchange(
                    toolsConfig.getK8sApiUrl() + "/api/v1/namespaces/" + namespace + "/services/" + serviceName,
                    HttpMethod.GET,
                    entity,
                    String.class
            );

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                logger.info("[{}] Service info fetched successfully", correlationId);
                return JsonUtil.fromJson(response.getBody(), Map.class);
            }

            throw new RuntimeException("Failed to fetch service info");

        }, "K8s-Get-Service-Info");
    }
}
