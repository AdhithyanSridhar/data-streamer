package com.example.demo.graph;

import com.example.demo.tools.GitTool;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class CodeOwnersNode implements Node {

    public static final String NAME = "getCodeOwners";
    private final GitTool gitTool;

    public CodeOwnersNode(GitTool gitTool) {
        this.gitTool = gitTool;
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public GraphState apply(GraphState state) {
        try {
            List<String> files = state.get("relevantFiles"); // Assuming this is set by another node
            if (files != null && !files.isEmpty()) {
                GitTool.CodeOwnersResponse response = gitTool.getCodeOwners(new GitTool.CodeOwnersRequest(files));
                state.set("codeOwners", response.owners());
            } else {
                state.set(NAME + "_info", "No relevant files found to determine code owners.");
            }
        } catch (Exception e) {
            state.set(NAME + "_error", "Failed to get code owners: " + e.getMessage());
        }
        return state;
    }
}
