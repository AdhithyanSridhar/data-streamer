<template>
  <div class="glass-card pa-5">
    <div class="section-header">
      <div class="section-header__icon">
        <v-icon icon="mdi-wrench-outline" size="20"></v-icon>
      </div>
      <h2 class="section-header__title">Issue Context</h2>
    </div>
    
    <v-row>
      <v-col cols="12" sm="6">
        <div class="context-item">
          <span class="context-label">
            <v-icon icon="mdi-identifier" size="16" class="mr-1"></v-icon>
            Trace ID
          </span>
          <div class="context-value code-value">
            {{ issueData.traceId }}
            <v-btn icon variant="text" size="x-small" @click="copyToClipboard(issueData.traceId)">
              <v-icon icon="mdi-content-copy" size="14"></v-icon>
            </v-btn>
          </div>
        </div>
      </v-col>
      
      <v-col cols="12" sm="6">
        <div class="context-item">
          <span class="context-label">
            <v-icon icon="mdi-server-outline" size="16" class="mr-1"></v-icon>
            Service
          </span>
          <div class="context-value">
            <v-chip variant="outlined" size="small">{{ issueData.serviceName }}</v-chip>
          </div>
        </div>
      </v-col>
      
      <v-col cols="12" sm="6">
        <div class="context-item">
          <span class="context-label">
            <v-icon icon="mdi-cloud-outline" size="16" class="mr-1"></v-icon>
            Cluster
          </span>
          <div class="context-value">
            <v-chip variant="outlined" size="small">{{ issueData.cluster }}</v-chip>
          </div>
        </div>
      </v-col>
      
      <v-col cols="12" sm="6">
        <div class="context-item">
          <span class="context-label">
            <v-icon icon="mdi-clock-outline" size="16" class="mr-1"></v-icon>
            Timestamp
          </span>
          <div class="context-value">{{ formatTimestamp(issueData.timestamp) }}</div>
        </div>
      </v-col>
      
      <v-col cols="12">
        <div class="context-item error-item">
          <span class="context-label">
            <v-icon icon="mdi-alert-circle-outline" size="16" class="mr-1"></v-icon>
            Error Summary
          </span>
          <div class="error-display">
            <code>{{ issueData.errorSummary }}</code>
          </div>
        </div>
      </v-col>
    </v-row>
  </div>
</template>

<script setup>
defineProps({
  issueData: {
    type: Object,
    required: true
  }
})

const formatTimestamp = (timestamp) => {
  return new Date(timestamp).toLocaleString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  })
}

const copyToClipboard = (text) => {
  navigator.clipboard.writeText(text)
}
</script>

<style scoped>
.context-item {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.context-label {
  display: flex;
  align-items: center;
  font-size: 0.75rem;
  color: #666666;
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.context-value {
  font-size: 0.9rem;
  color: #1a1a1a;
  font-weight: 500;
  display: flex;
  align-items: center;
  gap: 8px;
}

.code-value {
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.8rem;
  background: #f5f5f5;
  padding: 8px 12px;
  border-radius: 6px;
  word-break: break-all;
}

.error-item {
  margin-top: 8px;
}

.error-display {
  background: rgba(239, 68, 68, 0.05);
  border: 1px solid rgba(239, 68, 68, 0.2);
  border-radius: 6px;
  padding: 12px 16px;
}

.error-display code {
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.85rem;
  color: #dc2626;
  word-break: break-word;
}
</style>
