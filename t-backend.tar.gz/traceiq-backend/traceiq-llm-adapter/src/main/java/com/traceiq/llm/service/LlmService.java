package com.traceiq.llm.service;

import com.traceiq.llm.client.LlmApiClient;
import com.traceiq.llm.client.VectorSearchClient;
import com.traceiq.models.dto.graph.CodeSearchNodeOutput;
import com.traceiq.models.dto.graph.RcaNodeOutput;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Service for LLM operations including RCA analysis and code search
 */
@Service
public class LlmService {
    private static final Logger logger = LoggerFactory.getLogger(LlmService.class);

    private final LlmApiClient llmApiClient;
    private final VectorSearchClient vectorSearchClient;
    private final PromptTemplateService promptTemplateService;

    public LlmService(
            LlmApiClient llmApiClient,
            VectorSearchClient vectorSearchClient,
            PromptTemplateService promptTemplateService
    ) {
        this.llmApiClient = llmApiClient;
        this.vectorSearchClient = vectorSearchClient;
        this.promptTemplateService = promptTemplateService;
    }

    /**
     * Perform RCA analysis using LLM
     */
    public RcaNodeOutput performRcaAnalysis(
            String traceId,
            String context,
            Map<String, Object> elkData,
            Map<String, Object> dynatraceData,
            String correlationId
    ) {
        try {
            logger.info("[{}] Performing RCA analysis for trace: {}", correlationId, traceId);

            // Build comprehensive prompt from data
            String systemPrompt = promptTemplateService.getRcaSystemPrompt();
            String userPrompt = promptTemplateService.buildRcaPrompt(context, elkData, dynatraceData);

            // Generate RCA from LLM
            String rcaResponse = llmApiClient.generateCompletion(userPrompt, systemPrompt, correlationId);

            // Parse response (assuming structured JSON response from LLM)
            Map<String, Object> parsedResponse = parseRcaResponse(rcaResponse);

            return new RcaNodeOutput(
                    traceId,
                    (String) parsedResponse.get("root_cause_analysis"),
                    (List<String>) parsedResponse.getOrDefault("impacted_services", List.of()),
                    (List<String>) parsedResponse.getOrDefault("recommendations", List.of()),
                    (Double) parsedResponse.getOrDefault("confidence", 0.85),
                    true,
                    null
            );

        } catch (Exception e) {
            logger.error("[{}] Error performing RCA analysis", correlationId, e);
            return new RcaNodeOutput(traceId, null, null, null, 0.0, false, e.getMessage());
        }
    }

    /**
     * Perform code search and generate implementation plan
     */
    public CodeSearchNodeOutput performCodeSearch(
            String traceId,
            String rcaContext,
            String errorMessage,
            String stackTrace,
            String correlationId
    ) {
        try {
            logger.info("[{}] Performing code search for trace: {}", correlationId, traceId);

            // Search code using vector similarity
            String searchQuery = buildCodeSearchQuery(errorMessage, stackTrace, rcaContext);
            Map<String, Object> searchResults = vectorSearchClient.searchCode(
                    searchQuery,
                    rcaContext,
                    10,
                    correlationId
            );

            List<Map<String, Object>> codeLocations = (List<Map<String, Object>>) 
                    searchResults.getOrDefault("results", List.of());

            // Generate implementation plan
            Map<String, Object> implementationPlan = vectorSearchClient.getImplementationPlan(
                    rcaContext,
                    codeLocations,
                    correlationId
            );

            // Convert to response format
            List<CodeSearchNodeOutput.CodeLocation> locations = codeLocations.stream()
                    .map(loc -> new CodeSearchNodeOutput.CodeLocation(
                            (String) loc.get("repository"),
                            (String) loc.get("file_path"),
                            (Integer) loc.get("line_number"),
                            (String) loc.get("snippet"),
                            (String) loc.get("reason")
                    ))
                    .collect(Collectors.toList());

            String plan = (String) implementationPlan.getOrDefault("plan", "");
            String curatedPrompt = (String) implementationPlan.getOrDefault("curated_prompt", "");

            logger.info("[{}] Code search completed with {} locations found", 
                    correlationId, locations.size());

            return new CodeSearchNodeOutput(
                    traceId,
                    locations,
                    plan,
                    curatedPrompt,
                    true,
                    null
            );

        } catch (Exception e) {
            logger.error("[{}] Error performing code search", correlationId, e);
            return new CodeSearchNodeOutput(traceId, null, null, null, false, e.getMessage());
        }
    }

    private String buildCodeSearchQuery(String errorMessage, String stackTrace, String rcaContext) {
        StringBuilder query = new StringBuilder();
        if (errorMessage != null) {
            query.append("Error: ").append(errorMessage).append("\n");
        }
        if (stackTrace != null) {
            query.append("Stack Trace: ").append(stackTrace).append("\n");
        }
        if (rcaContext != null) {
            query.append("Context: ").append(rcaContext);
        }
        return query.toString();
    }

    private Map<String, Object> parseRcaResponse(String response) {
        // Parse LLM response (assuming JSON format)
        // In production, implement robust parsing
        try {
            return com.traceiq.utils.JsonUtil.fromJson(response, Map.class);
        } catch (Exception e) {
            // Fallback for plain text response
            return Map.of(
                    "root_cause_analysis", response,
                    "impacted_services", List.of(),
                    "recommendations", List.of(),
                    "confidence", 0.75
            );
        }
    }
}
