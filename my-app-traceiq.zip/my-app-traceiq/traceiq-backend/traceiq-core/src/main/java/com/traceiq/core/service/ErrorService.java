package com.traceiq.core.service;

import com.traceiq.adapters.cassandra.CassandraRepository;
import com.traceiq.models.domain.ErrorLog;
import com.traceiq.models.dto.ErrorListResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ErrorService {
    
    private static final Logger logger = LoggerFactory.getLogger(ErrorService.class);
    private final CassandraRepository cassandraRepository;
    
    public ErrorService(CassandraRepository cassandraRepository) {
        this.cassandraRepository = cassandraRepository;
    }
    
    public ErrorListResponse listErrors(int page, int size) {
        logger.info("Listing errors - page: {}, size: {}", page, size);
        
        List<ErrorLog> errors = cassandraRepository.findAll(page, size);
        
        List<ErrorListResponse.ErrorSummary> summaries = errors.stream()
            .map(e -> new ErrorListResponse.ErrorSummary(
                e.traceId(),
                e.message(),
                e.serviceName(),
                e.microserviceTeam(),
                e.level(),
                e.timestamp().toString(),
                1
            ))
            .collect(Collectors.toList());
        
        return ErrorListResponse.builder()
            .errors(summaries)
            .totalCount(summaries.size())
            .pageNumber(page)
            .pageSize(size)
            .status("success")
            .build();
    }
}
