package com.traceiq.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.List;

/**
 * Root Cause Analysis results from AI processing.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record RootCauseAnalysis(
    String summary,
    String rootCause,
    String category,
    String severity,
    List<String> contributingFactors,
    String detailedExplanation,
    double confidenceScore
) {}
