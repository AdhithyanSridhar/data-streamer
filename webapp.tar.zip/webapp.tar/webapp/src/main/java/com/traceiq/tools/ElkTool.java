package com.traceiq.tools;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.traceiq.client.ElkClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.function.Function;

/**
 * Spring AI Function Tool for ELK/Elasticsearch operations
 * Provides comprehensive log analysis capabilities
 */
@Component("elkTool")
public class ElkTool implements Function<ElkTool.ElkRequest, ElkTool.ElkResponse> {
    public static final Logger log = LoggerFactory.getLogger(ElkTool.class);

    private final ElkClient elkClient;

    public ElkTool(ElkClient elkClient) {
        this.elkClient = elkClient;
    }

    @Override
    public ElkResponse apply(ElkRequest request) {
        log.info("Executing ELK tool with operation: {}", request.operation);

        try {
            return switch (request.operation.toUpperCase()) {
                case "GET_LOGS_BY_TRACE" -> getLogsByTraceId(request);
                case "SEARCH_ERRORS" -> searchErrorsByMicroservice(request);
                case "LATENCY_ANALYSIS" -> performLatencyAnalysis(request);
                case "GET_FLOW_DIAGRAM" -> captureHighLevelFlow(request);
                case "COUNT_LOGS_BY_LEVEL" -> countLogsByLevel(request);
                case "SEARCH_LOG_PATTERN" -> searchLogPattern(request);
                case "CHECK_ALERTS" -> checkAlerts(request);
                default -> ElkResponse.builder()
                        .success(false)
                        .message("Unknown operation: " + request.operation)
                        .build();
            };
        } catch (Exception e) {
            log.error("Error executing ELK tool operation: {}", request.operation, e);
            return ElkResponse.builder()
                    .success(false)
                    .message("Error: " + e.getMessage())
                    .build();
        }
    }

    private ElkResponse getLogsByTraceId(ElkRequest request) {
        Map<String, Object> logs = elkClient.getLogsByTraceId(
                request.traceId,
                request.logLevel,
                request.microserviceName,
                request.timeRangeMinutes
        );

        return ElkResponse.builder()
                .success(true)
                .data(logs)
                .message("Retrieved logs for trace: " + request.traceId)
                .build();
    }

    private ElkResponse searchErrorsByMicroservice(ElkRequest request) {
        Map<String, Object> errors = elkClient.searchErrors(
                request.microserviceName,
                request.timeRangeMinutes
        );

        return ElkResponse.builder()
                .success(true)
                .data(errors)
                .message("Retrieved errors for microservice: " + request.microserviceName)
                .build();
    }

    private ElkResponse performLatencyAnalysis(ElkRequest request) {
        Map<String, Object> analysis = elkClient.performLatencyAnalysis(
                request.traceId,
                request.microserviceName
        );

        return ElkResponse.builder()
                .success(true)
                .data(analysis)
                .message("Latency analysis completed")
                .build();
    }

    private ElkResponse captureHighLevelFlow(ElkRequest request) {
        List<String> flow = elkClient.captureServiceFlow(
                request.traceId,
                request.microserviceName
        );

        return ElkResponse.builder()
                .success(true)
                .data(Map.of("flow", flow))
                .message("Captured service flow")
                .build();
    }

    private ElkResponse countLogsByLevel(ElkRequest request) {
        Map<String, Long> counts = elkClient.countLogsByLevel(
                request.traceId,
                request.microserviceName
        );

        return ElkResponse.builder()
                .success(true)
                .data(Map.of("counts", counts))
                .message("Log counts retrieved")
                .build();
    }

    private ElkResponse searchLogPattern(ElkRequest request) {
        List<Map<String, Object>> results = elkClient.searchLogPattern(
                request.logPattern,
                request.microserviceName,
                request.timeRangeMinutes
        );

        return ElkResponse.builder()
                .success(true)
                .data(Map.of("results", results, "count", results.size()))
                .message("Found " + results.size() + " matching logs")
                .build();
    }

    private ElkResponse checkAlerts(ElkRequest request) {
        List<Map<String, Object>> alerts = elkClient.checkAlerts(
                request.microserviceName,
                request.timeRangeMinutes
        );

        return ElkResponse.builder()
                .success(true)
                .data(Map.of("alerts", alerts, "hasAlerts", !alerts.isEmpty()))
                .message("Found " + alerts.size() + " alerts")
                .build();
    }

    /**
     * Request object for ELK operations
     */
    public record ElkRequest(
            @JsonProperty(required = true)
            @JsonPropertyDescription("Operation to perform: GET_LOGS_BY_TRACE, SEARCH_ERRORS, LATENCY_ANALYSIS, GET_FLOW_DIAGRAM, COUNT_LOGS_BY_LEVEL, SEARCH_LOG_PATTERN, CHECK_ALERTS")
            String operation,

            @JsonPropertyDescription("Trace ID for log retrieval")
            String traceId,

            @JsonPropertyDescription("Microservice name")
            String microserviceName,

            @JsonPropertyDescription("Log level filter: INFO, WARN, ERROR")
            String logLevel,

            @JsonPropertyDescription("Time range in minutes (default 60)")
            Integer timeRangeMinutes,

            @JsonPropertyDescription("Log pattern to search for")
            String logPattern
    ) {
    }

    /**
     * Response object for ELK operations
     */
    public record ElkResponse(
            boolean success,
            String message,
            Map<String, Object> data
    ) {
        public static ElkResponseBuilder builder() {
            return new ElkResponseBuilder();
        }

        public static class ElkResponseBuilder {
            private boolean success;
            private String message;
            private Map<String, Object> data;

            public ElkResponseBuilder success(boolean success) {
                this.success = success;
                return this;
            }

            public ElkResponseBuilder message(String message) {
                this.message = message;
                return this;
            }

            public ElkResponseBuilder data(Map<String, Object> data) {
                this.data = data;
                return this;
            }

            public ElkResponse build() {
                return new ElkResponse(success, message, data);
            }
        }
    }
}
