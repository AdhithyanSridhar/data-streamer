package com.traceiq.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.time.Instant;

/**
 * Represents a single log entry from ELK.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record LogEntry(
    Instant timestamp,
    String level,
    String message,
    String serviceName,
    String traceId,
    String spanId,
    String logger,
    String threadName,
    String exceptionStackTrace
) {}
