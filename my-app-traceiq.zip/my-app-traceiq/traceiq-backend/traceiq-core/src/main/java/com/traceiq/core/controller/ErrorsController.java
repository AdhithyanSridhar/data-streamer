package com.traceiq.core.controller;

import com.traceiq.core.service.ErrorService;
import com.traceiq.models.dto.ErrorListResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/errors")
@Tag(name = "Errors API", description = "Error listing and filtering")
public class ErrorsController {
    
    private static final Logger logger = LoggerFactory.getLogger(ErrorsController.class);
    private final ErrorService errorService;
    
    public ErrorsController(ErrorService errorService) {
        this.errorService = errorService;
    }
    
    @GetMapping
    @Operation(summary = "List all errors", description = "Get paginated list of errors from Cassandra")
    public ResponseEntity<ErrorListResponse> listErrors(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        logger.info("Listing errors - page: {}, size: {}", page, size);
        ErrorListResponse response = errorService.listErrors(page, size);
        return ResponseEntity.ok(response);
    }
}
