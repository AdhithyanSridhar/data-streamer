<template>
  <div class="min-h-screen bg-gray-50">
    <nav class="bg-blue-600 text-white shadow-lg">
      <div class="container mx-auto px-4">
        <div class="flex items-center justify-between h-16">
          <div class="flex items-center space-x-3">
            <i class="fas fa-brain text-2xl"></i>
            <h1 class="text-xl font-bold">TraceIQ</h1>
          </div>
          <div class="flex space-x-6">
            <router-link to="/" class="hover:text-blue-200">
              <i class="fas fa-search mr-2"></i>Trace Search
            </router-link>
            <router-link to="/errors" class="hover:text-blue-200">
              <i class="fas fa-exclamation-circle mr-2"></i>Errors
            </router-link>
            <router-link to="/jobs" class="hover:text-blue-200">
              <i class="fas fa-tasks mr-2"></i>Jobs
            </router-link>
            <router-link to="/help" class="hover:text-blue-200">
              <i class="fas fa-question-circle mr-2"></i>Help
            </router-link>
          </div>
        </div>
      </div>
    </nav>
    
    <main class="container mx-auto px-4 py-8">
      <router-view></router-view>
    </main>
  </div>
</template>

<script setup>
</script>

<style>
a.router-link-active {
  @apply text-blue-200;
}
</style>
