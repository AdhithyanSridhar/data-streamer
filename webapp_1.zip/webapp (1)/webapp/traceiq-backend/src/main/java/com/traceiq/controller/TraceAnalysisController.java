package com.traceiq.controller;

import com.traceiq.model.TraceAnalysisRequest;
import com.traceiq.model.TraceAnalysisResponse;
import com.traceiq.service.TraceAnalysisOrchestrator;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * REST API controller for TraceIQ analysis operations.
 */
@RestController
@RequestMapping("/api/v1/trace")
@CrossOrigin(origins = "*")
public class TraceAnalysisController {
    
    private static final Logger logger = LoggerFactory.getLogger(TraceAnalysisController.class);
    
    private final TraceAnalysisOrchestrator orchestrator;
    
    public TraceAnalysisController(TraceAnalysisOrchestrator orchestrator) {
        this.orchestrator = orchestrator;
    }
    
    /**
     * Analyze a trace and provide RCA with optional extended analysis.
     * 
     * POST /api/v1/trace/analyze
     * 
     * Request body:
     * {
     *   "traceId": "abc-123-def",
     *   "microserviceName": "order-service",
     *   "environment": "prod",
     *   "includeJiraAnalysis": false,
     *   "includeGitHubAnalysis": false,
     *   "includePerformanceAnalysis": true,
     *   "includeCodeAnalysis": true,
     *   "autoCreateJiraTicket": false
     * }
     */
    @PostMapping("/analyze")
    public ResponseEntity<TraceAnalysisResponse> analyzeTrace(
        @Valid @RequestBody TraceAnalysisRequest request
    ) {
        logger.info("Received trace analysis request for traceId: {}", request.traceId());
        
        try {
            TraceAnalysisResponse response = orchestrator.analyzeTrace(request);
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            logger.error("Error processing trace analysis request", e);
            return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(null);
        }
    }
    
    /**
     * Health check endpoint.
     */
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("TraceIQ API is running");
    }
}
