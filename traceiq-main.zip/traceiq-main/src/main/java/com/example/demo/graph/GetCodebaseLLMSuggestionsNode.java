package com.example.demo.graph;

import com.example.demo.tools.CodebaseLLMTool;
import org.springframework.stereotype.Component;

@Component
public class GetCodebaseLLMSuggestionsNode implements Node {

    public static final String NAME = "getCodebaseLLMSuggestions";
    private final CodebaseLLMTool codebaseLLMTool;

    public GetCodebaseLLMSuggestionsNode(CodebaseLLMTool codebaseLLMTool) {
        this.codebaseLLMTool = codebaseLLMTool;
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public GraphState apply(GraphState state) {
        try {
            String error = state.get("error"); // Assumes an error has been identified
            if (error != null) {
                CodebaseLLMTool.CodebaseLLMRequest request = new CodebaseLLMTool.CodebaseLLMRequest(error);
                CodebaseLLMTool.CodebaseLLMResponse response = codebaseLLMTool.getSuggestions(request);
                state.set("codebaseSuggestions", response.suggestions());
            } else {
                state.set(NAME + "_info", "No error found to get codebase LLM suggestions.");
            }
        } catch (Exception e) {
            state.set(NAME + "_error", "Failed to get codebase LLM suggestions: " + e.getMessage());
        }
        return state;
    }
}
