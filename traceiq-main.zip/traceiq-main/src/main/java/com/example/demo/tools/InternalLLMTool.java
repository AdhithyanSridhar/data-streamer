package com.example.demo.tools;

import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;

@Component
public class InternalLLMTool {

    public static class InternalLLMRequest {
        private final String traceId;
        private final String stateJson;

        public InternalLLMRequest(String traceId, String stateJson) {
            this.traceId = traceId;
            this.stateJson = stateJson;
        }

        public String getTraceId() {
            return traceId;
        }

        public String getStateJson() {
            return stateJson;
        }
    }

    public static class InternalLLMResponse {
        private final List<String> suggestions;

        public InternalLLMResponse(List<String> suggestions) {
            this.suggestions = suggestions;
        }

        public List<String> suggestions() {
            return suggestions;
        }
    }

    public InternalLLMResponse getSuggestions(InternalLLMRequest request) {
        // Mock implementation
        return new InternalLLMResponse(Collections.singletonList("Mock suggestion"));
    }
}
