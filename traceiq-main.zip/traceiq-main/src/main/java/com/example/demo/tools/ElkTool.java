package com.example.demo.tools;

import dev.langchain4j.agent.tool.Tool;
import org.springframework.stereotype.Component;

@Component
public class ElkTool {

  @Tool("Get logs (error, warn, info) for a given traceId from ELK")
  public GetLogsResponse getLogsForTrace(GetLogsRequest getLogsRequest) {
    System.out.println("Fetching logs for traceId: " + getLogsRequest.traceId);
    return new GetLogsResponse(
        "Simulated ELK response for "
            + getLogsRequest.traceId
            + ": Found 10 log entries, 2 errors.");
  }

  @Tool("Search for errors for a microservice and list all, grouped by error message")
  public SearchErrorsResponse searchErrors(SearchErrorsRequest searchErrorsRequest) {
    System.out.println("Searching errors for microservice: " + searchErrorsRequest.microservice);
    return new SearchErrorsResponse(
        "Simulated ELK error report for "
            + searchErrorsRequest.microservice
            + ": Group 1: NullPointerException - 5 occurrences. Group 2: TimeoutException - 3 occurrences.");
  }

  @Tool("Perform latency analysis on the provided logs from ELK")
  public LatencyAnalysisResponse analyzeLatency(LatencyAnalysisRequest latencyAnalysisRequest) {
    System.out.println("Analyzing latency for traceId: " + latencyAnalysisRequest.traceId);
    return new LatencyAnalysisResponse(
        "Simulated latency analysis for "
            + latencyAnalysisRequest.traceId
            + ": Service A -> Service B (50ms), Service B -> Service C (120ms). Total time: 170ms.");
  }

  @Tool("Capture high-level microservice flow from and to a microservice using logs")
  public CaptureFlowResponse captureMicroserviceFlow(CaptureFlowRequest captureFlowRequest) {
    System.out.println(
        "Capturing flow for microservice: " + captureFlowRequest.microservice);
    return new CaptureFlowResponse(
        "Simulated flow for "
            + captureFlowRequest.microservice
            + ": Received request from API Gateway -> Called User Service -> Called Order Service.");
  }

    @Tool("Get relevant errors for a given error")
    public RelevantErrorsResponse getRelevantErrors(RelevantErrorsRequest relevantErrorsRequest) {
        System.out.println("Getting relevant errors for: " + relevantErrorsRequest.error);
        return new RelevantErrorsResponse("Simulated relevant errors for " + relevantErrorsRequest.error + ": Found 3 similar errors.");
    }

    @Tool("Search for logs")
    public LogSearchResponse searchLogs(LogSearchRequest logSearchRequest) {
        System.out.println("Searching logs for: " + logSearchRequest.query);
        return new LogSearchResponse("Simulated logs for " + logSearchRequest.query + ": ...");
    }

    @Tool("Search for errors")
    public ErrorSearchResponse searchErrors(ErrorSearchRequest errorSearchRequest) {
        System.out.println("Searching errors for: " + errorSearchRequest.query);
        return new ErrorSearchResponse("Simulated errors for " + errorSearchRequest.query + ": ...");
    }

  public record GetLogsRequest(String traceId) {}

  public record GetLogsResponse(String logs) {}

  public record SearchErrorsRequest(String microservice) {}

  public record SearchErrorsResponse(String errorReport) {}

  public record LatencyAnalysisRequest(String traceId) {}

  public record LatencyAnalysisResponse(String analysis) {}

  public record CaptureFlowRequest(String microservice) {}

  public record CaptureFlowResponse(String flow) {}

    public record RelevantErrorsRequest(String error) {}

    public record RelevantErrorsResponse(String errors) {}

    public record LogSearchRequest(String query) {}

    public record LogSearchResponse(String logs) {}

    public record ErrorSearchRequest(String query) {}

    public record ErrorSearchResponse(String errors) {}
}
