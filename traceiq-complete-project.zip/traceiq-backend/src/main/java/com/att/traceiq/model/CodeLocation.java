package com.att.traceiq.model;

public record CodeLocation(
    String repositoryName,
    String filePath,
    int lineNumber,
    String className,
    String methodName,
    String codeSnippet,
    double relevanceScore
) {
    public String getGitHubUrl(String baseUrl, String org) {
        return String.format("%s/%s/%s/blob/main/%s#L%d", 
            baseUrl, org, repositoryName, filePath, lineNumber);
    }
}
