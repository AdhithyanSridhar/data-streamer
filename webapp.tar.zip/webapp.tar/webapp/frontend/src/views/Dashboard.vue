<template>
  <div>
    <!-- Header -->
    <div class="mb-8">
      <h1 class="text-3xl font-bold text-gray-900 mb-2">
        <i class="fas fa-chart-bar text-blue-600 mr-3"></i>
        TraceIQ Dashboard
      </h1>
      <p class="text-gray-600">AI-powered observability and root cause analysis platform</p>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
      <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm text-gray-600 mb-1">Weekly Defects</p>
            <p class="text-2xl font-bold text-gray-900">300</p>
          </div>
          <div class="bg-red-100 rounded-full p-3">
            <i class="fas fa-bug text-red-600 text-xl"></i>
          </div>
        </div>
      </div>

      <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm text-gray-600 mb-1">Config Issues</p>
            <p class="text-2xl font-bold text-gray-900">40%</p>
          </div>
          <div class="bg-yellow-100 rounded-full p-3">
            <i class="fas fa-cog text-yellow-600 text-xl"></i>
          </div>
        </div>
      </div>

      <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm text-gray-600 mb-1">Prod Tickets</p>
            <p class="text-2xl font-bold text-gray-900">50+</p>
          </div>
          <div class="bg-orange-100 rounded-full p-3">
            <i class="fas fa-exclamation-triangle text-orange-600 text-xl"></i>
          </div>
        </div>
      </div>

      <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm text-gray-600 mb-1">Time Saved</p>
            <p class="text-2xl font-bold text-green-600">3.5 hrs/day</p>
          </div>
          <div class="bg-green-100 rounded-full p-3">
            <i class="fas fa-clock text-green-600 text-xl"></i>
          </div>
        </div>
      </div>
    </div>

    <!-- Quick Actions -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
      <!-- Trace Analysis Card -->
      <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-semibold text-gray-900 mb-4">
          <i class="fas fa-search text-blue-600 mr-2"></i>
          Quick Trace Analysis
        </h2>
        <p class="text-gray-600 mb-4">Analyze a trace ID to identify errors, root causes, and get AI-powered insights.</p>
        <router-link to="/analysis" class="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition">
          Start Analysis <i class="fas fa-arrow-right ml-2"></i>
        </router-link>
      </div>

      <!-- System Overview Card -->
      <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-semibold text-gray-900 mb-4">
          <i class="fas fa-sitemap text-green-600 mr-2"></i>
          System Overview
        </h2>
        <div class="space-y-3">
          <div class="flex justify-between items-center">
            <span class="text-gray-600">Active Microservices</span>
            <span class="font-semibold">10 teams</span>
          </div>
          <div class="flex justify-between items-center">
            <span class="text-gray-600">Developers</span>
            <span class="font-semibold">400</span>
          </div>
          <div class="flex justify-between items-center">
            <span class="text-gray-600">QA Team</span>
            <span class="font-semibold">400</span>
          </div>
          <div class="flex justify-between items-center">
            <span class="text-gray-600">Environments</span>
            <span class="font-semibold">Test, Prod</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Features Grid -->
    <div class="bg-white rounded-lg shadow p-6">
      <h2 class="text-xl font-semibold text-gray-900 mb-6">
        <i class="fas fa-magic text-purple-600 mr-2"></i>
        TraceIQ Capabilities
      </h2>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="border rounded-lg p-4">
          <i class="fas fa-brain text-blue-600 text-2xl mb-3"></i>
          <h3 class="font-semibold text-gray-900 mb-2">AI-Powered RCA</h3>
          <p class="text-sm text-gray-600">Automatic root cause analysis using internal GPT-4 LLM trained on your systems</p>
        </div>

        <div class="border rounded-lg p-4">
          <i class="fas fa-code text-green-600 text-2xl mb-3"></i>
          <h3 class="font-semibold text-gray-900 mb-2">Code Location</h3>
          <p class="text-sm text-gray-600">Vectorized codebase search to pinpoint exact problematic code location</p>
        </div>

        <div class="border rounded-lg p-4">
          <i class="fas fa-tasks text-orange-600 text-2xl mb-3"></i>
          <h3 class="font-semibold text-gray-900 mb-2">Auto Jira Tickets</h3>
          <p class="text-sm text-gray-600">Automatically create detailed Jira tickets with RCA and fix suggestions</p>
        </div>

        <div class="border rounded-lg p-4">
          <i class="fas fa-chart-line text-red-600 text-2xl mb-3"></i>
          <h3 class="font-semibold text-gray-900 mb-2">Performance Analysis</h3>
          <p class="text-sm text-gray-600">Latency analysis from ELK logs and Dynatrace metrics integration</p>
        </div>

        <div class="border rounded-lg p-4">
          <i class="fas fa-project-diagram text-purple-600 text-2xl mb-3"></i>
          <h3 class="font-semibold text-gray-900 mb-2">Service Flow</h3>
          <p class="text-sm text-gray-600">Visualize distributed trace flow across microservices</p>
        </div>

        <div class="border rounded-lg p-4">
          <i class="fas fa-shield-alt text-indigo-600 text-2xl mb-3"></i>
          <h3 class="font-semibold text-gray-900 mb-2">Production Ready</h3>
          <p class="text-sm text-gray-600">Fix suggestions with implementation plans for GitHub Copilot</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
// Dashboard logic
</script>
