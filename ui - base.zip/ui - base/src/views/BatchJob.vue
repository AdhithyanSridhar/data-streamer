<template>
  <v-container fluid class="pa-6">
    <div class="page-header mb-6">
      <h1 class="page-title">Batch Jobs</h1>
      <p class="page-subtitle">Manage scheduled batch jobs across your applications</p>
    </div>

    <!-- Stats -->
    <v-row class="mb-6">
      <v-col cols="12" sm="6" md="3" v-for="stat in stats" :key="stat.title">
        <div class="glass-card pa-4 stat-card">
          <div class="stat-icon">
            <v-icon :icon="stat.icon" size="24"></v-icon>
          </div>
          <div class="stat-content">
            <span class="stat-value">{{ stat.value }}</span>
            <span class="stat-label">{{ stat.title }}</span>
          </div>
        </div>
      </v-col>
    </v-row>

    <!-- Jobs Table -->
    <div class="glass-card pa-5">
      <div class="section-header mb-4">
        <div class="section-header__icon">
          <v-icon icon="mdi-calendar-clock-outline" size="20"></v-icon>
        </div>
        <span class="section-header__title">Scheduled Jobs</span>
        <v-spacer></v-spacer>
        <v-btn variant="outlined" size="small" rounded="lg">
          <v-icon icon="mdi-plus" class="mr-1"></v-icon>Add Job
        </v-btn>
      </div>

      <v-data-table :headers="headers" :items="jobs" class="jobs-table" density="comfortable">
        <template v-slot:item.teamName="{ item }">
          <v-chip variant="outlined" size="small">{{ item.teamName }}</v-chip>
        </template>
        <template v-slot:item.appName="{ item }">
          <v-chip variant="outlined" size="small">{{ item.appName }}</v-chip>
        </template>
        <template v-slot:item.schedule="{ item }">
          <code class="schedule-code">{{ item.schedule }}</code>
        </template>
        <template v-slot:item.isActive="{ item }">
          <v-switch v-model="item.isActive" color="success" hide-details density="compact" @update:model-value="toggleJob(item)"></v-switch>
        </template>
        <template v-slot:item.actions="{ item }">
          <v-btn icon variant="text" size="small"><v-icon icon="mdi-pencil-outline" size="18"></v-icon></v-btn>
          <v-btn icon variant="text" size="small"><v-icon icon="mdi-play-outline" size="18"></v-icon></v-btn>
          <v-btn icon variant="text" size="small"><v-icon icon="mdi-delete-outline" size="18"></v-icon></v-btn>
        </template>
      </v-data-table>
    </div>
  </v-container>
</template>

<script setup>
import { ref } from 'vue'

const stats = [
  { title: 'Total Jobs', value: '24', icon: 'mdi-calendar-clock-outline' },
  { title: 'Active', value: '18', icon: 'mdi-check-circle-outline' },
  { title: 'Paused', value: '6', icon: 'mdi-pause-circle-outline' },
  { title: 'Failed Today', value: '2', icon: 'mdi-alert-circle-outline' }
]

const headers = [
  { title: 'Team', key: 'teamName' },
  { title: 'Application', key: 'appName' },
  { title: 'Job Name', key: 'jobName' },
  { title: 'Schedule', key: 'schedule' },
  { title: 'Description', key: 'description' },
  { title: 'Active', key: 'isActive', align: 'center' },
  { title: 'Actions', key: 'actions', align: 'center', sortable: false }
]

const jobs = ref([
  { id: 1, teamName: 'Payments', appName: 'payment-service', jobName: 'ProcessPendingPayments', schedule: '0 */15 * * * *', description: 'Process pending payment transactions', isActive: true },
  { id: 2, teamName: 'Payments', appName: 'billing-service', jobName: 'GenerateInvoices', schedule: '0 0 1 * * *', description: 'Generate monthly invoices', isActive: true },
  { id: 3, teamName: 'Orders', appName: 'order-service', jobName: 'CleanupExpiredOrders', schedule: '0 0 0 * * *', description: 'Clean up expired orders daily', isActive: true },
  { id: 4, teamName: 'Platform', appName: 'sync-service', jobName: 'SyncExternalData', schedule: '0 0 */6 * * *', description: 'Sync data from external sources', isActive: false },
  { id: 5, teamName: 'Auth', appName: 'auth-service', jobName: 'RefreshTokens', schedule: '0 */30 * * * *', description: 'Refresh authentication tokens', isActive: true }
])

const toggleJob = (job) => console.log('Toggled job:', job.jobName, job.isActive)
</script>

<style scoped>
.page-header { text-align: center; padding: 20px 0; }
.page-title { font-size: 1.75rem; font-weight: 700; color: #1a1a1a; margin-bottom: 8px; }
.page-subtitle { font-size: 0.95rem; color: #666666; }
.stat-card { display: flex; flex-direction: column; gap: 12px; }
.stat-icon { width: 44px; height: 44px; border-radius: 10px; display: flex; align-items: center; justify-content: center; background: #f5f5f5; color: #1a1a1a; }
.stat-content { display: flex; flex-direction: column; gap: 4px; }
.stat-value { font-size: 1.5rem; font-weight: 700; color: #1a1a1a; }
.stat-label { font-size: 0.8rem; color: #666666; }
.jobs-table { background: transparent !important; }
.schedule-code { font-size: 0.75rem; background: #f5f5f5; padding: 4px 8px; border-radius: 4px; color: #1a1a1a; font-family: monospace; }
</style>
