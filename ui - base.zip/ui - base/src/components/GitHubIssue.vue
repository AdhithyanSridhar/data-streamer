<template>
  <div class="glass-card pa-5">
    <div class="section-header">
      <div class="section-header__icon">
        <v-icon icon="mdi-github" size="20"></v-icon>
      </div>
      <h2 class="section-header__title">GitHub Issue</h2>
    </div>
    
    <div class="issue-card">
      <div class="issue-header">
        <div class="issue-number">#{{ issue.issueNumber }}</div>
        <v-chip variant="outlined" size="small">{{ issue.status }}</v-chip>
      </div>
      
      <h3 class="issue-title">{{ issue.title }}</h3>
      
      <div class="issue-meta">
        <div class="meta-item">
          <v-icon icon="mdi-source-repository" size="16"></v-icon>
          <span>{{ issue.repoName }}</span>
        </div>
        <div class="meta-item">
          <v-icon icon="mdi-robot-outline" size="16"></v-icon>
          <span>Created by {{ issue.agentName }}</span>
        </div>
      </div>
      
      <div class="issue-labels">
        <v-chip v-for="label in issue.labels" :key="label" variant="outlined" size="x-small" class="mr-1">{{ label }}</v-chip>
      </div>
      
      <div class="issue-actions">
        <v-btn variant="outlined" size="small" :href="issue.url" target="_blank" rounded="lg">
          <v-icon icon="mdi-open-in-new" class="mr-1" size="16"></v-icon>
          View on GitHub
        </v-btn>
      </div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  issue: {
    type: Object,
    required: true
  }
})
</script>

<style scoped>
.issue-card {
  background: #f5f5f5;
  border-radius: 10px;
  padding: 20px;
}

.issue-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
}

.issue-number {
  font-size: 1.2rem;
  font-weight: 700;
  color: #1a1a1a;
}

.issue-title {
  font-size: 1rem;
  font-weight: 600;
  color: #1a1a1a;
  margin-bottom: 16px;
  line-height: 1.4;
}

.issue-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  margin-bottom: 12px;
}

.meta-item {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 0.8rem;
  color: #666666;
}

.issue-labels {
  margin-bottom: 16px;
}

.issue-actions {
  display: flex;
  gap: 8px;
}
</style>
