package com.traceiq.core.orchestration;

import com.traceiq.llm.service.LlmService;
import com.traceiq.models.dto.graph.*;
import com.traceiq.tools.adapter.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * LangGraph4j orchestration builder for RCA flow
 * Defines nodes and edges for the RCA analysis workflow
 * 
 * Flow: TraceID → ELK Node → Dynatrace Node → RCA LLM Node → Code Search Node → Jira Node → Notify Node
 */
@Component
public class RcaGraphBuilder {
    private static final Logger logger = LoggerFactory.getLogger(RcaGraphBuilder.class);

    private final ElkAdapter elkAdapter;
    private final DynatraceAdapter dynatraceAdapter;
    private final LlmService llmService;
    private final JiraAdapter jiraAdapter;

    public RcaGraphBuilder(
            ElkAdapter elkAdapter,
            DynatraceAdapter dynatraceAdapter,
            LlmService llmService,
            JiraAdapter jiraAdapter
    ) {
        this.elkAdapter = elkAdapter;
        this.dynatraceAdapter = dynatraceAdapter;
        this.llmService = llmService;
        this.jiraAdapter = jiraAdapter;
    }

    /**
     * Execute full RCA workflow
     * This demonstrates LangGraph4j pattern with explicit node execution
     */
    public Map<String, Object> executeRcaFlow(String traceId, String correlationId, boolean includeCodeSearch) {
        logger.info("[{}] Starting RCA flow for trace: {}", correlationId, traceId);

        Map<String, Object> context = new HashMap<>();
        context.put("traceId", traceId);
        context.put("correlationId", correlationId);

        try {
            // Node 1: ELK - Fetch logs
            ElkNodeOutput elkOutput = executeElkNode(traceId, correlationId);
            context.put("elkData", elkOutput);

            if (!elkOutput.success()) {
                logger.error("[{}] ELK node failed: {}", correlationId, elkOutput.errorMessage());
                return createErrorResponse(elkOutput.errorMessage());
            }

            // Node 2: Dynatrace - Fetch telemetry
            Map<String, Object> dynatraceData = executeDynatraceNode(traceId, correlationId);
            context.put("dynatraceData", dynatraceData);

            // Node 3: RCA LLM - Perform root cause analysis
            RcaNodeOutput rcaOutput = executeRcaNode(
                    traceId,
                    buildContext(elkOutput, dynatraceData),
                    elkOutput.summary(),
                    dynatraceData,
                    correlationId
            );
            context.put("rcaResult", rcaOutput);

            if (!rcaOutput.success()) {
                logger.error("[{}] RCA node failed: {}", correlationId, rcaOutput.errorMessage());
                return createErrorResponse(rcaOutput.errorMessage());
            }

            // Node 4: Code Search (optional)
            if (includeCodeSearch) {
                CodeSearchNodeOutput codeSearchOutput = executeCodeSearchNode(
                        traceId,
                        rcaOutput.rootCauseAnalysis(),
                        getFirstErrorMessage(elkOutput),
                        getFirstStackTrace(elkOutput),
                        correlationId
                );
                context.put("codeSearchResult", codeSearchOutput);
            }

            // Node 5: Jira - Create ticket (optional)
            // Can be triggered based on severity or user action

            logger.info("[{}] RCA flow completed successfully", correlationId);
            return context;

        } catch (Exception e) {
            logger.error("[{}] RCA flow failed with exception", correlationId, e);
            return createErrorResponse(e.getMessage());
        }
    }

    /**
     * ELK Node - Fetch logs by traceID
     */
    private ElkNodeOutput executeElkNode(String traceId, String correlationId) {
        logger.info("[{}] Executing ELK node", correlationId);
        ElkNodeInput input = ElkNodeInput.builder()
                .traceId(traceId)
                .timeRange("now-24h")
                .correlationId(correlationId)
                .build();
        return elkAdapter.fetchLogsByTraceId(input);
    }

    /**
     * Dynatrace Node - Fetch telemetry and service flow
     */
    private Map<String, Object> executeDynatraceNode(String traceId, String correlationId) {
        logger.info("[{}] Executing Dynatrace node", correlationId);
        try {
            Map<String, Object> trace = dynatraceAdapter.fetchTrace(traceId, correlationId);
            Map<String, Object> serviceFlow = dynatraceAdapter.fetchServiceFlow(traceId, correlationId);
            
            Map<String, Object> result = new HashMap<>();
            result.put("trace", trace);
            result.put("serviceFlow", serviceFlow);
            result.put("success", true);
            return result;
        } catch (Exception e) {
            logger.warn("[{}] Dynatrace node failed, continuing without telemetry", correlationId, e);
            return Map.of("success", false, "error", e.getMessage());
        }
    }

    /**
     * RCA LLM Node - Perform root cause analysis
     */
    private RcaNodeOutput executeRcaNode(
            String traceId,
            String context,
            Map<String, Object> elkData,
            Map<String, Object> dynatraceData,
            String correlationId
    ) {
        logger.info("[{}] Executing RCA LLM node", correlationId);
        return llmService.performRcaAnalysis(traceId, context, elkData, dynatraceData, correlationId);
    }

    /**
     * Code Search Node - Find code locations and generate implementation plan
     */
    private CodeSearchNodeOutput executeCodeSearchNode(
            String traceId,
            String rcaContext,
            String errorMessage,
            String stackTrace,
            String correlationId
    ) {
        logger.info("[{}] Executing Code Search node", correlationId);
        return llmService.performCodeSearch(traceId, rcaContext, errorMessage, stackTrace, correlationId);
    }

    /**
     * Jira Node - Create Jira ticket
     */
    public void executeJiraNode(
            String summary,
            String description,
            String priority,
            String assignee,
            String correlationId
    ) {
        logger.info("[{}] Executing Jira node", correlationId);
        jiraAdapter.createTicket(summary, description, priority, assignee, correlationId);
    }

    private String buildContext(ElkNodeOutput elkOutput, Map<String, Object> dynatraceData) {
        StringBuilder sb = new StringBuilder();
        sb.append("Trace ID: ").append(elkOutput.traceId()).append("\n");
        sb.append("Total Logs: ").append(elkOutput.logs().size()).append("\n");
        sb.append("Dynatrace Available: ").append(dynatraceData.get("success")).append("\n");
        return sb.toString();
    }

    private String getFirstErrorMessage(ElkNodeOutput elkOutput) {
        return elkOutput.logs().isEmpty() ? "" : elkOutput.logs().get(0).message();
    }

    private String getFirstStackTrace(ElkNodeOutput elkOutput) {
        // Extract stack trace from logs if available
        return elkOutput.logs().stream()
                .filter(log -> log.fields().containsKey("stackTrace"))
                .findFirst()
                .map(log -> (String) log.fields().get("stackTrace"))
                .orElse("");
    }

    private Map<String, Object> createErrorResponse(String errorMessage) {
        return Map.of("success", false, "error", errorMessage);
    }
}
