package com.traceiq.core.service;

import com.traceiq.adapters.cassandra.CassandraRepository;
import com.traceiq.adapters.elk.ElkAdapter;
import com.traceiq.core.orchestration.RCAOrchestrator;
import com.traceiq.models.domain.*;
import com.traceiq.models.dto.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Service
public class TraceService {
    
    private static final Logger logger = LoggerFactory.getLogger(TraceService.class);
    
    private final CassandraRepository cassandraRepository;
    private final ElkAdapter elkAdapter;
    private final RCAOrchestrator rcaOrchestrator;
    
    public TraceService(
            CassandraRepository cassandraRepository,
            ElkAdapter elkAdapter,
            RCAOrchestrator rcaOrchestrator) {
        this.cassandraRepository = cassandraRepository;
        this.elkAdapter = elkAdapter;
        this.rcaOrchestrator = rcaOrchestrator;
    }
    
    public TraceSearchResponse searchTrace(String traceId) {
        logger.info("Searching trace: {}", traceId);
        
        List<ErrorLog> errors = cassandraRepository.findByTraceId(traceId);
        if (errors.isEmpty()) {
            errors = elkAdapter.searchByTraceId(traceId);
        }
        
        List<ServiceNode> services = buildServiceNodes(errors);
        TimelineEvent timeline = buildTimeline(traceId, errors);
        TraceSearchResponse.FlowDiagram flowDiagram = buildFlowDiagram(services);
        
        return TraceSearchResponse.builder()
            .traceId(traceId)
            .confidenceScore(0.92)
            .errorCount(errors.size())
            .errors(errors)
            .servicesInvolved(services)
            .timeline(timeline)
            .flowDiagram(flowDiagram)
            .status("success")
            .build();
    }
    
    public RCAResponse generateRCA(String traceId, RCARequest request) {
        logger.info("Generating RCA for trace: {}", traceId);
        
        RCAResult rcaResult = rcaOrchestrator.analyzeTrace(traceId);
        
        return RCAResponse.builder()
            .rcaResult(rcaResult)
            .fromCache(false)
            .status("success")
            .message("RCA generated successfully")
            .build();
    }
    
    public RCAResponse generateImplementationPlan(String traceId, RCARequest request) {
        logger.info("Generating implementation plan for trace: {}", traceId);
        
        ImplementationPlan plan = rcaOrchestrator.generateImplementationPlan(traceId);
        
        return RCAResponse.builder()
            .implementationPlan(plan)
            .fromCache(false)
            .status("success")
            .message("Implementation plan generated successfully")
            .build();
    }
    
    public RCAResponse godMode(String traceId) {
        logger.info("Running God Mode for trace: {}", traceId);
        
        RCAResult rcaResult = rcaOrchestrator.analyzeTrace(traceId);
        ImplementationPlan plan = rcaOrchestrator.generateImplementationPlan(traceId);
        
        return RCAResponse.builder()
            .rcaResult(rcaResult)
            .implementationPlan(plan)
            .fromCache(false)
            .status("success")
            .message("God Mode analysis completed successfully")
            .build();
    }
    
    private List<ServiceNode> buildServiceNodes(List<ErrorLog> errors) {
        List<ServiceNode> nodes = new ArrayList<>();
        nodes.add(ServiceNode.builder()
            .serviceName("api-gateway")
            .serviceType("gateway")
            .errorCount(0)
            .latencyMs(45.2)
            .status("healthy")
            .build());
        nodes.add(ServiceNode.builder()
            .serviceName("payment-service")
            .serviceType("microservice")
            .errorCount(errors.size())
            .latencyMs(234.5)
            .status("degraded")
            .build());
        return nodes;
    }
    
    private TimelineEvent buildTimeline(String traceId, List<ErrorLog> errors) {
        List<TimelineEvent.Event> events = new ArrayList<>();
        for (ErrorLog error : errors) {
            events.add(new TimelineEvent.Event(
                error.timestamp(),
                error.serviceName(),
                "ERROR",
                error.message(),
                error.level()
            ));
        }
        return TimelineEvent.builder()
            .traceId(traceId)
            .events(events)
            .build();
    }
    
    private TraceSearchResponse.FlowDiagram buildFlowDiagram(List<ServiceNode> services) {
        List<TraceSearchResponse.FlowDiagram.Node> nodes = new ArrayList<>();
        List<TraceSearchResponse.FlowDiagram.Edge> edges = new ArrayList<>();
        
        nodes.add(new TraceSearchResponse.FlowDiagram.Node("gw", "api-gateway", "gateway", 0));
        nodes.add(new TraceSearchResponse.FlowDiagram.Node("ps", "payment-service", "service", 2));
        
        edges.add(new TraceSearchResponse.FlowDiagram.Edge("gw", "ps", "http", "error"));
        
        return new TraceSearchResponse.FlowDiagram(nodes, edges);
    }
}
