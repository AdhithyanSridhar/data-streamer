# TraceIQ - AI-Powered Observability and RCA Platform

## 🎯 Project Overview

**TraceIQ** is an enterprise-grade AI-powered observability platform designed to dramatically improve developer and tester productivity in distributed microservices environments. It reduces defect triage time from 3-4 hours/day to minutes by leveraging AI for root cause analysis, code location identification, and automated remediation suggestions.

### Key Statistics
- **50+ weekly production tickets** across 10 teams
- **300 defects per week** requiring analysis
- **40% configuration-related issues**
- **400 developers + 400 QA team members** served
- **Target: 3-4 hours/day productivity improvement** per team member

## 🚀 Core Features

### 1. AI-Powered Root Cause Analysis
- Leverages internal GPT-4 LLM trained on your systems
- Analyzes ELK logs, error patterns, and historical data
- Provides confidence-scored RCA with contributing factors
- Generates executive summaries for stakeholders

### 2. Vectorized Code Location
- Pinpoints exact file, line number, and problematic code
- Uses internal codebase-trained LLM
- Provides code snippets and context
- Identifies related files and dependencies

### 3. Multi-Tool Orchestration (LangGraph4j)
- **ELK/Elasticsearch**: Log retrieval, error aggregation, latency analysis
- **Jira**: Ticket management, auto-creation with RCA
- **GitHub**: PR analysis, code owners, repository insights
- **Dynatrace**: Performance metrics, anomaly detection
- **Jenkins/GitHub Actions**: Build status, deployment verification
- **Kubernetes**: Pod status, restart counts, health checks

### 4. Automated Workflows
- Auto-create Jira tickets with detailed RCA
- Generate fix suggestions with implementation plans
- Recommend future guardrails and monitoring
- Assess production readiness of fixes

### 5. ELK Advanced Analysis
- Get logs by trace ID (ERROR, WARN, INFO)
- Search errors grouped by message
- Latency and performance analysis
- Service flow visualization
- Log pattern search and counting
- Alert detection and correlation

## 🏗️ Architecture

### Technology Stack
**Backend:**
- Java 17
- Spring Boot 3.2.1
- Spring AI 1.0.0-M4
- LangChain4j 0.35.0 (for orchestration)
- PostgreSQL + pgvector
- Maven

**Frontend:**
- Vue.js 3
- Vite
- Axios
- Tailwind CSS
- FontAwesome Icons

### System Design
```
┌─────────────────────────────────────────┐
│         Vue.js Frontend (Port 3000)     │
│    Trace Analysis UI + Dashboard        │
└────────────────┬────────────────────────┘
                 │ REST API
┌────────────────┴────────────────────────┐
│     Spring Boot Backend (Port 8080)     │
│  ┌──────────────────────────────────┐   │
│  │  LangGraph4j Orchestrator        │   │
│  │  (Graph-based Tool Execution)    │   │
│  └──────────────────────────────────┘   │
│                                          │
│  ┌──────────────────────────────────┐   │
│  │     Spring AI Function Tools      │   │
│  ├──────────────────────────────────┤   │
│  │ • ElkTool                         │   │
│  │ • JiraTool                        │   │
│  │ • GitHubTool                      │   │
│  │ • LlmRcaTool (Internal GPT-4)     │   │
│  │ • LlmCodebaseTool (Vector Search) │   │
│  │ • DynatraceTool                   │   │
│  │ • JenkinsTool                     │   │
│  │ • KubernetesTool                  │   │
│  └──────────────────────────────────┘   │
└──────────────────────────────────────────┘
```

### LangGraph4j Orchestration Flow
```
              [START]
                 |
            [ELK_LOGS] ──────────────┐
              /    \                  │
    [LLM_RCA]      [LATENCY]    [FLOW_DIAGRAM]
         |            \            /
  [CODE_LOCATE]   [AGGREGATION]
         |              |
   [CODE_FIX]    [GITHUB_INFO]
         \            /
      [JIRA_TICKET] (conditional)
             |
          [END]
```

## 📦 Installation & Setup

### Prerequisites
- Java 17+
- Maven 3.8+
- Node.js 18+
- PostgreSQL 15+ (or H2 for local development)
- Access to internal APIs (ELK, Jira, GitHub, etc.)

### Backend Setup

1. **Clone the repository**
```bash
git clone <repository-url>
cd traceiq-platform
```

2. **Configure environment variables**
```bash
cp .env.example .env
# Edit .env with your API tokens and configurations
```

3. **Build the project**
```bash
mvn clean install
```

4. **Run the application**
```bash
# Local development (uses H2 database)
mvn spring-boot:run -Dspring-boot.run.profiles=local

# Production (requires PostgreSQL)
mvn spring-boot:run -Dspring-boot.run.profiles=prod
```

The backend will start on `http://localhost:8080`

### Frontend Setup

1. **Navigate to frontend directory**
```bash
cd frontend
```

2. **Install dependencies**
```bash
npm install
```

3. **Run development server**
```bash
npm run dev
```

The frontend will start on `http://localhost:3000`

4. **Build for production**
```bash
npm run build
```

## 🔧 Configuration

### Application Configuration
Configuration is managed through `src/main/resources/application.yml` and environment variables.

**Key Configuration Sections:**
- **API Endpoints**: ELK, Jira, GitHub, Dynatrace, Jenkins, Kubernetes
- **LLM Configuration**: Internal GPT-4 RCA API and Codebase Search API
- **Security**: API tokens, authentication
- **Caching**: Caffeine cache for analysis results
- **CORS**: Frontend origin configuration

### API Token Requirements
You must configure API tokens for:
1. **ELK/Elasticsearch**: Username + Password or API Key
2. **Jira**: Email + API Token
3. **GitHub**: Personal Access Token (PAT)
4. **Dynatrace**: API Token
5. **Jenkins**: Username + API Token
6. **Kubernetes**: Service Account Token
7. **Internal LLM APIs**: API Keys
8. **Directory API**: API Key

## 📊 API Documentation

### REST Endpoints

#### POST `/api/v1/analysis/trace`
Performs comprehensive trace analysis.

**Request:**
```json
{
  "traceId": "1234-5678-9012-3456",
  "microserviceName": "user-service",
  "environment": "prod",
  "timeRangeMinutes": 60,
  "autoCreateJiraTicket": true,
  "priority": "HIGH",
  "errorDetails": "Optional pre-collected error"
}
```

**Response:**
```json
{
  "analysisId": "uuid",
  "traceId": "1234-5678-9012-3456",
  "status": "SUCCESS",
  "summary": "Root cause identified...",
  "rootCause": {
    "category": "Configuration Error",
    "description": "...",
    "rootCause": "...",
    "confidence": "HIGH"
  },
  "codeLocation": {
    "repositoryName": "user-service",
    "filePath": "src/main/java/...",
    "lineNumber": 123,
    "suggestedFix": "..."
  },
  "elkAnalysis": {
    "errorCount": 10,
    "warnCount": 5,
    "latencyAnalysis": {},
    "flowDiagram": []
  },
  "jiraTicket": {
    "ticketKey": "PROJ-123",
    "ticketUrl": "..."
  },
  "recommendedActions": [],
  "processingTimeMs": 2500
}
```

#### POST `/api/v1/analysis/trace/async`
Asynchronous trace analysis (returns CompletableFuture).

#### POST `/api/v1/analysis/batch`
Batch analysis for multiple traces.

#### GET `/api/v1/analysis/health`
Health check endpoint.

### Swagger/OpenAPI Documentation
Access interactive API documentation at: `http://localhost:8080/swagger-ui.html`

## 🎨 Frontend Usage

### Dashboard View
- Overview of system statistics
- Quick access to trace analysis
- System metrics and capabilities

### Trace Analysis View
- Enter trace ID or error details
- Select environment and priority
- Configure auto-Jira creation
- View comprehensive analysis results
- Access code locations and fix suggestions
- Review ELK log analysis
- See recommended actions

## 🔍 Use Cases

### 1. Defect Triage
**Problem**: Developer spends 3-4 hours triaging a production issue.
**Solution**: Enter trace ID → Get RCA, code location, and fix in 2-5 minutes.

### 2. Configuration Issues (40% of defects)
**Problem**: Misconfigured services causing failures.
**Solution**: AI detects configuration mismatches and suggests corrections.

### 3. Distributed Tracing
**Problem**: Issue spans multiple microservices, hard to pinpoint.
**Solution**: Service flow diagram + latency analysis identifies bottleneck.

### 4. Post-Deployment Validation
**Problem**: Need to verify deployment health quickly.
**Solution**: Analyze recent traces, check Jenkins build, verify K8s pod status.

### 5. Historical Analysis
**Problem**: Similar issues keep recurring.
**Solution**: LLM learns from past RCAs and suggests preventive guardrails.

## 🚀 Advanced Features

### LangGraph4j Orchestration
The platform uses LangGraph4j to build a Directed Acyclic Graph (DAG) of tool executions:
- **Nodes**: Individual tool invocations (ELK, Jira, GitHub, etc.)
- **Edges**: Dependencies between tools
- **Conditional Routing**: Tools invoked based on context
- **Parallel Execution**: Independent tools run concurrently
- **Error Handling**: Graceful degradation if tools fail

### Spring AI Function Tools
Each external API is wrapped as a Spring AI Function Tool:
- Declarative request/response records
- JSON schema for LLM understanding
- Type-safe parameter handling
- Comprehensive error handling

### Caching Strategy
- Analysis results cached for 1 hour (Caffeine)
- Reduces API calls and improves response time
- Cache key: `{traceId}-{environment}`

## 📈 Scalability

### Current Capacity
- **Single Instance**: Handles 100+ concurrent analyses
- **Stateless Design**: Easy horizontal scaling
- **Async Support**: Non-blocking for long-running analyses

### Production Recommendations
1. **Load Balancer**: Distribute across multiple instances
2. **Database**: PostgreSQL with connection pooling
3. **Caching**: Redis for distributed caching
4. **Monitoring**: Prometheus + Grafana
5. **Rate Limiting**: Protect external APIs

## 🛡️ Security Considerations

1. **API Tokens**: Store in environment variables, never commit
2. **HTTPS**: Use SSL/TLS for all external API calls
3. **Authentication**: Add JWT/OAuth for user authentication
4. **Rate Limiting**: Implement per-user rate limits
5. **Audit Logging**: Track all analysis requests

## 🧪 Testing

### Unit Tests
```bash
mvn test
```

### Integration Tests
```bash
mvn verify
```

### Groovy Spock Tests
All services include Groovy Spock test specifications (as per team standards).

## 📝 Future Enhancements

### Planned Features
1. **Real-time Monitoring Dashboard**: Live trace streaming
2. **ML-Based Anomaly Detection**: Proactive issue identification
3. **GitHub Copilot Integration**: Direct PR creation with fixes
4. **Slack/Teams Integration**: Notification of critical issues
5. **Custom Dashboards**: Team-specific views
6. **Historical Trend Analysis**: Track improvement over time
7. **Multi-tenant Support**: Isolation for different teams

### Additional Use Cases
1. **Capacity Planning**: Analyze resource usage patterns
2. **SLA Monitoring**: Track latency against SLAs
3. **Incident Management**: Integrate with PagerDuty
4. **Cost Optimization**: Identify inefficient services
5. **Security Analysis**: Detect security-related errors

## 👥 Team & Support

### Development Team
- **10 Teams**: All using Java Spring Boot microservices
- **Technology Stack**: Java 17, Spring Boot, Maven, Groovy Spock tests
- **IDE**: Visual Studio Code, IntelliJ with GitHub Copilot
- **CI/CD**: Jenkins → GitHub Actions (migration in progress)

### Contributing
Follow the team's coding standards:
- SOLID principles
- DRY (Don't Repeat Yourself)
- YAGNI (You Aren't Gonna Need It)
- Design patterns where applicable
- Comprehensive comments for complex logic

## 📄 License

Internal Enterprise Software - Proprietary

## 🔗 Links

- **Jira**: [Project Board](https://company.atlassian.net)
- **GitHub**: [Repository](https://github.com/company/traceiq)
- **Documentation**: [Confluence](https://company.atlassian.net/wiki)
- **Internal LLM APIs**: Contact Platform Team

## 📞 Contact

For issues, questions, or feature requests:
- **Slack**: #traceiq-support
- **Email**: traceiq-team@company.com
- **On-Call**: PagerDuty rotation

---

**TraceIQ** - Empowering developers and testers to focus on building, not triaging. 🚀
