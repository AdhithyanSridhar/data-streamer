package com.traceiq.adapters.llm;

import com.traceiq.adapters.config.AdapterConfiguration;
import com.traceiq.utils.JsonUtils;
import com.traceiq.utils.RetryUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

/**
 * Adapter for LLM API calls with jtoon wrapper support.
 * Handles both direct LLM calls and token-optimized calls via jtoon.
 */
@Component
public class LLMAdapter {
    
    private static final Logger logger = LoggerFactory.getLogger(LLMAdapter.class);
    
    private final RestTemplate restTemplate;
    private final AdapterConfiguration config;
    
    public LLMAdapter(RestTemplate restTemplate, AdapterConfiguration config) {
        this.restTemplate = restTemplate;
        this.config = config;
    }
    
    /**
     * Calls the LLM API with the given prompt.
     * Automatically routes through jtoon if enabled.
     *
     * @param prompt the prompt to send
     * @param systemPrompt optional system prompt
     * @return LLM response text
     */
    public String callLLM(String prompt, String systemPrompt) {
        if (!config.isAiEnabled()) {
            logger.info("AI is disabled, returning mock response");
            return getMockLLMResponse();
        }
        
        String processedPrompt;
        if (config.isJtoonEnabled()) {
            logger.info("Jtoon enabled, optimizing tokens");
            processedPrompt = optimizeWithJtoon(prompt);
        } else {
            processedPrompt = prompt;
        }

        return RetryUtils.executeWithRetry(() -> {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBearerAuth(config.getLlmApiToken());
            
            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("prompt", processedPrompt);
            if (systemPrompt != null && !systemPrompt.isEmpty()) {
                requestBody.put("system_prompt", systemPrompt);
            }
            requestBody.put("model", "gpt-4.1");
            requestBody.put("max_tokens", 2000);
            
            HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);
            
            logger.info("Calling LLM API: {}", config.getLlmApiUrl());
            ResponseEntity<String> response = restTemplate.exchange(
                config.getLlmApiUrl() + "/v1/chat/completions",
                HttpMethod.POST,
                request,
                String.class
            );
            
            return extractLLMResponse(response.getBody());
        }, "LLM API Call");
    }
    
    /**
     * Optimizes prompt using jtoon wrapper for token efficiency.
     *
     * @param prompt original prompt
     * @return optimized prompt
     */
    private String optimizeWithJtoon(String prompt) {
        // Placeholder for jtoon integration
        // In production, this would call jtoon API to compress/optimize the prompt
        logger.debug("Optimizing prompt with jtoon");
        return prompt; // For now, return as-is
    }
    
    /**
     * Extracts the response text from LLM API response.
     *
     * @param responseBody raw response body
     * @return extracted response text
     */
    private String extractLLMResponse(String responseBody) {
        // Simple extraction - in production, parse JSON properly
        return responseBody;
    }
    
    /**
     * Returns a mock LLM response for testing without API calls.
     *
     * @return mock response
     */
    private String getMockLLMResponse() {
        return "Mock LLM Response: Root cause analysis indicates a NullPointerException in the payment service due to missing configuration parameters.";
    }
}
