import { createApp } from 'vue'
import App from './App.vue'
import router from './router'

// Vuetify
import 'vuetify/styles'
import { createVuetify } from 'vuetify'
import * as components from 'vuetify/components'
import * as directives from 'vuetify/directives'
import '@mdi/font/css/materialdesignicons.css'

// Custom styles
import './style.css'

const vuetify = createVuetify({
  components,
  directives,
  theme: {
    defaultTheme: 'light',
    themes: {
      light: {
        colors: {
          primary: '#1a1a1a',
          secondary: '#666666',
          accent: '#6366f1',
          success: '#10b981',
          warning: '#f59e0b',
          error: '#ef4444',
          info: '#3b82f6',
          background: '#fafafa',
          surface: '#ffffff',
          'surface-variant': '#f5f5f5',
          'on-surface': '#1a1a1a',
          'on-background': '#1a1a1a',
        }
      }
    }
  }
})

createApp(App).use(vuetify).use(router).mount('#app')
