package com.traceiq.config;

import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

/**
 * Configuration for WebClient instances used for external API calls
 * Provides configured HTTP clients with proper timeouts and connection pooling
 */
@Configuration
public class WebClientConfig {

    /**
     * Creates a general-purpose WebClient with standard timeout settings
     *
     * @return Configured WebClient instance
     */
    @Bean
    public WebClient.Builder webClientBuilder() {
        HttpClient httpClient = HttpClient.create()
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 30000)
                .responseTimeout(Duration.ofSeconds(30))
                .doOnConnected(conn ->
                        conn.addHandlerLast(new ReadTimeoutHandler(30, TimeUnit.SECONDS))
                                .addHandlerLast(new WriteTimeoutHandler(30, TimeUnit.SECONDS))
                );

        return WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(httpClient));
    }

    /**
     * Creates a WebClient specifically for ELK API calls
     *
     * @param config API configuration
     * @return ELK-configured WebClient
     */
    @Bean("elkWebClient")
    public WebClient elkWebClient(ApiConfiguration config, WebClient.Builder builder) {
        return builder
                .baseUrl(config.getElk().getBaseUrl())
                .defaultHeaders(headers -> {
                    if (config.getElk().getUsername() != null && config.getElk().getPassword() != null) {
                        headers.setBasicAuth(config.getElk().getUsername(), config.getElk().getPassword());
                    }
                })
                .build();
    }

    /**
     * Creates a WebClient specifically for Jira API calls
     *
     * @param config API configuration
     * @return Jira-configured WebClient
     */
    @Bean("jiraWebClient")
    public WebClient jiraWebClient(ApiConfiguration config, WebClient.Builder builder) {
        return builder
                .baseUrl(config.getJira().getBaseUrl())
                .defaultHeaders(headers -> {
                    if (config.getJira().getUsername() != null && config.getJira().getApiToken() != null) {
                        headers.setBasicAuth(config.getJira().getUsername(), config.getJira().getApiToken());
                    }
                })
                .build();
    }

    /**
     * Creates a WebClient specifically for GitHub API calls
     *
     * @param config API configuration
     * @return GitHub-configured WebClient
     */
    @Bean("githubWebClient")
    public WebClient githubWebClient(ApiConfiguration config, WebClient.Builder builder) {
        return builder
                .baseUrl(config.getGithub().getBaseUrl())
                .defaultHeaders(headers -> {
                    if (config.getGithub().getToken() != null) {
                        headers.setBearerAuth(config.getGithub().getToken());
                    }
                    headers.set("Accept", "application/vnd.github.v3+json");
                })
                .build();
    }

    /**
     * Creates a WebClient specifically for Dynatrace API calls
     *
     * @param config API configuration
     * @return Dynatrace-configured WebClient
     */
    @Bean("dynatraceWebClient")
    public WebClient dynatraceWebClient(ApiConfiguration config, WebClient.Builder builder) {
        return builder
                .baseUrl(config.getDynatrace().getBaseUrl())
                .defaultHeaders(headers -> {
                    if (config.getDynatrace().getApiToken() != null) {
                        headers.set("Authorization", "Api-Token " + config.getDynatrace().getApiToken());
                    }
                })
                .build();
    }

    /**
     * Creates a WebClient specifically for Jenkins API calls
     *
     * @param config API configuration
     * @return Jenkins-configured WebClient
     */
    @Bean("jenkinsWebClient")
    public WebClient jenkinsWebClient(ApiConfiguration config, WebClient.Builder builder) {
        return builder
                .baseUrl(config.getJenkins().getBaseUrl())
                .defaultHeaders(headers -> {
                    if (config.getJenkins().getUsername() != null && config.getJenkins().getApiToken() != null) {
                        headers.setBasicAuth(config.getJenkins().getUsername(), config.getJenkins().getApiToken());
                    }
                })
                .build();
    }

    /**
     * Creates a WebClient specifically for Kubernetes API calls
     *
     * @param config API configuration
     * @return Kubernetes-configured WebClient
     */
    @Bean("kubernetesWebClient")
    public WebClient kubernetesWebClient(ApiConfiguration config, WebClient.Builder builder) {
        return builder
                .baseUrl(config.getKubernetes().getApiUrl())
                .defaultHeaders(headers -> {
                    if (config.getKubernetes().getToken() != null) {
                        headers.setBearerAuth(config.getKubernetes().getToken());
                    }
                })
                .build();
    }

    /**
     * Creates a WebClient specifically for internal LLM RCA API calls
     *
     * @param config API configuration
     * @return LLM RCA-configured WebClient
     */
    @Bean("llmRcaWebClient")
    public WebClient llmRcaWebClient(ApiConfiguration config, WebClient.Builder builder) {
        return builder
                .baseUrl(config.getLlm().getRca().getBaseUrl())
                .defaultHeaders(headers -> {
                    if (config.getLlm().getRca().getApiKey() != null) {
                        headers.setBearerAuth(config.getLlm().getRca().getApiKey());
                    }
                })
                .build();
    }

    /**
     * Creates a WebClient specifically for internal codebase LLM API calls
     *
     * @param config API configuration
     * @return Codebase LLM-configured WebClient
     */
    @Bean("llmCodebaseWebClient")
    public WebClient llmCodebaseWebClient(ApiConfiguration config, WebClient.Builder builder) {
        return builder
                .baseUrl(config.getLlm().getCodebase().getBaseUrl())
                .defaultHeaders(headers -> {
                    if (config.getLlm().getCodebase().getApiKey() != null) {
                        headers.setBearerAuth(config.getLlm().getCodebase().getApiKey());
                    }
                })
                .build();
    }

    /**
     * Creates a WebClient specifically for directory/webphone API calls
     *
     * @param config API configuration
     * @return Directory-configured WebClient
     */
    @Bean("directoryWebClient")
    public WebClient directoryWebClient(ApiConfiguration config, WebClient.Builder builder) {
        return builder
                .baseUrl(config.getDirectory().getBaseUrl())
                .defaultHeaders(headers -> {
                    if (config.getDirectory().getApiKey() != null) {
                        headers.set("X-API-Key", config.getDirectory().getApiKey());
                    }
                })
                .build();
    }
}
