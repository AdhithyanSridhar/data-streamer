package com.traceiq.models.domain;

import java.time.Instant;
import java.util.List;

/**
 * Represents the Root Cause Analysis result from LLM.
 */
public record RCAResult(
    String traceId,
    String rootCause,
    String analysisText,
    double confidenceScore,
    List<String> contributingFactors,
    List<String> affectedServices,
    String severity,
    Instant analyzedAt,
    String llmModel,
    int tokensUsed
) {
    public static class Builder {
        private String traceId;
        private String rootCause;
        private String analysisText;
        private double confidenceScore;
        private List<String> contributingFactors;
        private List<String> affectedServices;
        private String severity;
        private Instant analyzedAt;
        private String llmModel;
        private int tokensUsed;

        public Builder traceId(String traceId) {
            this.traceId = traceId;
            return this;
        }

        public Builder rootCause(String rootCause) {
            this.rootCause = rootCause;
            return this;
        }

        public Builder analysisText(String analysisText) {
            this.analysisText = analysisText;
            return this;
        }

        public Builder confidenceScore(double confidenceScore) {
            this.confidenceScore = confidenceScore;
            return this;
        }

        public Builder contributingFactors(List<String> contributingFactors) {
            this.contributingFactors = contributingFactors;
            return this;
        }

        public Builder affectedServices(List<String> affectedServices) {
            this.affectedServices = affectedServices;
            return this;
        }

        public Builder severity(String severity) {
            this.severity = severity;
            return this;
        }

        public Builder analyzedAt(Instant analyzedAt) {
            this.analyzedAt = analyzedAt;
            return this;
        }

        public Builder llmModel(String llmModel) {
            this.llmModel = llmModel;
            return this;
        }

        public Builder tokensUsed(int tokensUsed) {
            this.tokensUsed = tokensUsed;
            return this;
        }

        public RCAResult build() {
            return new RCAResult(
                traceId, rootCause, analysisText, confidenceScore,
                contributingFactors, affectedServices, severity,
                analyzedAt, llmModel, tokensUsed
            );
        }
    }

    public static Builder builder() {
        return new Builder();
    }
}
