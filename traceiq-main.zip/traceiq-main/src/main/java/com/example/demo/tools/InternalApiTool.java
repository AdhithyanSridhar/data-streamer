package com.example.demo.tools;

import dev.langchain4j.agent.tool.Tool;
import org.springframework.stereotype.Component;

@Component
public class InternalApiTool {

  @Tool("Get RCA, summary, and fix suggestions from the internal OpenAI API LLM tool")
  public InternalLLMResponse getInternalLLMSuggestions(
      InternalLLMRequest internalLLMRequest) {
    System.out.println("Getting suggestions from internal LLM: " + internalLLMRequest.prompt);
    return new InternalLLMResponse(
        "Simulated RCA: The error was caused by a missing configuration value. "
            + "Summary: A NullPointerException occurred when trying to access a required property. "
            + "Fix: Add the 'db.host' property to the application.properties file.",
        "To prevent this in the future, implement stricter configuration validation at startup.");
  }

  @Tool("Get source code location and fix suggestions from the internal codebase API LLM tool")
  public CodebaseLLMResponse getCodebaseLLMSuggestions(
      CodebaseLLMRequest codebaseLLMRequest) {
    System.out.println(
        "Getting suggestions from internal codebase LLM: " + codebaseLLMRequest.prompt);
    return new CodebaseLLMResponse(
        "src/main/java/com/example/demo/MyService.java",
        "Problematic code:\n\n" + "String dbHost = properties.get(\"db.host\"); // This line throws NullPointerException",
        "Suggested fix:\n\n" + "String dbHost = Optional.ofNullable(properties.get(\"db.host\")).orElse(\"default.host\");",
        "For GitHub Copilot: Implement the Optional pattern for all configuration properties to avoid NullPointerExceptions and provide default values where applicable.");
  }

  public record InternalLLMRequest(String prompt) {}

  public record InternalLLMResponse(String rcaAndSummary, String futureGuardrails) {}

  public record CodebaseLLMRequest(String prompt) {}

  public record CodebaseLLMResponse(
      String sourceCodeLocation,
      String problematicCode,
      String fixSuggestion,
      String copilotImplementationPlan) {}
}
