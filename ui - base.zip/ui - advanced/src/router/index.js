import { createRouter, createWebHistory } from 'vue-router'

const routes = [
    {
        path: '/',
        redirect: '/dashboard'
    },
    {
        path: '/dashboard',
        name: 'Dashboard',
        component: () => import('../views/Dashboard.vue'),
        meta: { title: 'Dashboard', icon: 'mdi-view-dashboard-outline' }
    },
    {
        path: '/app-errors',
        name: 'AppErrors',
        component: () => import('../views/AppErrors.vue'),
        meta: { title: 'App Errors', icon: 'mdi-alert-circle-outline' }
    },
    {
        path: '/trace-lookup',
        name: 'TraceLookup',
        component: () => import('../views/TraceIdLookup.vue'),
        meta: { title: 'Trace Lookup', icon: 'mdi-magnify' }
    },
    {
        path: '/agent-view',
        name: 'AgentView',
        component: () => import('../views/AgentView.vue'),
        meta: { title: 'Agent View', icon: 'mdi-robot-outline' }
    },
    {
        path: '/incidents',
        name: 'Incidents',
        component: () => import('../views/Incidents.vue'),
        meta: { title: 'Incidents', icon: 'mdi-alert-octagon-outline' }
    },
    {
        path: '/batch-job',
        name: 'BatchJob',
        component: () => import('../views/BatchJob.vue'),
        meta: { title: 'Batch Jobs', icon: 'mdi-calendar-clock-outline' }
    },
    {
        path: '/batch-run',
        name: 'BatchRun',
        component: () => import('../views/BatchRun.vue'),
        meta: { title: 'Batch Runs', icon: 'mdi-play-circle-outline' }
    },
    {
        path: '/settings',
        name: 'Settings',
        component: () => import('../views/Settings.vue'),
        meta: { title: 'Settings', icon: 'mdi-cog-outline' }
    },
    {
        path: '/faq',
        name: 'FAQ',
        component: () => import('../views/FAQ.vue'),
        meta: { title: 'FAQ', icon: 'mdi-help-circle-outline' }
    },
    {
        path: '/feedback',
        name: 'Feedback',
        component: () => import('../views/Feedback.vue'),
        meta: { title: 'Feedback', icon: 'mdi-message-outline' }
    }
]

const router = createRouter({
    history: createWebHistory(),
    routes
})

export default router
