package com.traceiq.core;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
@ComponentScan(basePackages = {"com.traceiq"})
public class TraceIQApplication {
    
    private static final Logger logger = LoggerFactory.getLogger(TraceIQApplication.class);
    
    public static void main(String[] args) {
        logger.info("Starting TraceIQ Application...");
        SpringApplication.run(TraceIQApplication.class, args);
        logger.info("TraceIQ Application started successfully");
    }
}
