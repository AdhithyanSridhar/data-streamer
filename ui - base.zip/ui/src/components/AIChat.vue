<template>
  <!-- Floating Chat Button -->
  <div class="chat-button" @click="isOpen = true" v-if="!isOpen">
    <v-icon icon="mdi-robot-outline" size="24"></v-icon>
    <span class="chat-badge" v-if="hasNewResponse"></span>
  </div>
  
  <!-- Chat Window -->
  <Teleport to="body">
    <Transition name="chat-slide">
      <div class="chat-window" v-if="isOpen">
        <div class="chat-header">
          <div class="chat-title">
            <v-icon icon="mdi-robot-outline" size="20"></v-icon>
            <span>TraceIQ AI Assistant</span>
          </div>
          <v-btn icon variant="text" size="small" @click="isOpen = false">
            <v-icon icon="mdi-close"></v-icon>
          </v-btn>
        </div>
        
        <div class="chat-messages" ref="messagesContainer">
          <div 
            v-for="msg in messages" 
            :key="msg.id" 
            class="message"
            :class="`message--${msg.role}`"
          >
            <div class="message-avatar">
              <v-icon :icon="msg.role === 'user' ? 'mdi-account' : 'mdi-robot'" size="16"></v-icon>
            </div>
            <div class="message-content">
              <div class="message-text" v-html="msg.content"></div>
              <span class="message-time">{{ msg.time }}</span>
            </div>
          </div>
          
          <div class="typing-indicator" v-if="isTyping">
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
          </div>
        </div>
        
        <div class="chat-suggestions" v-if="messages.length <= 1">
          <button 
            v-for="suggestion in suggestions" 
            :key="suggestion"
            class="suggestion-btn"
            @click="sendMessage(suggestion)"
          >
            {{ suggestion }}
          </button>
        </div>
        
        <div class="chat-input">
          <input 
            v-model="inputMessage" 
            type="text" 
            placeholder="Ask anything about your traces..."
            @keyup.enter="sendMessage(inputMessage)"
          />
          <v-btn icon variant="text" @click="sendMessage(inputMessage)" :disabled="!inputMessage.trim()">
            <v-icon icon="mdi-send"></v-icon>
          </v-btn>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script setup>
import { ref, nextTick } from 'vue'

const isOpen = ref(false)
const inputMessage = ref('')
const isTyping = ref(false)
const hasNewResponse = ref(false)
const messagesContainer = ref(null)

const suggestions = [
  "What errors occurred today?",
  "Show me payment service issues",
  "Generate incident report",
  "Why is billing-service failing?"
]

const messages = ref([
  { 
    id: 1, 
    role: 'assistant', 
    content: 'Hi! I\'m your TraceIQ AI assistant. I can help you analyze errors, find traces, and generate reports. What would you like to know?',
    time: 'Just now'
  }
])

let msgId = 1

const sendMessage = async (text) => {
  if (!text.trim()) return
  
  // Add user message
  messages.value.push({
    id: ++msgId,
    role: 'user',
    content: text,
    time: 'Just now'
  })
  
  inputMessage.value = ''
  isTyping.value = true
  
  await nextTick()
  scrollToBottom()
  
  // Simulate AI response
  setTimeout(() => {
    isTyping.value = false
    messages.value.push({
      id: ++msgId,
      role: 'assistant',
      content: generateResponse(text),
      time: 'Just now'
    })
    scrollToBottom()
  }, 1500)
}

const generateResponse = (query) => {
  const q = query.toLowerCase()
  
  if (q.includes('error') || q.includes('issue')) {
    return `Based on my analysis, I found <strong>247 errors</strong> in the last 24 hours. The top issues are:
    <br><br>
    1. <strong>NullPointerException</strong> in payment-service (156 occurrences)<br>
    2. <strong>ConnectionTimeout</strong> in order-service (89 occurrences)<br>
    3. <strong>InvalidCurrencyCode</strong> in billing-service (45 occurrences)
    <br><br>
    Would you like me to create an incident for any of these?`
  }
  
  if (q.includes('payment')) {
    return `The <strong>payment-service</strong> has seen increased error rates:
    <br><br>
    • Error rate: <strong>2.3%</strong> (↑ from 0.5% yesterday)<br>
    • Most common: NullPointerException<br>
    • Affected endpoint: POST /api/payments/process<br>
    • Root cause: Missing null check in PaymentProcessor
    <br><br>
    I can help you assign an agent to fix this issue.`
  }
  
  if (q.includes('report') || q.includes('incident')) {
    return `I've prepared an incident report:
    <br><br>
    📋 <strong>Incident Report - December 10, 2024</strong><br>
    • Affected Services: payment-service, billing-service<br>
    • Duration: 2 hours 15 minutes<br>
    • Impact: ~2,500 failed transactions<br>
    • RCA: Missing null validation in upstream call<br>
    • Status: Agent-generated fix pending review
    <br><br>
    <a href="#" style="color: #6366f1;">Download full report (PDF)</a>`
  }
  
  if (q.includes('billing')) {
    return `Analyzing <strong>billing-service</strong>...
    <br><br>
    The service is experiencing failures due to:
    <br>
    1. Upstream dependency on payment-service (currently degraded)<br>
    2. Connection pool exhaustion during peak hours<br>
    <br>
    Recommendation: Implement circuit breaker pattern and increase pool size.`
  }
  
  return `I understand you're asking about "${query}". 
  <br><br>
  I can help you with:
  <br>
  • Analyzing error patterns and trends<br>
  • Finding specific traces by ID<br>
  • Generating incident reports<br>
  • Identifying root causes<br>
  • Suggesting fixes
  <br><br>
  Could you be more specific about what you'd like to know?`
}

const scrollToBottom = () => {
  nextTick(() => {
    if (messagesContainer.value) {
      messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
    }
  })
}
</script>

<style scoped>
.chat-button {
  position: fixed;
  bottom: 24px;
  right: 24px;
  width: 56px;
  height: 56px;
  border-radius: 50%;
  background: #1a1a1a;
  color: #ffffff;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
  z-index: 9998;
  transition: transform 0.2s, box-shadow 0.2s;
}

.chat-button:hover {
  transform: scale(1.05);
  box-shadow: 0 6px 30px rgba(0, 0, 0, 0.4);
}

.chat-badge {
  position: absolute;
  top: 8px;
  right: 8px;
  width: 12px;
  height: 12px;
  background: #ef4444;
  border-radius: 50%;
  border: 2px solid #1a1a1a;
}

.chat-window {
  position: fixed;
  bottom: 24px;
  right: 24px;
  width: 400px;
  height: 550px;
  background: #ffffff;
  border-radius: 16px;
  box-shadow: 0 10px 50px rgba(0, 0, 0, 0.2);
  display: flex;
  flex-direction: column;
  z-index: 9999;
  overflow: hidden;
}

.chat-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px;
  background: #1a1a1a;
  color: #ffffff;
}

.chat-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 600;
  font-size: 0.9rem;
}

.chat-messages {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.message {
  display: flex;
  gap: 10px;
}

.message--user {
  flex-direction: row-reverse;
}

.message-avatar {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  background: #f5f5f5;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.message--assistant .message-avatar {
  background: #1a1a1a;
  color: #ffffff;
}

.message-content {
  max-width: 80%;
}

.message-text {
  padding: 10px 14px;
  border-radius: 12px;
  font-size: 0.85rem;
  line-height: 1.5;
}

.message--user .message-text {
  background: #1a1a1a;
  color: #ffffff;
  border-bottom-right-radius: 4px;
}

.message--assistant .message-text {
  background: #f5f5f5;
  color: #1a1a1a;
  border-bottom-left-radius: 4px;
}

.message-time {
  font-size: 0.7rem;
  color: #999999;
  margin-top: 4px;
  display: block;
}

.typing-indicator {
  display: flex;
  gap: 4px;
  padding: 12px 16px;
  background: #f5f5f5;
  border-radius: 12px;
  width: fit-content;
}

.dot {
  width: 8px;
  height: 8px;
  background: #999999;
  border-radius: 50%;
  animation: bounce 1.4s infinite ease-in-out both;
}

.dot:nth-child(1) { animation-delay: -0.32s; }
.dot:nth-child(2) { animation-delay: -0.16s; }

@keyframes bounce {
  0%, 80%, 100% { transform: scale(0); }
  40% { transform: scale(1); }
}

.chat-suggestions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  padding: 0 16px 16px;
}

.suggestion-btn {
  background: #f5f5f5;
  border: 1px solid #e5e5e5;
  border-radius: 16px;
  padding: 6px 12px;
  font-size: 0.75rem;
  color: #666666;
  cursor: pointer;
  transition: all 0.2s;
}

.suggestion-btn:hover {
  background: #e5e5e5;
  color: #1a1a1a;
}

.chat-input {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 16px;
  border-top: 1px solid #e5e5e5;
}

.chat-input input {
  flex: 1;
  border: none;
  outline: none;
  font-size: 0.9rem;
  color: #1a1a1a;
}

.chat-input input::placeholder {
  color: #999999;
}

/* Transition */
.chat-slide-enter-active,
.chat-slide-leave-active {
  transition: all 0.3s ease;
}

.chat-slide-enter-from,
.chat-slide-leave-to {
  transform: translateY(20px) scale(0.95);
  opacity: 0;
}
</style>
