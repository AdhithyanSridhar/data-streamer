package com.traceiq.models.dto.graph;

/**
 * Input schema for ELK node in LangGraph4j orchestration
 */
public record ElkNodeInput(
        String traceId,
        String timeRange,
        String correlationId
) {
    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String traceId;
        private String timeRange;
        private String correlationId;

        public Builder traceId(String traceId) {
            this.traceId = traceId;
            return this;
        }

        public Builder timeRange(String timeRange) {
            this.timeRange = timeRange;
            return this;
        }

        public Builder correlationId(String correlationId) {
            this.correlationId = correlationId;
            return this;
        }

        public ElkNodeInput build() {
            return new ElkNodeInput(traceId, timeRange, correlationId);
        }
    }
}
