package com.traceiq.models.dto;

import com.traceiq.models.domain.JobRun;

import java.util.List;

/**
 * Response DTO for listing jobs and their run history
 */
public record JobListResponse(
        List<JobRun> jobs,
        Integer totalCount
) {
    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private List<JobRun> jobs;
        private Integer totalCount;

        public Builder jobs(List<JobRun> jobs) {
            this.jobs = jobs;
            return this;
        }

        public Builder totalCount(Integer totalCount) {
            this.totalCount = totalCount;
            return this;
        }

        public JobListResponse build() {
            return new JobListResponse(jobs, totalCount);
        }
    }
}
