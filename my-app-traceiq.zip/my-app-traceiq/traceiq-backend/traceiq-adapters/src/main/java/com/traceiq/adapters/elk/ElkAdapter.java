package com.traceiq.adapters.elk;

import com.traceiq.adapters.config.AdapterConfiguration;
import com.traceiq.models.domain.ErrorLog;
import com.traceiq.utils.RetryUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Adapter for ELK/Kibana API.
 * Retrieves error logs by traceId or message text.
 */
@Component
public class ElkAdapter {
    
    private static final Logger logger = LoggerFactory.getLogger(ElkAdapter.class);
    
    private final RestTemplate restTemplate;
    private final AdapterConfiguration config;
    
    public ElkAdapter(RestTemplate restTemplate, AdapterConfiguration config) {
        this.restTemplate = restTemplate;
        this.config = config;
    }
    
    /**
     * Searches ELK for errors by traceId.
     *
     * @param traceId trace identifier
     * @return list of error logs
     */
    public List<ErrorLog> searchByTraceId(String traceId) {
        return RetryUtils.executeWithRetry(() -> {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "Bearer " + config.getElkApiToken());
            
            Map<String, Object> query = buildTraceIdQuery(traceId);
            HttpEntity<Map<String, Object>> request = new HttpEntity<>(query, headers);
            
            logger.info("Searching ELK for traceId: {}", traceId);
            ResponseEntity<String> response = restTemplate.exchange(
                config.getElkApiUrl() + "/_search",
                HttpMethod.POST,
                request,
                String.class
            );
            
            return parseElkResponse(response.getBody());
        }, "ELK Search by TraceId");
    }
    
    /**
     * Searches ELK for errors by message text.
     *
     * @param messageText message to search for
     * @return list of error logs
     */
    public List<ErrorLog> searchByMessage(String messageText) {
        return RetryUtils.executeWithRetry(() -> {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "Bearer " + config.getElkApiToken());
            
            Map<String, Object> query = buildMessageQuery(messageText);
            HttpEntity<Map<String, Object>> request = new HttpEntity<>(query, headers);
            
            logger.info("Searching ELK for message: {}", messageText);
            ResponseEntity<String> response = restTemplate.exchange(
                config.getElkApiUrl() + "/_search",
                HttpMethod.POST,
                request,
                String.class
            );
            
            return parseElkResponse(response.getBody());
        }, "ELK Search by Message");
    }
    
    /**
     * Retrieves all errors for nightly ingestion.
     *
     * @param from start time
     * @param to end time
     * @return list of error logs
     */
    public List<ErrorLog> getAllErrors(Instant from, Instant to) {
        logger.info("Retrieving all errors from {} to {}", from, to);
        // Return mock data for now
        return getMockErrorLogs("TRACE-MOCK-001");
    }
    
    private Map<String, Object> buildTraceIdQuery(String traceId) {
        Map<String, Object> query = new HashMap<>();
        Map<String, Object> match = new HashMap<>();
        match.put("traceId", traceId);
        query.put("query", Map.of("match", match));
        query.put("size", 100);
        return query;
    }
    
    private Map<String, Object> buildMessageQuery(String messageText) {
        Map<String, Object> query = new HashMap<>();
        Map<String, Object> match = new HashMap<>();
        match.put("message", messageText);
        query.put("query", Map.of("match", match));
        query.put("size", 100);
        return query;
    }
    
    private List<ErrorLog> parseElkResponse(String responseBody) {
        // Placeholder - return mock data
        return getMockErrorLogs("TRACE-001");
    }
    
    /**
     * Returns mock error logs for testing.
     */
    public List<ErrorLog> getMockErrorLogs(String traceId) {
        List<ErrorLog> errors = new ArrayList<>();
        
        errors.add(ErrorLog.builder()
            .traceId(traceId)
            .message("NullPointerException in PaymentService.processPayment()")
            .level("ERROR")
            .serviceName("payment-service")
            .microserviceTeam("payments-team")
            .ownerEmail("payments-team@example.com")
            .timestamp(Instant.now().minusSeconds(300))
            .environment("production")
            .stackTrace("java.lang.NullPointerException\n    at com.example.payment.PaymentService.processPayment(PaymentService.java:145)")
            .additionalFields(Map.of("user_id", "12345", "amount", "100.00"))
            .tags(List.of("payment", "error", "production"))
            .build());
        
        errors.add(ErrorLog.builder()
            .traceId(traceId)
            .message("Configuration value 'payment.gateway.url' not found")
            .level("ERROR")
            .serviceName("payment-service")
            .microserviceTeam("payments-team")
            .ownerEmail("payments-team@example.com")
            .timestamp(Instant.now().minusSeconds(299))
            .environment("production")
            .stackTrace("java.lang.IllegalStateException: Missing configuration\n    at com.example.payment.ConfigManager.getConfig(ConfigManager.java:67)")
            .additionalFields(Map.of("config_key", "payment.gateway.url"))
            .tags(List.of("configuration", "error", "production"))
            .build());
        
        return errors;
    }
}
