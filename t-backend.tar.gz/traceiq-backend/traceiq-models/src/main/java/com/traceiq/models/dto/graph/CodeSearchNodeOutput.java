package com.traceiq.models.dto.graph;

import java.util.List;

/**
 * Output schema for Code Search node
 */
public record CodeSearchNodeOutput(
        String traceId,
        List<CodeLocation> codeLocations,
        String implementationPlan,
        String curatedPrompt,
        boolean success,
        String errorMessage
) {
    public record CodeLocation(
            String repository,
            String filePath,
            Integer lineNumber,
            String snippet,
            String reason
    ) {}
}
