package com.traceiq.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.time.Instant;

/**
 * Deployment and build information from Jenkins/K8s.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record DeploymentInfo(
    String buildNumber,
    String buildStatus,
    Instant buildTime,
    String deploymentStatus,
    Instant deploymentTime,
    String environment,
    String podStatus,
    int podCount,
    String sonarCheckStatus,
    String componentTestStatus
) {}
