package com.traceiq.models.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.traceiq.models.enums.ErrorSeverity;

import java.time.Instant;
import java.util.Map;

/**
 * Domain model representing an error record ingested from ELK
 * Stored in Cassandra
 */
public record ErrorRecord(
        String traceId,
        String message,
        String service,
        ErrorSeverity severity,
        String stackTrace,
        Map<String, Object> metadata,
        String ownerEmail,
        String teamName,
        @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = "UTC")
        Instant timestamp,
        @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = "UTC")
        Instant ingestedAt
) {
    /**
     * Builder for ErrorRecord
     */
    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String traceId;
        private String message;
        private String service;
        private ErrorSeverity severity;
        private String stackTrace;
        private Map<String, Object> metadata;
        private String ownerEmail;
        private String teamName;
        private Instant timestamp;
        private Instant ingestedAt;

        public Builder traceId(String traceId) {
            this.traceId = traceId;
            return this;
        }

        public Builder message(String message) {
            this.message = message;
            return this;
        }

        public Builder service(String service) {
            this.service = service;
            return this;
        }

        public Builder severity(ErrorSeverity severity) {
            this.severity = severity;
            return this;
        }

        public Builder stackTrace(String stackTrace) {
            this.stackTrace = stackTrace;
            return this;
        }

        public Builder metadata(Map<String, Object> metadata) {
            this.metadata = metadata;
            return this;
        }

        public Builder ownerEmail(String ownerEmail) {
            this.ownerEmail = ownerEmail;
            return this;
        }

        public Builder teamName(String teamName) {
            this.teamName = teamName;
            return this;
        }

        public Builder timestamp(Instant timestamp) {
            this.timestamp = timestamp;
            return this;
        }

        public Builder ingestedAt(Instant ingestedAt) {
            this.ingestedAt = ingestedAt;
            return this;
        }

        public ErrorRecord build() {
            return new ErrorRecord(
                    traceId,
                    message,
                    service,
                    severity,
                    stackTrace,
                    metadata,
                    ownerEmail,
                    teamName,
                    timestamp,
                    ingestedAt
            );
        }
    }
}
