<template>
  <v-container fluid class="pa-6">
    <div class="page-header mb-6">
      <h1 class="page-title">Settings</h1>
      <p class="page-subtitle">Configure your preferences and integrations</p>
    </div>

    <v-row>
      <!-- Settings Navigation -->
      <v-col cols="12" md="3">
        <div class="glass-card pa-4">
          <v-list nav density="compact" class="settings-nav">
            <v-list-item 
              v-for="section in sections" 
              :key="section.id" 
              :value="section.id" 
              :active="activeSection === section.id"
              @click="activeSection = section.id"
              rounded="lg"
            >
              <template v-slot:prepend>
                <v-icon :icon="section.icon" size="20"></v-icon>
              </template>
              <v-list-item-title>{{ section.title }}</v-list-item-title>
            </v-list-item>
          </v-list>
        </div>
      </v-col>

      <!-- Settings Content -->
      <v-col cols="12" md="9">
        <!-- Profile Section -->
        <div v-if="activeSection === 'profile'" class="glass-card pa-5">
          <h2 class="section-title mb-4">Profile Settings</h2>
          
          <v-row>
            <v-col cols="12" md="6">
              <v-text-field v-model="profile.name" label="Display Name" variant="outlined"></v-text-field>
            </v-col>
            <v-col cols="12" md="6">
              <v-text-field v-model="profile.email" label="Email" variant="outlined" type="email"></v-text-field>
            </v-col>
            <v-col cols="12" md="6">
              <v-select v-model="profile.team" :items="teams" label="Team" variant="outlined"></v-select>
            </v-col>
            <v-col cols="12" md="6">
              <v-select v-model="profile.role" :items="roles" label="Role" variant="outlined"></v-select>
            </v-col>
          </v-row>
          
          <v-btn color="primary" class="mt-4">Save Changes</v-btn>
        </div>

        <!-- Notifications Section -->
        <div v-if="activeSection === 'notifications'" class="glass-card pa-5">
          <h2 class="section-title mb-4">Notification Preferences</h2>
          
          <div class="settings-group">
            <div class="setting-item">
              <div class="setting-info">
                <span class="setting-label">Email Notifications</span>
                <span class="setting-description">Receive email alerts for critical errors</span>
              </div>
              <v-switch v-model="notifications.email" color="primary" hide-details></v-switch>
            </div>
            
            <div class="setting-item">
              <div class="setting-info">
                <span class="setting-label">Slack Notifications</span>
                <span class="setting-description">Send alerts to Slack channel</span>
              </div>
              <v-switch v-model="notifications.slack" color="primary" hide-details></v-switch>
            </div>
            
            <div class="setting-item">
              <div class="setting-info">
                <span class="setting-label">Browser Notifications</span>
                <span class="setting-description">Show desktop notifications</span>
              </div>
              <v-switch v-model="notifications.browser" color="primary" hide-details></v-switch>
            </div>
            
            <div class="setting-item">
              <div class="setting-info">
                <span class="setting-label">Incident Alerts</span>
                <span class="setting-description">Notify when new incidents are created</span>
              </div>
              <v-switch v-model="notifications.incidents" color="primary" hide-details></v-switch>
            </div>
            
            <div class="setting-item">
              <div class="setting-info">
                <span class="setting-label">Agent Updates</span>
                <span class="setting-description">Notify when agent completes a task</span>
              </div>
              <v-switch v-model="notifications.agent" color="primary" hide-details></v-switch>
            </div>
          </div>
        </div>

        <!-- Integrations Section -->
        <div v-if="activeSection === 'integrations'" class="glass-card pa-5">
          <h2 class="section-title mb-4">Integrations</h2>
          
          <div class="integrations-grid">
            <div v-for="integration in integrations" :key="integration.id" class="integration-card" :class="{ 'integration-card--connected': integration.connected }">
              <div class="integration-icon">
                <v-icon :icon="integration.icon" size="32"></v-icon>
              </div>
              <div class="integration-info">
                <span class="integration-name">{{ integration.name }}</span>
                <span class="integration-description">{{ integration.description }}</span>
              </div>
              <v-btn 
                :variant="integration.connected ? 'outlined' : 'flat'" 
                :color="integration.connected ? 'default' : 'primary'"
                size="small"
                rounded="lg"
              >
                {{ integration.connected ? 'Configure' : 'Connect' }}
              </v-btn>
            </div>
          </div>
        </div>

        <!-- API Keys Section -->
        <div v-if="activeSection === 'api'" class="glass-card pa-5">
          <h2 class="section-title mb-4">API Keys</h2>
          
          <v-alert type="info" variant="tonal" class="mb-4">
            API keys are used to authenticate with the TraceIQ API. Keep them secure.
          </v-alert>
          
          <div class="api-keys-list">
            <div v-for="key in apiKeys" :key="key.id" class="api-key-item">
              <div class="key-info">
                <span class="key-name">{{ key.name }}</span>
                <span class="key-created">Created {{ key.created }}</span>
              </div>
              <div class="key-value">
                <code>{{ key.masked }}</code>
                <v-btn icon variant="text" size="small">
                  <v-icon icon="mdi-content-copy" size="16"></v-icon>
                </v-btn>
              </div>
              <v-btn icon variant="text" size="small" color="error">
                <v-icon icon="mdi-delete-outline" size="18"></v-icon>
              </v-btn>
            </div>
          </div>
          
          <v-btn variant="outlined" class="mt-4">
            <v-icon icon="mdi-plus" class="mr-2"></v-icon>
            Generate New Key
          </v-btn>
        </div>

        <!-- Appearance Section -->
        <div v-if="activeSection === 'appearance'" class="glass-card pa-5">
          <h2 class="section-title mb-4">Appearance</h2>
          
          <div class="settings-group">
            <div class="setting-item">
              <div class="setting-info">
                <span class="setting-label">Compact Mode</span>
                <span class="setting-description">Reduce spacing for denser layout</span>
              </div>
              <v-switch v-model="appearance.compact" color="primary" hide-details></v-switch>
            </div>
            
            <div class="setting-item">
              <div class="setting-info">
                <span class="setting-label">Show Sparklines</span>
                <span class="setting-description">Display mini charts in tables</span>
              </div>
              <v-switch v-model="appearance.sparklines" color="primary" hide-details></v-switch>
            </div>
            
            <div class="setting-item">
              <div class="setting-info">
                <span class="setting-label">Animation Effects</span>
                <span class="setting-description">Enable page transitions and animations</span>
              </div>
              <v-switch v-model="appearance.animations" color="primary" hide-details></v-switch>
            </div>
          </div>
          
          <h3 class="subsection-title mt-6 mb-3">Default Views</h3>
          
          <v-row>
            <v-col cols="12" md="6">
              <v-select v-model="appearance.defaultPage" :items="pages" label="Default Home Page" variant="outlined"></v-select>
            </v-col>
            <v-col cols="12" md="6">
              <v-select v-model="appearance.rowsPerPage" :items="[10, 25, 50, 100]" label="Default Rows Per Page" variant="outlined"></v-select>
            </v-col>
          </v-row>
        </div>

        <!-- Keyboard Shortcuts Section -->
        <div v-if="activeSection === 'shortcuts'" class="glass-card pa-5">
          <h2 class="section-title mb-4">Keyboard Shortcuts</h2>
          
          <div class="shortcuts-list">
            <div v-for="shortcut in shortcuts" :key="shortcut.key" class="shortcut-item">
              <span class="shortcut-description">{{ shortcut.description }}</span>
              <div class="shortcut-keys">
                <kbd v-for="key in shortcut.keys" :key="key">{{ key }}</kbd>
              </div>
            </div>
          </div>
        </div>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup>
import { ref } from 'vue'

const activeSection = ref('profile')

const sections = [
  { id: 'profile', title: 'Profile', icon: 'mdi-account-outline' },
  { id: 'notifications', title: 'Notifications', icon: 'mdi-bell-outline' },
  { id: 'integrations', title: 'Integrations', icon: 'mdi-connection' },
  { id: 'api', title: 'API Keys', icon: 'mdi-key-outline' },
  { id: 'appearance', title: 'Appearance', icon: 'mdi-palette-outline' },
  { id: 'shortcuts', title: 'Shortcuts', icon: 'mdi-keyboard-outline' }
]

const teams = ['Platform Team', 'Payments Team', 'Orders Team', 'Auth Team']
const roles = ['Admin', 'Developer', 'Viewer']
const pages = ['Dashboard', 'App Errors', 'Trace Lookup', 'Incidents']

const profile = ref({
  name: 'John Doe',
  email: 'john.doe@acme.com',
  team: 'Payments Team',
  role: 'Developer'
})

const notifications = ref({
  email: true,
  slack: true,
  browser: false,
  incidents: true,
  agent: true
})

const integrations = [
  { id: 1, name: 'GitHub', description: 'Connect to create issues and PRs', icon: 'mdi-github', connected: true },
  { id: 2, name: 'Slack', description: 'Send alerts to Slack channels', icon: 'mdi-slack', connected: true },
  { id: 3, name: 'Jira', description: 'Sync incidents with Jira tickets', icon: 'mdi-jira', connected: false },
  { id: 4, name: 'PagerDuty', description: 'Trigger on-call alerts', icon: 'mdi-alert-circle-outline', connected: false },
  { id: 5, name: 'Datadog', description: 'Import metrics and traces', icon: 'mdi-dog', connected: false },
  { id: 6, name: 'Dynatrace', description: 'Sync observability data', icon: 'mdi-chart-line', connected: true }
]

const apiKeys = [
  { id: 1, name: 'Production API Key', created: 'Dec 1, 2024', masked: 'sk-prod-****-****-****-abc123' },
  { id: 2, name: 'Development Key', created: 'Nov 15, 2024', masked: 'sk-dev-****-****-****-def456' }
]

const appearance = ref({
  compact: false,
  sparklines: true,
  animations: true,
  defaultPage: 'Dashboard',
  rowsPerPage: 25
})

const shortcuts = [
  { description: 'Open Command Palette', keys: ['⌘', 'K'] },
  { description: 'Go to Dashboard', keys: ['G', 'D'] },
  { description: 'Go to Errors', keys: ['G', 'E'] },
  { description: 'Go to Trace Lookup', keys: ['G', 'T'] },
  { description: 'Go to Incidents', keys: ['G', 'I'] },
  { description: 'Go to Settings', keys: ['G', 'S'] },
  { description: 'Focus Search', keys: ['/'] },
  { description: 'Show Shortcuts', keys: ['?'] },
  { description: 'Close Dialog / Panel', keys: ['Esc'] }
]
</script>

<style scoped>
.page-header { text-align: center; padding: 20px 0; }
.page-title { font-size: 1.5rem; font-weight: 700; color: #1a1a1a; margin-bottom: 4px; }
.page-subtitle { font-size: 0.9rem; color: #666666; }

.settings-nav { background: transparent !important; }
.section-title { font-size: 1.1rem; font-weight: 600; color: #1a1a1a; }
.subsection-title { font-size: 0.95rem; font-weight: 600; color: #1a1a1a; }

.settings-group { display: flex; flex-direction: column; gap: 16px; }
.setting-item { display: flex; align-items: center; justify-content: space-between; padding: 16px; background: #f5f5f5; border-radius: 8px; }
.setting-info { display: flex; flex-direction: column; gap: 4px; }
.setting-label { font-size: 0.9rem; font-weight: 500; color: #1a1a1a; }
.setting-description { font-size: 0.8rem; color: #666666; }

.integrations-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 16px; }
.integration-card { display: flex; align-items: center; gap: 16px; padding: 16px; background: #f5f5f5; border-radius: 10px; border: 2px solid transparent; transition: all 0.2s; }
.integration-card--connected { border-color: #10b981; background: rgba(16,185,129,0.05); }
.integration-icon { width: 48px; height: 48px; border-radius: 10px; background: #ffffff; display: flex; align-items: center; justify-content: center; }
.integration-info { flex: 1; display: flex; flex-direction: column; gap: 4px; }
.integration-name { font-size: 0.95rem; font-weight: 600; color: #1a1a1a; }
.integration-description { font-size: 0.8rem; color: #666666; }

.api-keys-list { display: flex; flex-direction: column; gap: 12px; }
.api-key-item { display: flex; align-items: center; gap: 16px; padding: 16px; background: #f5f5f5; border-radius: 8px; }
.key-info { flex: 1; display: flex; flex-direction: column; gap: 4px; }
.key-name { font-size: 0.9rem; font-weight: 500; color: #1a1a1a; }
.key-created { font-size: 0.75rem; color: #666666; }
.key-value { display: flex; align-items: center; gap: 8px; }
.key-value code { font-size: 0.8rem; background: #e5e5e5; padding: 4px 8px; border-radius: 4px; }

.shortcuts-list { display: flex; flex-direction: column; gap: 8px; }
.shortcut-item { display: flex; justify-content: space-between; align-items: center; padding: 12px 16px; background: #f5f5f5; border-radius: 8px; }
.shortcut-description { font-size: 0.9rem; color: #1a1a1a; }
.shortcut-keys { display: flex; gap: 4px; }
.shortcut-keys kbd { background: #ffffff; border: 1px solid #e5e5e5; border-radius: 4px; padding: 4px 8px; font-size: 0.75rem; font-family: monospace; color: #666666; }
</style>
