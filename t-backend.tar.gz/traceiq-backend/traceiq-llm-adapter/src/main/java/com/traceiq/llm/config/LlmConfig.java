package com.traceiq.llm.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

/**
 * Configuration for LLM adapter
 */
@Configuration
public class LlmConfig {

    @Value("${llm.api.url}")
    private String llmApiUrl;

    @Value("${llm.api.token}")
    private String llmApiToken;

    @Value("${llm.vector.api.url}")
    private String vectorApiUrl;

    @Value("${llm.vector.api.token}")
    private String vectorApiToken;

    @Value("${llm.jtoon.enabled:false}")
    private boolean jtoonEnabled;

    @Value("${llm.jtoon.url:}")
    private String jtoonUrl;

    @Value("${llm.model:gpt-4.1}")
    private String defaultModel;

    @Value("${llm.max.tokens:4096}")
    private int maxTokens;

    @Value("${llm.temperature:0.7}")
    private double temperature;

    @Bean
    public RestTemplate llmRestTemplate() {
        return new RestTemplate();
    }

    public String getLlmApiUrl() {
        return llmApiUrl;
    }

    public String getLlmApiToken() {
        return llmApiToken;
    }

    public String getVectorApiUrl() {
        return vectorApiUrl;
    }

    public String getVectorApiToken() {
        return vectorApiToken;
    }

    public boolean isJtoonEnabled() {
        return jtoonEnabled;
    }

    public String getJtoonUrl() {
        return jtoonUrl;
    }

    public String getDefaultModel() {
        return defaultModel;
    }

    public int getMaxTokens() {
        return maxTokens;
    }

    public double getTemperature() {
        return temperature;
    }
}
