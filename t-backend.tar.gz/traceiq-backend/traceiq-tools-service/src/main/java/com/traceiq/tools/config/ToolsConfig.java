package com.traceiq.tools.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

/**
 * Configuration for external tools integration
 */
@Configuration
public class ToolsConfig {

    @Value("${elk.api.url}")
    private String elkApiUrl;

    @Value("${elk.api.token}")
    private String elkApiToken;

    @Value("${jira.api.url}")
    private String jiraApiUrl;

    @Value("${jira.api.token}")
    private String jiraApiToken;

    @Value("${dynatrace.api.url}")
    private String dynatraceApiUrl;

    @Value("${dynatrace.api.token}")
    private String dynatraceApiToken;

    @Value("${github.api.url:https://api.github.com}")
    private String githubApiUrl;

    @Value("${github.token}")
    private String githubToken;

    @Value("${jenkins.url}")
    private String jenkinsUrl;

    @Value("${jenkins.token}")
    private String jenkinsToken;

    @Value("${k8s.api.url}")
    private String k8sApiUrl;

    @Value("${k8s.api.token}")
    private String k8sApiToken;

    @Bean
    public RestTemplate toolsRestTemplate() {
        return new RestTemplate();
    }

    // Getters
    public String getElkApiUrl() {
        return elkApiUrl;
    }

    public String getElkApiToken() {
        return elkApiToken;
    }

    public String getJiraApiUrl() {
        return jiraApiUrl;
    }

    public String getJiraApiToken() {
        return jiraApiToken;
    }

    public String getDynatraceApiUrl() {
        return dynatraceApiUrl;
    }

    public String getDynatraceApiToken() {
        return dynatraceApiToken;
    }

    public String getGithubApiUrl() {
        return githubApiUrl;
    }

    public String getGithubToken() {
        return githubToken;
    }

    public String getJenkinsUrl() {
        return jenkinsUrl;
    }

    public String getJenkinsToken() {
        return jenkinsToken;
    }

    public String getK8sApiUrl() {
        return k8sApiUrl;
    }

    public String getK8sApiToken() {
        return k8sApiToken;
    }
}
