package com.att.traceiq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * TraceIQ Application - AI-Powered Root Cause Analysis Platform
 * 
 * This application provides intelligent trace analysis using LangGraph4j workflows
 * to orchestrate multi-system integrations and AI-powered RCA generation.
 * 
 * Key Features:
 * - Automated error detection from ELK logs
 * - AI-powered root cause analysis using internal LLM
 * - Vectorized codebase search for code location
 * - Multi-system integration (Jira, GitHub, Dynatrace, etc.)
 * - Smart AI optimization (conditional execution)
 * 
 * @author AT&T Order Graph Team
 * @version 1.0.0
 */
@SpringBootApplication
@EnableCaching
@EnableAsync
public class TraceIQApplication {

    public static void main(String[] args) {
        SpringApplication.run(TraceIQApplication.class, args);
    }
}
