package com.traceiq.tools.adapter;

import com.traceiq.tools.config.ToolsConfig;
import com.traceiq.utils.JsonUtil;
import com.traceiq.utils.RetryUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Base64;
import java.util.Map;

/**
 * Adapter for Jenkins API integration
 * Query job status and build information
 */
@Component
public class JenkinsAdapter {
    private static final Logger logger = LoggerFactory.getLogger(JenkinsAdapter.class);

    private final RestTemplate restTemplate;
    private final ToolsConfig toolsConfig;

    public JenkinsAdapter(RestTemplate restTemplate, ToolsConfig toolsConfig) {
        this.restTemplate = restTemplate;
        this.toolsConfig = toolsConfig;
    }

    /**
     * Get job status
     */
    public Map<String, Object> getJobStatus(String jobName, String correlationId) {
        return RetryUtil.executeWithDefaultRetry(() -> {
            logger.info("[{}] Fetching Jenkins job status: {}", correlationId, jobName);

            HttpHeaders headers = new HttpHeaders();
            String auth = "admin:" + toolsConfig.getJenkinsToken();
            String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes());
            headers.set("Authorization", "Basic " + encodedAuth);
            headers.set("X-Correlation-Id", correlationId);

            HttpEntity<Void> entity = new HttpEntity<>(headers);

            ResponseEntity<String> response = restTemplate.exchange(
                    toolsConfig.getJenkinsUrl() + "/job/" + jobName + "/api/json",
                    HttpMethod.GET,
                    entity,
                    String.class
            );

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                logger.info("[{}] Job status fetched successfully", correlationId);
                return JsonUtil.fromJson(response.getBody(), Map.class);
            }

            throw new RuntimeException("Failed to fetch job status");

        }, "Jenkins-Get-Job-Status");
    }

    /**
     * Get build information
     */
    public Map<String, Object> getBuildInfo(String jobName, int buildNumber, String correlationId) {
        return RetryUtil.executeWithDefaultRetry(() -> {
            logger.info("[{}] Fetching Jenkins build info: {}/{}", correlationId, jobName, buildNumber);

            HttpHeaders headers = new HttpHeaders();
            String auth = "admin:" + toolsConfig.getJenkinsToken();
            String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes());
            headers.set("Authorization", "Basic " + encodedAuth);
            headers.set("X-Correlation-Id", correlationId);

            HttpEntity<Void> entity = new HttpEntity<>(headers);

            ResponseEntity<String> response = restTemplate.exchange(
                    toolsConfig.getJenkinsUrl() + "/job/" + jobName + "/" + buildNumber + "/api/json",
                    HttpMethod.GET,
                    entity,
                    String.class
            );

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                logger.info("[{}] Build info fetched successfully", correlationId);
                return JsonUtil.fromJson(response.getBody(), Map.class);
            }

            throw new RuntimeException("Failed to fetch build info");

        }, "Jenkins-Get-Build-Info");
    }
}
