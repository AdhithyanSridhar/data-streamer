package com.traceiq.models.enums;

/**
 * Status of scheduled jobs (e.g., nightly ingest)
 */
public enum JobStatus {
    SCHEDULED,
    RUNNING,
    COMPLETED,
    FAILED,
    CANCELLED
}
