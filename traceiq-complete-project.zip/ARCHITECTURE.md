# TraceIQ Architecture Documentation

## System Overview

TraceIQ is a monolithic Spring Boot application using LangGraph4j for workflow orchestration. It integrates with 8+ external systems to provide intelligent RCA analysis.

### Design Principles
1. **Single Deployment Unit**: Monolithic architecture for simpler state management
2. **Conditional AI Execution**: AI only called when errors/complexity detected
3. **Stateful Workflows**: LangGraph4j manages multi-step analysis flows
4. **Tool-Based Integration**: Spring AI tools wrap external API calls
5. **Caching Strategy**: Reduce redundant AI/API calls

## Architecture Layers

### Layer 1: Presentation (Vue.js Frontend)
- **Technology**: Vue 3 + Vite + Pinia
- **Components**: TraceSearch, AnalysisView, Dashboard
- **State Management**: Pinia stores for trace and analysis data
- **API Communication**: Axios with interceptors

### Layer 2: API Gateway (Spring Boot Controllers)
- **TraceController**: `/api/trace/*` - Trace search and ELK data
- **AnalysisController**: `/api/analyze/*` - AI-powered analysis
- **JiraController**: `/api/jira/*` - Ticket management

### Layer 3: Orchestration (LangGraph4j)
- **Graph Definition**: Nodes + Conditional Edges
- **State Management**: AgentState record passed through nodes
- **Decision Logic**: Skip AI for simple queries, execute full workflow for errors

#### Graph Structure
```
START → ELK_DATA_NODE
         ↓
    [Decision: Is Error?]
         ↓ YES                    ↓ NO
    AI_ANALYSIS_NODE        SUMMARY_NODE → END
         ↓
    CODE_LOCATION_NODE
         ↓
    [Decision: Create Jira?]
         ↓ YES                    ↓ NO
    JIRA_CREATION_NODE → END     END
```

### Layer 4: Tools (Spring AI Tool Calling)
Each tool is a Spring-managed bean with `@Description` annotated methods:
- **JiraTool**: View tickets, comments, attachments
- **ELKTool**: Query logs, error grouping, performance analysis
- **GitHubTool**: Recent PRs, code owners, repo overview
- **DynatraceTool**: APM metrics, service dependencies
- **JenkinsTool**: Build status, deployment info, Sonar results
- **K8sTool**: Pod status, resource utilization
- **AIAnalysisTool**: RCA, fix suggestions, guardrails
- **CodeSearchTool**: Locate code, get implementation details

### Layer 5: Client Layer (API Wrappers)
- RestClient-based HTTP clients for each external system
- Retry logic, timeout handling, error mapping
- Token management and authentication

### Layer 6: External Systems
- **Jira**: Ticket management
- **ELK/Kibana**: Log aggregation
- **GitHub**: Source code management
- **Dynatrace**: APM and monitoring
- **Jenkins/GitHub Actions**: CI/CD
- **Kubernetes**: Container orchestration
- **Internal GPT-4 LLM**: General RCA analysis
- **Code Search LLM**: Vectorized codebase search

## Data Flow

### Use Case 1: Error Trace Analysis (Full Workflow)
1. User enters TraceID → **TraceController**
2. Controller calls **TraceAnalysisService**
3. Service initiates **LangGraph4j workflow**:
   - **ELKDataNode**: Fetch logs via ELKTool
   - Decision: Errors found → Continue
   - **AIAnalysisNode**: Send logs to Internal LLM via AIAnalysisTool
   - **CodeLocationNode**: Search code via CodeSearchTool
   - Decision: User wants Jira → Yes
   - **JiraCreationNode**: Create ticket via JiraTool
4. Return **AnalysisResponse** to frontend
5. Frontend displays: Logs + RCA + Code Location + Jira Link

### Use Case 2: Simple Log Query (Optimized)
1. User enters TraceID for info logs → **TraceController**
2. Controller calls **TraceAnalysisService**
3. Service initiates **LangGraph4j workflow**:
   - **ELKDataNode**: Fetch logs via ELKTool
   - Decision: No errors, info logs only → Skip AI
   - **SummaryNode**: Format logs, return summary
4. Return simple response (no AI cost incurred)
5. Frontend displays logs only

### Use Case 3: Config Issue Detection (Rule-Based)
1. User enters TraceID → **TraceController**
2. **ELKDataNode**: Fetch logs
3. **ConfigDetector**: Pattern match for known config issues
4. Decision: Config issue detected → Skip AI, return known fix
5. Frontend displays: "Config Issue Detected" + Fix Steps

## State Management

### AgentState Record
```java
public record AgentState(
    String traceId,
    String errorMessage,
    List<String> elkLogs,
    String rcaSummary,
    String codeLocation,
    String fixSuggestion,
    String microserviceName,
    String teamEmail,
    Map<String, Object> metadata,
    boolean requiresAI,
    WorkflowStep currentStep
) {}
```

State is immutable and transformed at each node, creating a new instance.

## AI Optimization Strategy

### When to Skip AI
- Info-only logs (no errors/warnings)
- Known config patterns (Connection refused + config in message)
- Repeated queries (cached results)
- Simple status checks

### When to Use AI
- Unknown error patterns
- Complex multi-service failures
- Performance degradation analysis
- Fix suggestion requests

### Caching
- **Cache Key**: `traceId + analysisType`
- **TTL**: 60 minutes
- **Storage**: Caffeine in-memory cache
- **Invalidation**: Manual or TTL expiry

## Scalability Considerations

### Current Design (Single Service)
- **Pros**: Simple deployment, shared state, faster development
- **Cons**: Single point of failure, vertical scaling only

### Future Microservices Migration Path
If load exceeds single service capacity:
1. **Extract Analysis Service**: AI + Code Search logic
2. **Extract Integration Service**: External API clients
3. **Keep Orchestration Service**: LangGraph4j coordinator
4. **Shared Database**: PostgreSQL with connection pooling
5. **Message Queue**: Kafka for async analysis

### Horizontal Scaling
- **Stateless Design**: All state in AgentState, no in-memory sessions
- **Database Bottleneck**: Use read replicas for ELK cache
- **API Rate Limits**: Implement queue-based throttling

## Security

### Authentication
- **API Tokens**: All external APIs use bearer tokens
- **Environment Variables**: Secrets managed via K8s secrets
- **No Hardcoding**: Zero credentials in code

### Authorization
- **Team-Based**: Users can only view traces for their microservices
- **Directory Integration**: Webphone API for team membership

### Data Protection
- **No PII Logging**: Sanitize logs before AI submission
- **Encryption**: TLS for all external communication
- **Audit Trail**: Log all Jira creations and AI calls

## Monitoring

### Application Metrics
- **Spring Actuator**: `/actuator/health`, `/actuator/metrics`
- **Custom Metrics**: AI call count, cache hit rate, workflow duration

### Logging
- **SLF4J**: Structured logging with traceId correlation
- **Log Levels**: DEBUG for graph execution, INFO for API calls
- **Centralized**: Logs sent to ELK for analysis

### Alerting
- **High AI Usage**: Alert if >1000 AI calls/hour
- **API Failures**: Alert if any external API >5% error rate
- **Workflow Timeouts**: Alert if analysis >30 seconds

## Technology Choices Rationale

### Why LangGraph4j over plain Spring AI?
- **Stateful Workflows**: Built-in state management
- **Conditional Execution**: Easy to skip nodes based on state
- **Observability**: Graph visualization for debugging
- **Reusability**: Nodes can be reused in different graphs

### Why Monolithic over Microservices?
- **Team Size**: 10 teams, shared platform
- **Simplicity**: Faster onboarding, easier debugging
- **State Sharing**: Graph state naturally shared
- **Migration Path**: Can extract services later if needed

### Why PostgreSQL over NoSQL?
- **Structured Data**: Traces, tickets, analysis results are relational
- **ACID**: Critical for ticket creation consistency
- **pgvector**: Future semantic search on analysis history
- **Team Familiarity**: Teams already use PostgreSQL

## Future Enhancements

### Phase 2: Proactive Analysis
- **Scheduled Scans**: Analyze all ERROR logs nightly
- **Trend Detection**: Identify recurring issues
- **Auto-Remediation**: Trigger config fixes automatically

### Phase 3: Predictive Analytics
- **ML Models**: Predict issue likelihood before occurrence
- **Anomaly Detection**: Flag unusual patterns in logs
- **Capacity Planning**: Recommend scaling before incidents

### Phase 4: Self-Healing
- **Auto-Rollback**: Detect bad deployments, trigger rollback
- **Auto-Scaling**: Increase pods based on error rate
- **Circuit Breaker**: Disable failing features automatically
