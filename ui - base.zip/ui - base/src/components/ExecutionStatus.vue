<template>
  <div class="glass-card pa-5">
    <div class="section-header">
      <div class="section-header__icon">
        <v-icon icon="mdi-play-circle-outline" size="20"></v-icon>
      </div>
      <h2 class="section-header__title">Execution Status</h2>
    </div>
    
    <div class="status-sections">
      <!-- Completed -->
      <div class="status-section">
        <div class="section-label">
          <v-icon icon="mdi-check-circle-outline" size="16"></v-icon>
          <span>Completed ({{ status.completedActions.length }})</span>
        </div>
        <div class="actions-list">
          <div v-for="(action, idx) in status.completedActions" :key="idx" class="action-item action-completed">
            <v-icon icon="mdi-check" size="14"></v-icon>
            <span>{{ action }}</span>
          </div>
        </div>
      </div>
      
      <!-- Pending -->
      <div class="status-section" v-if="status.pendingActions.length">
        <div class="section-label">
          <v-icon icon="mdi-clock-outline" size="16"></v-icon>
          <span>Pending ({{ status.pendingActions.length }})</span>
        </div>
        <div class="actions-list">
          <div v-for="(action, idx) in status.pendingActions" :key="idx" class="action-item action-pending">
            <v-icon icon="mdi-clock-outline" size="14"></v-icon>
            <span>{{ action }}</span>
          </div>
        </div>
      </div>
      
      <!-- Failed -->
      <div class="status-section" v-if="status.failedActions.length">
        <div class="section-label">
          <v-icon icon="mdi-close-circle-outline" size="16"></v-icon>
          <span>Failed ({{ status.failedActions.length }})</span>
        </div>
        <div class="actions-list">
          <div v-for="(action, idx) in status.failedActions" :key="idx" class="action-item action-failed">
            <v-icon icon="mdi-close" size="14"></v-icon>
            <span>{{ action }}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  status: { type: Object, required: true }
})
</script>

<style scoped>
.status-sections {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.status-section {
  background: #f5f5f5;
  border-radius: 8px;
  padding: 12px;
}

.section-label {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 0.8rem;
  font-weight: 600;
  color: #1a1a1a;
  margin-bottom: 12px;
}

.actions-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.action-item {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  font-size: 0.8rem;
  padding: 6px 0;
}

.action-completed {
  color: #059669;
}

.action-pending {
  color: #666666;
}

.action-failed {
  color: #dc2626;
}
</style>
