package com.traceiq.ingest.repository;

import com.datastax.oss.driver.api.core.CqlSession;
import com.datastax.oss.driver.api.core.cql.*;
import com.traceiq.models.domain.ErrorRecord;
import com.traceiq.models.domain.JobRun;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Repository
public class CassandraRepository {
    private static final Logger logger = LoggerFactory.getLogger(CassandraRepository.class);
    private final CqlSession session;

    public CassandraRepository(CqlSession session) {
        this.session = session;
    }

    public void insertErrorRecord(ErrorRecord error) {
        String query = "INSERT INTO errors (trace_id, message, service, severity, stack_trace, owner_email, team_name, timestamp, ingested_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement prepared = session.prepare(query);
        BoundStatement bound = prepared.bind(
            error.traceId(),
            error.message(),
            error.service(),
            error.severity().name(),
            error.stackTrace(),
            error.ownerEmail(),
            error.teamName(),
            error.timestamp(),
            error.ingestedAt()
        );
        session.execute(bound);
    }

    public List<ErrorRecord> getAllErrors() {
        String query = "SELECT * FROM errors";
        ResultSet rs = session.execute(query);
        List<ErrorRecord> errors = new ArrayList<>();
        for (Row row : rs) {
            errors.add(mapRowToErrorRecord(row));
        }
        return errors;
    }

    public List<ErrorRecord> getErrorsByTraceId(String traceId) {
        String query = "SELECT * FROM errors WHERE trace_id = ?";
        PreparedStatement prepared = session.prepare(query);
        BoundStatement bound = prepared.bind(traceId);
        ResultSet rs = session.execute(bound);
        List<ErrorRecord> errors = new ArrayList<>();
        for (Row row : rs) {
            errors.add(mapRowToErrorRecord(row));
        }
        return errors;
    }

    public void insertJobRun(JobRun jobRun) {
        String query = "INSERT INTO job_runs (job_id, job_name, status, start_time, end_time, records_processed, error_message) VALUES (?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement prepared = session.prepare(query);
        BoundStatement bound = prepared.bind(
            jobRun.jobId(),
            jobRun.jobName(),
            jobRun.status().name(),
            jobRun.startTime(),
            jobRun.endTime(),
            jobRun.recordsProcessed(),
            jobRun.errorMessage()
        );
        session.execute(bound);
    }

    public List<JobRun> getAllJobRuns() {
        String query = "SELECT * FROM job_runs";
        ResultSet rs = session.execute(query);
        List<JobRun> jobs = new ArrayList<>();
        for (Row row : rs) {
            jobs.add(mapRowToJobRun(row));
        }
        return jobs;
    }

    private ErrorRecord mapRowToErrorRecord(Row row) {
        return ErrorRecord.builder()
            .traceId(row.getString("trace_id"))
            .message(row.getString("message"))
            .service(row.getString("service"))
            .severity(com.traceiq.models.enums.ErrorSeverity.valueOf(row.getString("severity")))
            .stackTrace(row.getString("stack_trace"))
            .ownerEmail(row.getString("owner_email"))
            .teamName(row.getString("team_name"))
            .timestamp(row.getInstant("timestamp"))
            .ingestedAt(row.getInstant("ingested_at"))
            .build();
    }

    private JobRun mapRowToJobRun(Row row) {
        return JobRun.builder()
            .jobId(row.getString("job_id"))
            .jobName(row.getString("job_name"))
            .status(com.traceiq.models.enums.JobStatus.valueOf(row.getString("status")))
            .startTime(row.getInstant("start_time"))
            .endTime(row.getInstant("end_time"))
            .recordsProcessed(row.getLong("records_processed"))
            .errorMessage(row.getString("error_message"))
            .build();
    }
}
