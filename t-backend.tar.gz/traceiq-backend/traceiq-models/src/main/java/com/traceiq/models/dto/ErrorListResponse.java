package com.traceiq.models.dto;

import com.traceiq.models.domain.ErrorRecord;

import java.util.List;

/**
 * Response DTO for listing all errors
 */
public record ErrorListResponse(
        List<ErrorRecord> errors,
        Integer totalCount,
        Integer page,
        Integer pageSize
) {
    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private List<ErrorRecord> errors;
        private Integer totalCount;
        private Integer page;
        private Integer pageSize;

        public Builder errors(List<ErrorRecord> errors) {
            this.errors = errors;
            return this;
        }

        public Builder totalCount(Integer totalCount) {
            this.totalCount = totalCount;
            return this;
        }

        public Builder page(Integer page) {
            this.page = page;
            return this;
        }

        public Builder pageSize(Integer pageSize) {
            this.pageSize = pageSize;
            return this;
        }

        public ErrorListResponse build() {
            return new ErrorListResponse(errors, totalCount, page, pageSize);
        }
    }
}
