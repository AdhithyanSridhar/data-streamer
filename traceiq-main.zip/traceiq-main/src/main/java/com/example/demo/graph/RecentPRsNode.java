package com.example.demo.graph;

import com.example.demo.tools.GitTool;
import org.springframework.stereotype.Component;

@Component
public class RecentPRsNode implements Node {

    public static final String NAME = "recentPRs";
    private final GitTool gitTool;

    public RecentPRsNode(GitTool gitTool) {
        this.gitTool = gitTool;
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public GraphState apply(GraphState state) {
        try {
            // This might need a repository name, assuming it's available in the state.
            String repository = state.get("repository");
            if (repository != null) {
                GitTool.RecentPRsResponse response = gitTool.getRecentPRs(new GitTool.RecentPRsRequest(repository));
                state.set("recentPRs", response.prs());
            } else {
                state.set(NAME + "_info", "No repository found to get recent PRs from.");
            }
        } catch (Exception e) {
            state.set(NAME + "_error", "Failed to get recent PRs: " + e.getMessage());
        }
        return state;
    }
}
