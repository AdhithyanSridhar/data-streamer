<template>
  <div class="glass-card pa-5">
    <div class="section-header">
      <div class="section-header__icon">
        <v-icon icon="mdi-flag-checkered" size="20"></v-icon>
      </div>
      <h2 class="section-header__title">Final Status</h2>
    </div>
    
    <div class="status-items">
      <div class="status-item">
        <span class="status-label">Issue #{{ finalStatus.issueNumber }}</span>
        <v-chip :color="finalStatus.issueStatus === 'closed' ? 'success' : 'info'" size="small" variant="flat">
          {{ finalStatus.issueStatus }}
        </v-chip>
      </div>
      
      <div class="status-item">
        <span class="status-label">PR #{{ finalStatus.prNumber }}</span>
        <v-chip :color="finalStatus.prStatus === 'merged' ? 'success' : 'info'" size="small" variant="flat">
          {{ finalStatus.prStatus }}
        </v-chip>
      </div>
      
      <div class="status-item">
        <span class="status-label">Auto-close</span>
        <v-chip :color="finalStatus.autoClosePerformed ? 'success' : 'default'" size="small" variant="flat">
          {{ finalStatus.autoClosePerformed ? 'Yes' : 'Pending' }}
        </v-chip>
      </div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  finalStatus: { type: Object, required: true }
})
</script>

<style scoped>
.status-items {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.status-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px;
  background: #f5f5f5;
  border-radius: 8px;
}

.status-label {
  font-size: 0.9rem;
  font-weight: 500;
  color: #1a1a1a;
}
</style>
