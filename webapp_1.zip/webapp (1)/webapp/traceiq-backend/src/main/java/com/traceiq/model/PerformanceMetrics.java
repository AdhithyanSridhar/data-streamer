package com.traceiq.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.List;
import java.util.Map;

/**
 * Performance and latency metrics from trace analysis.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record PerformanceMetrics(
    long totalDurationMs,
    long avgResponseTimeMs,
    Map<String, Long> serviceLatencies,
    List<BottleneckInfo> bottlenecks,
    String performanceSummary
) {}

@JsonInclude(JsonInclude.Include.NON_NULL)
record BottleneckInfo(
    String serviceName,
    String operationName,
    long durationMs,
    String reason
) {}
