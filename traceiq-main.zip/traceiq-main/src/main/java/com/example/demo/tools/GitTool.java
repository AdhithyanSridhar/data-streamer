package com.example.demo.tools;

import dev.langchain4j.agent.tool.Tool;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class GitTool {

    @Tool("Get recent pull requests")
    public RecentPRsResponse getRecentPRs(RecentPRsRequest recentPRsRequest) {
        System.out.println("Getting recent PRs for: " + recentPRsRequest.repository);
        return new RecentPRsResponse("Simulated recent PRs for " + recentPRsRequest.repository + ": ...");
    }

    @Tool("Get PRs for a file")
    public PRsForFileResponse getPRsForFile(PRsForFileRequest prsForFileRequest) {
        System.out.println("Getting PRs for file: " + prsForFileRequest.file);
        return new PRsForFileResponse("Simulated PRs for file " + prsForFileRequest.file + ": ...");
    }

    @Tool("Get code owners for a list of files")
    public CodeOwnersResponse getCodeOwners(CodeOwnersRequest codeOwnersRequest) {
        System.out.println("Getting code owners for: " + codeOwnersRequest.files);
        return new CodeOwnersResponse("Simulated code owners for " + codeOwnersRequest.files + ": ...");
    }

    public record RecentPRsRequest(String repository) {}

    public record RecentPRsResponse(String prs) {}

    public record PRsForFileRequest(String file) {}

    public record PRsForFileResponse(String prs) {}

    public record CodeOwnersRequest(List<String> files) {}

    public record CodeOwnersResponse(String owners) {}
}
