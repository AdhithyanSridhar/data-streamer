<template>
  <v-container fluid class="pa-6">
    <!-- Page Header -->
    <div class="page-header mb-6">
      <h1 class="page-title">System Status</h1>
      <p class="page-subtitle">Real-time health monitoring of all TraceIQ services</p>
    </div>

    <!-- Overall Status Banner -->
    <div class="status-banner glass-card pa-5 mb-6" :class="`status-banner--${overallStatus}`">
      <div class="status-banner-icon">
        <v-icon :icon="getStatusIcon(overallStatus)" size="48"></v-icon>
      </div>
      <div class="status-banner-content">
        <h2 class="status-banner-title">{{ getStatusTitle(overallStatus) }}</h2>
        <p class="status-banner-subtitle">Last updated: {{ lastUpdated }}</p>
      </div>
      <div class="status-banner-action">
        <v-btn variant="outlined" @click="refreshStatus">
          <v-icon icon="mdi-refresh" class="mr-1"></v-icon>
          Refresh
        </v-btn>
      </div>
    </div>

    <!-- Uptime Stats -->
    <v-row class="mb-6">
      <v-col cols="12" sm="6" md="3" v-for="stat in uptimeStats" :key="stat.title">
        <div class="glass-card pa-4 uptime-card">
          <div class="uptime-value">{{ stat.value }}</div>
          <div class="uptime-label">{{ stat.label }}</div>
          <div class="uptime-bar">
            <div class="uptime-progress" :style="{ width: stat.percentage + '%', background: stat.color }"></div>
          </div>
        </div>
      </v-col>
    </v-row>

    <!-- Services Grid -->
    <div class="glass-card pa-5 mb-6">
      <div class="section-header mb-4">
        <div class="section-header__icon">
          <v-icon icon="mdi-server-outline" size="20"></v-icon>
        </div>
        <span class="section-header__title">Service Status</span>
      </div>

      <div class="services-grid">
        <div v-for="service in services" :key="service.name" class="service-status-card" :class="`service-status-card--${service.status}`">
          <div class="service-status-indicator">
            <span class="status-dot" :class="`status-dot--${service.status}`"></span>
          </div>
          <div class="service-info">
            <span class="service-name">{{ service.name }}</span>
            <span class="service-description">{{ service.description }}</span>
          </div>
          <div class="service-metrics">
            <div class="metric">
              <span class="metric-value">{{ service.uptime }}%</span>
              <span class="metric-label">Uptime</span>
            </div>
            <div class="metric">
              <span class="metric-value">{{ service.latency }}ms</span>
              <span class="metric-label">Latency</span>
            </div>
          </div>
          <div class="service-chart">
            <svg viewBox="0 0 100 30" class="mini-uptime-chart">
              <polyline :points="service.uptimeHistory" fill="none" :stroke="getStatusColor(service.status)" stroke-width="2"/>
            </svg>
          </div>
        </div>
      </div>
    </div>

    <!-- Incident History -->
    <div class="glass-card pa-5">
      <div class="section-header mb-4">
        <div class="section-header__icon">
          <v-icon icon="mdi-history" size="20"></v-icon>
        </div>
        <span class="section-header__title">Recent Incidents</span>
      </div>

      <div class="incidents-timeline">
        <div v-for="day in incidentHistory" :key="day.date" class="timeline-day">
          <div class="day-header">
            <span class="day-date">{{ day.date }}</span>
            <v-chip :color="day.incidents.length === 0 ? 'success' : 'warning'" size="x-small" variant="flat">
              {{ day.incidents.length === 0 ? 'No incidents' : `${day.incidents.length} incident(s)` }}
            </v-chip>
          </div>
          
          <div class="day-uptime-bar">
            <div 
              v-for="(segment, idx) in day.segments" 
              :key="idx"
              class="uptime-segment"
              :class="`uptime-segment--${segment.status}`"
              :style="{ width: segment.width + '%' }"
              :title="segment.tooltip"
            ></div>
          </div>
          
          <div v-if="day.incidents.length" class="day-incidents">
            <div v-for="incident in day.incidents" :key="incident.id" class="mini-incident">
              <span class="incident-time">{{ incident.time }}</span>
              <span class="incident-title">{{ incident.title }}</span>
              <span class="incident-duration">{{ incident.duration }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </v-container>
</template>

<script setup>
import { ref } from 'vue'

const overallStatus = ref('operational')
const lastUpdated = ref(new Date().toLocaleTimeString())

const uptimeStats = [
  { value: '99.98%', label: 'Last 24 Hours', percentage: 99.98, color: '#10b981' },
  { value: '99.95%', label: 'Last 7 Days', percentage: 99.95, color: '#10b981' },
  { value: '99.91%', label: 'Last 30 Days', percentage: 99.91, color: '#10b981' },
  { value: '99.87%', label: 'Last 90 Days', percentage: 99.87, color: '#10b981' }
]

const services = [
  { name: 'TraceIQ API', description: 'Core API services', status: 'operational', uptime: 99.99, latency: 45, uptimeHistory: '0,5 20,5 40,5 60,5 80,5 100,5' },
  { name: 'AI Engine', description: 'LLM reasoning services', status: 'operational', uptime: 99.95, latency: 120, uptimeHistory: '0,8 20,5 40,7 60,5 80,6 100,5' },
  { name: 'Data Pipeline', description: 'ELK ingestion', status: 'operational', uptime: 99.92, latency: 85, uptimeHistory: '0,5 20,10 40,5 60,8 80,5 100,5' },
  { name: 'Agent Service', description: 'Automated remediation', status: 'degraded', uptime: 98.50, latency: 250, uptimeHistory: '0,5 20,5 40,15 60,20 80,10 100,8' },
  { name: 'GitHub Integration', description: 'Issue & PR management', status: 'operational', uptime: 99.99, latency: 180, uptimeHistory: '0,5 20,5 40,5 60,5 80,5 100,5' },
  { name: 'Slack Integration', description: 'Notifications', status: 'operational', uptime: 99.97, latency: 95, uptimeHistory: '0,5 20,8 40,5 60,5 80,7 100,5' }
]

const incidentHistory = [
  {
    date: 'Today',
    segments: Array(24).fill({ status: 'operational', width: 4.17, tooltip: 'Operational' }),
    incidents: []
  },
  {
    date: 'Yesterday',
    segments: [
      ...Array(14).fill({ status: 'operational', width: 4.17, tooltip: 'Operational' }),
      { status: 'degraded', width: 4.17, tooltip: '14:00 - Degraded performance' },
      { status: 'degraded', width: 4.17, tooltip: '15:00 - Degraded performance' },
      ...Array(8).fill({ status: 'operational', width: 4.17, tooltip: 'Operational' })
    ],
    incidents: [
      { id: 1, time: '14:00 - 16:00', title: 'Agent Service degraded performance', duration: '2h' }
    ]
  },
  {
    date: 'Dec 8, 2024',
    segments: Array(24).fill({ status: 'operational', width: 4.17, tooltip: 'Operational' }),
    incidents: []
  }
]

const getStatusIcon = (status) => {
  const icons = {
    operational: 'mdi-check-circle',
    degraded: 'mdi-alert-circle',
    outage: 'mdi-close-circle'
  }
  return icons[status] || icons.operational
}

const getStatusTitle = (status) => {
  const titles = {
    operational: 'All Systems Operational',
    degraded: 'Partial System Outage',
    outage: 'Major System Outage'
  }
  return titles[status] || titles.operational
}

const getStatusColor = (status) => {
  const colors = {
    operational: '#10b981',
    degraded: '#f59e0b',
    outage: '#ef4444'
  }
  return colors[status] || colors.operational
}

const refreshStatus = () => {
  lastUpdated.value = new Date().toLocaleTimeString()
}
</script>

<style scoped>
.page-header { text-align: center; padding: 20px 0; }
.page-title { font-size: 1.5rem; font-weight: 700; color: #1a1a1a; margin-bottom: 8px; }
.page-subtitle { font-size: 0.9rem; color: #666666; }

.status-banner { display: flex; align-items: center; gap: 20px; }
.status-banner--operational { border-left: 4px solid #10b981; }
.status-banner--degraded { border-left: 4px solid #f59e0b; }
.status-banner--outage { border-left: 4px solid #ef4444; }
.status-banner-icon { color: #10b981; }
.status-banner--degraded .status-banner-icon { color: #f59e0b; }
.status-banner--outage .status-banner-icon { color: #ef4444; }
.status-banner-content { flex: 1; }
.status-banner-title { font-size: 1.2rem; font-weight: 600; color: #1a1a1a; }
.status-banner-subtitle { font-size: 0.8rem; color: #666666; }

.uptime-card { text-align: center; }
.uptime-value { font-size: 1.75rem; font-weight: 700; color: #1a1a1a; }
.uptime-label { font-size: 0.8rem; color: #666666; margin-bottom: 12px; }
.uptime-bar { height: 6px; background: #e5e5e5; border-radius: 3px; overflow: hidden; }
.uptime-progress { height: 100%; border-radius: 3px; transition: width 0.5s ease; }

.services-grid { display: flex; flex-direction: column; gap: 12px; }
.service-status-card { display: flex; align-items: center; gap: 16px; padding: 16px; background: #f5f5f5; border-radius: 10px; border-left: 4px solid; }
.service-status-card--operational { border-color: #10b981; }
.service-status-card--degraded { border-color: #f59e0b; }
.service-status-card--outage { border-color: #ef4444; }

.service-status-indicator { flex-shrink: 0; }
.status-dot { width: 12px; height: 12px; border-radius: 50%; display: inline-block; }
.status-dot--operational { background: #10b981; animation: pulse 2s infinite; }
.status-dot--degraded { background: #f59e0b; animation: pulse 1s infinite; }
.status-dot--outage { background: #ef4444; animation: pulse 0.5s infinite; }

.service-info { flex: 1; }
.service-name { font-weight: 600; color: #1a1a1a; display: block; }
.service-description { font-size: 0.8rem; color: #666666; }

.service-metrics { display: flex; gap: 24px; }
.metric { text-align: center; }
.metric-value { font-size: 1rem; font-weight: 600; color: #1a1a1a; display: block; }
.metric-label { font-size: 0.7rem; color: #666666; }

.service-chart { width: 100px; height: 30px; }
.mini-uptime-chart { width: 100%; height: 100%; }

.incidents-timeline { display: flex; flex-direction: column; gap: 16px; }
.timeline-day { padding: 16px; background: #f5f5f5; border-radius: 8px; }
.day-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
.day-date { font-weight: 600; color: #1a1a1a; }
.day-uptime-bar { display: flex; height: 24px; border-radius: 4px; overflow: hidden; }
.uptime-segment { transition: all 0.2s; }
.uptime-segment--operational { background: #10b981; }
.uptime-segment--degraded { background: #f59e0b; }
.uptime-segment--outage { background: #ef4444; }
.uptime-segment:hover { opacity: 0.8; transform: scaleY(1.1); }

.day-incidents { margin-top: 12px; }
.mini-incident { display: flex; gap: 12px; font-size: 0.8rem; padding: 8px; background: #ffffff; border-radius: 4px; }
.incident-time { color: #666666; }
.incident-title { flex: 1; color: #1a1a1a; }
.incident-duration { color: #999999; }

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}
</style>
