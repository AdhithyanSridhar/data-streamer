import { createRouter, createWebHistory } from 'vue-router'
import TraceSearch from './views/TraceSearch.vue'
import ErrorsList from './views/ErrorsList.vue'
import Jobs from './views/Jobs.vue'
import Help from './views/Help.vue'

const routes = [
  {
    path: '/',
    name: 'TraceSearch',
    component: TraceSearch
  },
  {
    path: '/errors',
    name: 'ErrorsList',
    component: ErrorsList
  },
  {
    path: '/jobs',
    name: 'Jobs',
    component: Jobs
  },
  {
    path: '/help',
    name: 'Help',
    component: Help
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
