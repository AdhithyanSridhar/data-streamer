package com.att.traceiq.model;

import java.time.LocalDateTime;
import java.util.List;

public record AnalysisResponse(
    String traceId,
    List<ELKLog> logs,
    String rcaSummary,
    CodeLocation codeLocation,
    String fixSuggestion,
    String microserviceName,
    String teamEmail,
    String jiraTicketId,
    boolean aiAnalyzed,
    LocalDateTime analyzedAt,
    long processingTimeMs
) {
    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String traceId;
        private List<ELKLog> logs;
        private String rcaSummary;
        private CodeLocation codeLocation;
        private String fixSuggestion;
        private String microserviceName;
        private String teamEmail;
        private String jiraTicketId;
        private boolean aiAnalyzed;
        private LocalDateTime analyzedAt = LocalDateTime.now();
        private long processingTimeMs;

        public Builder traceId(String traceId) {
            this.traceId = traceId;
            return this;
        }

        public Builder logs(List<ELKLog> logs) {
            this.logs = logs;
            return this;
        }

        public Builder rcaSummary(String rcaSummary) {
            this.rcaSummary = rcaSummary;
            return this;
        }

        public Builder codeLocation(CodeLocation codeLocation) {
            this.codeLocation = codeLocation;
            return this;
        }

        public Builder fixSuggestion(String fixSuggestion) {
            this.fixSuggestion = fixSuggestion;
            return this;
        }

        public Builder microserviceName(String microserviceName) {
            this.microserviceName = microserviceName;
            return this;
        }

        public Builder teamEmail(String teamEmail) {
            this.teamEmail = teamEmail;
            return this;
        }

        public Builder jiraTicketId(String jiraTicketId) {
            this.jiraTicketId = jiraTicketId;
            return this;
        }

        public Builder aiAnalyzed(boolean aiAnalyzed) {
            this.aiAnalyzed = aiAnalyzed;
            return this;
        }

        public Builder processingTimeMs(long processingTimeMs) {
            this.processingTimeMs = processingTimeMs;
            return this;
        }

        public AnalysisResponse build() {
            return new AnalysisResponse(
                traceId, logs, rcaSummary, codeLocation, fixSuggestion,
                microserviceName, teamEmail, jiraTicketId, aiAnalyzed,
                analyzedAt, processingTimeMs
            );
        }
    }
}
