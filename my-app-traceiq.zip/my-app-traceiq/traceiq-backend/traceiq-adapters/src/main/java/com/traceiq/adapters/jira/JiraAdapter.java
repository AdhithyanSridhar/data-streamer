package com.traceiq.adapters.jira;

import com.traceiq.adapters.config.AdapterConfiguration;
import com.traceiq.utils.RetryUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

/**
 * Adapter for Jira API.
 * Creates and retrieves tickets via Spring AI tool calling.
 */
@Component
public class JiraAdapter {
    
    private static final Logger logger = LoggerFactory.getLogger(JiraAdapter.class);
    
    private final RestTemplate restTemplate;
    private final AdapterConfiguration config;
    
    public JiraAdapter(RestTemplate restTemplate, AdapterConfiguration config) {
        this.restTemplate = restTemplate;
        this.config = config;
    }
    
    /**
     * Creates a Jira ticket for the given trace error.
     *
     * @param traceId trace identifier
     * @param summary ticket summary
     * @param description ticket description
     * @param ownerEmail assignee email
     * @return created ticket ID
     */
    public String createTicket(String traceId, String summary, String description, String ownerEmail) {
        return RetryUtils.executeWithRetry(() -> {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBasicAuth("api-user", config.getJiraApiToken());
            
            Map<String, Object> fields = new HashMap<>();
            fields.put("project", Map.of("key", "TRACE"));
            fields.put("summary", summary);
            fields.put("description", description);
            fields.put("issuetype", Map.of("name", "Bug"));
            fields.put("labels", new String[]{"trace-" + traceId, "auto-generated"});
            
            Map<String, Object> requestBody = Map.of("fields", fields);
            HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);
            
            logger.info("Creating Jira ticket for traceId: {}", traceId);
            ResponseEntity<String> response = restTemplate.exchange(
                config.getJiraApiUrl() + "/rest/api/2/issue",
                HttpMethod.POST,
                request,
                String.class
            );
            
            return extractTicketId(response.getBody());
        }, "Jira Create Ticket");
    }
    
    /**
     * Retrieves ticket information by ticket ID.
     *
     * @param ticketId Jira ticket ID
     * @return ticket details as JSON string
     */
    public String getTicket(String ticketId) {
        return RetryUtils.executeWithRetry(() -> {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBasicAuth("api-user", config.getJiraApiToken());
            
            HttpEntity<Void> request = new HttpEntity<>(headers);
            
            logger.info("Retrieving Jira ticket: {}", ticketId);
            ResponseEntity<String> response = restTemplate.exchange(
                config.getJiraApiUrl() + "/rest/api/2/issue/" + ticketId,
                HttpMethod.GET,
                request,
                String.class
            );
            
            return response.getBody();
        }, "Jira Get Ticket");
    }
    
    /**
     * Updates a Jira ticket with new information.
     *
     * @param ticketId ticket ID
     * @param comment comment to add
     * @return success indicator
     */
    public boolean addComment(String ticketId, String comment) {
        return RetryUtils.executeWithRetry(() -> {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBasicAuth("api-user", config.getJiraApiToken());
            
            Map<String, Object> requestBody = Map.of("body", comment);
            HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);
            
            logger.info("Adding comment to Jira ticket: {}", ticketId);
            restTemplate.exchange(
                config.getJiraApiUrl() + "/rest/api/2/issue/" + ticketId + "/comment",
                HttpMethod.POST,
                request,
                String.class
            );
            
            return true;
        }, "Jira Add Comment");
    }
    
    private String extractTicketId(String responseBody) {
        // Simplified extraction - in production, parse JSON properly
        return "TRACE-12345";
    }
}
