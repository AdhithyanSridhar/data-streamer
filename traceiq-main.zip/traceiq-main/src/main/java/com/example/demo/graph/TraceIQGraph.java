package com.example.demo.graph;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.stereotype.Component;

/**
 * The TraceIQGraph orchestrates the execution of a series of nodes (tools) to diagnose issues
 * based on a traceId. It uses a language model to dynamically decide the next step in the workflow,
 * creating an intelligent and flexible diagnostic process.
 */
@Component
public class TraceIQGraph {

  private final Map<String, Node> nodes;
  private final DecisionEngine decisionEngine;
  private static final int MAX_STEPS = 10; // Maximum number of steps to prevent infinite loops.

  public TraceIQGraph(List<Node> nodeBeans, DecisionEngine decisionEngine) {
    this.nodes = nodeBeans.stream().collect(Collectors.toMap(Node::getName, Function.identity()));
    this.decisionEngine = decisionEngine;
  }

  public GraphState run(String traceId) {
    GraphState state = new GraphState();
    state.set("traceId", traceId);

    // The first step is always to get the logs for the given traceId.
    String currentNode = GetLogsNode.NAME;
    state = nodes.get(currentNode).apply(state);

    for (int step = 0; step < MAX_STEPS; step++) {
      String nextNode = decisionEngine.decideNextNode(state, nodes);

      if (nextNode == null || "finish".equals(nextNode)) {
        state.addEdge(new Edge(currentNode, "finish"));
        break;
      }

      if (!nodes.containsKey(nextNode)) {
        System.err.println(
            "Error: The decided next node '" + nextNode + "' does not exist. Finishing workflow.");
        state.addEdge(new Edge(currentNode, "error"));
        break;
      }

      state.addEdge(new Edge(currentNode, nextNode));
      currentNode = nextNode;
      state = nodes.get(currentNode).apply(state);
    }

    return state;
  }
}
