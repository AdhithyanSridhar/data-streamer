package com.traceiq.ingest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * TraceIQ Ingest Application.
 * Runs nightly job to ingest errors from ELK to Cassandra.
 */
@SpringBootApplication
@EnableScheduling
@ComponentScan(basePackages = {"com.traceiq"})
public class IngestApplication {
    
    private static final Logger logger = LoggerFactory.getLogger(IngestApplication.class);
    
    public static void main(String[] args) {
        logger.info("Starting TraceIQ Ingest Application...");
        SpringApplication.run(IngestApplication.class, args);
        logger.info("TraceIQ Ingest Application started successfully");
    }
}
