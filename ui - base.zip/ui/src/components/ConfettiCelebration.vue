<template>
  <Teleport to="body">
    <canvas ref="confettiCanvas" class="confetti-canvas"></canvas>
  </Teleport>
</template>

<script setup>
import { ref, onMounted } from 'vue'

const confettiCanvas = ref(null)
let ctx = null
let particles = []
let animationId = null

const colors = ['#ef4444', '#f59e0b', '#10b981', '#3b82f6', '#8b5cf6', '#ec4899']

class Particle {
  constructor(x, y) {
    this.x = x
    this.y = y
    this.size = Math.random() * 8 + 4
    this.speedX = Math.random() * 6 - 3
    this.speedY = Math.random() * -15 - 5
    this.gravity = 0.3
    this.rotation = Math.random() * 360
    this.rotationSpeed = Math.random() * 10 - 5
    this.color = colors[Math.floor(Math.random() * colors.length)]
    this.opacity = 1
    this.shape = Math.random() > 0.5 ? 'rect' : 'circle'
  }

  update() {
    this.speedY += this.gravity
    this.x += this.speedX
    this.y += this.speedY
    this.rotation += this.rotationSpeed
    this.opacity -= 0.008
  }

  draw(ctx) {
    ctx.save()
    ctx.translate(this.x, this.y)
    ctx.rotate((this.rotation * Math.PI) / 180)
    ctx.globalAlpha = this.opacity
    ctx.fillStyle = this.color

    if (this.shape === 'rect') {
      ctx.fillRect(-this.size / 2, -this.size / 2, this.size, this.size / 2)
    } else {
      ctx.beginPath()
      ctx.arc(0, 0, this.size / 2, 0, Math.PI * 2)
      ctx.fill()
    }

    ctx.restore()
  }
}

const createConfetti = (x, y, count = 100) => {
  for (let i = 0; i < count; i++) {
    particles.push(new Particle(x, y))
  }
}

const animate = () => {
  if (!ctx) return
  
  ctx.clearRect(0, 0, confettiCanvas.value.width, confettiCanvas.value.height)
  
  particles.forEach((particle, index) => {
    particle.update()
    particle.draw(ctx)
    
    if (particle.opacity <= 0 || particle.y > confettiCanvas.value.height) {
      particles.splice(index, 1)
    }
  })
  
  if (particles.length > 0) {
    animationId = requestAnimationFrame(animate)
  }
}

const celebrate = () => {
  if (!confettiCanvas.value) return
  
  const canvas = confettiCanvas.value
  canvas.width = window.innerWidth
  canvas.height = window.innerHeight
  
  // Create confetti from multiple points
  createConfetti(window.innerWidth * 0.2, window.innerHeight * 0.5, 50)
  createConfetti(window.innerWidth * 0.5, window.innerHeight * 0.3, 80)
  createConfetti(window.innerWidth * 0.8, window.innerHeight * 0.5, 50)
  
  if (!animationId) {
    animate()
  }
}

onMounted(() => {
  if (confettiCanvas.value) {
    ctx = confettiCanvas.value.getContext('2d')
    confettiCanvas.value.width = window.innerWidth
    confettiCanvas.value.height = window.innerHeight
  }
})

defineExpose({ celebrate })
</script>

<style scoped>
.confetti-canvas {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  pointer-events: none;
  z-index: 99999;
}
</style>
