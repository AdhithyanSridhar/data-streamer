package com.example.demo.graph;

import com.example.demo.tools.ElkTool;
import org.springframework.stereotype.Component;

/**
 * The AnalyzeLatencyNode is responsible for analyzing the latency of a given traceId in the ELK
 * stack.
 */
@Component
public class AnalyzeLatencyNode implements Node {

  public static final String NAME = "analyzeLatency";
  private final ElkTool elkTool;

  public AnalyzeLatencyNode(ElkTool elkTool) {
    this.elkTool = elkTool;
  }

  @Override
  public String getName() {
    return NAME;
  }

  /**
   * Analyzes latency and updates the graph state. It includes error handling to ensure the workflow
   * can continue even if latency analysis fails.
   *
   * @param state The current state of the graph, which must contain a traceId.
   * @return The updated graph state with the latency analysis or an error message.
   */
  @Override
  public GraphState apply(GraphState state) {
    try {
      String traceId = state.get("traceId");
      ElkTool.LatencyAnalysisResponse response =
          elkTool.analyzeLatency(new ElkTool.LatencyAnalysisRequest(traceId));
      state.set("latencyAnalysis", response.analysis());
    } catch (Exception e) {
      // If an error occurs, we record it in the state so the workflow can decide on the next
      // step.
      state.set(NAME + "_error", "Failed to analyze latency: " + e.getMessage());
    }
    return state;
  }
}
