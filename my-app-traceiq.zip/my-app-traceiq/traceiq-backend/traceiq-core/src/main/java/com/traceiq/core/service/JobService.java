package com.traceiq.core.service;

import com.traceiq.models.dto.JobListResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Service
public class JobService {
    
    private static final Logger logger = LoggerFactory.getLogger(JobService.class);
    
    public JobListResponse listJobs() {
        logger.info("Listing all jobs");
        
        List<JobListResponse.JobInfo> jobs = new ArrayList<>();
        
        List<JobListResponse.JobExecution> executions = new ArrayList<>();
        executions.add(new JobListResponse.JobExecution(
            "exec-001",
            Instant.now().minusSeconds(86400),
            Instant.now().minusSeconds(86100),
            "SUCCESS",
            "Ingested 1523 records",
            1523,
            0
        ));
        
        jobs.add(new JobListResponse.JobInfo(
            "elk-ingest-job",
            "ELK Nightly Ingest",
            "SCHEDULED",
            "0 0 2 * * ?",
            "ACTIVE",
            Instant.now().minusSeconds(86400),
            Instant.now().plusSeconds(3600),
            executions
        ));
        
        return JobListResponse.builder()
            .jobs(jobs)
            .status("success")
            .build();
    }
}
