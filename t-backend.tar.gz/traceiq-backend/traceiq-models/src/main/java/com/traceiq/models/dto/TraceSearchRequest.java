package com.traceiq.models.dto;

import jakarta.validation.constraints.NotBlank;

/**
 * Request DTO for trace ID search
 */
public record TraceSearchRequest(
        @NotBlank(message = "Trace ID is required")
        String traceId,
        Boolean includeRca,
        Boolean includeCodeSpot,
        Boolean godMode
) {
    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String traceId;
        private Boolean includeRca;
        private Boolean includeCodeSpot;
        private Boolean godMode;

        public Builder traceId(String traceId) {
            this.traceId = traceId;
            return this;
        }

        public Builder includeRca(Boolean includeRca) {
            this.includeRca = includeRca;
            return this;
        }

        public Builder includeCodeSpot(Boolean includeCodeSpot) {
            this.includeCodeSpot = includeCodeSpot;
            return this;
        }

        public Builder godMode(Boolean godMode) {
            this.godMode = godMode;
            return this;
        }

        public TraceSearchRequest build() {
            return new TraceSearchRequest(traceId, includeRca, includeCodeSpot, godMode);
        }
    }
}
