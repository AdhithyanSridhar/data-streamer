#!/bin/bash

# TraceIQ Frontend Startup Script

echo "========================================="
echo " TraceIQ Frontend Startup"
echo "========================================="

# Navigate to frontend directory
cd "$(dirname "$0")/traceiq-frontend" || exit 1

# Check if node_modules exists
if [ ! -d "node_modules" ]; then
    echo "Installing dependencies..."
    npm install
    
    if [ $? -ne 0 ]; then
        echo ""
        echo "Dependency installation failed. Please check your npm setup."
        exit 1
    fi
fi

echo ""
echo "========================================="
echo " Starting TraceIQ Frontend Server"
echo "========================================="
echo ""
echo "Frontend will be available at: http://localhost:3000"
echo "API Proxy: Backend requests will proxy to http://localhost:8080"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

# Run the development server
npm run dev
