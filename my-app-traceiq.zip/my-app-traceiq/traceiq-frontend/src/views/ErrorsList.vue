<template>
  <div class="bg-white rounded-lg shadow-md p-6">
    <h2 class="text-2xl font-bold text-gray-800 mb-6">
      <i class="fas fa-exclamation-triangle text-red-600 mr-2"></i>
      Error List
    </h2>
    
    <div v-if="loading" class="text-center py-8">
      <i class="fas fa-spinner fa-spin text-4xl text-indigo-600"></i>
    </div>
    
    <div v-else class="space-y-3">
      <div
        v-for="error in errors"
        :key="error.traceId"
        class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition cursor-pointer"
        @click="goToTrace(error.traceId)"
      >
        <div class="flex justify-between items-start">
          <div class="flex-1">
            <p class="font-semibold text-gray-800">{{ error.message }}</p>
            <p class="text-sm text-gray-600 mt-1">
              <span class="font-mono text-indigo-600">{{ error.traceId }}</span>
              <span class="mx-2">•</span>
              <i class="fas fa-server mr-1"></i>{{ error.serviceName }}
              <span class="mx-2">•</span>
              <i class="fas fa-users mr-1"></i>{{ error.microserviceTeam }}
            </p>
            <p class="text-sm text-gray-500 mt-1">
              <i class="fas fa-clock mr-1"></i>{{ error.timestamp }}
            </p>
          </div>
          <span class="px-3 py-1 rounded-full text-sm" 
                :class="{
                  'bg-red-100 text-red-800': error.level === 'ERROR',
                  'bg-yellow-100 text-yellow-800': error.level === 'WARN'
                }">
            {{ error.level }}
          </span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import axios from 'axios'

const router = useRouter()
const errors = ref([])
const loading = ref(true)

onMounted(async () => {
  try {
    const response = await axios.get('/api/errors')
    errors.value = response.data.errors
  } catch (error) {
    console.error('Error loading errors:', error)
  } finally {
    loading.value = false
  }
})

const goToTrace = (traceId) => {
  router.push(`/?traceId=${traceId}`)
}
</script>
