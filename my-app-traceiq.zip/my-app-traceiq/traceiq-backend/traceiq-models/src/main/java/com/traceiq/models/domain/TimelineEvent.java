package com.traceiq.models.domain;

import java.time.Instant;
import java.util.List;

/**
 * Represents timeline events for a trace.
 */
public record TimelineEvent(
    String traceId,
    List<Event> events
) {
    public record Event(
        Instant timestamp,
        String serviceName,
        String eventType,
        String description,
        String severity
    ) {}

    public static class Builder {
        private String traceId;
        private List<Event> events;

        public Builder traceId(String traceId) {
            this.traceId = traceId;
            return this;
        }

        public Builder events(List<Event> events) {
            this.events = events;
            return this;
        }

        public TimelineEvent build() {
            return new TimelineEvent(traceId, events);
        }
    }

    public static Builder builder() {
        return new Builder();
    }
}
