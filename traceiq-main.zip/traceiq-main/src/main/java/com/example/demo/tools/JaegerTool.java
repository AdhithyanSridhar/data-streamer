package com.example.demo.tools;

import org.springframework.stereotype.Component;

@Component
public class JaegerTool {

    public static class MicroserviceFlowRequest {
        private final String traceId;

        public MicroserviceFlowRequest(String traceId) {
            this.traceId = traceId;
        }

        public String getTraceId() {
            return traceId;
        }
    }

    public static class MicroserviceFlowResponse {
        private final String flow;

        public MicroserviceFlowResponse(String flow) {
            this.flow = flow;
        }

        public String flow() {
            return flow;
        }
    }

    public MicroserviceFlowResponse captureMicroserviceFlow(MicroserviceFlowRequest request) {
        // Mock implementation
        return new MicroserviceFlowResponse("service-a -> service-b");
    }
}
