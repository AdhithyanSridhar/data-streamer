package com.example.demo.graph;

import com.example.demo.tools.InternalLLMTool;
import org.springframework.stereotype.Component;

@Component
public class RouterNode implements Node {

    public static final String NAME = "router";
    private final InternalLLMTool internalLLMTool;

    public RouterNode(InternalLLMTool internalLLMTool) {
        this.internalLLMTool = internalLLMTool;
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public GraphState apply(GraphState state) {
        InternalLLMTool.InternalLLMResponse response = internalLLMTool.getSuggestions(
            new InternalLLMTool.InternalLLMRequest(state.get("traceId"), state.toJson()));

        state.set("nextStep", response.suggestions().get(0));
        return state;
    }
}
