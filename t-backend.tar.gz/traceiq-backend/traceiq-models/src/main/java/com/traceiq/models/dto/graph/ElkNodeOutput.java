package com.traceiq.models.dto.graph;

import java.util.List;
import java.util.Map;

/**
 * Output schema for ELK node in LangGraph4j orchestration
 */
public record ElkNodeOutput(
        String traceId,
        List<LogEntry> logs,
        Map<String, Object> summary,
        boolean success,
        String errorMessage
) {
    public record LogEntry(
            String timestamp,
            String level,
            String message,
            String service,
            Map<String, Object> fields
    ) {}

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String traceId;
        private List<LogEntry> logs;
        private Map<String, Object> summary;
        private boolean success;
        private String errorMessage;

        public Builder traceId(String traceId) {
            this.traceId = traceId;
            return this;
        }

        public Builder logs(List<LogEntry> logs) {
            this.logs = logs;
            return this;
        }

        public Builder summary(Map<String, Object> summary) {
            this.summary = summary;
            return this;
        }

        public Builder success(boolean success) {
            this.success = success;
            return this;
        }

        public Builder errorMessage(String errorMessage) {
            this.errorMessage = errorMessage;
            return this;
        }

        public ElkNodeOutput build() {
            return new ElkNodeOutput(traceId, logs, summary, success, errorMessage);
        }
    }
}
