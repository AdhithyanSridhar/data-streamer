# TraceIQ Quick Start Guide

## Prerequisites

✅ **Java 17** installed  
✅ **Maven 3.8+** installed  
✅ **Node.js 18+** and npm installed  
✅ **Access to internal systems** (ELK, LLM APIs, Jira, GitHub, Jenkins, K8s)

## Quick Setup (5 minutes)

### Step 1: Configure Environment

```bash
# Copy environment template
cp .env.template .env

# Edit .env with your API tokens
nano .env  # or use your preferred editor
```

**Required tokens:**
- ELK API token
- Internal LLM API token
- Codebase LLM API token
- Jira API token
- GitHub API token
- Jenkins API token
- Kubernetes API token

### Step 2: Start Backend

```bash
# Option 1: Using startup script (recommended)
./start-backend.sh

# Option 2: Manual start
cd traceiq-backend
export JAVA_HOME=/path/to/jdk17
mvn spring-boot:run
```

Backend runs on `http://localhost:8080`

### Step 3: Start Frontend (New Terminal)

```bash
# Option 1: Using startup script (recommended)
./start-frontend.sh

# Option 2: Manual start
cd traceiq-frontend
npm install
npm run dev
```

Frontend runs on `http://localhost:3000`

### Step 4: Test the Application

1. Open browser: `http://localhost:3000`
2. Enter a trace ID from your system
3. Select analysis options (keep default for first test)
4. Click "Analyze Trace"
5. Wait 10-30 seconds for results

## Basic Usage

### Analyzing a Trace

1. **Enter Trace ID**: Required field from your distributed system
2. **Microservice Name**: Optional, helps narrow down the search
3. **Environment**: Choose Test or Production
4. **Analysis Options**:
   - ✅ **Code Analysis**: Locates problematic code (uses AI)
   - ✅ **Performance Analysis**: Analyzes latency
   - ☐ **Jira Integration**: Searches existing tickets
   - ☐ **GitHub PRs**: Shows recent merged PRs
   - ☐ **Auto Create Jira**: Creates ticket automatically

### Understanding Results

#### Root Cause Analysis
- **Summary**: Brief description of the issue
- **Root Cause**: Main cause identified by AI
- **Category**: Configuration | Code | Infrastructure | Integration
- **Severity**: Critical | High | Medium | Low
- **Confidence Score**: AI confidence (0-100%)

#### Code Analysis (if enabled)
- **File Path**: Location of problematic code
- **Line Number**: Exact line with issue
- **Problematic Code**: Current code snippet
- **Suggested Fix**: AI-recommended fix
- **Implementation Plan**: Step-by-step fix guide

#### Performance Metrics
- **Total Duration**: Complete trace duration
- **Service Latencies**: Time spent in each service
- **Bottlenecks**: Identified performance issues

## Cost Optimization Tips

TraceIQ is designed to minimize AI costs:

1. **Cache Results**: Same trace ID uses cached data for 10 minutes
2. **Selective Analysis**: Only enable AI features when needed
3. **Share Results**: Analysis results can be shared with team
4. **Batch Similar Issues**: Analyze similar traces together

## Troubleshooting

### Backend won't start

```bash
# Check Java version
java -version  # Should be 17

# Check if port 8080 is in use
lsof -i :8080
# If in use, kill the process or change port in application.yml
```

### Frontend won't start

```bash
# Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install

# Check if port 3000 is in use
lsof -i :3000
```

### "No errors found" message

This means the trace completed successfully. Possible causes:
- Trace ID might be incorrect
- Logs not yet indexed in ELK
- Different environment (check Test vs Prod)

### API Connection Errors

```bash
# Test ELK connection
curl -H "Authorization: Bearer YOUR_TOKEN" http://elk-server:9200/_cat/health

# Test backend health
curl http://localhost:8080/api/v1/trace/health
```

### Analysis Takes Too Long

Normal analysis time: 10-30 seconds
If longer:
- Check network connectivity to internal systems
- Verify all API tokens are valid
- Check backend logs for errors

## Development Mode

### Backend Development

```bash
cd traceiq-backend

# Run with hot reload
mvn spring-boot:run

# Run tests (when added)
mvn test

# Package
mvn clean package
```

### Frontend Development

```bash
cd traceiq-frontend

# Development with hot reload
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## API Testing with cURL

### Analyze Trace

```bash
curl -X POST http://localhost:8080/api/v1/trace/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "traceId": "abc-123-def-456",
    "microserviceName": "order-service",
    "environment": "prod",
    "includeCodeAnalysis": true,
    "includePerformanceAnalysis": true,
    "includeJiraAnalysis": false,
    "includeGitHubAnalysis": false,
    "autoCreateJiraTicket": false
  }'
```

### Health Check

```bash
curl http://localhost:8080/api/v1/trace/health
```

## Next Steps

1. **Configure Team Settings**: Update team names and owner emails in code
2. **Add Custom Prompts**: Tailor LLM prompts for your specific needs
3. **Integrate with Slack**: Add notifications (future feature)
4. **Set up Analytics**: Track productivity improvements

## Getting Help

- **Technical Issues**: Check logs in `traceiq-backend/logs/`
- **Feature Requests**: Document in Jira or internal wiki
- **Questions**: Contact Engineering Team

## Production Deployment

For production deployment guide, see [README.md](README.md) deployment section.

---

**Pro Tip**: Start with minimal options (just Code Analysis) to understand the workflow, then gradually enable more features as you get comfortable with the tool.
