<template>
  <v-container fluid class="pa-6">
    <div class="page-header mb-6">
      <h1 class="page-title">Frequently Asked Questions</h1>
      <p class="page-subtitle">Find answers to common questions about TraceIQ</p>
    </div>

    <!-- Search -->
    <div class="glass-card pa-5 mb-6">
      <v-text-field v-model="searchQuery" label="Search FAQs" variant="outlined" density="comfortable" prepend-inner-icon="mdi-magnify" placeholder="Type your question..." clearable></v-text-field>
    </div>

    <!-- FAQ Categories -->
    <v-row>
      <v-col cols="12" md="3">
        <div class="glass-card pa-4">
          <h3 class="category-title mb-3">Categories</h3>
          <v-list nav density="compact" class="category-list">
            <v-list-item v-for="category in categories" :key="category.id" :value="category.id" :active="selectedCategory === category.id" @click="selectedCategory = category.id" rounded="lg">
              <template v-slot:prepend>
                <v-icon :icon="category.icon" size="20"></v-icon>
              </template>
              <v-list-item-title>{{ category.name }}</v-list-item-title>
              <template v-slot:append>
                <v-chip size="x-small" variant="outlined">{{ category.count }}</v-chip>
              </template>
            </v-list-item>
          </v-list>
        </div>
      </v-col>

      <v-col cols="12" md="9">
        <div class="glass-card pa-5">
          <h3 class="section-title mb-4">
            <v-icon :icon="currentCategory?.icon" class="mr-2"></v-icon>
            {{ currentCategory?.name }}
          </h3>

          <v-expansion-panels variant="accordion" class="faq-panels">
            <v-expansion-panel v-for="faq in filteredFaqs" :key="faq.id">
              <v-expansion-panel-title>
                <div class="faq-question">
                  <v-icon icon="mdi-help-circle-outline" size="20" class="mr-2"></v-icon>
                  {{ faq.question }}
                </div>
              </v-expansion-panel-title>
              <v-expansion-panel-text>
                <div class="faq-answer" v-html="faq.answer"></div>
                <div class="faq-helpful mt-4">
                  <span class="helpful-text">Was this helpful?</span>
                  <v-btn icon variant="text" size="small"><v-icon icon="mdi-thumb-up-outline"></v-icon></v-btn>
                  <v-btn icon variant="text" size="small"><v-icon icon="mdi-thumb-down-outline"></v-icon></v-btn>
                </div>
              </v-expansion-panel-text>
            </v-expansion-panel>
          </v-expansion-panels>
        </div>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup>
import { ref, computed } from 'vue'

const searchQuery = ref('')
const selectedCategory = ref('general')

const categories = [
  { id: 'general', name: 'General', icon: 'mdi-information-outline', count: 5 },
  { id: 'agent', name: 'AI Agent', icon: 'mdi-robot-outline', count: 4 },
  { id: 'traces', name: 'Trace Analysis', icon: 'mdi-chart-timeline-variant', count: 3 },
  { id: 'batch', name: 'Batch Jobs', icon: 'mdi-calendar-clock-outline', count: 3 },
  { id: 'integration', name: 'Integrations', icon: 'mdi-connection', count: 4 }
]

const faqs = ref([
  { id: 1, category: 'general', question: 'What is TraceIQ?', answer: 'TraceIQ is an intelligent observability platform that uses AI agents to automatically analyze errors, identify root causes, and generate fixes for your distributed microservices.' },
  { id: 2, category: 'general', question: 'How does TraceIQ integrate with my existing stack?', answer: 'TraceIQ integrates with popular observability tools like <strong>Dynatrace</strong>, <strong>ELK Stack</strong>, <strong>Jaeger</strong>, and <strong>Prometheus</strong>. It also connects with <strong>GitHub</strong>, <strong>Jira</strong>, and <strong>Jenkins</strong> for end-to-end automation.' },
  { id: 3, category: 'general', question: 'Is TraceIQ secure?', answer: 'Yes! TraceIQ follows enterprise security standards including SOC2 compliance, encryption at rest and in transit, and role-based access control (RBAC).' },
  { id: 4, category: 'agent', question: 'What can the AI Agent do?', answer: 'The AI Agent can: <ul><li>Perform Root Cause Analysis (RCA)</li><li>Generate implementation plans</li><li>Create pull requests with fixes</li><li>Generate unit tests</li><li>Auto-merge PRs after approval</li><li>Close issues automatically</li></ul>' },
  { id: 5, category: 'agent', question: 'How accurate is the AI analysis?', answer: 'Our AI achieves <strong>92% accuracy</strong> in root cause identification based on internal benchmarks. The model is continuously learning from feedback and historical data.' },
  { id: 6, category: 'traces', question: 'What is a Trace ID?', answer: 'A Trace ID is a unique identifier that follows a request as it travels through your distributed system. It helps correlate logs, spans, and errors across multiple microservices.' },
  { id: 7, category: 'traces', question: 'How do I search for a trace?', answer: 'Navigate to the <strong>Trace Lookup</strong> page, enter your trace ID in the search box, and click "Search Trace". The system will display all related spans, errors, and AI-generated analysis.' },
  { id: 8, category: 'batch', question: 'How do I schedule a batch job?', answer: 'Go to <strong>Batch Jobs</strong> page, click "Add Job", fill in the job details including the cron schedule, and save. Jobs can be enabled/disabled using the toggle switch.' },
  { id: 9, category: 'batch', question: 'Can I view historical batch runs?', answer: 'Yes! The <strong>Batch Runs</strong> page shows the complete execution history with status, duration, and logs for each run.' },
  { id: 10, category: 'integration', question: 'How do I connect GitHub?', answer: 'Go to Settings > Integrations > GitHub, and click "Connect". You will be redirected to authorize TraceIQ with your GitHub organization.' }
])

const currentCategory = computed(() => categories.find(c => c.id === selectedCategory.value))

const filteredFaqs = computed(() => {
  let result = faqs.value.filter(f => f.category === selectedCategory.value)
  if (searchQuery.value) {
    const query = searchQuery.value.toLowerCase()
    result = faqs.value.filter(f => f.question.toLowerCase().includes(query) || f.answer.toLowerCase().includes(query))
  }
  return result
})
</script>

<style scoped>
.page-header { text-align: center; padding: 20px 0; }
.page-title { font-size: 1.75rem; font-weight: 700; color: #1a1a1a; margin-bottom: 8px; }
.page-subtitle { font-size: 0.95rem; color: #666666; }
.category-title { font-size: 0.95rem; font-weight: 600; color: #1a1a1a; }
.category-list { background: transparent !important; }
.section-title { font-size: 1rem; font-weight: 600; color: #1a1a1a; display: flex; align-items: center; }
.faq-panels { background: transparent; }
.faq-question { display: flex; align-items: center; font-weight: 500; color: #1a1a1a; }
.faq-answer { color: #666666; line-height: 1.7; }
.faq-answer ul { margin: 10px 0; padding-left: 20px; }
.faq-answer li { margin-bottom: 6px; }
.faq-helpful { display: flex; align-items: center; gap: 8px; border-top: 1px solid #e5e5e5; padding-top: 12px; }
.helpful-text { font-size: 0.8rem; color: #999999; }
</style>
