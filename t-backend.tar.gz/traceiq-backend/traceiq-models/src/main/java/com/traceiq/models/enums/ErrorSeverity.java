package com.traceiq.models.enums;

/**
 * Severity levels for errors detected in the system
 */
public enum ErrorSeverity {
    CRITICAL,
    HIGH,
    MEDIUM,
    LOW,
    INFO
}
