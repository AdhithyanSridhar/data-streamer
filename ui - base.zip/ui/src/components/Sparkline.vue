<template>
  <svg :viewBox="`0 0 ${width} ${height}`" class="sparkline" :style="{ width: width + 'px', height: height + 'px' }">
    <defs>
      <linearGradient :id="gradientId" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" :stop-color="color" stop-opacity="0.3"/>
        <stop offset="100%" :stop-color="color" stop-opacity="0"/>
      </linearGradient>
    </defs>
    
    <!-- Fill area -->
    <path 
      v-if="filled"
      :d="areaPath"
      :fill="`url(#${gradientId})`"
    />
    
    <!-- Line -->
    <polyline
      :points="points"
      fill="none"
      :stroke="color"
      :stroke-width="strokeWidth"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    
    <!-- End dot -->
    <circle
      v-if="showEndDot"
      :cx="endPoint.x"
      :cy="endPoint.y"
      :r="strokeWidth + 1"
      :fill="color"
    />
  </svg>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  data: {
    type: Array,
    required: true
  },
  width: {
    type: Number,
    default: 80
  },
  height: {
    type: Number,
    default: 24
  },
  color: {
    type: String,
    default: '#1a1a1a'
  },
  strokeWidth: {
    type: Number,
    default: 1.5
  },
  filled: {
    type: Boolean,
    default: false
  },
  showEndDot: {
    type: Boolean,
    default: false
  }
})

const gradientId = computed(() => `sparkline-gradient-${Math.random().toString(36).substr(2, 9)}`)

const normalizedData = computed(() => {
  const max = Math.max(...props.data)
  const min = Math.min(...props.data)
  const range = max - min || 1
  
  return props.data.map(val => (val - min) / range)
})

const points = computed(() => {
  const padding = 2
  const usableWidth = props.width - padding * 2
  const usableHeight = props.height - padding * 2
  
  return normalizedData.value.map((val, idx) => {
    const x = padding + (idx / (props.data.length - 1)) * usableWidth
    const y = padding + (1 - val) * usableHeight
    return `${x},${y}`
  }).join(' ')
})

const areaPath = computed(() => {
  const padding = 2
  const usableWidth = props.width - padding * 2
  const usableHeight = props.height - padding * 2
  
  const pathPoints = normalizedData.value.map((val, idx) => {
    const x = padding + (idx / (props.data.length - 1)) * usableWidth
    const y = padding + (1 - val) * usableHeight
    return `${x},${y}`
  })
  
  const startX = padding
  const endX = padding + usableWidth
  const bottom = props.height - padding
  
  return `M ${startX},${bottom} L ${pathPoints.join(' L ')} L ${endX},${bottom} Z`
})

const endPoint = computed(() => {
  const padding = 2
  const usableWidth = props.width - padding * 2
  const usableHeight = props.height - padding * 2
  const lastVal = normalizedData.value[normalizedData.value.length - 1]
  
  return {
    x: padding + usableWidth,
    y: padding + (1 - lastVal) * usableHeight
  }
})
</script>

<style scoped>
.sparkline {
  display: inline-block;
  vertical-align: middle;
}
</style>
