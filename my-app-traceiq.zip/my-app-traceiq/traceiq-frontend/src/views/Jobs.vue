<template>
  <div class="bg-white rounded-lg shadow-md p-6">
    <h2 class="text-2xl font-bold text-gray-800 mb-6">
      <i class="fas fa-tasks text-indigo-600 mr-2"></i>
      Scheduled Jobs
    </h2>
    
    <div v-if="loading" class="text-center py-8">
      <i class="fas fa-spinner fa-spin text-4xl text-indigo-600"></i>
    </div>
    
    <div v-else class="space-y-6">
      <div
        v-for="job in jobs"
        :key="job.jobId"
        class="border border-gray-200 rounded-lg p-6"
      >
        <div class="flex justify-between items-start mb-4">
          <div>
            <h3 class="text-lg font-semibold text-gray-800">{{ job.jobName }}</h3>
            <p class="text-sm text-gray-600 mt-1">
              <i class="fas fa-clock mr-1"></i>Schedule: {{ job.schedule }}
            </p>
          </div>
          <span class="px-3 py-1 rounded-full text-sm"
                :class="{
                  'bg-green-100 text-green-800': job.status === 'ACTIVE',
                  'bg-gray-100 text-gray-800': job.status === 'INACTIVE'
                }">
            {{ job.status }}
          </span>
        </div>
        
        <div class="grid grid-cols-2 gap-4 text-sm">
          <div>
            <p class="text-gray-600">Last Run:</p>
            <p class="font-medium">{{ new Date(job.lastRunTime).toLocaleString() }}</p>
          </div>
          <div>
            <p class="text-gray-600">Next Run:</p>
            <p class="font-medium">{{ new Date(job.nextRunTime).toLocaleString() }}</p>
          </div>
        </div>
        
        <!-- Recent Executions -->
        <div v-if="job.recentExecutions?.length" class="mt-4">
          <p class="font-semibold text-gray-700 mb-2">Recent Executions:</p>
          <div class="space-y-2">
            <div
              v-for="exec in job.recentExecutions"
              :key="exec.executionId"
              class="bg-gray-50 p-3 rounded text-sm"
            >
              <div class="flex justify-between">
                <span>{{ new Date(exec.startTime).toLocaleString() }}</span>
                <span class="px-2 py-1 rounded text-xs"
                      :class="{
                        'bg-green-100 text-green-800': exec.status === 'SUCCESS',
                        'bg-red-100 text-red-800': exec.status === 'FAILED'
                      }">
                  {{ exec.status }}
                </span>
              </div>
              <p class="text-gray-600 mt-1">{{ exec.message }}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'

const jobs = ref([])
const loading = ref(true)

onMounted(async () => {
  try {
    const response = await axios.get('/api/jobs')
    jobs.value = response.data.jobs
  } catch (error) {
    console.error('Error loading jobs:', error)
  } finally {
    loading.value = false
  }
})
</script>
