package com.traceiq.tools;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.traceiq.client.GitHubClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.function.Function;

/**
 * Spring AI Function Tool for GitHub operations
 * Provides PR analysis, code owners, and repository insights
 */
@Component("githubTool")
public class GitHubTool implements Function<GitHubTool.GitHubRequest, GitHubTool.GitHubResponse> {
    public static final Logger log = LoggerFactory.getLogger(GitHubTool.class);

    private final GitHubClient githubClient;

    public GitHubTool(GitHubClient githubClient) {
        this.githubClient = githubClient;
    }

    @Override
    public GitHubResponse apply(GitHubRequest request) {
        log.info("Executing GitHub tool with operation: {}", request.operation);

        try {
            return switch (request.operation.toUpperCase()) {
                case "GET_RECENT_PRS" -> getRecentPullRequests(request);
                case "GET_CODE_OWNERS" -> getCodeOwners(request);
                case "GET_REPO_OVERVIEW" -> getRepositoryOverview(request);
                case "GET_LAST_COMMIT" -> getLastCommit(request);
                case "SEARCH_CODE" -> searchCode(request);
                case "GET_FILE_CONTENT" -> getFileContent(request);
                default -> GitHubResponse.builder()
                        .success(false)
                        .message("Unknown operation: " + request.operation)
                        .build();
            };
        } catch (Exception e) {
            log.error("Error executing GitHub tool operation: {}", request.operation, e);
            return GitHubResponse.builder()
                    .success(false)
                    .message("Error: " + e.getMessage())
                    .build();
        }
    }

    private GitHubResponse getRecentPullRequests(GitHubRequest request) {
        List<Map<String, Object>> prs = githubClient.getRecentPullRequests(
                request.repository,
                request.state,
                request.limit
        );

        return GitHubResponse.builder()
                .success(true)
                .data(Map.of("pullRequests", prs, "count", prs.size()))
                .message("Retrieved " + prs.size() + " pull requests")
                .build();
    }

    private GitHubResponse getCodeOwners(GitHubRequest request) {
        List<String> owners = githubClient.getCodeOwners(
                request.repository,
                request.filePath
        );

        return GitHubResponse.builder()
                .success(true)
                .data(Map.of("codeOwners", owners))
                .message("Retrieved code owners")
                .build();
    }

    private GitHubResponse getRepositoryOverview(GitHubRequest request) {
        Map<String, Object> overview = githubClient.getRepositoryOverview(request.repository);

        return GitHubResponse.builder()
                .success(true)
                .data(overview)
                .message("Retrieved repository overview")
                .build();
    }

    private GitHubResponse getLastCommit(GitHubRequest request) {
        Map<String, Object> commit = githubClient.getLastCommit(
                request.repository,
                request.branch
        );

        return GitHubResponse.builder()
                .success(true)
                .data(commit)
                .message("Retrieved last commit")
                .build();
    }

    private GitHubResponse searchCode(GitHubRequest request) {
        List<Map<String, Object>> results = githubClient.searchCode(
                request.query,
                request.repository
        );

        return GitHubResponse.builder()
                .success(true)
                .data(Map.of("results", results, "count", results.size()))
                .message("Found " + results.size() + " code matches")
                .build();
    }

    private GitHubResponse getFileContent(GitHubRequest request) {
        String content = githubClient.getFileContent(
                request.repository,
                request.filePath,
                request.branch
        );

        return GitHubResponse.builder()
                .success(true)
                .data(Map.of("content", content))
                .message("Retrieved file content")
                .build();
    }

    /**
     * Request object for GitHub operations
     */
    public record GitHubRequest(
            @JsonProperty(required = true)
            @JsonPropertyDescription("Operation: GET_RECENT_PRS, GET_CODE_OWNERS, GET_REPO_OVERVIEW, GET_LAST_COMMIT, SEARCH_CODE, GET_FILE_CONTENT")
            String operation,

            @JsonPropertyDescription("Repository name (e.g., org/repo)")
            String repository,

            @JsonPropertyDescription("PR state: open, closed, all")
            String state,

            @JsonPropertyDescription("Number of results to retrieve")
            Integer limit,

            @JsonPropertyDescription("File path in repository")
            String filePath,

            @JsonPropertyDescription("Branch name (default: main)")
            String branch,

            @JsonPropertyDescription("Search query")
            String query
    ) {
    }

    /**
     * Response object for GitHub operations
     */
    public record GitHubResponse(
            boolean success,
            String message,
            Map<String, Object> data
    ) {
        public static GitHubResponseBuilder builder() {
            return new GitHubResponseBuilder();
        }

        public static class GitHubResponseBuilder {
            private boolean success;
            private String message;
            private Map<String, Object> data;

            public GitHubResponseBuilder success(boolean success) {
                this.success = success;
                return this;
            }

            public GitHubResponseBuilder message(String message) {
                this.message = message;
                return this;
            }

            public GitHubResponseBuilder data(Map<String, Object> data) {
                this.data = data;
                return this;
            }

            public GitHubResponse build() {
                return new GitHubResponse(success, message, data);
            }
        }
    }
}
