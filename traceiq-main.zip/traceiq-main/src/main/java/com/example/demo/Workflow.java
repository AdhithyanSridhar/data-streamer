package com.example.demo;

import com.example.demo.graph.GraphState;
import com.example.demo.graph.Node;
import com.example.demo.graph.RouterNode;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class Workflow {

    private final Map<String, Node> nodes = new HashMap<>();
    private final RouterNode routerNode;

    public Workflow(RouterNode routerNode) {
        this.routerNode = routerNode;
    }

    public void addNode(Node node) {
        nodes.put(node.getName(), node);
    }

    public GraphState run(String traceId) {
        GraphState state = new GraphState();
        state.set("traceId", traceId);

        while (true) {
            routerNode.apply(state);
            String nextNodeName = state.get("nextStep");

            if (nextNodeName == null || nextNodeName.equals("exit")) {
                break;
            }

            Node nextNode = nodes.get(nextNodeName);
            if (nextNode != null) {
                state = nextNode.apply(state);
            } else {
                state.set("error", "Node not found: " + nextNodeName);
                break;
            }
        }

        return state;
    }
}
