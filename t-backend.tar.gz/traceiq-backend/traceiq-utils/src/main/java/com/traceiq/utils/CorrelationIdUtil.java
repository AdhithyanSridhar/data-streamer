package com.traceiq.utils;

import java.util.UUID;

/**
 * Utility for generating and managing correlation IDs for request tracing
 */
public class CorrelationIdUtil {
    private static final ThreadLocal<String> correlationIdHolder = new ThreadLocal<>();

    private CorrelationIdUtil() {
        // Utility class
    }

    /**
     * Generate a new correlation ID
     */
    public static String generate() {
        return UUID.randomUUID().toString();
    }

    /**
     * Set correlation ID for current thread
     */
    public static void set(String correlationId) {
        correlationIdHolder.set(correlationId);
    }

    /**
     * Get correlation ID for current thread
     */
    public static String get() {
        return correlationIdHolder.get();
    }

    /**
     * Clear correlation ID for current thread
     */
    public static void clear() {
        correlationIdHolder.remove();
    }

    /**
     * Get or generate correlation ID
     */
    public static String getOrGenerate() {
        String correlationId = get();
        if (correlationId == null) {
            correlationId = generate();
            set(correlationId);
        }
        return correlationId;
    }
}
