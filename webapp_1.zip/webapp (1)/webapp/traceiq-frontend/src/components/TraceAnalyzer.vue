<template>
  <div class="space-y-6">
    <!-- Input Section -->
    <div class="bg-white rounded-lg shadow p-6">
      <h2 class="text-xl font-semibold text-gray-800 mb-4">
        <i class="fas fa-search mr-2"></i>Trace Analysis
      </h2>
      
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">
            Trace ID <span class="text-red-500">*</span>
          </label>
          <input 
            v-model="request.traceId"
            type="text" 
            class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Enter trace ID"
          />
        </div>
        
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">
            Microservice Name
          </label>
          <input 
            v-model="request.microserviceName"
            type="text" 
            class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="e.g., order-service"
          />
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">
            Environment
          </label>
          <select 
            v-model="request.environment"
            class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="test">Test</option>
            <option value="prod">Production</option>
          </select>
        </div>
      </div>

      <!-- Analysis Options -->
      <div class="mb-4">
        <h3 class="text-sm font-medium text-gray-700 mb-3">Analysis Options</h3>
        <div class="grid grid-cols-2 md:grid-cols-3 gap-3">
          <label class="flex items-center space-x-2 cursor-pointer">
            <input 
              v-model="request.includeCodeAnalysis" 
              type="checkbox" 
              class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
            />
            <span class="text-sm text-gray-700">Code Analysis</span>
          </label>

          <label class="flex items-center space-x-2 cursor-pointer">
            <input 
              v-model="request.includePerformanceAnalysis" 
              type="checkbox" 
              class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
            />
            <span class="text-sm text-gray-700">Performance Analysis</span>
          </label>

          <label class="flex items-center space-x-2 cursor-pointer">
            <input 
              v-model="request.includeJiraAnalysis" 
              type="checkbox" 
              class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
            />
            <span class="text-sm text-gray-700">Jira Integration</span>
          </label>

          <label class="flex items-center space-x-2 cursor-pointer">
            <input 
              v-model="request.includeGitHubAnalysis" 
              type="checkbox" 
              class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
            />
            <span class="text-sm text-gray-700">GitHub PRs</span>
          </label>

          <label class="flex items-center space-x-2 cursor-pointer">
            <input 
              v-model="request.autoCreateJiraTicket" 
              type="checkbox" 
              class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
            />
            <span class="text-sm text-gray-700">Auto Create Jira</span>
          </label>
        </div>
      </div>

      <!-- Action Buttons -->
      <div class="flex space-x-3">
        <button 
          @click="analyzeTrace"
          :disabled="loading || !request.traceId"
          class="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition"
        >
          <i class="fas fa-search mr-2"></i>
          {{ loading ? 'Analyzing...' : 'Analyze Trace' }}
        </button>
        
        <button 
          @click="resetForm"
          :disabled="loading"
          class="px-6 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 disabled:bg-gray-100 transition"
        >
          <i class="fas fa-redo mr-2"></i>Reset
        </button>
      </div>
    </div>

    <!-- Loading State -->
    <div v-if="loading" class="bg-white rounded-lg shadow p-6">
      <div class="flex items-center justify-center space-x-3">
        <i class="fas fa-spinner fa-spin text-2xl text-blue-600"></i>
        <span class="text-gray-700">Analyzing trace... This may take a moment.</span>
      </div>
    </div>

    <!-- Error State -->
    <div v-if="error" class="bg-red-50 border border-red-200 rounded-lg p-4">
      <div class="flex items-start space-x-3">
        <i class="fas fa-exclamation-circle text-red-500 text-xl mt-0.5"></i>
        <div>
          <h3 class="font-semibold text-red-800">Analysis Failed</h3>
          <p class="text-red-700 text-sm mt-1">{{ error }}</p>
        </div>
      </div>
    </div>

    <!-- Results Section -->
    <div v-if="response" class="space-y-6">
      <AnalysisResults :response="response" />
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { analyzeTraceApi } from '../services/api'
import AnalysisResults from './AnalysisResults.vue'

const loading = ref(false)
const error = ref(null)
const response = ref(null)

const request = reactive({
  traceId: '',
  microserviceName: '',
  environment: 'test',
  includeJiraAnalysis: false,
  includeGitHubAnalysis: false,
  includePerformanceAnalysis: true,
  includeCodeAnalysis: true,
  autoCreateJiraTicket: false
})

const analyzeTrace = async () => {
  if (!request.traceId) {
    error.value = 'Trace ID is required'
    return
  }

  loading.value = true
  error.value = null
  response.value = null

  try {
    const result = await analyzeTraceApi(request)
    response.value = result
  } catch (err) {
    error.value = err.message || 'Failed to analyze trace'
    console.error('Analysis error:', err)
  } finally {
    loading.value = false
  }
}

const resetForm = () => {
  request.traceId = ''
  request.microserviceName = ''
  request.environment = 'test'
  request.includeJiraAnalysis = false
  request.includeGitHubAnalysis = false
  request.includePerformanceAnalysis = true
  request.includeCodeAnalysis = true
  request.autoCreateJiraTicket = false
  response.value = null
  error.value = null
}
</script>
