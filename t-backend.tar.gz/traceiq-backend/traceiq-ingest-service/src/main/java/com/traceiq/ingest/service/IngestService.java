package com.traceiq.ingest.service;

import com.traceiq.ingest.repository.CassandraRepository;
import com.traceiq.models.domain.ErrorRecord;
import com.traceiq.models.domain.JobRun;
import com.traceiq.models.enums.ErrorSeverity;
import com.traceiq.models.enums.JobStatus;
import com.traceiq.tools.adapter.ElkAdapter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class IngestService {
    private static final Logger logger = LoggerFactory.getLogger(IngestService.class);

    private final ElkAdapter elkAdapter;
    private final CassandraRepository cassandraRepository;

    public IngestService(ElkAdapter elkAdapter, CassandraRepository cassandraRepository) {
        this.elkAdapter = elkAdapter;
        this.cassandraRepository = cassandraRepository;
    }

    public JobRun ingestErrors(String timeRange) {
        String jobId = UUID.randomUUID().toString();
        Instant startTime = Instant.now();
        logger.info("Starting error ingest job: {}", jobId);

        try {
            List<Map<String, Object>> errors = elkAdapter.searchErrors(timeRange);
            logger.info("Found {} errors to ingest", errors.size());

            long processed = 0;
            for (Map<String, Object> error : errors) {
                try {
                    ErrorRecord record = convertToErrorRecord(error);
                    cassandraRepository.insertErrorRecord(record);
                    processed++;
                } catch (Exception e) {
                    logger.error("Error processing record", e);
                }
            }

            JobRun jobRun = JobRun.builder()
                    .jobId(jobId)
                    .jobName("elk-ingest")
                    .status(JobStatus.COMPLETED)
                    .startTime(startTime)
                    .endTime(Instant.now())
                    .recordsProcessed(processed)
                    .build();

            cassandraRepository.insertJobRun(jobRun);
            logger.info("Ingest job completed: {} records processed", processed);
            return jobRun;

        } catch (Exception e) {
            logger.error("Ingest job failed", e);
            JobRun jobRun = JobRun.builder()
                    .jobId(jobId)
                    .jobName("elk-ingest")
                    .status(JobStatus.FAILED)
                    .startTime(startTime)
                    .endTime(Instant.now())
                    .recordsProcessed(0L)
                    .errorMessage(e.getMessage())
                    .build();
            cassandraRepository.insertJobRun(jobRun);
            return jobRun;
        }
    }

    private ErrorRecord convertToErrorRecord(Map<String, Object> error) {
        return ErrorRecord.builder()
                .traceId((String) error.getOrDefault("traceId", "unknown"))
                .message((String) error.get("message"))
                .service((String) error.getOrDefault("service", "unknown"))
                .severity(ErrorSeverity.valueOf((String) error.getOrDefault("severity", "MEDIUM")))
                .stackTrace((String) error.get("stackTrace"))
                .ownerEmail((String) error.get("ownerEmail"))
                .teamName((String) error.get("teamName"))
                .timestamp(Instant.parse((String) error.get("@timestamp")))
                .ingestedAt(Instant.now())
                .build();
    }
}
