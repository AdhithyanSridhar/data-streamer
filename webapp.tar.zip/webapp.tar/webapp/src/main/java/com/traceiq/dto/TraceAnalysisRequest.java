package com.traceiq.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;

import java.util.List;
import java.util.Map;

/**
 * Request DTO for initiating trace analysis
 * Supports both trace ID-based and error details-based analysis
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TraceAnalysisRequest {
    public TraceAnalysisRequest() {
    }

    /**
     * Trace ID to analyze (optional if errorDetails provided)
     */
    private String traceId;

    /**
     * Pre-collected error details (optional if traceId provided)
     */
    private String errorDetails;

    /**
     * Microservice name for targeted analysis
     */
    private String microserviceName;

    /**
     * Environment (test/prod)
     */
    @NotBlank(message = "Environment is required")
    private String environment;

    /**
     * Time range for log analysis (in minutes, default 60)
     */
    private Integer timeRangeMinutes = 60;

    /**
     * Whether to create Jira ticket automatically
     */
    private Boolean autoCreateJiraTicket = false;

    /**
     * Additional context for analysis
     */
    private Map<String, Object> additionalContext;

    /**
     * Tools to enable/disable for this analysis
     */
    private List<String> enabledTools;

    /**
     * Priority for analysis (LOW, MEDIUM, HIGH, CRITICAL)
     */
    private String priority = "MEDIUM";

    /**
     * User requesting the analysis
     */
    private String requestedBy;

    public TraceAnalysisRequest(String traceId, String errorDetails, String microserviceName, String environment, Integer timeRangeMinutes, Boolean autoCreateJiraTicket, Map<String, Object> additionalContext, List<String> enabledTools, String priority, String requestedBy) {
        this.traceId = traceId;
        this.errorDetails = errorDetails;
        this.microserviceName = microserviceName;
        this.environment = environment;
        this.timeRangeMinutes = timeRangeMinutes;
        this.autoCreateJiraTicket = autoCreateJiraTicket;
        this.additionalContext = additionalContext;
        this.enabledTools = enabledTools;
        this.priority = priority;
        this.requestedBy = requestedBy;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public String getErrorDetails() {
        return errorDetails;
    }

    public void setErrorDetails(String errorDetails) {
        this.errorDetails = errorDetails;
    }

    public String getMicroserviceName() {
        return microserviceName;
    }

    public void setMicroserviceName(String microserviceName) {
        this.microserviceName = microserviceName;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public Integer getTimeRangeMinutes() {
        return timeRangeMinutes;
    }

    public void setTimeRangeMinutes(Integer timeRangeMinutes) {
        this.timeRangeMinutes = timeRangeMinutes;
    }

    public Boolean getAutoCreateJiraTicket() {
        return autoCreateJiraTicket;
    }

    public void setAutoCreateJiraTicket(Boolean autoCreateJiraTicket) {
        this.autoCreateJiraTicket = autoCreateJiraTicket;
    }

    public Map<String, Object> getAdditionalContext() {
        return additionalContext;
    }

    public void setAdditionalContext(Map<String, Object> additionalContext) {
        this.additionalContext = additionalContext;
    }

    public List<String> getEnabledTools() {
        return enabledTools;
    }

    public void setEnabledTools(List<String> enabledTools) {
        this.enabledTools = enabledTools;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getRequestedBy() {
        return requestedBy;
    }

    public void setRequestedBy(String requestedBy) {
        this.requestedBy = requestedBy;
    }
}
