package com.traceiq.llm.client;

import com.traceiq.llm.config.LlmConfig;
import com.traceiq.utils.JsonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

/**
 * Client for jtoon wrapper service to optimize token usage
 * jtoon compresses and optimizes prompts before sending to LLM
 */
@Component
public class JtoonClient {
    private static final Logger logger = LoggerFactory.getLogger(JtoonClient.class);

    private final RestTemplate restTemplate;
    private final LlmConfig llmConfig;

    public JtoonClient(RestTemplate restTemplate, LlmConfig llmConfig) {
        this.restTemplate = restTemplate;
        this.llmConfig = llmConfig;
    }

    /**
     * Optimize text through jtoon before sending to LLM
     * This reduces token usage while preserving semantic meaning
     *
     * @param text Original text to optimize
     * @param context Context for optimization
     * @return Optimized text
     */
    public String optimize(String text, String context) {
        if (!llmConfig.isJtoonEnabled()) {
            logger.debug("jtoon is disabled, returning original text");
            return text;
        }

        try {
            logger.info("Optimizing text through jtoon. Original length: {}", text.length());

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            Map<String, Object> request = Map.of(
                    "text", text,
                    "context", context,
                    "strategy", "compress"
            );

            HttpEntity<String> entity = new HttpEntity<>(JsonUtil.toJson(request), headers);

            ResponseEntity<String> response = restTemplate.exchange(
                    llmConfig.getJtoonUrl() + "/optimize",
                    HttpMethod.POST,
                    entity,
                    String.class
            );

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                Map<String, Object> result = JsonUtil.fromJson(response.getBody(), Map.class);
                String optimizedText = (String) result.get("optimizedText");
                logger.info("jtoon optimization complete. Optimized length: {}", optimizedText.length());
                return optimizedText;
            }

            logger.warn("jtoon optimization failed, returning original text");
            return text;

        } catch (Exception e) {
            logger.error("Error calling jtoon service, falling back to original text", e);
            return text;
        }
    }

    /**
     * Check if jtoon is enabled and available
     */
    public boolean isAvailable() {
        if (!llmConfig.isJtoonEnabled()) {
            return false;
        }

        try {
            ResponseEntity<String> response = restTemplate.getForEntity(
                    llmConfig.getJtoonUrl() + "/health",
                    String.class
            );
            return response.getStatusCode() == HttpStatus.OK;
        } catch (Exception e) {
            logger.warn("jtoon service is not available", e);
            return false;
        }
    }
}
