package com.traceiq.tool;

import com.traceiq.model.JiraTicketInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.Map;
import java.util.function.Function;

/**
 * Spring AI Tool for Jira API integration.
 * Provides ticket viewing, commenting, and creation capabilities.
 */
@Component
public class JiraTool implements Function<JiraTool.JiraRequest, JiraTicketInfo> {
    
    private static final Logger logger = LoggerFactory.getLogger(JiraTool.class);
    
    private final WebClient webClient;
    
    public JiraTool(
        @Value("${jira.base-url}") String jiraBaseUrl,
        @Value("${jira.api-token}") String jiraApiToken,
        WebClient.Builder webClientBuilder
    ) {
        this.webClient = webClientBuilder
            .baseUrl(jiraBaseUrl)
            .defaultHeader("Authorization", "Bearer " + jiraApiToken)
            .build();
        
        logger.info("JiraTool initialized with base URL: {}", jiraBaseUrl);
    }
    
    @Override
    public JiraTicketInfo apply(JiraRequest request) {
        logger.info("Executing Jira tool with action: {}", request.action());
        
        return switch (request.action()) {
            case "getTicket" -> getTicketDetails(request.ticketId());
            case "getComments" -> getTicketWithComments(request.ticketId());
            case "createTicket" -> createTicket(request);
            default -> throw new IllegalArgumentException("Unknown action: " + request.action());
        };
    }
    
    /**
     * Get Jira ticket details.
     */
    private JiraTicketInfo getTicketDetails(String ticketId) {
        logger.info("Fetching Jira ticket: {}", ticketId);
        
        try {
            Map<String, Object> response = webClient.get()
                .uri("/rest/api/3/issue/{ticketId}", ticketId)
                .retrieve()
                .bodyToMono(Map.class)
                .block();
            
            return parseJiraTicket(response);
            
        } catch (Exception e) {
            logger.error("Error fetching Jira ticket: {}", ticketId, e);
            return createErrorTicket(ticketId, e.getMessage());
        }
    }
    
    /**
     * Get Jira ticket with all comments.
     */
    private JiraTicketInfo getTicketWithComments(String ticketId) {
        logger.info("Fetching Jira ticket with comments: {}", ticketId);
        
        try {
            Map<String, Object> response = webClient.get()
                .uri("/rest/api/3/issue/{ticketId}?expand=comments", ticketId)
                .retrieve()
                .bodyToMono(Map.class)
                .block();
            
            return parseJiraTicketWithComments(response);
            
        } catch (Exception e) {
            logger.error("Error fetching Jira ticket with comments: {}", ticketId, e);
            return createErrorTicket(ticketId, e.getMessage());
        }
    }
    
    /**
     * Create a new Jira ticket.
     */
    private JiraTicketInfo createTicket(JiraRequest request) {
        logger.info("Creating Jira ticket: {}", request.summary());
        
        try {
            Map<String, Object> ticketPayload = Map.of(
                "fields", Map.of(
                    "project", Map.of("key", request.projectKey()),
                    "summary", request.summary(),
                    "description", Map.of(
                        "type", "doc",
                        "version", 1,
                        "content", List.of(
                            Map.of(
                                "type", "paragraph",
                                "content", List.of(
                                    Map.of("type", "text", "text", request.description())
                                )
                            )
                        )
                    ),
                    "issuetype", Map.of("name", "Bug"),
                    "priority", Map.of("name", request.priority())
                )
            );
            
            Map<String, Object> response = webClient.post()
                .uri("/rest/api/3/issue")
                .bodyValue(ticketPayload)
                .retrieve()
                .bodyToMono(Map.class)
                .block();
            
            String createdTicketId = (String) response.get("key");
            logger.info("Created Jira ticket: {}", createdTicketId);
            
            return getTicketDetails(createdTicketId);
            
        } catch (Exception e) {
            logger.error("Error creating Jira ticket", e);
            return createErrorTicket("CREATE_FAILED", e.getMessage());
        }
    }
    
    // Helper methods
    
    @SuppressWarnings("unchecked")
    private JiraTicketInfo parseJiraTicket(Map<String, Object> response) {
        Map<String, Object> fields = (Map<String, Object>) response.get("fields");
        
        String ticketId = (String) response.get("key");
        String summary = (String) fields.get("summary");
        String description = extractDescription(fields.get("description"));
        
        Map<String, Object> status = (Map<String, Object>) fields.get("status");
        String statusName = (String) status.get("name");
        
        Map<String, Object> priority = (Map<String, Object>) fields.get("priority");
        String priorityName = priority != null ? (String) priority.get("name") : "Medium";
        
        Map<String, Object> assignee = (Map<String, Object>) fields.get("assignee");
        String assigneeName = assignee != null ? (String) assignee.get("displayName") : "Unassigned";
        
        return new JiraTicketInfo(
            ticketId,
            summary,
            description,
            statusName,
            priorityName,
            assigneeName,
            List.of(),
            List.of(),
            buildJiraUrl(ticketId)
        );
    }
    
    @SuppressWarnings("unchecked")
    private JiraTicketInfo parseJiraTicketWithComments(Map<String, Object> response) {
        JiraTicketInfo baseTicket = parseJiraTicket(response);
        
        Map<String, Object> fields = (Map<String, Object>) response.get("fields");
        Map<String, Object> commentObj = (Map<String, Object>) fields.get("comment");
        List<Map<String, Object>> comments = (List<Map<String, Object>>) commentObj.get("comments");
        
        List<String> commentTexts = comments.stream()
            .map(c -> {
                Map<String, Object> author = (Map<String, Object>) c.get("author");
                String authorName = (String) author.get("displayName");
                String body = extractDescription(c.get("body"));
                return authorName + ": " + body;
            })
            .toList();
        
        return new JiraTicketInfo(
            baseTicket.ticketId(),
            baseTicket.title(),
            baseTicket.description(),
            baseTicket.status(),
            baseTicket.priority(),
            baseTicket.assignee(),
            commentTexts,
            baseTicket.attachments(),
            baseTicket.url()
        );
    }
    
    @SuppressWarnings("unchecked")
    private String extractDescription(Object descObj) {
        if (descObj instanceof String) {
            return (String) descObj;
        }
        
        if (descObj instanceof Map) {
            Map<String, Object> doc = (Map<String, Object>) descObj;
            List<Map<String, Object>> content = (List<Map<String, Object>>) doc.get("content");
            if (content != null && !content.isEmpty()) {
                return extractTextFromContent(content);
            }
        }
        
        return "No description";
    }
    
    @SuppressWarnings("unchecked")
    private String extractTextFromContent(List<Map<String, Object>> content) {
        StringBuilder text = new StringBuilder();
        
        for (Map<String, Object> node : content) {
            List<Map<String, Object>> innerContent = (List<Map<String, Object>>) node.get("content");
            if (innerContent != null) {
                for (Map<String, Object> textNode : innerContent) {
                    String nodeText = (String) textNode.get("text");
                    if (nodeText != null) {
                        text.append(nodeText).append(" ");
                    }
                }
            }
        }
        
        return text.toString().trim();
    }
    
    private String buildJiraUrl(String ticketId) {
        // Assuming standard Jira URL structure
        return String.format("https://your-domain.atlassian.net/browse/%s", ticketId);
    }
    
    private JiraTicketInfo createErrorTicket(String ticketId, String error) {
        return new JiraTicketInfo(
            ticketId,
            "Error",
            error,
            "Unknown",
            "Unknown",
            "Unknown",
            List.of(),
            List.of(),
            ""
        );
    }
    
    /**
     * Request model for Jira tool.
     */
    public record JiraRequest(
        String action,
        String ticketId,
        String projectKey,
        String summary,
        String description,
        String priority
    ) {
        public static Builder builder() {
            return new Builder();
        }
        
        public static class Builder {
            private String action;
            private String ticketId;
            private String projectKey;
            private String summary;
            private String description;
            private String priority = "Medium";
            
            public Builder action(String action) {
                this.action = action;
                return this;
            }
            
            public Builder ticketId(String ticketId) {
                this.ticketId = ticketId;
                return this;
            }
            
            public Builder projectKey(String projectKey) {
                this.projectKey = projectKey;
                return this;
            }
            
            public Builder summary(String summary) {
                this.summary = summary;
                return this;
            }
            
            public Builder description(String description) {
                this.description = description;
                return this;
            }
            
            public Builder priority(String priority) {
                this.priority = priority;
                return this;
            }
            
            public JiraRequest build() {
                return new JiraRequest(action, ticketId, projectKey, summary, description, priority);
            }
        }
    }
}
