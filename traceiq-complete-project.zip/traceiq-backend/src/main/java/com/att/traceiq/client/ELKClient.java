package com.att.traceiq.client;

import com.att.traceiq.model.ELKLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.util.Base64;
import java.util.List;
import java.util.Map;

/**
 * Client for interacting with ELK/Kibana APIs
 */
@Component
public class ELKClient {

    private static final Logger logger = LoggerFactory.getLogger(ELKClient.class);

    private final RestClient restClient;
    private final String baseUrl;
    private final String username;
    private final String password;
    private final String indexPattern;

    public ELKClient(
            RestClient.Builder restClientBuilder,
            @Value("${traceiq.apis.elk.base-url}") String baseUrl,
            @Value("${traceiq.apis.elk.username}") String username,
            @Value("${traceiq.apis.elk.password}") String password,
            @Value("${traceiq.apis.elk.index-pattern}") String indexPattern) {
        this.baseUrl = baseUrl;
        this.username = username;
        this.password = password;
        this.indexPattern = indexPattern;

        String auth = username + ":" + password;
        String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes());

        this.restClient = restClientBuilder
            .baseUrl(baseUrl)
            .defaultHeader("Authorization", "Basic " + encodedAuth)
            .defaultHeader("Content-Type", "application/json")
            .build();
    }

    /**
     * Fetch all logs for a given traceID
     */
    public List<ELKLog> getLogsByTraceId(String traceId) {
        logger.info("Fetching ELK logs for traceId: {}", traceId);

        Map<String, Object> query = buildQuery(traceId);

        try {
            var response = restClient.post()
                .uri("/_search")
                .body(query)
                .retrieve()
                .body(Map.class);

            return parseLogsFromResponse(response);
        } catch (Exception e) {
            logger.error("Error fetching logs from ELK for traceId: {}", traceId, e);
            return List.of();
        }
    }

    /**
     * Get only error logs for a traceID
     */
    public List<ELKLog> getErrorLogsByTraceId(String traceId) {
        logger.info("Fetching ERROR logs for traceId: {}", traceId);

        Map<String, Object> query = buildQueryWithLevel(traceId, "ERROR");

        try {
            var response = restClient.post()
                .uri("/_search")
                .body(query)
                .retrieve()
                .body(Map.class);

            return parseLogsFromResponse(response);
        } catch (Exception e) {
            logger.error("Error fetching error logs from ELK for traceId: {}", traceId, e);
            return List.of();
        }
    }

    /**
     * Group errors by error message
     */
    public Map<String, List<ELKLog>> groupErrorsByMessage(String microservice) {
        logger.info("Grouping errors for microservice: {}", microservice);
        // Implementation would aggregate by error message
        return Map.of();
    }

    private Map<String, Object> buildQuery(String traceId) {
        return Map.of(
            "query", Map.of(
                "bool", Map.of(
                    "must", List.of(
                        Map.of("match", Map.of("traceId", traceId))
                    )
                )
            ),
            "size", 1000,
            "sort", List.of(Map.of("@timestamp", Map.of("order", "asc")))
        );
    }

    private Map<String, Object> buildQueryWithLevel(String traceId, String level) {
        return Map.of(
            "query", Map.of(
                "bool", Map.of(
                    "must", List.of(
                        Map.of("match", Map.of("traceId", traceId)),
                        Map.of("match", Map.of("level", level))
                    )
                )
            ),
            "size", 1000,
            "sort", List.of(Map.of("@timestamp", Map.of("order", "asc")))
        );
    }

    @SuppressWarnings("unchecked")
    private List<ELKLog> parseLogsFromResponse(Map<String, Object> response) {
        try {
            Map<String, Object> hits = (Map<String, Object>) response.get("hits");
            List<Map<String, Object>> hitsList = (List<Map<String, Object>>) hits.get("hits");

            return hitsList.stream()
                .map(hit -> {
                    Map<String, Object> source = (Map<String, Object>) hit.get("_source");
                    return new ELKLog(
                        (String) source.get("@timestamp"),
                        (String) source.get("level"),
                        (String) source.get("message"),
                        (String) source.get("logger"),
                        (String) source.get("serviceName"),
                        (String) source.get("traceId"),
                        (String) source.get("spanId"),
                        (String) source.get("threadName")
                    );
                })
                .toList();
        } catch (Exception e) {
            logger.error("Error parsing ELK response", e);
            return List.of();
        }
    }
}
