<template>
  <div>
    <h2 class="text-3xl font-bold mb-6">Job Runs</h2>
    
    <div class="bg-white p-6 rounded-lg shadow mb-6">
      <button @click="runIngest" :disabled="running" class="px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700 disabled:bg-gray-400">
        <i class="fas fa-play mr-2"></i>
        {{ running ? 'Running...' : 'Run Ingest Job' }}
      </button>
    </div>
    
    <div class="bg-white rounded-lg shadow">
      <div class="p-6">
        <div class="overflow-x-auto">
          <table class="w-full">
            <thead class="bg-gray-50">
              <tr>
                <th class="px-4 py-3 text-left">Job Name</th>
                <th class="px-4 py-3 text-left">Status</th>
                <th class="px-4 py-3 text-left">Start Time</th>
                <th class="px-4 py-3 text-left">End Time</th>
                <th class="px-4 py-3 text-left">Records Processed</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="job in jobs" :key="job.jobId" class="border-t hover:bg-gray-50">
                <td class="px-4 py-3 font-semibold">{{ job.jobName }}</td>
                <td class="px-4 py-3">
                  <span :class="statusClass(job.status)" class="px-2 py-1 rounded text-xs font-semibold">
                    {{ job.status }}
                  </span>
                </td>
                <td class="px-4 py-3 text-sm">{{ formatDate(job.startTime) }}</td>
                <td class="px-4 py-3 text-sm">{{ formatDate(job.endTime) }}</td>
                <td class="px-4 py-3">{{ job.recordsProcessed || 0 }}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import api from '../api/traceiq'

const jobs = ref([])
const running = ref(false)

const loadJobs = async () => {
  try {
    const res = await api.getJobs()
    jobs.value = res.data.jobs
  } catch (error) {
    console.error('Failed to load jobs:', error)
  }
}

const runIngest = async () => {
  running.value = true
  try {
    await api.runIngestJob()
    await loadJobs()
  } catch (error) {
    console.error('Failed to run ingest job:', error)
  } finally {
    running.value = false
  }
}

const statusClass = (status) => {
  const classes = {
    COMPLETED: 'bg-green-600 text-white',
    RUNNING: 'bg-blue-600 text-white',
    FAILED: 'bg-red-600 text-white',
    SCHEDULED: 'bg-yellow-600 text-white'
  }
  return classes[status] || 'bg-gray-600 text-white'
}

const formatDate = (timestamp) => {
  return timestamp ? new Date(timestamp).toLocaleString() : '-'
}

onMounted(() => {
  loadJobs()
})
</script>
