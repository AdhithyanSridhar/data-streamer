package com.example.demo.tools;

import dev.langchain4j.agent.tool.Tool;
import org.springframework.stereotype.Component;

@Component
public class GitHubTool {

  @Tool("Find recent PRs merged for a microservice")
  public RecentPRsResponse getRecentPRs(RecentPRsRequest recentPRsRequest) {
    System.out.println("Fetching recent PRs for: " + recentPRsRequest.microservice);
    return new RecentPRsResponse(
        "Simulated PRs for "
            + recentPRsRequest.microservice
            + ": PR #123: Feature - Add new endpoint, PR #125: Bugfix - Fix null pointer exception.");
  }

  @Tool("Get code owners for a microservice")
  public CodeOwnersResponse getCodeOwners(CodeOwnersRequest codeOwnersRequest) {
    System.out.println("Fetching code owners for: " + codeOwnersRequest.microservice);
    return new CodeOwnersResponse(
        "Simulated code owners for " + codeOwnersRequest.microservice + ": @user1, @user2.");
  }

  @Tool("Get an overview of the microservice involved")
  public MicroserviceOverviewResponse getMicroserviceOverview(
      MicroserviceOverviewRequest microserviceOverviewRequest) {
    System.out.println("Fetching overview for: " + microserviceOverviewRequest.microservice);
    return new MicroserviceOverviewResponse(
        "Simulated overview for "
            + microserviceOverviewRequest.microservice
            + ": This service is responsible for handling user authentication and authorization.");
  }

  public record RecentPRsRequest(String microservice) {}

  public record RecentPRsResponse(String prs) {}

  public record CodeOwnersRequest(String microservice) {}

  public record CodeOwnersResponse(String owners) {}

  public record MicroserviceOverviewRequest(String microservice) {}

  public record MicroserviceOverviewResponse(String overview) {}
}
