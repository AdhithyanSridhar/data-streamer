package com.traceiq.adapters.k8s;

import com.traceiq.adapters.config.AdapterConfiguration;
import com.traceiq.utils.RetryUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class KubernetesAdapter {
    private static final Logger logger = LoggerFactory.getLogger(KubernetesAdapter.class);
    private final RestTemplate restTemplate;
    private final AdapterConfiguration config;
    
    public KubernetesAdapter(RestTemplate restTemplate, AdapterConfiguration config) {
        this.restTemplate = restTemplate;
        this.config = config;
    }
    
    public String getPodStatus(String namespace, String podName) {
        return RetryUtils.executeWithRetry(() -> {
            HttpHeaders headers = new HttpHeaders();
            headers.setBearerAuth(config.getK8sApiToken());
            HttpEntity<Void> request = new HttpEntity<>(headers);
            
            logger.info("Fetching K8s pod status: {}/{}", namespace, podName);
            ResponseEntity<String> response = restTemplate.exchange(
                config.getK8sApiUrl() + "/api/v1/namespaces/" + namespace + "/pods/" + podName,
                HttpMethod.GET,
                request,
                String.class
            );
            return response.getBody();
        }, "K8s Get Pod Status");
    }
    
    public String getServiceInfo(String namespace, String serviceName) {
        logger.info("Getting service info for {}/{}", namespace, serviceName);
        return "{\"service\": \"" + serviceName + "\", \"namespace\": \"" + namespace + "\", \"status\": \"Running\"}";
    }
}
