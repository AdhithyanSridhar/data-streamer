#!/bin/bash

# TraceIQ Backend Startup Script

echo "========================================="
echo " TraceIQ Backend Startup"
echo "========================================="

# Set Java 17
export JAVA_HOME=/home/user/jdk-17.0.9+9
export PATH=$JAVA_HOME/bin:/home/user/apache-maven-3.9.5/bin:$PATH

echo "Using Java: $(java -version 2>&1 | head -1)"
echo "Using Maven: $(mvn --version | head -1)"

# Navigate to backend directory
cd "$(dirname "$0")/traceiq-backend" || exit 1

echo ""
echo "Building application..."
mvn clean package -DskipTests

if [ $? -eq 0 ]; then
    echo ""
    echo "========================================="
    echo " Starting TraceIQ Backend Server"
    echo "========================================="
    echo ""
    echo "API will be available at: http://localhost:8080"
    echo "Health Check: http://localhost:8080/api/v1/trace/health"
    echo ""
    
    # Run the application
    java -jar target/traceiq-backend-1.0.0.jar
else
    echo ""
    echo "Build failed. Please check the errors above."
    exit 1
fi
