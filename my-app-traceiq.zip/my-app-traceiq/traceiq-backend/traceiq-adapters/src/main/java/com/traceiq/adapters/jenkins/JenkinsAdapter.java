package com.traceiq.adapters.jenkins;

import com.traceiq.adapters.config.AdapterConfiguration;
import com.traceiq.utils.RetryUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class JenkinsAdapter {
    private static final Logger logger = LoggerFactory.getLogger(JenkinsAdapter.class);
    private final RestTemplate restTemplate;
    private final AdapterConfiguration config;
    
    public JenkinsAdapter(RestTemplate restTemplate, AdapterConfiguration config) {
        this.restTemplate = restTemplate;
        this.config = config;
    }
    
    public String getJobStatus(String jobName) {
        return RetryUtils.executeWithRetry(() -> {
            HttpHeaders headers = new HttpHeaders();
            headers.setBasicAuth("admin", config.getJenkinsApiToken());
            HttpEntity<Void> request = new HttpEntity<>(headers);
            
            logger.info("Fetching Jenkins job status: {}", jobName);
            ResponseEntity<String> response = restTemplate.exchange(
                config.getJenkinsApiUrl() + "/job/" + jobName + "/api/json",
                HttpMethod.GET,
                request,
                String.class
            );
            return response.getBody();
        }, "Jenkins Get Job Status");
    }
    
    public String getBuildStatus(String jobName, int buildNumber) {
        logger.info("Getting build status for {}: #{}", jobName, buildNumber);
        return "{\"status\": \"SUCCESS\", \"buildNumber\": " + buildNumber + "}";
    }
}
