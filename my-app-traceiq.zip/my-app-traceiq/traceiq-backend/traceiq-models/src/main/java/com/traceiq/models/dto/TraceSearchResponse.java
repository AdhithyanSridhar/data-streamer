package com.traceiq.models.dto;

import com.traceiq.models.domain.*;
import java.util.List;

/**
 * Response DTO for trace search API.
 * Returns comprehensive trace information with errors and flow.
 */
public record TraceSearchResponse(
    String traceId,
    double confidenceScore,
    int errorCount,
    List<ErrorLog> errors,
    List<ServiceNode> servicesInvolved,
    TimelineEvent timeline,
    FlowDiagram flowDiagram,
    String status
) {
    /**
     * Flow diagram representation showing service dependencies.
     */
    public record FlowDiagram(
        List<Node> nodes,
        List<Edge> edges
    ) {
        public record Node(
            String id,
            String serviceName,
            String type,
            int errorCount
        ) {}

        public record Edge(
            String from,
            String to,
            String protocol,
            String status
        ) {}
    }

    public static class Builder {
        private String traceId;
        private double confidenceScore;
        private int errorCount;
        private List<ErrorLog> errors;
        private List<ServiceNode> servicesInvolved;
        private TimelineEvent timeline;
        private FlowDiagram flowDiagram;
        private String status;

        public Builder traceId(String traceId) {
            this.traceId = traceId;
            return this;
        }

        public Builder confidenceScore(double confidenceScore) {
            this.confidenceScore = confidenceScore;
            return this;
        }

        public Builder errorCount(int errorCount) {
            this.errorCount = errorCount;
            return this;
        }

        public Builder errors(List<ErrorLog> errors) {
            this.errors = errors;
            return this;
        }

        public Builder servicesInvolved(List<ServiceNode> servicesInvolved) {
            this.servicesInvolved = servicesInvolved;
            return this;
        }

        public Builder timeline(TimelineEvent timeline) {
            this.timeline = timeline;
            return this;
        }

        public Builder flowDiagram(FlowDiagram flowDiagram) {
            this.flowDiagram = flowDiagram;
            return this;
        }

        public Builder status(String status) {
            this.status = status;
            return this;
        }

        public TraceSearchResponse build() {
            return new TraceSearchResponse(
                traceId, confidenceScore, errorCount, errors,
                servicesInvolved, timeline, flowDiagram, status
            );
        }
    }

    public static Builder builder() {
        return new Builder();
    }
}
