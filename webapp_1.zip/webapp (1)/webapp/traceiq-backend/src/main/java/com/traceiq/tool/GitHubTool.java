package com.traceiq.tool;

import com.traceiq.model.GitHubPRInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

/**
 * Spring AI Tool for GitHub API integration.
 * Provides PR analysis, code owner identification, and repository insights.
 */
@Component
public class GitHubTool implements Function<GitHubTool.GitHubRequest, List<GitHubPRInfo>> {
    
    private static final Logger logger = LoggerFactory.getLogger(GitHubTool.class);
    
    private final WebClient webClient;
    
    public GitHubTool(
        @Value("${github.api-url:https://api.github.com}") String githubApiUrl,
        @Value("${github.api-token}") String githubApiToken,
        WebClient.Builder webClientBuilder
    ) {
        this.webClient = webClientBuilder
            .baseUrl(githubApiUrl)
            .defaultHeader("Authorization", "Bearer " + githubApiToken)
            .defaultHeader("Accept", "application/vnd.github+json")
            .build();
        
        logger.info("GitHubTool initialized with API URL: {}", githubApiUrl);
    }
    
    @Override
    public List<GitHubPRInfo> apply(GitHubRequest request) {
        logger.info("Executing GitHub tool for repository: {}/{}", request.owner(), request.repo());
        
        return switch (request.action()) {
            case "getRecentPRs" -> getRecentMergedPRs(request);
            case "getServicePRs" -> getServicePRs(request);
            default -> throw new IllegalArgumentException("Unknown action: " + request.action());
        };
    }
    
    /**
     * Get recent merged PRs for a repository.
     */
    private List<GitHubPRInfo> getRecentMergedPRs(GitHubRequest request) {
        logger.info("Fetching recent merged PRs for {}/{}", request.owner(), request.repo());
        
        try {
            List<Map<String, Object>> response = webClient.get()
                .uri(uriBuilder -> uriBuilder
                    .path("/repos/{owner}/{repo}/pulls")
                    .queryParam("state", "closed")
                    .queryParam("sort", "updated")
                    .queryParam("direction", "desc")
                    .queryParam("per_page", 10)
                    .build(request.owner(), request.repo()))
                .retrieve()
                .bodyToFlux(Map.class)
                .collectList()
                .block();
            
            if (response == null) {
                return List.of();
            }
            
            return response.stream()
                .filter(pr -> pr.get("merged_at") != null)
                .map(this::parsePRInfo)
                .limit(5)
                .toList();
            
        } catch (Exception e) {
            logger.error("Error fetching recent PRs", e);
            return List.of();
        }
    }
    
    /**
     * Get PRs related to a specific service/microservice.
     */
    private List<GitHubPRInfo> getServicePRs(GitHubRequest request) {
        logger.info("Fetching PRs for service: {}", request.serviceName());
        
        try {
            // Search for PRs that modified files in the service directory
            String query = String.format("repo:%s/%s %s is:pr is:merged",
                request.owner(),
                request.repo(),
                request.serviceName()
            );
            
            Map<String, Object> searchResponse = webClient.get()
                .uri(uriBuilder -> uriBuilder
                    .path("/search/issues")
                    .queryParam("q", query)
                    .queryParam("sort", "updated")
                    .queryParam("per_page", 5)
                    .build())
                .retrieve()
                .bodyToMono(Map.class)
                .block();
            
            if (searchResponse == null) {
                return List.of();
            }
            
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> items = (List<Map<String, Object>>) searchResponse.get("items");
            
            return items.stream()
                .map(this::parsePRInfo)
                .toList();
            
        } catch (Exception e) {
            logger.error("Error fetching service PRs", e);
            return List.of();
        }
    }
    
    // Helper methods
    
    @SuppressWarnings("unchecked")
    private GitHubPRInfo parsePRInfo(Map<String, Object> pr) {
        String prNumber = String.valueOf(pr.get("number"));
        String title = (String) pr.get("title");
        
        Map<String, Object> user = (Map<String, Object>) pr.get("user");
        String author = user != null ? (String) user.get("login") : "Unknown";
        
        String state = (String) pr.get("state");
        String mergedAtStr = (String) pr.get("merged_at");
        Instant mergedAt = mergedAtStr != null ? Instant.parse(mergedAtStr) : null;
        
        Map<String, Object> base = (Map<String, Object>) pr.get("base");
        String targetBranch = base != null ? (String) base.get("ref") : "main";
        
        String htmlUrl = (String) pr.get("html_url");
        
        // Files changed would require additional API call
        List<String> filesChanged = List.of("See PR for details");
        
        return new GitHubPRInfo(
            prNumber,
            title,
            author,
            state,
            mergedAt,
            targetBranch,
            filesChanged,
            htmlUrl
        );
    }
    
    /**
     * Request model for GitHub tool.
     */
    public record GitHubRequest(
        String action,
        String owner,
        String repo,
        String serviceName
    ) {
        public static Builder builder() {
            return new Builder();
        }
        
        public static class Builder {
            private String action;
            private String owner;
            private String repo;
            private String serviceName;
            
            public Builder action(String action) {
                this.action = action;
                return this;
            }
            
            public Builder owner(String owner) {
                this.owner = owner;
                return this;
            }
            
            public Builder repo(String repo) {
                this.repo = repo;
                return this;
            }
            
            public Builder serviceName(String serviceName) {
                this.serviceName = serviceName;
                return this;
            }
            
            public GitHubRequest build() {
                return new GitHubRequest(action, owner, repo, serviceName);
            }
        }
    }
}
