# TraceIQ Frontend

Modern Vue.js UI for AI-powered Root Cause Analysis Platform

## Overview

TraceIQ Frontend provides an intuitive interface for:
- **Trace Search**: Search and visualize error traces
- **RCA Analysis**: View AI-generated root cause analysis
- **Implementation Plans**: Access curated GitHub Copilot prompts
- **Error Management**: Browse and filter error logs
- **Job Monitoring**: Track scheduled jobs and execution history

## Tech Stack

- **Vue 3** - Progressive JavaScript framework
- **Vite** - Next-generation frontend tooling
- **Pinia** - State management (replaces Vuex)
- **Vue Router** - Client-side routing
- **Axios** - HTTP client
- **TailwindCSS** - Utility-first CSS (via CDN)
- **Font Awesome** - Icons

## Quick Start

### Prerequisites
- Node.js 18+ and npm 9+

### Installation

```bash
cd traceiq-frontend
npm install
```

### Development

```bash
# Start dev server (proxies API calls to localhost:8080)
npm run dev

# Access at http://localhost:3000
```

### Build

```bash
# Build for production
npm run build

# Preview production build
npm run preview
```

## Project Structure

```
traceiq-frontend/
├── src/
│   ├── views/              # Page components
│   │   ├── TraceSearch.vue    # Main trace search screen
│   │   ├── ErrorsList.vue     # Errors list screen
│   │   ├── Jobs.vue           # Jobs management screen
│   │   └── Help.vue           # Help & FAQ screen
│   ├── components/         # Reusable components
│   ├── stores/            # Pinia stores
│   ├── services/          # API services
│   ├── router.js          # Route definitions
│   ├── main.js            # App entry point
│   └── App.vue            # Root component
├── public/                # Static assets
├── index.html             # HTML template
├── vite.config.js         # Vite configuration
└── package.json           # Dependencies
```

## Screens

### 1. Trace Search (/)
- Single trace ID input
- Confidence score, error count display
- Service flow diagram
- Timeline visualization
- Action buttons:
  - **Get RCA**: Generate root cause analysis
  - **Get Implementation Plan**: Generate code fixes
  - **God Mode**: Run complete analysis

### 2. Errors List (/errors)
- Paginated error list from Cassandra
- Clickable rows navigate to trace detail
- Filter by service, team, level

### 3. Jobs (/jobs)
- List configured jobs
- Execution history
- Schedule information
- Status indicators

### 4. Help (/help)
- Team members with photos
- Product vision and version
- Swagger integration
- Useful tool links (GitHub, Jenkins, Dynatrace, Jira)
- FAQ section
- Feedback option

## API Integration

### Configuration

Vite dev server proxies API calls:
```javascript
// vite.config.js
server: {
  proxy: {
    '/api': {
      target: 'http://localhost:8080',
      changeOrigin: true
    }
  }
}
```

### API Calls Example

```javascript
import axios from 'axios'

// Search trace
const response = await axios.get(`/api/trace/${traceId}`)

// Generate RCA
const rcaResponse = await axios.post(`/api/trace/${traceId}/rca`, {
  traceId,
  enableAI: true
})

// God Mode
const godResponse = await axios.post(`/api/trace/${traceId}/god-mode`)
```

## UI Components

### God Mode Button
- Purple color scheme
- Runs complete RCA + Implementation Plan
- Shows loading spinner during processing

### RCA Display
- Root cause summary
- Detailed analysis text
- Severity badge (HIGH/MEDIUM/LOW)
- Contributing factors list

### Implementation Plan Display
- Code locations with file paths
- Line numbers and code snippets
- Issue descriptions
- GitHub Copilot prompts (formatted, copyable)

### Timeline
- Chronological event list
- Service-based filtering
- Event type indicators

## Styling

Using TailwindCSS via CDN:
```html
<script src="https://cdn.tailwindcss.com"></script>
```

### Color Scheme
- **Primary**: Indigo (indigo-600)
- **Success**: Green (green-600)
- **Error**: Red (red-600)
- **Warning**: Orange (orange-500)
- **Info**: Blue (blue-600)

## Development

### Add New View
1. Create `.vue` file in `src/views/`
2. Add route to `src/router.js`
3. Add navigation link in `App.vue`

### API Service Pattern
```javascript
// src/services/traceService.js
import axios from 'axios'

export default {
  async searchTrace(traceId) {
    const response = await axios.get(`/api/trace/${traceId}`)
    return response.data
  }
}
```

### State Management (Pinia)
```javascript
// src/stores/traceStore.js
import { defineStore } from 'pinia'

export const useTraceStore = defineStore('trace', {
  state: () => ({
    currentTrace: null,
    rcaResult: null
  }),
  actions: {
    setTrace(trace) {
      this.currentTrace = trace
    }
  }
})
```

## Production Deployment

### Build Assets
```bash
npm run build
# Outputs to dist/
```

### Serve with Nginx
```nginx
server {
    listen 80;
    server_name traceiq.example.com;
    root /var/www/traceiq-frontend/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api {
        proxy_pass http://backend:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

### Docker
```dockerfile
FROM node:18-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=builder /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

## Features

### God Mode
One-click comprehensive analysis:
1. Fetches trace data
2. Generates RCA
3. Generates implementation plan
4. Provides Copilot prompts

### Responsive Design
- Mobile-friendly
- Tablet-optimized
- Desktop-first

### Loading States
- Spinners for async operations
- Modal overlays for processing
- Progress indicators

## Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)

## Support

For issues or feature requests:
- Email: support@traceiq.example.com
- Internal Wiki: https://wiki.example.com/traceiq

## License

Internal use only - Proprietary
