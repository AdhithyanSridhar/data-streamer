package com.traceiq.tools;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.traceiq.client.JiraClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.function.Function;

/**
 * Spring AI Function Tool for Jira operations
 * Provides ticket management, viewing, and commenting capabilities
 */
@Component("jiraTool")
public class JiraTool implements Function<JiraTool.JiraRequest, JiraTool.JiraResponse> {
    public static final Logger log = LoggerFactory.getLogger(JiraTool.class);

    private final JiraClient jiraClient;

    public JiraTool(JiraClient jiraClient) {
        this.jiraClient = jiraClient;
    }

    @Override
    public JiraResponse apply(JiraRequest request) {
        log.info("Executing Jira tool with operation: {}", request.operation);

        try {
            return switch (request.operation.toUpperCase()) {
                case "CREATE_TICKET" -> createTicket(request);
                case "GET_TICKET" -> getTicketDetails(request);
                case "GET_COMMENTS" -> getComments(request);
                case "ADD_COMMENT" -> addComment(request);
                case "GET_ATTACHMENTS" -> getAttachments(request);
                case "UPDATE_TICKET" -> updateTicket(request);
                case "SEARCH_TICKETS" -> searchTickets(request);
                default -> JiraResponse.builder()
                        .success(false)
                        .message("Unknown operation: " + request.operation)
                        .build();
            };
        } catch (Exception e) {
            log.error("Error executing Jira tool operation: {}", request.operation, e);
            return JiraResponse.builder()
                    .success(false)
                    .message("Error: " + e.getMessage())
                    .build();
        }
    }

    private JiraResponse createTicket(JiraRequest request) {
        Map<String, Object> ticket = jiraClient.createTicket(
                request.projectKey,
                request.summary,
                request.description,
                request.issueType,
                request.priority,
                request.assignee
        );

        return JiraResponse.builder()
                .success(true)
                .data(ticket)
                .message("Created Jira ticket: " + ticket.get("key"))
                .build();
    }

    private JiraResponse getTicketDetails(JiraRequest request) {
        Map<String, Object> ticket = jiraClient.getTicketDetails(request.ticketKey);

        return JiraResponse.builder()
                .success(true)
                .data(ticket)
                .message("Retrieved ticket details for: " + request.ticketKey)
                .build();
    }

    private JiraResponse getComments(JiraRequest request) {
        List<Map<String, Object>> comments = jiraClient.getComments(request.ticketKey);

        return JiraResponse.builder()
                .success(true)
                .data(Map.of("comments", comments, "count", comments.size()))
                .message("Retrieved " + comments.size() + " comments")
                .build();
    }

    private JiraResponse addComment(JiraRequest request) {
        Map<String, Object> comment = jiraClient.addComment(
                request.ticketKey,
                request.commentText
        );

        return JiraResponse.builder()
                .success(true)
                .data(comment)
                .message("Added comment to ticket: " + request.ticketKey)
                .build();
    }

    private JiraResponse getAttachments(JiraRequest request) {
        List<Map<String, Object>> attachments = jiraClient.getAttachments(request.ticketKey);

        return JiraResponse.builder()
                .success(true)
                .data(Map.of("attachments", attachments, "count", attachments.size()))
                .message("Retrieved " + attachments.size() + " attachments")
                .build();
    }

    private JiraResponse updateTicket(JiraRequest request) {
        Map<String, Object> result = jiraClient.updateTicket(
                request.ticketKey,
                request.fieldsToUpdate
        );

        return JiraResponse.builder()
                .success(true)
                .data(result)
                .message("Updated ticket: " + request.ticketKey)
                .build();
    }

    private JiraResponse searchTickets(JiraRequest request) {
        List<Map<String, Object>> tickets = jiraClient.searchTickets(
                request.jql,
                request.maxResults
        );

        return JiraResponse.builder()
                .success(true)
                .data(Map.of("tickets", tickets, "count", tickets.size()))
                .message("Found " + tickets.size() + " tickets")
                .build();
    }

    /**
     * Request object for Jira operations
     */
    public record JiraRequest(
            @JsonProperty(required = true)
            @JsonPropertyDescription("Operation: CREATE_TICKET, GET_TICKET, GET_COMMENTS, ADD_COMMENT, GET_ATTACHMENTS, UPDATE_TICKET, SEARCH_TICKETS")
            String operation,

            @JsonPropertyDescription("Jira ticket key (e.g., PROJ-123)")
            String ticketKey,

            @JsonPropertyDescription("Project key for ticket creation")
            String projectKey,

            @JsonPropertyDescription("Ticket summary/title")
            String summary,

            @JsonPropertyDescription("Ticket description")
            String description,

            @JsonPropertyDescription("Issue type: Bug, Story, Task, etc.")
            String issueType,

            @JsonPropertyDescription("Priority: Highest, High, Medium, Low, Lowest")
            String priority,

            @JsonPropertyDescription("Assignee username")
            String assignee,

            @JsonPropertyDescription("Comment text to add")
            String commentText,

            @JsonPropertyDescription("JQL query for ticket search")
            String jql,

            @JsonPropertyDescription("Maximum results for search (default 50)")
            Integer maxResults,

            @JsonPropertyDescription("Fields to update in ticket")
            Map<String, Object> fieldsToUpdate
    ) {
    }

    /**
     * Response object for Jira operations
     */
    public record JiraResponse(
            boolean success,
            String message,
            Map<String, Object> data
    ) {
        public static JiraResponseBuilder builder() {
            return new JiraResponseBuilder();
        }

        public static class JiraResponseBuilder {
            private boolean success;
            private String message;
            private Map<String, Object> data;

            public JiraResponseBuilder success(boolean success) {
                this.success = success;
                return this;
            }

            public JiraResponseBuilder message(String message) {
                this.message = message;
                return this;
            }

            public JiraResponseBuilder data(Map<String, Object> data) {
                this.data = data;
                return this;
            }

            public JiraResponse build() {
                return new JiraResponse(success, message, data);
            }
        }
    }
}
