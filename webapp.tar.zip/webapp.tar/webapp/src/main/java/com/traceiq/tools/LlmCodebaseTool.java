package com.traceiq.tools;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.traceiq.client.LlmCodebaseClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.function.Function;

/**
 * Spring AI Function Tool for Vectorized Codebase LLM
 * Provides code search, location identification, and fix suggestions
 */
@Component("llmCodebaseTool")
public class LlmCodebaseTool implements Function<LlmCodebaseTool.CodebaseRequest, LlmCodebaseTool.CodebaseResponse> {
    public static final Logger log = LoggerFactory.getLogger(LlmCodebaseTool.class);

    private final LlmCodebaseClient codebaseClient;

    public LlmCodebaseTool(LlmCodebaseClient codebaseClient) {
        this.codebaseClient = codebaseClient;
    }

    @Override
    public CodebaseResponse apply(CodebaseRequest request) {
        log.info("Executing Codebase LLM tool with operation: {}", request.operation);

        try {
            return switch (request.operation.toUpperCase()) {
                case "LOCATE_CODE" -> locateProblematicCode(request);
                case "SUGGEST_FIX" -> suggestCodeFix(request);
                case "IMPLEMENTATION_PLAN" -> generateImplementationPlan(request);
                case "SEARCH_SIMILAR" -> searchSimilarCode(request);
                default -> CodebaseResponse.builder()
                        .success(false)
                        .message("Unknown operation: " + request.operation)
                        .build();
            };
        } catch (Exception e) {
            log.error("Error executing Codebase LLM tool: {}", request.operation, e);
            return CodebaseResponse.builder()
                    .success(false)
                    .message("Error: " + e.getMessage())
                    .build();
        }
    }

    private CodebaseResponse locateProblematicCode(CodebaseRequest request) {
        Map<String, Object> location = codebaseClient.locateCode(
                request.errorMessage,
                request.stackTrace,
                request.microserviceName,
                request.context
        );

        return CodebaseResponse.builder()
                .success(true)
                .data(location)
                .message("Code location identified")
                .build();
    }

    private CodebaseResponse suggestCodeFix(CodebaseRequest request) {
        Map<String, Object> fix = codebaseClient.suggestFix(
                request.codeSnippet,
                request.rootCause,
                request.context
        );

        return CodebaseResponse.builder()
                .success(true)
                .data(fix)
                .message("Code fix suggested")
                .build();
    }

    private CodebaseResponse generateImplementationPlan(CodebaseRequest request) {
        Map<String, Object> plan = codebaseClient.generateImplementationPlan(
                request.fixDescription,
                request.codeContext,
                request.dependencies
        );

        return CodebaseResponse.builder()
                .success(true)
                .data(plan)
                .message("Implementation plan generated")
                .build();
    }

    private CodebaseResponse searchSimilarCode(CodebaseRequest request) {
        Map<String, Object> similar = codebaseClient.searchSimilar(
                request.codeSnippet,
                request.microserviceName
        );

        return CodebaseResponse.builder()
                .success(true)
                .data(similar)
                .message("Similar code found")
                .build();
    }

    public record CodebaseRequest(
            @JsonProperty(required = true)
            @JsonPropertyDescription("Operation: LOCATE_CODE, SUGGEST_FIX, IMPLEMENTATION_PLAN, SEARCH_SIMILAR")
            String operation,

            @JsonPropertyDescription("Error message to locate")
            String errorMessage,

            @JsonPropertyDescription("Stack trace")
            String stackTrace,

            @JsonPropertyDescription("Microservice name")
            String microserviceName,

            @JsonPropertyDescription("Code snippet")
            String codeSnippet,

            @JsonPropertyDescription("Root cause description")
            String rootCause,

            @JsonPropertyDescription("Additional context")
            String context,

            @JsonPropertyDescription("Fix description")
            String fixDescription,

            @JsonPropertyDescription("Code context")
            String codeContext,

            @JsonPropertyDescription("Dependencies list")
            String dependencies
    ) {
    }

    public record CodebaseResponse(
            boolean success,
            String message,
            Map<String, Object> data
    ) {
        public static CodebaseResponseBuilder builder() {
            return new CodebaseResponseBuilder();
        }

        public static class CodebaseResponseBuilder {
            private boolean success;
            private String message;
            private Map<String, Object> data;

            public CodebaseResponseBuilder success(boolean success) {
                this.success = success;
                return this;
            }

            public CodebaseResponseBuilder message(String message) {
                this.message = message;
                return this;
            }

            public CodebaseResponseBuilder data(Map<String, Object> data) {
                this.data = data;
                return this;
            }

            public CodebaseResponse build() {
                return new CodebaseResponse(success, message, data);
            }
        }
    }
}
