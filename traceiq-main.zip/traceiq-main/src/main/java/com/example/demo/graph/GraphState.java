package com.example.demo.graph;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GraphState {

  private Map<String, Object> state;
  private List<Edge> edges;
  private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

  public GraphState() {
    this.state = new HashMap<>();
    this.edges = new ArrayList<>();
  }

  @SuppressWarnings("unchecked")
  public <T> T get(String key) {
    return (T) state.get(key);
  }

  public void set(String key, Object value) {
    state.put(key, value);
  }

  public void addEdge(Edge edge) {
    edges.add(edge);
  }

  public List<Edge> getEdges() {
    return new ArrayList<>(edges); // Return a copy to prevent external modification.
  }

  public String toJson() {
    Map<String, Object> combinedState = new HashMap<>();
    combinedState.put("state", state);
    combinedState.put("edges", edges);
    try {
      return OBJECT_MAPPER.writeValueAsString(combinedState);
    } catch (JsonProcessingException e) {
      return "{\"error\": \"Could not serialize state to JSON\"}";
    }
  }

  @Override
  public String toString() {
    return "GraphState{" + "state=" + state + ", edges=" + edges + '}';
  }
}
