package com.att.traceiq.model;

import java.time.LocalDateTime;

public record JiraTicket(
    String id,
    String key,
    String summary,
    String description,
    String status,
    String assignee,
    String reporter,
    LocalDateTime createdAt,
    String url
) {}
