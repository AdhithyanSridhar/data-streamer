<template>
  <div class="glass-card pa-5">
    <div class="section-header">
      <div class="section-header__icon">
        <v-icon icon="mdi-chart-bar" size="20"></v-icon>
      </div>
      <h2 class="section-header__title">Workflow Analytics</h2>
    </div>
    
    <v-row>
      <v-col cols="12">
        <div class="chart-container">
          <Doughnut :data="doughnutData" :options="doughnutOptions" />
        </div>
      </v-col>
    </v-row>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js'
import { Doughnut } from 'vue-chartjs'

ChartJS.register(ArcElement, Tooltip, Legend)

const props = defineProps({
  chartData: { type: Object, required: true }
})

const doughnutData = computed(() => ({
  labels: ['Completed', 'Pending', 'Failed'],
  datasets: [{
    data: [
      props.chartData.taskCompletion.completed,
      props.chartData.taskCompletion.pending,
      props.chartData.taskCompletion.failed
    ],
    backgroundColor: ['#10b981', '#f59e0b', '#ef4444'],
    borderWidth: 0
  }]
}))

const doughnutOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'bottom',
      labels: { color: '#666666', usePointStyle: true }
    }
  }
}
</script>

<style scoped>
.chart-container {
  height: 200px;
}
</style>
