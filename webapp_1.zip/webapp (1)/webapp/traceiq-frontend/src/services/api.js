import axios from 'axios'

const API_BASE_URL = '/api/v1'

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 120000, // 2 minutes for long-running analysis
  headers: {
    'Content-Type': 'application/json'
  }
})

// Request interceptor
apiClient.interceptors.request.use(
  (config) => {
    console.log('API Request:', config.method.toUpperCase(), config.url)
    return config
  },
  (error) => {
    console.error('Request Error:', error)
    return Promise.reject(error)
  }
)

// Response interceptor
apiClient.interceptors.response.use(
  (response) => {
    console.log('API Response:', response.status, response.config.url)
    return response
  },
  (error) => {
    console.error('Response Error:', error.response?.status, error.message)
    return Promise.reject(error)
  }
)

/**
 * Analyze a trace and get RCA results.
 * 
 * @param {Object} request - Trace analysis request
 * @returns {Promise<Object>} Analysis response
 */
export const analyzeTraceApi = async (request) => {
  try {
    const response = await apiClient.post('/trace/analyze', request)
    return response.data
  } catch (error) {
    throw new Error(
      error.response?.data?.message || 
      error.message || 
      'Failed to analyze trace'
    )
  }
}

/**
 * Health check endpoint.
 */
export const healthCheck = async () => {
  try {
    const response = await apiClient.get('/trace/health')
    return response.data
  } catch (error) {
    throw new Error('Backend health check failed')
  }
}

export default apiClient
