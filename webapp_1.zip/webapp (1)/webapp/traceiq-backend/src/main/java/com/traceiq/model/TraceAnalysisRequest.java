package com.traceiq.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;
import java.util.List;

/**
 * Request model for trace analysis.
 * Supports both traceId-based and error-details-based analysis.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record TraceAnalysisRequest(
    @NotBlank(message = "TraceId or error details required")
    String traceId,
    
    String errorMessage,
    String microserviceName,
    String environment,
    
    // Analysis options
    boolean includeJiraAnalysis,
    boolean includeGitHubAnalysis,
    boolean includePerformanceAnalysis,
    boolean includeCodeAnalysis,
    boolean autoCreateJiraTicket,
    
    // Additional context
    List<String> additionalFilters,
    String customPrompt
) {
    public static Builder builder() {
        return new Builder();
    }
    
    public static class Builder {
        private String traceId;
        private String errorMessage;
        private String microserviceName;
        private String environment;
        private boolean includeJiraAnalysis;
        private boolean includeGitHubAnalysis;
        private boolean includePerformanceAnalysis;
        private boolean includeCodeAnalysis;
        private boolean autoCreateJiraTicket;
        private List<String> additionalFilters;
        private String customPrompt;
        
        public Builder traceId(String traceId) {
            this.traceId = traceId;
            return this;
        }
        
        public Builder errorMessage(String errorMessage) {
            this.errorMessage = errorMessage;
            return this;
        }
        
        public Builder microserviceName(String microserviceName) {
            this.microserviceName = microserviceName;
            return this;
        }
        
        public Builder environment(String environment) {
            this.environment = environment;
            return this;
        }
        
        public Builder includeJiraAnalysis(boolean includeJiraAnalysis) {
            this.includeJiraAnalysis = includeJiraAnalysis;
            return this;
        }
        
        public Builder includeGitHubAnalysis(boolean includeGitHubAnalysis) {
            this.includeGitHubAnalysis = includeGitHubAnalysis;
            return this;
        }
        
        public Builder includePerformanceAnalysis(boolean includePerformanceAnalysis) {
            this.includePerformanceAnalysis = includePerformanceAnalysis;
            return this;
        }
        
        public Builder includeCodeAnalysis(boolean includeCodeAnalysis) {
            this.includeCodeAnalysis = includeCodeAnalysis;
            return this;
        }
        
        public Builder autoCreateJiraTicket(boolean autoCreateJiraTicket) {
            this.autoCreateJiraTicket = autoCreateJiraTicket;
            return this;
        }
        
        public Builder additionalFilters(List<String> additionalFilters) {
            this.additionalFilters = additionalFilters;
            return this;
        }
        
        public Builder customPrompt(String customPrompt) {
            this.customPrompt = customPrompt;
            return this;
        }
        
        public TraceAnalysisRequest build() {
            return new TraceAnalysisRequest(
                traceId, errorMessage, microserviceName, environment,
                includeJiraAnalysis, includeGitHubAnalysis, includePerformanceAnalysis,
                includeCodeAnalysis, autoCreateJiraTicket, additionalFilters, customPrompt
            );
        }
    }
}
