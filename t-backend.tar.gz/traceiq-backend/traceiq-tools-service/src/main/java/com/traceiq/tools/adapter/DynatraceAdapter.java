package com.traceiq.tools.adapter;

import com.traceiq.tools.config.ToolsConfig;
import com.traceiq.utils.JsonUtil;
import com.traceiq.utils.RetryUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

/**
 * Adapter for Dynatrace API integration
 * Fetches telemetry, traces, and service flow information
 */
@Component
public class DynatraceAdapter {
    private static final Logger logger = LoggerFactory.getLogger(DynatraceAdapter.class);

    private final RestTemplate restTemplate;
    private final ToolsConfig toolsConfig;

    public DynatraceAdapter(RestTemplate restTemplate, ToolsConfig toolsConfig) {
        this.restTemplate = restTemplate;
        this.toolsConfig = toolsConfig;
    }

    /**
     * Fetch trace details from Dynatrace
     */
    public Map<String, Object> fetchTrace(String traceId, String correlationId) {
        return RetryUtil.executeWithDefaultRetry(() -> {
            logger.info("[{}] Fetching trace from Dynatrace: {}", correlationId, traceId);

            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Api-Token " + toolsConfig.getDynatraceApiToken());
            headers.set("X-Correlation-Id", correlationId);

            HttpEntity<Void> entity = new HttpEntity<>(headers);

            ResponseEntity<String> response = restTemplate.exchange(
                    toolsConfig.getDynatraceApiUrl() + "/api/v2/traces/" + traceId,
                    HttpMethod.GET,
                    entity,
                    String.class
            );

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                logger.info("[{}] Dynatrace trace fetched successfully", correlationId);
                return JsonUtil.fromJson(response.getBody(), Map.class);
            }

            throw new RuntimeException("Failed to fetch Dynatrace trace");

        }, "Dynatrace-Fetch-Trace");
    }

    /**
     * Fetch service flow diagram from Dynatrace
     */
    public Map<String, Object> fetchServiceFlow(String traceId, String correlationId) {
        return RetryUtil.executeWithDefaultRetry(() -> {
            logger.info("[{}] Fetching service flow from Dynatrace: {}", correlationId, traceId);

            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Api-Token " + toolsConfig.getDynatraceApiToken());
            headers.set("X-Correlation-Id", correlationId);

            HttpEntity<Void> entity = new HttpEntity<>(headers);

            ResponseEntity<String> response = restTemplate.exchange(
                    toolsConfig.getDynatraceApiUrl() + "/api/v2/serviceFlow?traceId=" + traceId,
                    HttpMethod.GET,
                    entity,
                    String.class
            );

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                logger.info("[{}] Service flow fetched successfully", correlationId);
                return JsonUtil.fromJson(response.getBody(), Map.class);
            }

            throw new RuntimeException("Failed to fetch service flow");

        }, "Dynatrace-Service-Flow");
    }
}
