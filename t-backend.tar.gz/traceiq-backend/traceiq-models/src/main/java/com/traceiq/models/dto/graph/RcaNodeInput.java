package com.traceiq.models.dto.graph;

import java.util.Map;

/**
 * Input schema for RCA LLM node in LangGraph4j orchestration
 */
public record RcaNodeInput(
        String traceId,
        String context,
        Map<String, Object> elkData,
        Map<String, Object> dynatraceData,
        String correlationId
) {}
