import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json'
  }
})

export default {
  // Trace API
  searchTrace(traceId, includeRca = false, includeCodeSpot = false, godMode = false) {
    return api.post('/trace/search', {
      traceId,
      includeRca,
      includeCodeSpot,
      godMode
    })
  },
  
  getTrace(traceId) {
    return api.get(`/trace/${traceId}`)
  },
  
  // Errors API
  getErrors(page = 0, size = 50) {
    return api.get('/errors', {
      params: { page, size }
    })
  },
  
  // Jobs API
  getJobs() {
    return api.get('/jobs')
  },
  
  runIngestJob(timeRange = 'now-24h') {
    return api.post('/jobs/ingest/run', null, {
      params: { timeRange }
    })
  },
  
  // Health
  getHealth() {
    return api.get('/health')
  }
}
