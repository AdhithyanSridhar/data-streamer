<template>
  <Teleport to="body">
    <Transition name="tour">
      <div v-if="isVisible" class="tour-overlay">
        <div class="tour-backdrop" @click="skipTour"></div>
        
        <div class="tour-spotlight" :style="spotlightStyle"></div>
        
        <div class="tour-tooltip" :style="tooltipStyle">
          <div class="tour-header">
            <span class="tour-step">{{ currentStep + 1 }} / {{ steps.length }}</span>
            <v-btn icon variant="text" size="x-small" @click="skipTour">
              <v-icon icon="mdi-close"></v-icon>
            </v-btn>
          </div>
          
          <div class="tour-content">
            <div class="tour-icon">
              <v-icon :icon="currentStepData.icon" size="32"></v-icon>
            </div>
            <h3 class="tour-title">{{ currentStepData.title }}</h3>
            <p class="tour-description">{{ currentStepData.description }}</p>
          </div>
          
          <div class="tour-actions">
            <v-btn variant="text" size="small" @click="skipTour">Skip Tour</v-btn>
            <v-spacer></v-spacer>
            <v-btn variant="text" size="small" @click="prevStep" :disabled="currentStep === 0">
              <v-icon icon="mdi-chevron-left"></v-icon>
            </v-btn>
            <v-btn 
              color="primary" 
              size="small" 
              @click="nextStep"
            >
              {{ currentStep === steps.length - 1 ? 'Finish' : 'Next' }}
              <v-icon icon="mdi-chevron-right" v-if="currentStep < steps.length - 1"></v-icon>
            </v-btn>
          </div>
          
          <div class="tour-progress">
            <div 
              v-for="(step, idx) in steps" 
              :key="idx" 
              class="progress-dot"
              :class="{ 'progress-dot--active': idx === currentStep, 'progress-dot--done': idx < currentStep }"
            ></div>
          </div>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script setup>
import { ref, computed, onMounted, nextTick } from 'vue'

const emit = defineEmits(['complete', 'skip'])

const isVisible = ref(false)
const currentStep = ref(0)

const steps = [
  {
    target: '.brand-section',
    title: 'Welcome to TraceIQ! 🎉',
    description: 'Your intelligent observability platform powered by AI. Let me show you around!',
    icon: 'mdi-brain',
    position: { x: 200, y: 100 }
  },
  {
    target: '.shortcut-hint',
    title: 'Command Palette',
    description: 'Press Cmd+K anytime to quickly search and navigate. It\'s the fastest way to get things done!',
    icon: 'mdi-keyboard-outline',
    position: { x: 'auto', y: 100 }
  },
  {
    target: '.nav-menu',
    title: 'Navigation',
    description: 'Access all features from the top navigation. Dashboard, Errors, Traces, Incidents, and more!',
    icon: 'mdi-navigation-outline',
    position: { x: 400, y: 100 }
  },
  {
    target: '.chat-button',
    title: 'AI Assistant',
    description: 'Click the AI button to chat with TraceIQ. Ask questions about errors, generate reports, or get help!',
    icon: 'mdi-robot-outline',
    position: { x: 'auto', y: 'auto' }
  },
  {
    target: null,
    title: 'You\'re Ready! 🚀',
    description: 'That\'s it! Explore the dashboard, analyze traces, and let AI help you resolve issues faster.',
    icon: 'mdi-check-circle-outline',
    position: { x: 'center', y: 'center' }
  }
]

const currentStepData = computed(() => steps[currentStep.value])

const spotlightStyle = computed(() => {
  const step = steps[currentStep.value]
  if (!step.target) {
    return { display: 'none' }
  }
  
  const el = document.querySelector(step.target)
  if (!el) {
    return { display: 'none' }
  }
  
  const rect = el.getBoundingClientRect()
  return {
    top: `${rect.top - 10}px`,
    left: `${rect.left - 10}px`,
    width: `${rect.width + 20}px`,
    height: `${rect.height + 20}px`
  }
})

const tooltipStyle = computed(() => {
  const step = steps[currentStep.value]
  
  if (step.position.x === 'center') {
    return {
      top: '50%',
      left: '50%',
      transform: 'translate(-50%, -50%)'
    }
  }
  
  if (step.position.x === 'auto') {
    return {
      top: `${step.position.y + 60}px`,
      right: '100px'
    }
  }
  
  return {
    top: `${step.position.y + 60}px`,
    left: `${step.position.x}px`
  }
})

const nextStep = () => {
  if (currentStep.value < steps.length - 1) {
    currentStep.value++
  } else {
    completeTour()
  }
}

const prevStep = () => {
  if (currentStep.value > 0) {
    currentStep.value--
  }
}

const skipTour = () => {
  isVisible.value = false
  localStorage.setItem('traceiq-tour-completed', 'true')
  emit('skip')
}

const completeTour = () => {
  isVisible.value = false
  localStorage.setItem('traceiq-tour-completed', 'true')
  emit('complete')
}

const startTour = () => {
  currentStep.value = 0
  isVisible.value = true
}

onMounted(() => {
  // Check if tour has been completed
  const completed = localStorage.getItem('traceiq-tour-completed')
  if (!completed) {
    // Delay start for page to load
    setTimeout(() => {
      startTour()
    }, 1500)
  }
})

defineExpose({ startTour })
</script>

<style scoped>
.tour-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  z-index: 100000;
}

.tour-backdrop {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.7);
}

.tour-spotlight {
  position: absolute;
  border-radius: 8px;
  box-shadow: 0 0 0 9999px rgba(0, 0, 0, 0.7);
  pointer-events: none;
  transition: all 0.3s ease;
}

.tour-tooltip {
  position: absolute;
  width: 360px;
  background: #ffffff;
  border-radius: 16px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  padding: 20px;
  z-index: 1;
}

.tour-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.tour-step {
  font-size: 0.75rem;
  color: #666666;
  font-weight: 500;
}

.tour-content {
  text-align: center;
  margin-bottom: 20px;
}

.tour-icon {
  width: 64px;
  height: 64px;
  border-radius: 50%;
  background: #f5f5f5;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 16px;
}

.tour-title {
  font-size: 1.1rem;
  font-weight: 600;
  color: #1a1a1a;
  margin-bottom: 8px;
}

.tour-description {
  font-size: 0.9rem;
  color: #666666;
  line-height: 1.5;
}

.tour-actions {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 16px;
}

.tour-progress {
  display: flex;
  justify-content: center;
  gap: 6px;
}

.progress-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #e5e5e5;
  transition: all 0.3s ease;
}

.progress-dot--active {
  background: #1a1a1a;
  transform: scale(1.2);
}

.progress-dot--done {
  background: #10b981;
}

/* Transitions */
.tour-enter-active,
.tour-leave-active {
  transition: opacity 0.3s ease;
}

.tour-enter-from,
.tour-leave-to {
  opacity: 0;
}
</style>
