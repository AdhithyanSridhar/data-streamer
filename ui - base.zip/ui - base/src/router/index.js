import { createRouter, createWebHistory } from 'vue-router'

import AppErrors from '../views/AppErrors.vue'
import TraceIdLookup from '../views/TraceIdLookup.vue'
import AgentView from '../views/AgentView.vue'
import BatchJob from '../views/BatchJob.vue'
import BatchRun from '../views/BatchRun.vue'
import FAQ from '../views/FAQ.vue'
import Feedback from '../views/Feedback.vue'

const routes = [
    {
        path: '/',
        redirect: '/app-errors'
    },
    {
        path: '/app-errors',
        name: 'AppErrors',
        component: AppErrors,
        meta: { title: 'App Errors', icon: 'mdi-alert-circle' }
    },
    {
        path: '/trace-lookup',
        name: 'TraceIdLookup',
        component: TraceIdLookup,
        meta: { title: 'Trace ID Lookup', icon: 'mdi-magnify' }
    },
    {
        path: '/agent-view',
        name: 'AgentView',
        component: AgentView,
        meta: { title: 'Agent View', icon: 'mdi-robot' }
    },
    {
        path: '/batch-job',
        name: 'BatchJob',
        component: BatchJob,
        meta: { title: 'Batch Jobs', icon: 'mdi-calendar-clock' }
    },
    {
        path: '/batch-run',
        name: 'BatchRun',
        component: BatchRun,
        meta: { title: 'Batch Runs', icon: 'mdi-play-circle' }
    },
    {
        path: '/faq',
        name: 'FAQ',
        component: FAQ,
        meta: { title: 'FAQ', icon: 'mdi-help-circle' }
    },
    {
        path: '/feedback',
        name: 'Feedback',
        component: Feedback,
        meta: { title: 'Feedback', icon: 'mdi-message-text' }
    }
]

const router = createRouter({
    history: createWebHistory(),
    routes
})

export default router
