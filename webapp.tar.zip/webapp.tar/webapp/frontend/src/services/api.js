import axios from 'axios'

// Create axios instance with base configuration
const api = axios.create({
  baseURL: '/api',
  timeout: 120000, // 2 minutes timeout for long-running analyses
  headers: {
    'Content-Type': 'application/json'
  }
})

// Request interceptor
api.interceptors.request.use(
  config => {
    // Add authentication token if available
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  error => Promise.reject(error)
)

// Response interceptor
api.interceptors.response.use(
  response => response.data,
  error => {
    console.error('API Error:', error)
    return Promise.reject(error)
  }
)

/**
 * Trace Analysis API Service
 */
export const analysisApi = {
  /**
   * Analyzes a trace synchronously
   */
  analyzeTrace(request) {
    return api.post('/v1/analysis/trace', request)
  },

  /**
   * Analyzes a trace asynchronously
   */
  analyzeTraceAsync(request) {
    return api.post('/v1/analysis/trace/async', request)
  },

  /**
   * Batch analysis for multiple traces
   */
  analyzeBatch(requests) {
    return api.post('/v1/analysis/batch', requests)
  },

  /**
   * Health check
   */
  healthCheck() {
    return api.get('/v1/analysis/health')
  }
}

export default api
