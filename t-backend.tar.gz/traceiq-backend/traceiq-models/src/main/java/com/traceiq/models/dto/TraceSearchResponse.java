package com.traceiq.models.dto;

import com.traceiq.models.domain.ErrorRecord;

import java.util.List;
import java.util.Map;

/**
 * Response DTO for trace ID search containing all relevant trace information
 */
public record TraceSearchResponse(
        String traceId,
        Double confidenceScore,
        Integer errorCount,
        List<ErrorRecord> errors,
        List<TimelineEvent> timeline,
        FlowDiagram flowDiagram,
        RcaResult rcaResult,
        CodeSpotResult codeSpotResult
) {
    public static Builder builder() {
        return new Builder();
    }

    /**
     * Represents an event in the trace timeline
     */
    public record TimelineEvent(
            String timestamp,
            String service,
            String event,
            Map<String, Object> metadata
    ) {}

    /**
     * Flow diagram showing services involved in the trace
     */
    public record FlowDiagram(
            List<ServiceNode> nodes,
            List<ServiceEdge> edges
    ) {}

    /**
     * Service node in the flow diagram
     */
    public record ServiceNode(
            String id,
            String name,
            String type
    ) {}

    /**
     * Edge connecting services in the flow diagram
     */
    public record ServiceEdge(
            String source,
            String target,
            String label
    ) {}

    /**
     * RCA result from LLM analysis
     */
    public record RcaResult(
            String analysis,
            String rootCause,
            List<String> impactedServices,
            List<String> recommendations,
            String llmModel,
            Double confidence
    ) {}

    /**
     * Code spot result from vectorized codebase LLM
     */
    public record CodeSpotResult(
            List<CodeLocation> codeLocations,
            String implementationPlan,
            List<String> affectedFiles
    ) {}

    /**
     * Specific code location identified by the code LLM
     */
    public record CodeLocation(
            String repository,
            String filePath,
            Integer lineNumber,
            String snippet,
            String reason
    ) {}

    public static class Builder {
        private String traceId;
        private Double confidenceScore;
        private Integer errorCount;
        private List<ErrorRecord> errors;
        private List<TimelineEvent> timeline;
        private FlowDiagram flowDiagram;
        private RcaResult rcaResult;
        private CodeSpotResult codeSpotResult;

        public Builder traceId(String traceId) {
            this.traceId = traceId;
            return this;
        }

        public Builder confidenceScore(Double confidenceScore) {
            this.confidenceScore = confidenceScore;
            return this;
        }

        public Builder errorCount(Integer errorCount) {
            this.errorCount = errorCount;
            return this;
        }

        public Builder errors(List<ErrorRecord> errors) {
            this.errors = errors;
            return this;
        }

        public Builder timeline(List<TimelineEvent> timeline) {
            this.timeline = timeline;
            return this;
        }

        public Builder flowDiagram(FlowDiagram flowDiagram) {
            this.flowDiagram = flowDiagram;
            return this;
        }

        public Builder rcaResult(RcaResult rcaResult) {
            this.rcaResult = rcaResult;
            return this;
        }

        public Builder codeSpotResult(CodeSpotResult codeSpotResult) {
            this.codeSpotResult = codeSpotResult;
            return this;
        }

        public TraceSearchResponse build() {
            return new TraceSearchResponse(
                    traceId,
                    confidenceScore,
                    errorCount,
                    errors,
                    timeline,
                    flowDiagram,
                    rcaResult,
                    codeSpotResult
            );
        }
    }
}
