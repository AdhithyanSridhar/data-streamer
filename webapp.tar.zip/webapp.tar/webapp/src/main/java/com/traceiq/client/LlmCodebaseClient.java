package com.traceiq.client;

import com.traceiq.config.ApiConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Client for Vectorized Codebase LLM API
 */
@Component
public class LlmCodebaseClient {
    public static final Logger log = LoggerFactory.getLogger(LlmCodebaseClient.class);

    @Qualifier("llmCodebaseWebClient")
    private final WebClient llmCodebaseWebClient;
    private final ApiConfiguration apiConfig;

    public LlmCodebaseClient(WebClient llmCodebaseWebClient, ApiConfiguration apiConfig) {
        this.llmCodebaseWebClient = llmCodebaseWebClient;
        this.apiConfig = apiConfig;
    }

    public Map<String, Object> locateCode(String errorMessage, String stackTrace,
                                          String microserviceName, String context) {
        log.info("Locating code for error in: {}", microserviceName);

        Map<String, Object> request = Map.of(
                "operation", "locate",
                "error_message", errorMessage,
                "stack_trace", stackTrace != null ? stackTrace : "",
                "microservice", microserviceName,
                "context", context != null ? context : ""
        );

        try {
            return llmCodebaseWebClient.post()
                    .uri("/v1/code/locate")
                    .bodyValue(request)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();
        } catch (Exception e) {
            log.error("Error locating code", e);
            return Map.of(
                    "error", e.getMessage(),
                    "repository", microserviceName,
                    "file_path", "Unknown",
                    "line_number", 0
            );
        }
    }

    public Map<String, Object> suggestFix(String codeSnippet, String rootCause, String context) {
        log.info("Generating code fix suggestion");

        Map<String, Object> request = Map.of(
                "operation", "suggest_fix",
                "code_snippet", codeSnippet,
                "root_cause", rootCause,
                "context", context != null ? context : ""
        );

        try {
            return llmCodebaseWebClient.post()
                    .uri("/v1/code/fix")
                    .bodyValue(request)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();
        } catch (Exception e) {
            log.error("Error suggesting fix", e);
            return Map.of(
                    "error", e.getMessage(),
                    "suggested_fix", "Please review the code manually",
                    "confidence", "low"
            );
        }
    }

    public Map<String, Object> generateImplementationPlan(String fixDescription,
                                                          String codeContext, String dependencies) {
        log.info("Generating implementation plan");

        Map<String, Object> request = Map.of(
                "operation", "implementation_plan",
                "fix_description", fixDescription,
                "code_context", codeContext != null ? codeContext : "",
                "dependencies", dependencies != null ? dependencies : ""
        );

        try {
            return llmCodebaseWebClient.post()
                    .uri("/v1/code/plan")
                    .bodyValue(request)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();
        } catch (Exception e) {
            log.error("Error generating implementation plan", e);
            return Map.of(
                    "error", e.getMessage(),
                    "plan", List.of("Review fix manually", "Test thoroughly", "Deploy with caution")
            );
        }
    }

    public Map<String, Object> searchSimilar(String codeSnippet, String microserviceName) {
        log.info("Searching for similar code patterns");

        Map<String, Object> request = Map.of(
                "operation", "search_similar",
                "code_snippet", codeSnippet,
                "microservice", microserviceName
        );

        try {
            return llmCodebaseWebClient.post()
                    .uri("/v1/code/similar")
                    .bodyValue(request)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();
        } catch (Exception e) {
            log.error("Error searching similar code", e);
            return Map.of(
                    "error", e.getMessage(),
                    "similar_files", Collections.emptyList()
            );
        }
    }
}
