package com.traceiq.models.dto;

import com.traceiq.models.domain.RCAResult;
import com.traceiq.models.domain.ImplementationPlan;

/**
 * Response DTO for RCA analysis.
 * Contains both the RCA result and optional implementation plan.
 */
public record RCAResponse(
    RCAResult rcaResult,
    ImplementationPlan implementationPlan,
    boolean fromCache,
    String status,
    String message
) {
    public static class Builder {
        private RCAResult rcaResult;
        private ImplementationPlan implementationPlan;
        private boolean fromCache;
        private String status;
        private String message;

        public Builder rcaResult(RCAResult rcaResult) {
            this.rcaResult = rcaResult;
            return this;
        }

        public Builder implementationPlan(ImplementationPlan implementationPlan) {
            this.implementationPlan = implementationPlan;
            return this;
        }

        public Builder fromCache(boolean fromCache) {
            this.fromCache = fromCache;
            return this;
        }

        public Builder status(String status) {
            this.status = status;
            return this;
        }

        public Builder message(String message) {
            this.message = message;
            return this;
        }

        public RCAResponse build() {
            return new RCAResponse(rcaResult, implementationPlan, fromCache, status, message);
        }
    }

    public static Builder builder() {
        return new Builder();
    }
}
