<template>
  <div class="glass-card pa-5">
    <div class="section-header">
      <div class="section-header__icon">
        <v-icon icon="mdi-format-list-numbered" size="20"></v-icon>
      </div>
      <h2 class="section-header__title">Implementation Plan</h2>
    </div>
    
    <div class="markdown-content" v-html="renderedPlan"></div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { marked } from 'marked'

const props = defineProps({
  plan: { type: String, required: true }
})

const renderedPlan = computed(() => marked(props.plan))
</script>

<style scoped>
:deep(.markdown-content h2) {
  font-size: 1rem;
  font-weight: 600;
  color: #1a1a1a;
  margin-bottom: 16px;
}

:deep(.markdown-content h3) {
  font-size: 0.9rem;
  font-weight: 600;
  color: #1a1a1a;
  margin: 16px 0 8px;
  padding: 8px 12px;
  background: #f5f5f5;
  border-radius: 6px;
}

:deep(.markdown-content ol) {
  padding-left: 20px;
  margin-bottom: 16px;
}

:deep(.markdown-content li) {
  font-size: 0.875rem;
  color: #666666;
  margin-bottom: 8px;
  line-height: 1.5;
}

:deep(.markdown-content code) {
  background: #f5f5f5;
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 0.8rem;
  color: #1a1a1a;
}
</style>
