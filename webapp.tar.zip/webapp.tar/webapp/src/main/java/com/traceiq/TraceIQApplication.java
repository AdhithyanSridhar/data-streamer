package com.traceiq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * TraceIQ - AI-Powered Observability and RCA Platform
 * <p>
 * Main application entry point for the TraceIQ platform that provides:
 * - Intelligent trace analysis and error detection
 * - Automated root cause analysis using AI
 * - Code location identification through vectorized search
 * - Multi-tool orchestration for comprehensive diagnostics
 * - Integration with ELK, Jira, GitHub, Dynatrace, Jenkins, and Kubernetes
 *
 * @author TraceIQ Team
 * @version 1.0.0
 */
@SpringBootApplication
@EnableCaching
@EnableAsync
public class TraceIQApplication {

    public static void main(String[] args) {
        SpringApplication.run(TraceIQApplication.class, args);
    }
}
