package com.traceiq.service;

import com.traceiq.client.CodebaseLlmClient;
import com.traceiq.client.ElkClient;
import com.traceiq.client.InternalLlmClient;
import com.traceiq.model.*;
import com.traceiq.tool.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.CompletableFuture;

/**
 * Core orchestration service for TraceIQ analysis.
 * Implements a graph-based workflow using conditional tool execution.
 * 
 * Workflow Graph:
 * 1. Start -> ELK Log Retrieval
 * 2. ELK Logs -> RCA Analysis (Internal LLM)
 * 3. RCA -> Code Location (Codebase LLM)
 * 4. Conditional Branches:
 *    - If includeJiraAnalysis -> Jira Tool
 *    - If includeGitHubAnalysis -> GitHub Tool
 *    - If includeDeploymentAnalysis -> Jenkins + K8s Tools
 * 5. All Results -> Final Aggregation
 */
@Service
public class TraceAnalysisOrchestrator {
    
    private static final Logger logger = LoggerFactory.getLogger(TraceAnalysisOrchestrator.class);
    
    private final ElkClient elkClient;
    private final InternalLlmClient internalLlmClient;
    private final CodebaseLlmClient codebaseLlmClient;
    private final JiraTool jiraTool;
    private final GitHubTool gitHubTool;
    private final JenkinsTool jenkinsTool;
    private final KubernetesTool kubernetesTool;
    
    public TraceAnalysisOrchestrator(
        ElkClient elkClient,
        InternalLlmClient internalLlmClient,
        CodebaseLlmClient codebaseLlmClient,
        JiraTool jiraTool,
        GitHubTool gitHubTool,
        JenkinsTool jenkinsTool,
        KubernetesTool kubernetesTool
    ) {
        this.elkClient = elkClient;
        this.internalLlmClient = internalLlmClient;
        this.codebaseLlmClient = codebaseLlmClient;
        this.jiraTool = jiraTool;
        this.gitHubTool = gitHubTool;
        this.jenkinsTool = jenkinsTool;
        this.kubernetesTool = kubernetesTool;
    }
    
    /**
     * Execute the complete RCA workflow based on request parameters.
     * This implements a LangGraph-style orchestration with conditional nodes.
     */
    public TraceAnalysisResponse analyzeTrace(TraceAnalysisRequest request) {
        logger.info("Starting trace analysis for traceId: {}", request.traceId());
        
        String analysisId = UUID.randomUUID().toString();
        
        try {
            // Node 1: ELK Log Retrieval
            logger.info("[Node: ELK] Retrieving logs for traceId: {}", request.traceId());
            List<LogEntry> allLogs = elkClient.getLogsByTraceId(request.traceId());
            
            List<LogEntry> errorLogs = filterLogsByLevel(allLogs, "ERROR");
            List<LogEntry> warnLogs = filterLogsByLevel(allLogs, "WARN");
            
            if (errorLogs.isEmpty()) {
                logger.warn("No error logs found for traceId: {}", request.traceId());
                return createNoErrorResponse(analysisId, request.traceId(), allLogs);
            }
            
            // Node 2: RCA Analysis (Internal LLM) - Only if errors exist
            logger.info("[Node: RCA] Analyzing root cause with internal LLM");
            RootCauseAnalysis rca = internalLlmClient.analyzeRootCause(
                request.traceId(),
                errorLogs,
                request.customPrompt()
            );
            
            // Node 3: Code Analysis (Codebase LLM) - Only if includeCodeAnalysis
            CodeAnalysis codeAnalysis = null;
            String implementationPlan = null;
            
            if (request.includeCodeAnalysis()) {
                logger.info("[Node: CodeAnalysis] Locating problematic code");
                
                String stackTrace = extractStackTrace(errorLogs);
                String serviceName = extractServiceName(errorLogs, request.microserviceName());
                
                codeAnalysis = codebaseLlmClient.locateProblematicCode(
                    serviceName,
                    rca,
                    stackTrace
                );
                
                implementationPlan = codebaseLlmClient.generateImplementationPlan(
                    codeAnalysis,
                    rca
                );
            }
            
            // Parallel execution of conditional branches
            CompletableFuture<JiraTicketInfo> jiraFuture = null;
            CompletableFuture<List<GitHubPRInfo>> githubFuture = null;
            CompletableFuture<DeploymentInfo> deploymentFuture = null;
            CompletableFuture<PerformanceMetrics> perfFuture = null;
            
            // Node 4a: Jira Tool (Conditional)
            if (request.includeJiraAnalysis()) {
                logger.info("[Node: Jira] Fetching Jira ticket information");
                jiraFuture = CompletableFuture.supplyAsync(() -> 
                    executeJiraAnalysis(request, rca)
                );
            }
            
            // Node 4b: GitHub Tool (Conditional)
            if (request.includeGitHubAnalysis()) {
                logger.info("[Node: GitHub] Fetching recent PRs");
                githubFuture = CompletableFuture.supplyAsync(() -> 
                    executeGitHubAnalysis(request)
                );
            }
            
            // Node 4c: Deployment Tools (Conditional)
            if (request.includePerformanceAnalysis()) {
                logger.info("[Node: Performance] Analyzing latency and deployment");
                perfFuture = CompletableFuture.supplyAsync(() -> 
                    analyzePerformance(allLogs)
                );
                
                deploymentFuture = CompletableFuture.supplyAsync(() -> 
                    executeDeploymentAnalysis(request)
                );
            }
            
            // Node 5: Generate Fix Suggestions and Guardrails
            logger.info("[Node: Recommendations] Generating fix suggestions");
            List<String> fixSuggestions = internalLlmClient.generateFixSuggestions(
                rca,
                buildContext(allLogs, codeAnalysis)
            );
            
            List<String> guardrails = internalLlmClient.generateGuardrails(rca);
            
            // Node 6: Extract Team Information
            String teamName = extractTeamName(allLogs);
            String ownerEmail = extractOwnerEmail(allLogs);
            List<String> affectedServices = extractAffectedServices(allLogs);
            
            // Wait for all async operations
            JiraTicketInfo jiraTicket = jiraFuture != null ? jiraFuture.join() : null;
            List<GitHubPRInfo> recentPRs = githubFuture != null ? githubFuture.join() : null;
            DeploymentInfo deploymentInfo = deploymentFuture != null ? deploymentFuture.join() : null;
            PerformanceMetrics perfMetrics = perfFuture != null ? perfFuture.join() : null;
            
            // Node 7: Final Aggregation
            logger.info("[Node: Aggregation] Building final response");
            return TraceAnalysisResponse.builder()
                .analysisId(analysisId)
                .traceId(request.traceId())
                .status("COMPLETED")
                .timestamp(LocalDateTime.now())
                .rootCauseAnalysis(rca)
                .codeAnalysis(codeAnalysis)
                .errorLogs(errorLogs)
                .warnLogs(warnLogs)
                .performanceMetrics(perfMetrics)
                .jiraTicket(jiraTicket)
                .recentPRs(recentPRs)
                .deploymentInfo(deploymentInfo)
                .fixSuggestions(fixSuggestions)
                .guardrails(guardrails)
                .implementationPlan(implementationPlan)
                .teamName(teamName)
                .ownerEmail(ownerEmail)
                .affectedServices(affectedServices)
                .additionalContext(buildAdditionalContext(request))
                .build();
            
        } catch (Exception e) {
            logger.error("Error during trace analysis for traceId: {}", request.traceId(), e);
            return createErrorResponse(analysisId, request.traceId(), e.getMessage());
        }
    }
    
    // Helper methods for graph nodes
    
    private JiraTicketInfo executeJiraAnalysis(TraceAnalysisRequest request, RootCauseAnalysis rca) {
        try {
            if (request.autoCreateJiraTicket()) {
                // Create new Jira ticket
                JiraTool.JiraRequest jiraReq = JiraTool.JiraRequest.builder()
                    .action("createTicket")
                    .projectKey("TRACE")
                    .summary(String.format("[TraceIQ] %s - %s", 
                        request.traceId(), rca.summary()))
                    .description(buildJiraDescription(request, rca))
                    .priority(mapSeverityToPriority(rca.severity()))
                    .build();
                
                return jiraTool.apply(jiraReq);
            }
            
            return null;
            
        } catch (Exception e) {
            logger.error("Error in Jira analysis", e);
            return null;
        }
    }
    
    private List<GitHubPRInfo> executeGitHubAnalysis(TraceAnalysisRequest request) {
        try {
            // Assuming standard GitHub organization structure
            GitHubTool.GitHubRequest githubReq = GitHubTool.GitHubRequest.builder()
                .action("getServicePRs")
                .owner("your-org")
                .repo(request.microserviceName())
                .serviceName(request.microserviceName())
                .build();
            
            return gitHubTool.apply(githubReq);
            
        } catch (Exception e) {
            logger.error("Error in GitHub analysis", e);
            return List.of();
        }
    }
    
    private DeploymentInfo executeDeploymentAnalysis(TraceAnalysisRequest request) {
        try {
            // Get Jenkins build info
            JenkinsTool.JenkinsRequest jenkinsReq = JenkinsTool.JenkinsRequest.builder()
                .jobName(request.microserviceName())
                .buildNumber(null)  // Latest build
                .build();
            
            DeploymentInfo jenkinsInfo = jenkinsTool.apply(jenkinsReq);
            
            // Get K8s pod status
            KubernetesTool.K8sRequest k8sReq = KubernetesTool.K8sRequest.builder()
                .serviceName(request.microserviceName())
                .namespace(request.environment() != null ? request.environment() : "default")
                .build();
            
            KubernetesTool.K8sResponse k8sInfo = kubernetesTool.apply(k8sReq);
            
            // Merge both sources
            return new DeploymentInfo(
                jenkinsInfo.buildNumber(),
                jenkinsInfo.buildStatus(),
                jenkinsInfo.buildTime(),
                jenkinsInfo.deploymentStatus(),
                jenkinsInfo.deploymentTime(),
                jenkinsInfo.environment(),
                k8sInfo.status(),
                k8sInfo.totalPods(),
                jenkinsInfo.sonarCheckStatus(),
                jenkinsInfo.componentTestStatus()
            );
            
        } catch (Exception e) {
            logger.error("Error in deployment analysis", e);
            return null;
        }
    }
    
    private PerformanceMetrics analyzePerformance(List<LogEntry> logs) {
        try {
            Map<String, Object> latencyData = elkClient.performLatencyAnalysis(logs);
            
            @SuppressWarnings("unchecked")
            Map<String, Long> serviceLatencies = 
                (Map<String, Long>) latencyData.get("serviceLatencies");
            
            long totalDuration = (long) latencyData.get("totalDurationMs");
            
            return new PerformanceMetrics(
                totalDuration,
                totalDuration / Math.max(logs.size(), 1),
                serviceLatencies,
                List.of(),
                String.format("Total duration: %dms across %d logs", totalDuration, logs.size())
            );
            
        } catch (Exception e) {
            logger.error("Error in performance analysis", e);
            return null;
        }
    }
    
    // Utility methods
    
    private List<LogEntry> filterLogsByLevel(List<LogEntry> logs, String level) {
        return logs.stream()
            .filter(log -> level.equals(log.level()))
            .toList();
    }
    
    private String extractStackTrace(List<LogEntry> logs) {
        return logs.stream()
            .map(LogEntry::exceptionStackTrace)
            .filter(Objects::nonNull)
            .findFirst()
            .orElse("No stack trace available");
    }
    
    private String extractServiceName(List<LogEntry> logs, String fallback) {
        return logs.stream()
            .map(LogEntry::serviceName)
            .filter(Objects::nonNull)
            .findFirst()
            .orElse(fallback);
    }
    
    private String extractTeamName(List<LogEntry> logs) {
        // Extract from log metadata - simplified implementation
        return "Engineering Team";
    }
    
    private String extractOwnerEmail(List<LogEntry> logs) {
        // Extract from log metadata - simplified implementation
        return "team-owner@example.com";
    }
    
    private List<String> extractAffectedServices(List<LogEntry> logs) {
        return logs.stream()
            .map(LogEntry::serviceName)
            .filter(Objects::nonNull)
            .distinct()
            .toList();
    }
    
    private String buildContext(List<LogEntry> logs, CodeAnalysis codeAnalysis) {
        StringBuilder context = new StringBuilder();
        context.append("Total logs: ").append(logs.size()).append("\n");
        
        if (codeAnalysis != null) {
            context.append("Affected file: ").append(codeAnalysis.filePath()).append("\n");
            context.append("Method: ").append(codeAnalysis.methodName()).append("\n");
        }
        
        return context.toString();
    }
    
    private String buildJiraDescription(TraceAnalysisRequest request, RootCauseAnalysis rca) {
        return String.format(
            "Automated TraceIQ Analysis\n\n" +
            "TraceID: %s\n" +
            "Environment: %s\n\n" +
            "Root Cause: %s\n\n" +
            "Category: %s\n" +
            "Severity: %s\n\n" +
            "Details: %s",
            request.traceId(),
            request.environment(),
            rca.rootCause(),
            rca.category(),
            rca.severity(),
            rca.detailedExplanation()
        );
    }
    
    private String mapSeverityToPriority(String severity) {
        return switch (severity.toLowerCase()) {
            case "critical" -> "Highest";
            case "high" -> "High";
            case "medium" -> "Medium";
            default -> "Low";
        };
    }
    
    private Map<String, Object> buildAdditionalContext(TraceAnalysisRequest request) {
        Map<String, Object> context = new HashMap<>();
        context.put("environment", request.environment());
        context.put("microserviceName", request.microserviceName());
        context.put("analysisOptions", Map.of(
            "jira", request.includeJiraAnalysis(),
            "github", request.includeGitHubAnalysis(),
            "performance", request.includePerformanceAnalysis(),
            "code", request.includeCodeAnalysis()
        ));
        return context;
    }
    
    private TraceAnalysisResponse createNoErrorResponse(
        String analysisId,
        String traceId,
        List<LogEntry> logs
    ) {
        return TraceAnalysisResponse.builder()
            .analysisId(analysisId)
            .traceId(traceId)
            .status("NO_ERRORS_FOUND")
            .timestamp(LocalDateTime.now())
            .rootCauseAnalysis(new RootCauseAnalysis(
                "No errors found",
                "The trace completed successfully",
                "Success",
                "Low",
                List.of(),
                "All logs indicate successful execution",
                1.0
            ))
            .errorLogs(List.of())
            .warnLogs(filterLogsByLevel(logs, "WARN"))
            .build();
    }
    
    private TraceAnalysisResponse createErrorResponse(
        String analysisId,
        String traceId,
        String errorMessage
    ) {
        return TraceAnalysisResponse.builder()
            .analysisId(analysisId)
            .traceId(traceId)
            .status("ERROR")
            .timestamp(LocalDateTime.now())
            .rootCauseAnalysis(new RootCauseAnalysis(
                "Analysis failed",
                errorMessage,
                "System Error",
                "Unknown",
                List.of(),
                "TraceIQ analysis encountered an error",
                0.0
            ))
            .build();
    }
}
