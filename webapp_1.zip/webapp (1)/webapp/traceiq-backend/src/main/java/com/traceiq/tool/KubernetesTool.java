package com.traceiq.tool;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.Map;
import java.util.function.Function;

/**
 * Spring AI Tool for Kubernetes API integration.
 * Provides pod status and deployment information.
 */
@Component
public class KubernetesTool implements Function<KubernetesTool.K8sRequest, KubernetesTool.K8sResponse> {
    
    private static final Logger logger = LoggerFactory.getLogger(KubernetesTool.class);
    
    private final WebClient webClient;
    
    public KubernetesTool(
        @Value("${kubernetes.api-url}") String k8sApiUrl,
        @Value("${kubernetes.api-token}") String k8sApiToken,
        WebClient.Builder webClientBuilder
    ) {
        this.webClient = webClientBuilder
            .baseUrl(k8sApiUrl)
            .defaultHeader("Authorization", "Bearer " + k8sApiToken)
            .build();
        
        logger.info("KubernetesTool initialized with API URL: {}", k8sApiUrl);
    }
    
    @Override
    public K8sResponse apply(K8sRequest request) {
        logger.info("Fetching K8s pod status for service: {} in namespace: {}", 
            request.serviceName(), request.namespace());
        
        return getPodStatus(request);
    }
    
    /**
     * Get pod status for a service.
     */
    private K8sResponse getPodStatus(K8sRequest request) {
        logger.info("Fetching pod status for: {}", request.serviceName());
        
        try {
            Map<String, Object> response = webClient.get()
                .uri(uriBuilder -> uriBuilder
                    .path("/api/v1/namespaces/{namespace}/pods")
                    .queryParam("labelSelector", "app=" + request.serviceName())
                    .build(request.namespace()))
                .retrieve()
                .bodyToMono(Map.class)
                .block();
            
            return parsePodStatus(response, request.serviceName());
            
        } catch (Exception e) {
            logger.error("Error fetching pod status", e);
            return createErrorResponse(e.getMessage());
        }
    }
    
    // Helper methods
    
    @SuppressWarnings("unchecked")
    private K8sResponse parsePodStatus(Map<String, Object> response, String serviceName) {
        List<Map<String, Object>> items = 
            (List<Map<String, Object>>) response.get("items");
        
        if (items == null || items.isEmpty()) {
            return new K8sResponse(
                serviceName,
                "No pods found",
                0,
                0,
                List.of()
            );
        }
        
        int totalPods = items.size();
        long runningPods = items.stream()
            .filter(pod -> {
                Map<String, Object> status = (Map<String, Object>) pod.get("status");
                String phase = (String) status.get("phase");
                return "Running".equals(phase);
            })
            .count();
        
        String overallStatus = runningPods == totalPods ? "Healthy" : "Degraded";
        
        List<String> podNames = items.stream()
            .map(pod -> {
                Map<String, Object> metadata = (Map<String, Object>) pod.get("metadata");
                return (String) metadata.get("name");
            })
            .toList();
        
        return new K8sResponse(
            serviceName,
            overallStatus,
            totalPods,
            (int) runningPods,
            podNames
        );
    }
    
    private K8sResponse createErrorResponse(String error) {
        return new K8sResponse(
            "Unknown",
            "Error: " + error,
            0,
            0,
            List.of()
        );
    }
    
    /**
     * Request model for Kubernetes tool.
     */
    public record K8sRequest(
        String serviceName,
        String namespace
    ) {
        public static Builder builder() {
            return new Builder();
        }
        
        public static class Builder {
            private String serviceName;
            private String namespace = "default";
            
            public Builder serviceName(String serviceName) {
                this.serviceName = serviceName;
                return this;
            }
            
            public Builder namespace(String namespace) {
                this.namespace = namespace;
                return this;
            }
            
            public K8sRequest build() {
                return new K8sRequest(serviceName, namespace);
            }
        }
    }
    
    /**
     * Response model for Kubernetes tool.
     */
    public record K8sResponse(
        String serviceName,
        String status,
        int totalPods,
        int runningPods,
        List<String> podNames
    ) {}
}
