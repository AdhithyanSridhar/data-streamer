<template>
  <Teleport to="body">
    <Transition name="easter">
      <div v-if="isVisible" class="easter-egg-overlay" @click="close">
        <div class="easter-egg-content" @click.stop>
          <div class="particle-bg">
            <div v-for="i in 30" :key="i" class="particle" :style="getParticleStyle(i)"></div>
          </div>
          
          <div class="easter-card">
            <div class="emoji-rain">
              <span v-for="i in 20" :key="i" class="rain-emoji" :style="getEmojiStyle(i)">{{ getRandomEmoji() }}</span>
            </div>
            
            <div class="easter-icon">🎮</div>
            
            <h2 class="easter-title">
              <span class="gradient-text">Konami Code Activated!</span>
            </h2>
            
            <p class="easter-message">
              You found the secret! 🎉<br>
              The legendary ↑ ↑ ↓ ↓ ← → ← → B A works here too!
            </p>
            
            <div class="easter-stats">
              <div class="stat-item">
                <span class="stat-value">{{ unlockCount }}</span>
                <span class="stat-label">Times Unlocked</span>
              </div>
              <div class="stat-item">
                <span class="stat-value">Elite</span>
                <span class="stat-label">Status</span>
              </div>
              <div class="stat-item">
                <span class="stat-value">∞</span>
                <span class="stat-label">Power Level</span>
              </div>
            </div>
            
            <div class="easter-badges">
              <div class="badge">🏆 Secret Finder</div>
              <div class="badge">🎯 Konami Master</div>
              <div class="badge">⭐ Easter Egg Hunter</div>
            </div>
            
            <v-btn color="primary" size="large" rounded="lg" @click="close" class="easter-btn">
              <v-icon icon="mdi-rocket-launch-outline" class="mr-2"></v-icon>
              Continue Being Awesome
            </v-btn>
          </div>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'

const emit = defineEmits(['activated'])

const isVisible = ref(false)
const unlockCount = ref(parseInt(localStorage.getItem('konami-count') || '0'))

const konamiCode = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'KeyB', 'KeyA']
let konamiIndex = 0

const emojis = ['🎉', '🚀', '⭐', '🔥', '💎', '🎮', '🏆', '✨', '💪', '🎯']

const getRandomEmoji = () => emojis[Math.floor(Math.random() * emojis.length)]

const getParticleStyle = (i) => ({
  left: `${Math.random() * 100}%`,
  top: `${Math.random() * 100}%`,
  animationDelay: `${Math.random() * 5}s`,
  animationDuration: `${3 + Math.random() * 4}s`
})

const getEmojiStyle = (i) => ({
  left: `${(i / 20) * 100}%`,
  animationDelay: `${Math.random() * 2}s`,
  animationDuration: `${2 + Math.random() * 3}s`
})

const handleKeydown = (e) => {
  if (e.code === konamiCode[konamiIndex]) {
    konamiIndex++
    if (konamiIndex === konamiCode.length) {
      activate()
      konamiIndex = 0
    }
  } else {
    konamiIndex = 0
  }
}

const activate = () => {
  isVisible.value = true
  unlockCount.value++
  localStorage.setItem('konami-count', unlockCount.value.toString())
  emit('activated')
}

const close = () => {
  isVisible.value = false
}

onMounted(() => {
  window.addEventListener('keydown', handleKeydown)
})

onUnmounted(() => {
  window.removeEventListener('keydown', handleKeydown)
})

defineExpose({ activate })
</script>

<style scoped>
.easter-egg-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(0, 0, 0, 0.9);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 999999;
}

.easter-egg-content {
  position: relative;
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.particle-bg {
  position: absolute;
  width: 100%;
  height: 100%;
  overflow: hidden;
}

.particle {
  position: absolute;
  width: 10px;
  height: 10px;
  background: linear-gradient(135deg, #f59e0b, #ef4444, #8b5cf6, #3b82f6);
  border-radius: 50%;
  animation: float infinite ease-in-out;
  opacity: 0.6;
}

@keyframes float {
  0%, 100% {
    transform: translateY(0) scale(1);
    opacity: 0.6;
  }
  50% {
    transform: translateY(-30px) scale(1.2);
    opacity: 1;
  }
}

.easter-card {
  position: relative;
  background: linear-gradient(145deg, #1a1a1a 0%, #2d2d2d 100%);
  border-radius: 24px;
  padding: 48px;
  text-align: center;
  max-width: 500px;
  box-shadow: 0 0 60px rgba(139, 92, 246, 0.4), 0 0 120px rgba(59, 130, 246, 0.2);
  border: 2px solid rgba(255, 255, 255, 0.1);
  overflow: hidden;
}

.emoji-rain {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  overflow: hidden;
}

.rain-emoji {
  position: absolute;
  top: -50px;
  font-size: 24px;
  animation: rain linear infinite;
}

@keyframes rain {
  0% {
    transform: translateY(0) rotate(0deg);
    opacity: 1;
  }
  100% {
    transform: translateY(600px) rotate(360deg);
    opacity: 0;
  }
}

.easter-icon {
  font-size: 64px;
  margin-bottom: 16px;
  animation: bounce 1s infinite;
}

@keyframes bounce {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-10px); }
}

.easter-title {
  font-size: 1.75rem;
  font-weight: 700;
  margin-bottom: 16px;
}

.gradient-text {
  background: linear-gradient(135deg, #f59e0b, #ef4444, #8b5cf6, #3b82f6);
  background-size: 300% 300%;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  animation: gradient 3s ease infinite;
}

@keyframes gradient {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}

.easter-message {
  color: #999999;
  font-size: 1rem;
  line-height: 1.6;
  margin-bottom: 24px;
}

.easter-stats {
  display: flex;
  justify-content: center;
  gap: 32px;
  margin-bottom: 24px;
}

.stat-item {
  text-align: center;
}

.stat-value {
  display: block;
  font-size: 1.5rem;
  font-weight: 700;
  color: #ffffff;
}

.stat-label {
  font-size: 0.75rem;
  color: #666666;
}

.easter-badges {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 8px;
  margin-bottom: 24px;
}

.badge {
  background: rgba(255, 255, 255, 0.1);
  padding: 8px 16px;
  border-radius: 20px;
  font-size: 0.8rem;
  color: #ffffff;
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.easter-btn {
  position: relative;
  z-index: 1;
}

/* Transition */
.easter-enter-active,
.easter-leave-active {
  transition: all 0.5s ease;
}

.easter-enter-from,
.easter-leave-to {
  opacity: 0;
  transform: scale(0.9);
}
</style>
