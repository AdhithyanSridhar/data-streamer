<template>
  <div>
    <h2 class="text-3xl font-bold mb-6">Help & FAQ</h2>
    
    <div class="bg-white p-6 rounded-lg shadow mb-6">
      <h3 class="text-xl font-bold mb-4">Vision</h3>
      <p class="text-gray-700 mb-4">
        TraceIQ is an AI-powered Root Cause Analysis (RCA) system designed to reduce triage time for developers and testers 
        by providing automated analysis and targeted code location suggestions. Our system integrates with ELK, Dynatrace, 
        Jira, GitHub, Jenkins, and internal LLMs to provide comprehensive insights.
      </p>
    </div>
    
    <div class="bg-white p-6 rounded-lg shadow mb-6">
      <h3 class="text-xl font-bold mb-4">Team Members</h3>
      <ul class="space-y-2">
        <li class="flex items-center">
          <i class="fas fa-user-circle text-2xl text-blue-600 mr-3"></i>
          <span>Engineering Team - RCA Platform</span>
        </li>
      </ul>
    </div>
    
    <div class="bg-white p-6 rounded-lg shadow mb-6">
      <h3 class="text-xl font-bold mb-4">Frequently Asked Questions</h3>
      <div class="space-y-4">
        <div>
          <h4 class="font-semibold">Q: What is GodMode?</h4>
          <p class="text-gray-700">GodMode runs both RCA Analysis and Code Spot in a single click, providing complete insights.</p>
        </div>
        <div>
          <h4 class="font-semibold">Q: How often are errors ingested from ELK?</h4>
          <p class="text-gray-700">Errors are ingested nightly at 2 AM via scheduled job. You can also trigger manual ingestion.</p>
        </div>
        <div>
          <h4 class="font-semibold">Q: How do I use the curated prompts?</h4>
          <p class="text-gray-700">Copy the implementation plan and use it with GitHub Copilot in your IDE to implement the fix.</p>
        </div>
      </div>
    </div>
    
    <div class="bg-white p-6 rounded-lg shadow">
      <h3 class="text-xl font-bold mb-4">Feedback</h3>
      <p class="text-gray-700 mb-4">We'd love to hear your feedback!</p>
      <a href="mailto:traceiq-team@company.com" class="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 inline-block">
        <i class="fas fa-envelope mr-2"></i>Send Feedback
      </a>
    </div>
  </div>
</template>

<script setup>
</script>
