package com.traceiq.tools.adapter;

import com.traceiq.models.dto.graph.ElkNodeInput;
import com.traceiq.models.dto.graph.ElkNodeOutput;
import com.traceiq.tools.config.ToolsConfig;
import com.traceiq.utils.JsonUtil;
import com.traceiq.utils.RetryUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Adapter for ELK/Kibana API integration
 * Fetches logs and traces by traceID
 */
@Component
public class ElkAdapter {
    private static final Logger logger = LoggerFactory.getLogger(ElkAdapter.class);

    private final RestTemplate restTemplate;
    private final ToolsConfig toolsConfig;

    public ElkAdapter(RestTemplate restTemplate, ToolsConfig toolsConfig) {
        this.restTemplate = restTemplate;
        this.toolsConfig = toolsConfig;
    }

    /**
     * Fetch logs from ELK by traceID
     * Implements LangGraph4j node function
     */
    public ElkNodeOutput fetchLogsByTraceId(ElkNodeInput input) {
        return RetryUtil.executeWithDefaultRetry(() -> {
            logger.info("[{}] Fetching logs from ELK for trace: {}",
                    input.correlationId(), input.traceId());

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "Bearer " + toolsConfig.getElkApiToken());
            headers.set("X-Correlation-Id", input.correlationId());

            // Build Elasticsearch query
            Map<String, Object> query = Map.of(
                    "query", Map.of(
                            "bool", Map.of(
                                    "must", List.of(
                                            Map.of("term", Map.of("traceId.keyword", input.traceId()))
                                    )
                            )
                    ),
                    "size", 1000,
                    "sort", List.of(Map.of("@timestamp", "asc"))
            );

            HttpEntity<String> entity = new HttpEntity<>(JsonUtil.toJson(query), headers);

            ResponseEntity<String> response = restTemplate.exchange(
                    toolsConfig.getElkApiUrl() + "/logs-*/_search",
                    HttpMethod.POST,
                    entity,
                    String.class
            );

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                Map<String, Object> result = JsonUtil.fromJson(response.getBody(), Map.class);
                List<ElkNodeOutput.LogEntry> logs = parseElkResponse(result);

                Map<String, Object> summary = Map.of(
                        "totalLogs", logs.size(),
                        "traceId", input.traceId(),
                        "timeRange", input.timeRange()
                );

                logger.info("[{}] Successfully fetched {} logs from ELK",
                        input.correlationId(), logs.size());

                return ElkNodeOutput.builder()
                        .traceId(input.traceId())
                        .logs(logs)
                        .summary(summary)
                        .success(true)
                        .build();
            }

            throw new RuntimeException("Invalid response from ELK API");

        }, "ELK-Fetch-Logs");
    }

    /**
     * Search errors in ELK for nightly ingest
     */
    public List<Map<String, Object>> searchErrors(String timeRange) {
        return RetryUtil.executeWithDefaultRetry(() -> {
            logger.info("Searching errors in ELK for time range: {}", timeRange);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "Bearer " + toolsConfig.getElkApiToken());

            Map<String, Object> query = Map.of(
                    "query", Map.of(
                            "bool", Map.of(
                                    "must", List.of(
                                            Map.of("term", Map.of("level", "ERROR")),
                                            Map.of("range", Map.of("@timestamp", Map.of("gte", timeRange)))
                                    )
                            )
                    ),
                    "size", 10000
            );

            HttpEntity<String> entity = new HttpEntity<>(JsonUtil.toJson(query), headers);

            ResponseEntity<String> response = restTemplate.exchange(
                    toolsConfig.getElkApiUrl() + "/logs-*/_search",
                    HttpMethod.POST,
                    entity,
                    String.class
            );

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                Map<String, Object> result = JsonUtil.fromJson(response.getBody(), Map.class);
                return parseErrorsFromElk(result);
            }

            throw new RuntimeException("Invalid response from ELK API");

        }, "ELK-Search-Errors");
    }

    private List<ElkNodeOutput.LogEntry> parseElkResponse(Map<String, Object> result) {
        List<ElkNodeOutput.LogEntry> logs = new ArrayList<>();
        Map<String, Object> hits = (Map<String, Object>) result.get("hits");
        if (hits != null) {
            List<Map<String, Object>> hitsList = (List<Map<String, Object>>) hits.get("hits");
            if (hitsList != null) {
                for (Map<String, Object> hit : hitsList) {
                    Map<String, Object> source = (Map<String, Object>) hit.get("_source");
                    logs.add(new ElkNodeOutput.LogEntry(
                            (String) source.get("@timestamp"),
                            (String) source.get("level"),
                            (String) source.get("message"),
                            (String) source.get("service"),
                            source
                    ));
                }
            }
        }
        return logs;
    }

    private List<Map<String, Object>> parseErrorsFromElk(Map<String, Object> result) {
        List<Map<String, Object>> errors = new ArrayList<>();
        Map<String, Object> hits = (Map<String, Object>) result.get("hits");
        if (hits != null) {
            List<Map<String, Object>> hitsList = (List<Map<String, Object>>) hits.get("hits");
            if (hitsList != null) {
                for (Map<String, Object> hit : hitsList) {
                    Map<String, Object> source = (Map<String, Object>) hit.get("_source");
                    errors.add(source);
                }
            }
        }
        return errors;
    }
}
