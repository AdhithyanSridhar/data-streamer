package com.traceiq.core.controller;

import com.traceiq.core.service.JobService;
import com.traceiq.models.dto.JobListResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/jobs")
@Tag(name = "Jobs API", description = "Job management and history")
public class JobsController {
    
    private static final Logger logger = LoggerFactory.getLogger(JobsController.class);
    private final JobService jobService;
    
    public JobsController(JobService jobService) {
        this.jobService = jobService;
    }
    
    @GetMapping
    @Operation(summary = "List jobs", description = "Get all configured jobs and their execution history")
    public ResponseEntity<JobListResponse> listJobs() {
        logger.info("Listing all jobs");
        JobListResponse response = jobService.listJobs();
        return ResponseEntity.ok(response);
    }
}
