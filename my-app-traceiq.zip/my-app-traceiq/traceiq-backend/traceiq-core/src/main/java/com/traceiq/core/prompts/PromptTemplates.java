package com.traceiq.core.prompts;

import com.traceiq.models.domain.ImplementationPlan;
import com.traceiq.models.domain.RCAResult;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Professional, rich prompt templates for LLM interactions.
 * These prompts are versioned and designed for optimal AI output quality.
 * 
 * @version 1.0.0
 * @author TraceIQ Engineering Team
 */
@Component
public class PromptTemplates {
    
    private static final String RCA_SYSTEM_PROMPT = """
        You are an expert Site Reliability Engineer (SRE) and software architect with deep expertise in:
        - Distributed systems debugging and root cause analysis
        - Microservices architecture patterns and anti-patterns
        - Production incident response and postmortem analysis
        - Stack trace interpretation across multiple programming languages
        - Performance profiling and bottleneck identification
        
        Your task is to analyze error logs, metrics, and traces to identify the root cause of production issues.
        Provide clear, actionable insights with high confidence scores.
        
        Analysis Framework:
        1. Identify the primary failure point
        2. Trace the error propagation path
        3. Determine contributing factors (configuration, dependencies, timing, data)
        4. Assess impact scope (affected services, users, transactions)
        5. Assign severity based on business impact
        
        Output Format:
        - Root Cause: One clear sentence describing the primary issue
        - Analysis: Detailed technical explanation (200-400 words)
        - Contributing Factors: Bulleted list of secondary causes
        - Confidence Score: 0.0-1.0 based on evidence quality
        - Severity: CRITICAL/HIGH/MEDIUM/LOW
        """;
    
    private static final String IMPLEMENTATION_PLAN_SYSTEM_PROMPT = """
        You are an elite software engineering consultant specializing in production issue remediation.
        Your expertise includes:
        - Code review and quality assessment
        - Refactoring strategies for reliability improvements
        - Test-driven development and quality assurance
        - DevOps best practices and deployment strategies
        - GitHub Copilot prompt engineering for AI-assisted coding
        
        Your task is to create detailed, actionable implementation plans that developers can execute using:
        - Their IDE (VS Code, IntelliJ)
        - GitHub Copilot for code generation assistance
        - Standard SDLC processes (PR reviews, testing, deployment)
        
        Plan Components:
        1. Code Locations: Specific files and line numbers requiring changes
        2. Implementation Steps: Ordered, granular actions with clear objectives
        3. Copilot Prompts: High-quality, context-rich prompts for each code change
        4. Testing Strategy: Unit tests, integration tests, and validation steps
        5. Rollback Plan: Safe reversion strategy if issues arise
        
        Copilot Prompt Guidelines:
        - Be specific about the exact change required
        - Include context about the surrounding code
        - Specify edge cases and error handling requirements
        - Reference relevant design patterns or best practices
        - Indicate expected test coverage
        
        Output Style:
        - Clear, professional, and actionable
        - Suitable for both junior and senior developers
        - Emphasizes code quality, maintainability, and reliability
        """;
    
    /**
     * Builds a comprehensive RCA prompt with full context.
     *
     * @param traceId trace identifier
     * @param contextSummary error logs and metrics summary
     * @return formatted prompt
     */
    public String buildRCAPrompt(String traceId, String contextSummary) {
        return String.format("""
            # Root Cause Analysis Request
            
            ## Trace Information
            - **Trace ID**: %s
            - **Environment**: Production
            - **Analysis Timestamp**: %s
            
            ## Error Context
            %s
            
            ## Your Task
            Analyze the above error information and provide a comprehensive root cause analysis.
            
            Focus Areas:
            1. **Primary Failure Point**: Where did the error originate?
            2. **Error Propagation**: How did it spread through the system?
            3. **Contributing Factors**: What conditions enabled this failure?
            4. **Impact Assessment**: What services/users were affected?
            5. **Systemic Issues**: Are there underlying architectural problems?
            
            ## Expected Output
            Provide a structured analysis including:
            - Root cause statement (1-2 sentences)
            - Detailed technical analysis (200-400 words)
            - List of 3-5 contributing factors
            - Confidence score (0.0-1.0) based on evidence
            - Severity classification (CRITICAL/HIGH/MEDIUM/LOW)
            - Recommended immediate actions
            
            ## Context Notes
            - This is a microservices architecture with multiple language stacks
            - Services communicate via REST APIs and message queues
            - Configuration is managed through environment variables and config servers
            - The system uses centralized logging (ELK) and distributed tracing (Dynatrace)
            """,
            traceId,
            java.time.Instant.now(),
            contextSummary
        );
    }
    
    /**
     * Builds an implementation plan prompt with RCA context and code locations.
     *
     * @param traceId trace identifier
     * @param rcaResult RCA analysis result
     * @param codeLocations identified code locations
     * @return formatted prompt
     */
    public String buildImplementationPlanPrompt(
            String traceId, 
            RCAResult rcaResult, 
            List<ImplementationPlan.CodeLocation> codeLocations) {
        
        StringBuilder codeLocationsSummary = new StringBuilder();
        for (ImplementationPlan.CodeLocation loc : codeLocations) {
            codeLocationsSummary.append(String.format("""
                ### Location %d: %s
                - **File**: %s (lines %d-%d)
                - **Repository**: %s
                - **Issue**: %s
                - **Relevance Score**: %.2f
                
                **Code Snippet**:
                ```
                %s
                ```
                
                """,
                codeLocations.indexOf(loc) + 1,
                loc.filePath(),
                loc.filePath(),
                loc.startLine(),
                loc.endLine(),
                loc.repository(),
                loc.issueDescription(),
                loc.relevanceScore(),
                loc.codeSnippet()
            ));
        }
        
        return String.format("""
            # Implementation Plan Generation Request
            
            ## Trace Information
            - **Trace ID**: %s
            - **Root Cause**: %s
            - **Severity**: %s
            
            ## RCA Summary
            %s
            
            ## Identified Code Locations
            %s
            
            ## Your Task
            Create a detailed, actionable implementation plan that developers can execute using their IDE and GitHub Copilot.
            
            ### Plan Requirements
            
            1. **Implementation Steps**
               - Break down the fix into granular, ordered steps
               - Each step should be completable in 15-30 minutes
               - Include specific file modifications, additions, or deletions
               - Reference line numbers and code sections
            
            2. **GitHub Copilot Prompts**
               For each code change, provide a rich Copilot prompt that includes:
               - Exact change description
               - Context about surrounding code
               - Error handling requirements
               - Edge cases to consider
               - Expected behavior after change
               - Example: "In PaymentService.java line 145, add a null check before accessing configValue. 
                 If configValue is null, throw IllegalStateException with message 'Configuration payment.gateway.url is missing'. 
                 Add JavaDoc explaining this validation. Ensure the check happens before any payment processing logic."
            
            3. **Testing Strategy**
               - Unit tests required (with test case descriptions)
               - Integration tests needed
               - Manual testing steps
               - Regression test areas
            
            4. **Rollback Plan**
               - Steps to safely revert changes if issues arise
               - Monitoring checkpoints during rollout
               - Feature flags or gradual rollout recommendations
            
            ## Output Format
            Structure your response as a professional implementation plan with:
            - Executive summary (50 words)
            - Detailed steps (numbered, with substeps)
            - Copilot prompts for each code change (rich and specific)
            - Testing strategy
            - Rollback procedure
            - Estimated implementation time
            
            ## Quality Guidelines
            - Be specific and actionable
            - Assume developer has IDE access and GitHub Copilot
            - Emphasize code quality and maintainability
            - Include error handling and edge cases
            - Reference industry best practices where applicable
            """,
            traceId,
            rcaResult.rootCause(),
            rcaResult.severity(),
            rcaResult.analysisText(),
            codeLocationsSummary.toString()
        );
    }
    
    /**
     * Builds curated GitHub Copilot prompts for each code location.
     * These are high-quality, reusable prompts that developers can use directly in their IDE.
     *
     * @param rcaResult RCA analysis
     * @param codeLocations code locations to fix
     * @return list of Copilot prompts
     */
    public List<String> buildCopilotPrompts(RCAResult rcaResult, List<ImplementationPlan.CodeLocation> locations) {
        List<String> prompts = new ArrayList<>();
        
        for (ImplementationPlan.CodeLocation loc : locations) {
            String prompt = String.format("""
                // COPILOT PROMPT - Use in IDE at %s (line %d)
                // Context: Fixing RCA issue - %s
                // Issue at this location: %s
                //
                // Task: Implement a robust fix that:
                // 1. Adds null/empty validation before using the value
                // 2. Throws meaningful exception with clear error message if validation fails
                // 3. Includes JavaDoc explaining the validation logic
                // 4. Follows defensive programming principles
                // 5. Maintains backward compatibility where possible
                //
                // Requirements:
                // - Add appropriate null checks
                // - Use Optional<T> pattern if applicable
                // - Include logging at WARN or ERROR level for debugging
                // - Add inline comments explaining edge cases
                // - Ensure thread safety if this code is accessed concurrently
                //
                // Example pattern:
                // if (value == null || value.isEmpty()) {
                //     logger.error("Configuration value missing: {}", configKey);
                //     throw new IllegalStateException("Required configuration '" + configKey + "' is not set");
                // }
                //
                // Generate the complete, production-ready fix below:
                """,
                loc.filePath(),
                loc.startLine(),
                rcaResult.rootCause(),
                loc.issueDescription()
            );
            
            prompts.add(prompt);
        }
        
        // Add comprehensive testing prompt
        prompts.add("""
            // COPILOT PROMPT - Create comprehensive test coverage
            // Context: Testing fixes for production issue
            //
            // Task: Generate JUnit 5 test class that covers:
            // 1. Happy path - normal execution with valid inputs
            // 2. Null input handling - verify proper exception is thrown
            // 3. Empty/invalid input handling - edge cases
            // 4. Boundary conditions - limits and extremes
            // 5. Concurrent access scenarios if applicable
            //
            // Test Structure:
            // - Use @ParameterizedTest for multiple input scenarios
            // - Use @Test for specific edge cases
            // - Include clear test names following pattern: should[ExpectedBehavior]When[Condition]
            // - Add descriptive error messages in assertions
            // - Mock external dependencies appropriately
            //
            // Example test:
            // @Test
            // void shouldThrowIllegalStateExceptionWhenConfigValueIsNull() {
            //     // Given
            //     when(configManager.getConfig("key")).thenReturn(null);
            //     
            //     // When/Then
            //     IllegalStateException exception = assertThrows(
            //         IllegalStateException.class,
            //         () -> paymentService.processPayment(request)
            //     );
            //     assertThat(exception.getMessage()).contains("Configuration");
            // }
            //
            // Generate the complete test class below:
            """);
        
        return prompts;
    }
    
    public String getRCASystemPrompt() {
        return RCA_SYSTEM_PROMPT;
    }
    
    public String getImplementationPlanSystemPrompt() {
        return IMPLEMENTATION_PLAN_SYSTEM_PROMPT;
    }
}
