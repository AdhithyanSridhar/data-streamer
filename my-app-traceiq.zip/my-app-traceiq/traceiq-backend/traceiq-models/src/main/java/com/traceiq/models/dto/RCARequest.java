package com.traceiq.models.dto;

/**
 * Request DTO for RCA generation.
 */
public record RCARequest(
    String traceId,
    boolean forceRefresh,
    boolean enableAI,
    String llmModel
) {
    public static class Builder {
        private String traceId;
        private boolean forceRefresh;
        private boolean enableAI = true;
        private String llmModel;

        public Builder traceId(String traceId) {
            this.traceId = traceId;
            return this;
        }

        public Builder forceRefresh(boolean forceRefresh) {
            this.forceRefresh = forceRefresh;
            return this;
        }

        public Builder enableAI(boolean enableAI) {
            this.enableAI = enableAI;
            return this;
        }

        public Builder llmModel(String llmModel) {
            this.llmModel = llmModel;
            return this;
        }

        public RCARequest build() {
            return new RCARequest(traceId, forceRefresh, enableAI, llmModel);
        }
    }

    public static Builder builder() {
        return new Builder();
    }
}
