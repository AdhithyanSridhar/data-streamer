package com.traceiq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * TraceIQ - AI-Powered RCA and Code Analysis Platform
 * 
 * Main application entry point.
 */
@SpringBootApplication
public class TraceIqApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(TraceIqApplication.class, args);
    }
}
