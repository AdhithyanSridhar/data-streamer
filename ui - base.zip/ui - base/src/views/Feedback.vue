<template>
  <v-container fluid class="pa-6">
    <div class="page-header mb-6">
      <h1 class="page-title">Send Feedback</h1>
      <p class="page-subtitle">We'd love to hear from you! Share your thoughts, suggestions, or report issues.</p>
    </div>

    <v-row justify="center">
      <v-col cols="12" md="8" lg="6">
        <div class="glass-card pa-8 feedback-card">
          <div class="feedback-icon mb-6">
            <v-icon icon="mdi-message-outline" size="64"></v-icon>
          </div>

          <h2 class="feedback-title mb-2">Get in Touch</h2>
          <p class="feedback-description mb-6">
            Have questions, suggestions, or found a bug? We're here to help. Click the button below to send us an email.
          </p>

          <v-btn color="primary" size="x-large" rounded="lg" href="mailto:traceiq-support@acme.com?subject=TraceIQ Feedback" class="feedback-btn">
            <v-icon icon="mdi-email-outline" class="mr-2"></v-icon>
            Send Email to traceiq-support@acme.com
          </v-btn>

          <v-divider class="my-8"></v-divider>

          <!-- Quick Feedback Options -->
          <h3 class="quick-title mb-4">Quick Feedback</h3>
          <div class="quick-options">
            <v-btn v-for="option in quickOptions" :key="option.label" variant="outlined" size="large" rounded="lg" class="quick-btn" :href="`mailto:traceiq-support@acme.com?subject=${option.subject}`">
              <v-icon :icon="option.icon" class="mr-2"></v-icon>
              {{ option.label }}
            </v-btn>
          </div>

          <v-divider class="my-8"></v-divider>

          <!-- Contact Info -->
          <div class="contact-info">
            <div class="contact-item">
              <v-icon icon="mdi-email-outline" class="mr-2"></v-icon>
              <span>traceiq-support@acme.com</span>
            </div>
            <div class="contact-item">
              <v-icon icon="mdi-slack" class="mr-2"></v-icon>
              <span>#traceiq-support on Slack</span>
            </div>
            <div class="contact-item">
              <v-icon icon="mdi-book-open-variant" class="mr-2"></v-icon>
              <span>docs.traceiq.acme.com</span>
            </div>
          </div>
        </div>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup>
const quickOptions = [
  { label: 'Report Bug', icon: 'mdi-bug-outline', subject: '[Bug Report] ' },
  { label: 'Feature Request', icon: 'mdi-lightbulb-outline', subject: '[Feature Request] ' },
  { label: 'General Question', icon: 'mdi-help-circle-outline', subject: '[Question] ' },
  { label: 'Praise', icon: 'mdi-heart-outline', subject: '[Feedback] Love TraceIQ!' }
]
</script>

<style scoped>
.page-header { text-align: center; padding: 20px 0; }
.page-title { font-size: 1.75rem; font-weight: 700; color: #1a1a1a; margin-bottom: 8px; }
.page-subtitle { font-size: 0.95rem; color: #666666; }

.feedback-card { text-align: center; }
.feedback-icon { display: flex; justify-content: center; color: #1a1a1a; }
.feedback-title { font-size: 1.35rem; font-weight: 600; color: #1a1a1a; }
.feedback-description { font-size: 0.95rem; color: #666666; line-height: 1.6; max-width: 400px; margin: 0 auto; }
.feedback-btn { text-transform: none; font-weight: 600; letter-spacing: 0; }

.quick-title { font-size: 0.95rem; font-weight: 600; color: #1a1a1a; text-align: center; }
.quick-options { display: flex; flex-wrap: wrap; gap: 12px; justify-content: center; }
.quick-btn { text-transform: none; font-weight: 500; }

.contact-info { display: flex; flex-direction: column; gap: 12px; align-items: center; }
.contact-item { display: flex; align-items: center; font-size: 0.9rem; color: #666666; }
</style>
