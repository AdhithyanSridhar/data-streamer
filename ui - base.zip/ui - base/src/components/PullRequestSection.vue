<template>
  <div class="glass-card pa-5">
    <div class="section-header">
      <div class="section-header__icon">
        <v-icon icon="mdi-source-pull" size="20"></v-icon>
      </div>
      <h2 class="section-header__title">Pull Request</h2>
    </div>
    
    <div class="pr-card">
      <div class="pr-header">
        <div class="pr-number">#{{ pr.prNumber }}</div>
        <v-chip variant="outlined" size="small">{{ pr.status }}</v-chip>
      </div>
      
      <h3 class="pr-title">{{ pr.title }}</h3>
      
      <div class="pr-meta">
        <div class="meta-item">
          <v-icon icon="mdi-source-branch" size="16"></v-icon>
          <code>{{ pr.branchName }}</code>
        </div>
        <div class="meta-item">
          <v-icon icon="mdi-robot-outline" size="16"></v-icon>
          <span>Created by {{ pr.agentName }}</span>
        </div>
      </div>
      
      <div class="pr-diff">
        <div class="diff-header">
          <v-icon icon="mdi-file-document-outline" size="16"></v-icon>
          <span>Code Changes</span>
        </div>
        <pre class="diff-content"><code>{{ pr.codeDiff }}</code></pre>
      </div>
      
      <div class="pr-actions">
        <v-btn variant="outlined" size="small" :href="pr.url" target="_blank" rounded="lg">
          <v-icon icon="mdi-open-in-new" class="mr-1" size="16"></v-icon>
          View on GitHub
        </v-btn>
      </div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  pr: { type: Object, required: true }
})
</script>

<style scoped>
.pr-card {
  background: #f5f5f5;
  border-radius: 10px;
  padding: 20px;
}

.pr-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
}

.pr-number {
  font-size: 1.2rem;
  font-weight: 700;
  color: #1a1a1a;
}

.pr-title {
  font-size: 1rem;
  font-weight: 600;
  color: #1a1a1a;
  margin-bottom: 16px;
}

.pr-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  margin-bottom: 16px;
}

.meta-item {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 0.8rem;
  color: #666666;
}

.meta-item code {
  background: #e5e5e5;
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 0.75rem;
}

.pr-diff {
  margin-bottom: 16px;
}

.diff-header {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 0.8rem;
  color: #666666;
  margin-bottom: 8px;
}

.diff-content {
  background: #1a1a1a;
  border-radius: 8px;
  padding: 16px;
  overflow-x: auto;
  font-size: 0.75rem;
  line-height: 1.6;
}

.diff-content code {
  color: #e5e5e5;
  font-family: 'JetBrains Mono', monospace;
}

.pr-actions {
  display: flex;
  gap: 8px;
}
</style>
