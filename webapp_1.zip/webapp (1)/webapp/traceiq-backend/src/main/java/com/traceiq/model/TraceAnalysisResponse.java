package com.traceiq.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * Comprehensive response model containing RCA analysis results.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record TraceAnalysisResponse(
    String analysisId,
    String traceId,
    String status,
    LocalDateTime timestamp,
    
    // Core Analysis
    RootCauseAnalysis rootCauseAnalysis,
    CodeAnalysis codeAnalysis,
    
    // Supporting Data
    List<LogEntry> errorLogs,
    List<LogEntry> warnLogs,
    PerformanceMetrics performanceMetrics,
    
    // External System Data
    JiraTicketInfo jiraTicket,
    List<GitHubPRInfo> recentPRs,
    DeploymentInfo deploymentInfo,
    
    // Recommendations
    List<String> fixSuggestions,
    List<String> guardrails,
    String implementationPlan,
    
    // Metadata
    String teamName,
    String ownerEmail,
    List<String> affectedServices,
    Map<String, Object> additionalContext
) {
    public static Builder builder() {
        return new Builder();
    }
    
    public static class Builder {
        private String analysisId;
        private String traceId;
        private String status;
        private LocalDateTime timestamp;
        private RootCauseAnalysis rootCauseAnalysis;
        private CodeAnalysis codeAnalysis;
        private List<LogEntry> errorLogs;
        private List<LogEntry> warnLogs;
        private PerformanceMetrics performanceMetrics;
        private JiraTicketInfo jiraTicket;
        private List<GitHubPRInfo> recentPRs;
        private DeploymentInfo deploymentInfo;
        private List<String> fixSuggestions;
        private List<String> guardrails;
        private String implementationPlan;
        private String teamName;
        private String ownerEmail;
        private List<String> affectedServices;
        private Map<String, Object> additionalContext;
        
        public Builder analysisId(String analysisId) {
            this.analysisId = analysisId;
            return this;
        }
        
        public Builder traceId(String traceId) {
            this.traceId = traceId;
            return this;
        }
        
        public Builder status(String status) {
            this.status = status;
            return this;
        }
        
        public Builder timestamp(LocalDateTime timestamp) {
            this.timestamp = timestamp;
            return this;
        }
        
        public Builder rootCauseAnalysis(RootCauseAnalysis rootCauseAnalysis) {
            this.rootCauseAnalysis = rootCauseAnalysis;
            return this;
        }
        
        public Builder codeAnalysis(CodeAnalysis codeAnalysis) {
            this.codeAnalysis = codeAnalysis;
            return this;
        }
        
        public Builder errorLogs(List<LogEntry> errorLogs) {
            this.errorLogs = errorLogs;
            return this;
        }
        
        public Builder warnLogs(List<LogEntry> warnLogs) {
            this.warnLogs = warnLogs;
            return this;
        }
        
        public Builder performanceMetrics(PerformanceMetrics performanceMetrics) {
            this.performanceMetrics = performanceMetrics;
            return this;
        }
        
        public Builder jiraTicket(JiraTicketInfo jiraTicket) {
            this.jiraTicket = jiraTicket;
            return this;
        }
        
        public Builder recentPRs(List<GitHubPRInfo> recentPRs) {
            this.recentPRs = recentPRs;
            return this;
        }
        
        public Builder deploymentInfo(DeploymentInfo deploymentInfo) {
            this.deploymentInfo = deploymentInfo;
            return this;
        }
        
        public Builder fixSuggestions(List<String> fixSuggestions) {
            this.fixSuggestions = fixSuggestions;
            return this;
        }
        
        public Builder guardrails(List<String> guardrails) {
            this.guardrails = guardrails;
            return this;
        }
        
        public Builder implementationPlan(String implementationPlan) {
            this.implementationPlan = implementationPlan;
            return this;
        }
        
        public Builder teamName(String teamName) {
            this.teamName = teamName;
            return this;
        }
        
        public Builder ownerEmail(String ownerEmail) {
            this.ownerEmail = ownerEmail;
            return this;
        }
        
        public Builder affectedServices(List<String> affectedServices) {
            this.affectedServices = affectedServices;
            return this;
        }
        
        public Builder additionalContext(Map<String, Object> additionalContext) {
            this.additionalContext = additionalContext;
            return this;
        }
        
        public TraceAnalysisResponse build() {
            return new TraceAnalysisResponse(
                analysisId, traceId, status, timestamp,
                rootCauseAnalysis, codeAnalysis, errorLogs, warnLogs,
                performanceMetrics, jiraTicket, recentPRs, deploymentInfo,
                fixSuggestions, guardrails, implementationPlan,
                teamName, ownerEmail, affectedServices, additionalContext
            );
        }
    }
}
