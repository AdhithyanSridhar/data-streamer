<template>
  <div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <header class="bg-white shadow-sm border-b">
      <div class="container mx-auto px-6 py-4">
        <div class="flex items-center justify-between">
          <div class="flex items-center space-x-3">
            <i class="fas fa-search-location text-3xl text-blue-600"></i>
            <div>
              <h1 class="text-2xl font-bold text-gray-800">TraceIQ</h1>
              <p class="text-sm text-gray-500">AI-Powered RCA & Code Analysis</p>
            </div>
          </div>
          <div class="flex space-x-4">
            <button class="px-4 py-2 text-gray-600 hover:text-gray-800">
              <i class="fas fa-cog mr-2"></i>Settings
            </button>
            <button class="px-4 py-2 text-gray-600 hover:text-gray-800">
              <i class="fas fa-question-circle mr-2"></i>Help
            </button>
          </div>
        </div>
      </div>
    </header>

    <!-- Main Content -->
    <main class="container mx-auto px-6 py-8">
      <TraceAnalyzer />
    </main>

    <!-- Footer -->
    <footer class="bg-white border-t mt-12">
      <div class="container mx-auto px-6 py-4 text-center text-gray-600 text-sm">
        <p>TraceIQ v1.0 - Improving Developer & QA Productivity</p>
      </div>
    </footer>
  </div>
</template>

<script setup>
import TraceAnalyzer from './components/TraceAnalyzer.vue'
</script>
