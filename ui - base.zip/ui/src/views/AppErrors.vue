<template>
  <v-container fluid class="pa-6">
    <!-- Page Header -->
    <div class="page-header mb-6">
      <h1 class="page-title">Application Errors</h1>
      <p class="page-subtitle">Monitor and analyze errors across your applications</p>
    </div>

    <!-- Analytics Panels -->
    <v-row class="mb-6">
      <v-col cols="12" sm="6" md="3" v-for="stat in analyticsStats" :key="stat.title">
        <div class="glass-card pa-4 stat-card">
          <div class="stat-icon">
            <v-icon :icon="stat.icon" size="24"></v-icon>
          </div>
          <div class="stat-content">
            <span class="stat-value">{{ stat.value }}</span>
            <span class="stat-label">{{ stat.title }}</span>
          </div>
          <div class="stat-sparkline">
            <svg viewBox="0 0 60 20" class="sparkline">
              <polyline :points="stat.sparkline" fill="none" stroke="#1a1a1a" stroke-width="1.5"/>
            </svg>
          </div>
        </div>
      </v-col>
    </v-row>

    <!-- Filters -->
    <div class="glass-card pa-5 mb-6">
      <div class="section-header mb-4">
        <div class="section-header__icon">
          <v-icon icon="mdi-filter-outline" size="20"></v-icon>
        </div>
        <span class="section-header__title">Filter Errors</span>
      </div>
      <v-row align="center">
        <v-col cols="12" md="4">
          <v-select v-model="selectedTeam" :items="teams" label="Team Name" variant="outlined" density="comfortable" prepend-inner-icon="mdi-account-group-outline" @update:model-value="onTeamChange"></v-select>
        </v-col>
        <v-col cols="12" md="4">
          <v-select v-model="selectedApp" :items="filteredApps" label="Application Name" variant="outlined" density="comfortable" prepend-inner-icon="mdi-application-outline" :disabled="!selectedTeam"></v-select>
        </v-col>
        <v-col cols="12" md="4">
          <v-btn color="primary" size="large" :disabled="!selectedTeam || !selectedApp" @click="showErrors" rounded="lg" class="px-8">
            <v-icon icon="mdi-magnify" class="mr-2"></v-icon>
            Show Errors
          </v-btn>
        </v-col>
      </v-row>
    </div>

    <!-- Bulk Actions Bar -->
    <div class="bulk-actions-bar glass-card pa-4 mb-4" v-if="selectedErrors.length">
      <div class="bulk-info">
        <v-checkbox v-model="selectAll" @update:model-value="toggleSelectAll" hide-details density="compact"></v-checkbox>
        <span>{{ selectedErrors.length }} selected</span>
      </div>
      <div class="bulk-buttons">
        <v-btn variant="outlined" size="small" @click="bulkAssignAgent">
          <v-icon icon="mdi-robot-outline" class="mr-1"></v-icon>
          Assign Agent
        </v-btn>
        <v-btn variant="outlined" size="small" @click="bulkMarkResolved">
          <v-icon icon="mdi-check-circle-outline" class="mr-1"></v-icon>
          Mark Resolved
        </v-btn>
        <v-btn variant="outlined" size="small" @click="compareErrors" :disabled="selectedErrors.length < 2">
          <v-icon icon="mdi-compare" class="mr-1"></v-icon>
          Compare
        </v-btn>
        <v-btn variant="outlined" size="small" @click="bulkExport">
          <v-icon icon="mdi-download-outline" class="mr-1"></v-icon>
          Export
        </v-btn>
      </div>
    </div>

    <!-- Errors Table with Advanced Features -->
    <div class="glass-card pa-5">
      <div class="section-header mb-4">
        <div class="section-header__icon">
          <v-icon icon="mdi-table" size="20"></v-icon>
        </div>
        <span class="section-header__title">Error Summary</span>
        <v-spacer></v-spacer>
        <v-chip variant="outlined" size="small">{{ filteredErrors.length }} errors</v-chip>
      </div>
      
      <!-- Table Toolbar -->
      <div class="table-toolbar mb-4">
        <v-text-field
          v-model="tableSearch"
          prepend-inner-icon="mdi-magnify"
          label="Search in table..."
          variant="outlined"
          density="compact"
          hide-details
          clearable
          class="search-field"
        ></v-text-field>
        
        <v-btn-toggle v-model="groupByService" density="compact" variant="outlined">
          <v-btn :value="false" size="small">Flat</v-btn>
          <v-btn :value="true" size="small">Group</v-btn>
        </v-btn-toggle>
        
        <v-spacer></v-spacer>
        
        <!-- Column Toggle -->
        <v-menu>
          <template v-slot:activator="{ props }">
            <v-btn v-bind="props" variant="outlined" size="small" class="mr-2">
              <v-icon icon="mdi-view-column-outline" class="mr-1"></v-icon>
              Columns
            </v-btn>
          </template>
          <v-list density="compact">
            <v-list-item v-for="col in allColumns" :key="col.key">
              <v-checkbox v-model="visibleColumns" :label="col.title" :value="col.key" density="compact" hide-details></v-checkbox>
            </v-list-item>
          </v-list>
        </v-menu>
        
        <!-- Export Menu -->
        <v-menu>
          <template v-slot:activator="{ props }">
            <v-btn v-bind="props" variant="outlined" size="small">
              <v-icon icon="mdi-download-outline" class="mr-1"></v-icon>
              Export
            </v-btn>
          </template>
          <v-list density="compact">
            <v-list-item @click="exportJSON">
              <v-list-item-title>Export as JSON</v-list-item-title>
            </v-list-item>
            <v-list-item @click="exportExcel">
              <v-list-item-title>Export as Excel</v-list-item-title>
            </v-list-item>
          </v-list>
        </v-menu>
      </div>
      
      <!-- Grouped View -->
      <div v-if="groupByService" class="grouped-view">
        <div v-for="group in groupedErrors" :key="group.service" class="error-group">
          <div class="group-header" @click="group.expanded = !group.expanded">
            <v-icon :icon="group.expanded ? 'mdi-chevron-down' : 'mdi-chevron-right'" size="18"></v-icon>
            <span class="group-name">{{ group.service }}</span>
            <v-chip size="x-small" variant="outlined">{{ group.errors.length }} errors</v-chip>
            <span class="group-total">{{ group.totalCount }} occurrences</span>
          </div>
          <v-expand-transition>
            <div v-show="group.expanded" class="group-content">
              <div v-for="error in group.errors" :key="error.id" class="group-error-item" @click="openDialog('stackTrace', error)">
                <v-checkbox v-model="selectedErrors" :value="error.id" hide-details density="compact" @click.stop></v-checkbox>
                <span class="error-msg-short">{{ error.sMsg }}</span>
                <v-chip size="x-small" :color="getCountColor(error.count)">{{ error.count }}</v-chip>
              </div>
            </div>
          </v-expand-transition>
        </div>
      </div>
      
      <!-- Flat Table View -->
      <v-data-table
        v-else
        :headers="visibleHeaders"
        :items="filteredErrors"
        :search="tableSearch"
        :items-per-page="itemsPerPage"
        :sort-by="sortBy"
        class="error-table"
        density="comfortable"
        show-select
        v-model="selectedErrors"
        item-value="id"
        hover
      >
        <template v-slot:item.sMsg="{ item }">
          <div class="error-msg-cell">
            <div class="error-msg">
              <code>{{ item.sMsg }}</code>
            </div>
            <div class="similar-badge" v-if="item.similarCount">
              <v-chip size="x-small" variant="tonal" color="info" @click.stop="showSimilar(item)">
                +{{ item.similarCount }} similar
              </v-chip>
            </div>
          </div>
        </template>
        
        <template v-slot:item.traceId="{ item }">
          <div class="trace-cell">
            <a href="#" class="trace-link" @click.prevent="navigateToTrace(item.traceId)">
              {{ item.traceId }}
            </a>
            <v-btn icon variant="text" size="x-small" @click.stop="copyTraceId(item.traceId)">
              <v-icon icon="mdi-content-copy" size="12"></v-icon>
            </v-btn>
          </div>
        </template>
        
        <template v-slot:item.count="{ item }">
          <div class="count-cell">
            <v-chip :color="getCountColor(item.count)" variant="flat" size="small">{{ item.count }}</v-chip>
            <svg viewBox="0 0 40 16" class="count-sparkline">
              <polyline :points="item.sparkline" fill="none" :stroke="getCountColor(item.count)" stroke-width="1.5"/>
            </svg>
          </div>
        </template>
        
        <template v-slot:item.lastOccurred="{ item }">
          <span class="timestamp">{{ formatDate(item.lastOccurred) }}</span>
        </template>
        
        <template v-slot:item.insights="{ item }">
          <div class="insights-actions">
            <v-btn icon variant="text" size="small" @click="openDialog('stackTrace', item)" title="Stack Trace">
              <v-icon icon="mdi-code-braces"></v-icon>
            </v-btn>
            <v-btn icon variant="text" size="small" @click="openDialog('eventMetadata', item)" title="Event Metadata">
              <v-icon icon="mdi-database-outline"></v-icon>
            </v-btn>
            <v-btn icon variant="text" size="small" @click="openDialog('askATT', item)" title="AskATT - LLM Reasoning">
              <v-icon icon="mdi-robot-outline"></v-icon>
            </v-btn>
          </div>
        </template>
        
        <template v-slot:item.assignAgent="{ item }">
          <v-btn variant="outlined" size="small" rounded="lg" @click="openAssignDialog(item)">
            <v-icon icon="mdi-robot-outline" class="mr-1" size="16"></v-icon>
            Assign
          </v-btn>
        </template>

        <!-- Row expansion for details -->
        <template v-slot:expanded-row="{ columns, item }">
          <tr>
            <td :colspan="columns.length" class="expanded-row">
              <div class="expanded-content">
                <div class="expanded-section">
                  <h4>Stack Trace Preview</h4>
                  <pre>{{ item.stackTrace?.substring(0, 200) }}...</pre>
                </div>
                <div class="expanded-section">
                  <h4>Quick Actions</h4>
                  <div class="quick-actions">
                    <v-btn size="small" variant="outlined" @click="watchError(item)">
                      <v-icon icon="mdi-bell-outline" class="mr-1"></v-icon>
                      Watch
                    </v-btn>
                    <v-btn size="small" variant="outlined" @click="addNote(item)">
                      <v-icon icon="mdi-note-outline" class="mr-1"></v-icon>
                      Add Note
                    </v-btn>
                  </div>
                </div>
              </div>
            </td>
          </tr>
        </template>
        
        <template v-slot:bottom>
          <div class="table-footer">
            <v-select
              v-model="itemsPerPage"
              :items="[5, 10, 25, 50, 100]"
              label="Rows per page"
              variant="outlined"
              density="compact"
              hide-details
              class="rows-select"
            ></v-select>
          </div>
        </template>
      </v-data-table>
    </div>

    <!-- Stack Trace Dialog -->
    <v-dialog v-model="dialogs.stackTrace" max-width="900">
      <v-card class="dialog-card">
        <v-card-title class="dialog-title">
          <v-icon icon="mdi-code-braces" class="mr-2"></v-icon>
          Stack Trace
          <v-spacer></v-spacer>
          <v-btn icon variant="text" @click="dialogs.stackTrace = false">
            <v-icon icon="mdi-close"></v-icon>
          </v-btn>
        </v-card-title>
        <v-card-text>
          <pre class="stack-trace-content">{{ selectedError?.stackTrace }}</pre>
        </v-card-text>
      </v-card>
    </v-dialog>

    <!-- Comparison Dialog -->
    <v-dialog v-model="dialogs.compare" max-width="1200">
      <v-card class="dialog-card">
        <v-card-title class="dialog-title">
          <v-icon icon="mdi-compare" class="mr-2"></v-icon>
          Compare Errors
          <v-spacer></v-spacer>
          <v-btn icon variant="text" @click="dialogs.compare = false">
            <v-icon icon="mdi-close"></v-icon>
          </v-btn>
        </v-card-title>
        <v-card-text>
          <div class="compare-grid">
            <div v-for="errorId in selectedErrors.slice(0, 3)" :key="errorId" class="compare-column">
              <div class="compare-header">Error #{{ errorId }}</div>
              <div class="compare-content">
                <div class="compare-field">
                  <label>Message</label>
                  <code>{{ getErrorById(errorId)?.sMsg }}</code>
                </div>
                <div class="compare-field">
                  <label>Count</label>
                  <span>{{ getErrorById(errorId)?.count }}</span>
                </div>
                <div class="compare-field">
                  <label>Stack Trace</label>
                  <pre>{{ getErrorById(errorId)?.stackTrace?.substring(0, 300) }}...</pre>
                </div>
              </div>
            </div>
          </div>
        </v-card-text>
      </v-card>
    </v-dialog>

    <!-- Event Metadata Dialog -->
    <v-dialog v-model="dialogs.eventMetadata" max-width="700">
      <v-card class="dialog-card">
        <v-card-title class="dialog-title">
          <v-icon icon="mdi-database-outline" class="mr-2"></v-icon>
          Event Metadata
          <v-spacer></v-spacer>
          <v-btn icon variant="text" @click="dialogs.eventMetadata = false">
            <v-icon icon="mdi-close"></v-icon>
          </v-btn>
        </v-card-title>
        <v-card-text>
          <v-list density="compact" class="metadata-list">
            <v-list-item v-for="(value, key) in selectedError?.metadata" :key="key">
              <template v-slot:prepend><v-icon icon="mdi-tag-outline" size="small"></v-icon></template>
              <v-list-item-title>{{ key }}</v-list-item-title>
              <v-list-item-subtitle>{{ value }}</v-list-item-subtitle>
            </v-list-item>
          </v-list>
        </v-card-text>
      </v-card>
    </v-dialog>

    <!-- AskATT Dialog -->
    <v-dialog v-model="dialogs.askATT" max-width="800">
      <v-card class="dialog-card">
        <v-card-title class="dialog-title">
          <v-icon icon="mdi-robot-outline" class="mr-2"></v-icon>
          AskATT - LLM Reasoning
          <v-spacer></v-spacer>
          <v-btn icon variant="text" @click="dialogs.askATT = false">
            <v-icon icon="mdi-close"></v-icon>
          </v-btn>
        </v-card-title>
        <v-card-text>
          <div class="att-content">
            <div class="att-section">
              <h4><v-icon icon="mdi-lightbulb-outline" class="mr-1"></v-icon>Root Cause Analysis</h4>
              <p>{{ selectedError?.attReasoning?.rca }}</p>
            </div>
            <div class="att-section">
              <h4><v-icon icon="mdi-wrench-outline" class="mr-1"></v-icon>Suggested Fix</h4>
              <p>{{ selectedError?.attReasoning?.suggestedFix }}</p>
            </div>
            <div class="att-section">
              <h4><v-icon icon="mdi-chart-timeline-variant" class="mr-1"></v-icon>Impact Assessment</h4>
              <p>{{ selectedError?.attReasoning?.impact }}</p>
            </div>
          </div>
        </v-card-text>
      </v-card>
    </v-dialog>

    <!-- Assign Agent Dialog -->
    <v-dialog v-model="dialogs.assignAgent" max-width="600">
      <v-card class="dialog-card">
        <v-card-title class="dialog-title">
          <v-icon icon="mdi-robot-outline" class="mr-2"></v-icon>
          Assign Agent to Error
          <v-spacer></v-spacer>
          <v-btn icon variant="text" @click="dialogs.assignAgent = false">
            <v-icon icon="mdi-close"></v-icon>
          </v-btn>
        </v-card-title>
        <v-card-text>
          <v-alert type="info" variant="tonal" class="mb-4">
            Select the agent tasks you want to perform for this error.
          </v-alert>
          <v-checkbox v-for="task in agentTasks" :key="task.id" v-model="selectedTasks" :label="task.label" :value="task.id" density="compact" hide-details class="mb-2"></v-checkbox>
        </v-card-text>
        <v-card-actions class="pa-4">
          <v-spacer></v-spacer>
          <v-btn variant="text" @click="dialogs.assignAgent = false">Cancel</v-btn>
          <v-btn color="primary" variant="flat" @click="assignAgent" :disabled="!selectedTasks.length">
            <v-icon icon="mdi-check" class="mr-1"></v-icon>
            Assign Agent
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <!-- Watch Dialog -->
    <v-dialog v-model="dialogs.watch" max-width="400">
      <v-card class="dialog-card">
        <v-card-title class="dialog-title">
          <v-icon icon="mdi-bell-outline" class="mr-2"></v-icon>
          Watch Error
        </v-card-title>
        <v-card-text>
          <p class="mb-4">You'll be notified when this error status changes.</p>
          <v-checkbox label="Email notifications" v-model="watchEmail" hide-details class="mb-2"></v-checkbox>
          <v-checkbox label="Slack notifications" v-model="watchSlack" hide-details></v-checkbox>
        </v-card-text>
        <v-card-actions class="pa-4">
          <v-spacer></v-spacer>
          <v-btn variant="text" @click="dialogs.watch = false">Cancel</v-btn>
          <v-btn color="primary" variant="flat" @click="confirmWatch">Watch</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script setup>
import { ref, computed, inject } from 'vue'
import { useRouter } from 'vue-router'
import * as XLSX from 'xlsx'
import { saveAs } from 'file-saver'

const router = useRouter()
const toast = inject('toast')

const selectedTeam = ref(null)
const selectedApp = ref(null)
const selectedError = ref(null)
const selectedTasks = ref([])
const selectedErrors = ref([])
const selectAll = ref(false)
const tableSearch = ref('')
const itemsPerPage = ref(10)
const sortBy = ref([{ key: 'count', order: 'desc' }])
const groupByService = ref(false)
const watchEmail = ref(true)
const watchSlack = ref(false)

const dialogs = ref({
  stackTrace: false,
  eventMetadata: false,
  askATT: false,
  assignAgent: false,
  compare: false,
  watch: false
})

const analyticsStats = [
  { title: 'Total Errors', value: '1,247', icon: 'mdi-alert-circle-outline', sparkline: '0,15 10,12 20,18 30,14 40,20 50,16 60,14' },
  { title: 'Critical', value: '23', icon: 'mdi-alert-outline', sparkline: '0,10 10,12 20,8 30,15 40,10 50,8 60,5' },
  { title: 'Resolved', value: '892', icon: 'mdi-check-circle-outline', sparkline: '0,5 10,8 20,10 30,12 40,15 50,18 60,20' },
  { title: 'Pending RCA', value: '156', icon: 'mdi-clock-outline', sparkline: '0,12 10,12 20,10 30,12 40,11 50,10 60,10' }
]

const teams = ['Platform Team', 'Payments Team', 'Orders Team', 'Auth Team', 'Notifications Team']
const appsByTeam = {
  'Platform Team': ['api-gateway', 'config-service', 'discovery-service'],
  'Payments Team': ['payment-service', 'billing-service', 'invoice-service'],
  'Orders Team': ['order-service', 'cart-service', 'inventory-service'],
  'Auth Team': ['auth-service', 'user-service', 'oauth-service'],
  'Notifications Team': ['notification-service', 'email-service', 'sms-service']
}

const filteredApps = computed(() => selectedTeam.value ? appsByTeam[selectedTeam.value] || [] : [])
const onTeamChange = () => { selectedApp.value = null }

const allColumns = [
  { title: 'Error Message', key: 'sMsg', width: '30%' },
  { title: 'Trace ID', key: 'traceId', width: '15%' },
  { title: 'Count', key: 'count', width: '12%', align: 'center' },
  { title: 'Last Occurred', key: 'lastOccurred', width: '15%' },
  { title: 'Insights', key: 'insights', width: '12%', align: 'center', sortable: false },
  { title: 'Action', key: 'assignAgent', width: '12%', align: 'center', sortable: false }
]

const visibleColumns = ref(['sMsg', 'traceId', 'count', 'lastOccurred', 'insights', 'assignAgent'])
const visibleHeaders = computed(() => allColumns.filter(col => visibleColumns.value.includes(col.key)))

const errors = ref([
  { id: 1, sMsg: 'NullPointerException in PaymentProcessor.process()', traceId: 'trace-abc123-def456', count: 156, lastOccurred: '2024-12-10T14:30:00Z', service: 'payment-service', similarCount: 3, sparkline: '0,5 8,8 16,10 24,12 32,15 40,16', stackTrace: 'java.lang.NullPointerException\n  at com.acme.payment.PaymentProcessor.process(PaymentProcessor.java:142)', metadata: { traceId: 'trace-abc123', spanId: 'span-456', cluster: 'prod-us-east-1', pod: 'payment-service-7b9d8c' }, attReasoning: { rca: 'Missing null check for transaction context before processing.', suggestedFix: 'Add Optional wrapper and null validation at entry point.', impact: 'High - affects 2,500+ transactions per hour.' } },
  { id: 2, sMsg: 'ConnectionTimeout: Database connection pool exhausted', traceId: 'trace-def456-ghi789', count: 89, lastOccurred: '2024-12-10T14:25:00Z', service: 'billing-service', similarCount: 0, sparkline: '0,8 8,10 16,12 24,10 32,8 40,8', stackTrace: 'com.zaxxer.hikari.pool.HikariPool$PoolEntryCreator.call\n  at java.util.concurrent.FutureTask.run', metadata: { traceId: 'trace-def456', spanId: 'span-789', cluster: 'prod-us-east-1', pod: 'order-service-5c4d3b' }, attReasoning: { rca: 'Connection pool size too small for current load.', suggestedFix: 'Increase pool size from 10 to 25 and add connection timeout.', impact: 'Medium - causes 5% of requests to fail.' } },
  { id: 3, sMsg: 'IllegalArgumentException: Invalid currency code', traceId: 'trace-ghi789-jkl012', count: 45, lastOccurred: '2024-12-10T14:20:00Z', service: 'billing-service', similarCount: 2, sparkline: '0,3 8,4 16,5 24,4 32,5 40,4', stackTrace: 'java.lang.IllegalArgumentException: Invalid currency code: XYZ\n  at com.acme.billing.CurrencyValidator.validate', metadata: { traceId: 'trace-ghi789', spanId: 'span-012', cluster: 'prod-eu-west-1', pod: 'billing-service-8e7f6a' }, attReasoning: { rca: 'Input validation missing for currency codes from external API.', suggestedFix: 'Add whitelist validation for ISO 4217 currency codes.', impact: 'Low - affects edge cases only.' } },
  { id: 4, sMsg: 'OutOfMemoryError: Java heap space', traceId: 'trace-mno345-pqr678', count: 12, lastOccurred: '2024-12-10T13:00:00Z', service: 'order-service', similarCount: 0, sparkline: '0,2 8,2 16,3 24,2 32,2 40,1', stackTrace: 'java.lang.OutOfMemoryError: Java heap space', metadata: { traceId: 'trace-mno345', cluster: 'prod-us-east-1' }, attReasoning: { rca: 'Memory leak in order caching mechanism.', suggestedFix: 'Implement LRU cache with max size limit.', impact: 'High - service crashes under load.' } }
])

const filteredErrors = computed(() => errors.value)

const groupedErrors = computed(() => {
  const groups = {}
  errors.value.forEach(err => {
    if (!groups[err.service]) {
      groups[err.service] = { service: err.service, errors: [], totalCount: 0, expanded: true }
    }
    groups[err.service].errors.push(err)
    groups[err.service].totalCount += err.count
  })
  return Object.values(groups)
})

const agentTasks = [
  { id: 'rca', label: 'Root Cause Analysis' },
  { id: 'plan', label: 'Generate Implementation Plan' },
  { id: 'pr', label: 'Create Pull Request' },
  { id: 'tests', label: 'Generate Unit Tests' },
  { id: 'merge', label: 'Auto-merge PR' },
  { id: 'close', label: 'Close Issue' }
]

const showErrors = () => { /* API call */ }
const formatDate = (date) => new Date(date).toLocaleString()
const getCountColor = (count) => count > 100 ? 'error' : count > 50 ? 'warning' : 'success'
const getErrorById = (id) => errors.value.find(e => e.id === id)

const openDialog = (type, error) => {
  selectedError.value = error
  dialogs.value[type] = true
}

const openAssignDialog = (error) => {
  selectedError.value = error
  selectedTasks.value = []
  dialogs.value.assignAgent = true
}

const assignAgent = () => {
  dialogs.value.assignAgent = false
  toast?.success('Agent Assigned', `Agent assigned to error #${selectedError.value?.id}`)
  router.push({ path: '/agent-view', query: { errorId: selectedError.value?.id, tasks: selectedTasks.value.join(',') } })
}

const navigateToTrace = (traceId) => {
  router.push({ path: '/trace-lookup', query: { traceId: traceId, autoSearch: 'true' } })
}

const copyTraceId = (traceId) => {
  navigator.clipboard.writeText(traceId)
  toast?.success('Copied', 'Trace ID copied to clipboard')
}

const toggleSelectAll = (val) => {
  selectedErrors.value = val ? errors.value.map(e => e.id) : []
}

const bulkAssignAgent = () => {
  toast?.info('Bulk Action', `Assigning agent to ${selectedErrors.value.length} errors`)
  dialogs.value.assignAgent = true
}

const bulkMarkResolved = () => {
  toast?.success('Marked Resolved', `${selectedErrors.value.length} errors marked as resolved`)
  selectedErrors.value = []
}

const compareErrors = () => {
  dialogs.value.compare = true
}

const bulkExport = () => {
  const data = errors.value.filter(e => selectedErrors.value.includes(e.id))
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
  saveAs(blob, 'selected-errors.json')
  toast?.success('Exported', `${selectedErrors.value.length} errors exported`)
}

const watchError = (error) => {
  selectedError.value = error
  dialogs.value.watch = true
}

const confirmWatch = () => {
  dialogs.value.watch = false
  toast?.success('Watching', `You'll be notified about error #${selectedError.value?.id}`)
}

const addNote = (error) => {
  toast?.info('Add Note', 'Note feature coming soon')
}

const showSimilar = (error) => {
  toast?.info('Similar Errors', `Showing ${error.similarCount} similar errors`)
}

const exportJSON = () => {
  const data = JSON.stringify(filteredErrors.value, null, 2)
  const blob = new Blob([data], { type: 'application/json' })
  saveAs(blob, 'errors.json')
  toast?.success('Exported', 'Errors exported as JSON')
}

const exportExcel = () => {
  const ws = XLSX.utils.json_to_sheet(filteredErrors.value.map(e => ({
    'Error Message': e.sMsg,
    'Trace ID': e.traceId,
    'Count': e.count,
    'Service': e.service,
    'Last Occurred': e.lastOccurred
  })))
  const wb = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(wb, ws, 'Errors')
  XLSX.writeFile(wb, 'errors.xlsx')
  toast?.success('Exported', 'Errors exported as Excel')
}
</script>

<style scoped>
.page-header { text-align: center; padding: 20px 0; }
.page-title { font-size: 1.5rem; font-weight: 700; color: #1a1a1a; margin-bottom: 8px; }
.page-subtitle { font-size: 0.9rem; color: #666666; }

.stat-card { display: flex; flex-direction: column; gap: 8px; position: relative; }
.stat-icon { width: 40px; height: 40px; border-radius: 8px; display: flex; align-items: center; justify-content: center; background: #f5f5f5; color: #1a1a1a; }
.stat-content { display: flex; flex-direction: column; gap: 2px; }
.stat-value { font-size: 1.35rem; font-weight: 700; color: #1a1a1a; }
.stat-label { font-size: 0.75rem; color: #666666; }
.stat-sparkline { height: 20px; }
.sparkline { width: 100%; height: 100%; }

.bulk-actions-bar { display: flex; align-items: center; justify-content: space-between; }
.bulk-info { display: flex; align-items: center; gap: 8px; font-size: 0.9rem; color: #1a1a1a; }
.bulk-buttons { display: flex; gap: 8px; }

.table-toolbar { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; }
.search-field { max-width: 300px; }
.rows-select { max-width: 120px; }
.table-footer { display: flex; justify-content: flex-end; padding: 16px; }

.error-table { background: transparent !important; }
.error-msg-cell { display: flex; flex-direction: column; gap: 4px; }
.error-msg { max-width: 350px; }
.error-msg code { font-size: 0.75rem; color: #1a1a1a; background: #f5f5f5; padding: 4px 8px; border-radius: 4px; word-break: break-word; }
.trace-cell { display: flex; align-items: center; gap: 4px; }
.trace-link { color: #6366f1; text-decoration: none; font-family: monospace; font-size: 0.8rem; }
.trace-link:hover { text-decoration: underline; }
.count-cell { display: flex; align-items: center; gap: 8px; }
.count-sparkline { width: 40px; height: 16px; }
.timestamp { font-size: 0.8rem; color: #666666; }
.insights-actions { display: flex; gap: 2px; }

.grouped-view { display: flex; flex-direction: column; gap: 8px; }
.error-group { background: #f5f5f5; border-radius: 8px; overflow: hidden; }
.group-header { display: flex; align-items: center; gap: 12px; padding: 12px 16px; cursor: pointer; }
.group-header:hover { background: #e5e5e5; }
.group-name { font-weight: 600; color: #1a1a1a; }
.group-total { font-size: 0.8rem; color: #666666; margin-left: auto; }
.group-content { padding: 8px 16px; }
.group-error-item { display: flex; align-items: center; gap: 12px; padding: 8px; border-radius: 4px; cursor: pointer; }
.group-error-item:hover { background: #e5e5e5; }
.error-msg-short { flex: 1; font-size: 0.85rem; color: #1a1a1a; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

.expanded-row { background: #f5f5f5 !important; }
.expanded-content { display: flex; gap: 24px; padding: 16px; }
.expanded-section { flex: 1; }
.expanded-section h4 { font-size: 0.85rem; font-weight: 600; color: #1a1a1a; margin-bottom: 8px; }
.expanded-section pre { font-size: 0.75rem; color: #666666; background: #ffffff; padding: 8px; border-radius: 4px; }
.quick-actions { display: flex; gap: 8px; }

.dialog-card { background: #ffffff !important; }
.dialog-title { display: flex; align-items: center; background: #f5f5f5; padding: 16px 20px !important; color: #1a1a1a; font-size: 1rem; }
.stack-trace-content { background: #1a1a1a; padding: 16px; border-radius: 8px; font-family: monospace; font-size: 0.75rem; color: #e5e5e5; overflow-x: auto; white-space: pre-wrap; max-height: 400px; }
.metadata-list { background: transparent !important; }
.att-content { display: flex; flex-direction: column; gap: 20px; }
.att-section h4 { font-size: 0.9rem; color: #1a1a1a; margin-bottom: 8px; display: flex; align-items: center; }
.att-section p { color: #666666; line-height: 1.6; padding-left: 28px; margin: 0; }

.compare-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 16px; }
.compare-column { background: #f5f5f5; border-radius: 8px; padding: 16px; }
.compare-header { font-weight: 600; color: #1a1a1a; margin-bottom: 12px; padding-bottom: 8px; border-bottom: 1px solid #e5e5e5; }
.compare-field { margin-bottom: 12px; }
.compare-field label { font-size: 0.75rem; color: #666666; display: block; margin-bottom: 4px; }
.compare-field code { font-size: 0.8rem; color: #1a1a1a; }
.compare-field pre { font-size: 0.7rem; color: #666666; background: #ffffff; padding: 8px; border-radius: 4px; max-height: 150px; overflow: auto; }
</style>
