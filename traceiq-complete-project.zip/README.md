# TraceIQ - AI-Powered Root Cause Analysis Platform

## Overview
TraceIQ is an enterprise-grade RCA platform that reduces defect triage time from 3-4 hours to <30 minutes through intelligent orchestration of observability data, AI analysis, and automated code location.

## Features
- **Intelligent Trace Analysis**: Automated error detection and log aggregation from ELK
- **AI-Powered RCA**: Context-aware root cause analysis using internal GPT-4 LLM
- **Code Location**: Vectorized codebase search to pinpoint problematic code
- **Multi-System Integration**: Jira, GitHub, Dynatrace, Jenkins, Kubernetes
- **Workflow Orchestration**: LangGraph4j-based conditional execution
- **Smart AI Optimization**: AI calls only when needed (not for simple queries)

## Architecture
- **Backend**: Java 17 + Spring Boot 3.2 + Spring AI + LangGraph4j
- **Frontend**: Vue.js 3 + Pinia + Axios
- **Database**: PostgreSQL with pgvector
- **Orchestration**: LangGraph4j state-based workflows

## Quick Start

### Prerequisites
- Java 17+
- Maven 3.8+
- Node.js 18+
- PostgreSQL 15+
- Access to internal LLM APIs

### Backend Setup
```bash
cd traceiq-backend
mvn clean install
mvn spring-boot:run
```

### Frontend Setup
```bash
cd traceiq-frontend
npm install
npm run dev
```

### Environment Variables
Copy `.env.example` to `.env` and configure:
- INTERNAL_LLM_BASE_URL
- INTERNAL_LLM_API_KEY
- JIRA_BASE_URL, JIRA_API_TOKEN
- ELK_BASE_URL, ELK_USERNAME, ELK_PASSWORD
- GITHUB_API_TOKEN
- DYNATRACE_BASE_URL, DYNATRACE_API_TOKEN
- JENKINS_BASE_URL, JENKINS_API_TOKEN
- K8S_BASE_URL, K8S_API_TOKEN
- CODE_SEARCH_LLM_URL, CODE_SEARCH_API_KEY

## Usage

### Trace Analysis
1. Enter TraceID in the search bar
2. System fetches ELK logs automatically
3. AI analyzes errors (if detected)
4. View RCA summary, code location, and fix suggestions
5. Create Jira ticket with one click

### ELK Query Features
- Get all logs (info/error/warn) for traceID
- Performance/latency analysis
- Service flow visualization
- Error grouping by message
- Log pattern verification

## Project Structure
See [ARCHITECTURE.md](ARCHITECTURE.md) for detailed architecture documentation.

## Deployment
See [DEPLOYMENT.md](DEPLOYMENT.md) for Kubernetes deployment guide.

## Contributing
This is an internal AT&T project. Contact the Order Graph team for contribution guidelines.

## License
Internal AT&T Use Only
