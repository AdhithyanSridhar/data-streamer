package com.att.traceiq.model;

import java.time.LocalDateTime;

public record ELKLog(
    String timestamp,
    String level,
    String message,
    String logger,
    String serviceName,
    String traceId,
    String spanId,
    String threadName
) {
    public boolean isError() {
        return "ERROR".equalsIgnoreCase(level);
    }

    public boolean isWarning() {
        return "WARN".equalsIgnoreCase(level) || "WARNING".equalsIgnoreCase(level);
    }

    public boolean isInfo() {
        return "INFO".equalsIgnoreCase(level);
    }
}
