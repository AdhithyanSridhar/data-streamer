package com.example.demo.graph;

import com.example.demo.tools.InternalLLMTool;
import org.springframework.stereotype.Component;

@Component
public class GetInternalLLMSuggestionsNode implements Node {

    public static final String NAME = "getInternalLLMSuggestions";
    private final InternalLLMTool internalLLMTool;

    public GetInternalLLMSuggestionsNode(InternalLLMTool internalLLMTool) {
        this.internalLLMTool = internalLLMTool;
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public GraphState apply(GraphState state) {
        try {
            String traceId = state.get("traceId");
            InternalLLMTool.InternalLLMRequest request = new InternalLLMTool.InternalLLMRequest(traceId, state.toJson());
            InternalLLMTool.InternalLLMResponse response = internalLLMTool.getSuggestions(request);
            state.set("internalSuggestions", response.suggestions());
        } catch (Exception e) {
            state.set(NAME + "_error", "Failed to get internal LLM suggestions: " + e.getMessage());
        }
        return state;
    }
}
