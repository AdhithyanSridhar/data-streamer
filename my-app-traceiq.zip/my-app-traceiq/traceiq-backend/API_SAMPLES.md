# TraceIQ API Samples

## Trace Search

### Request
```bash
curl -X GET http://localhost:8080/api/trace/TRACE-001 \
  -H "Content-Type: application/json"
```

### Response
```json
{
  "traceId": "TRACE-001",
  "confidenceScore": 0.92,
  "errorCount": 2,
  "errors": [
    {
      "traceId": "TRACE-001",
      "message": "NullPointerException in PaymentService.processPayment()",
      "level": "ERROR",
      "serviceName": "payment-service",
      "microserviceTeam": "payments-team",
      "ownerEmail": "payments-team@example.com",
      "timestamp": "2024-01-15T10:30:45.123Z",
      "environment": "production",
      "stackTrace": "java.lang.NullPointerException\\n    at com.example.payment.PaymentService.processPayment(PaymentService.java:145)",
      "additionalFields": {
        "user_id": "12345",
        "amount": "100.00"
      },
      "tags": ["payment", "error", "production"]
    }
  ],
  "servicesInvolved": [
    {
      "serviceName": "api-gateway",
      "serviceType": "gateway",
      "errorCount": 0,
      "latencyMs": 45.2,
      "status": "healthy"
    },
    {
      "serviceName": "payment-service",
      "serviceType": "microservice",
      "errorCount": 2,
      "latencyMs": 234.5,
      "status": "degraded"
    }
  ],
  "timeline": {
    "traceId": "TRACE-001",
    "events": [
      {
        "timestamp": "2024-01-15T10:30:45.123Z",
        "serviceName": "payment-service",
        "eventType": "ERROR",
        "description": "NullPointerException in PaymentService",
        "severity": "ERROR"
      }
    ]
  },
  "flowDiagram": {
    "nodes": [
      {
        "id": "gw",
        "serviceName": "api-gateway",
        "type": "gateway",
        "errorCount": 0
      },
      {
        "id": "ps",
        "serviceName": "payment-service",
        "type": "service",
        "errorCount": 2
      }
    ],
    "edges": [
      {
        "from": "gw",
        "to": "ps",
        "protocol": "http",
        "status": "error"
      }
    ]
  },
  "status": "success"
}
```

## Generate RCA

### Request
```bash
curl -X POST http://localhost:8080/api/trace/TRACE-001/rca \
  -H "Content-Type: application/json" \
  -d '{
    "traceId": "TRACE-001",
    "forceRefresh": false,
    "enableAI": true,
    "llmModel": "gpt-4.1"
  }'
```

### Response
```json
{
  "rcaResult": {
    "traceId": "TRACE-001",
    "rootCause": "NullPointerException due to missing configuration parameter",
    "analysisText": "The error occurs when PaymentService attempts to access a configuration value that is null. The configuration key 'payment.gateway.url' is not set in the environment, causing a null reference exception. This is a critical path in the payment processing flow, affecting all payment transactions.",
    "confidenceScore": 0.89,
    "contributingFactors": [
      "Missing environment variable 'PAYMENT_GATEWAY_URL'",
      "No default fallback value configured",
      "Lack of null checks in configuration access"
    ],
    "affectedServices": ["payment-service"],
    "severity": "HIGH",
    "analyzedAt": "2024-01-15T10:35:00.000Z",
    "llmModel": "gpt-4.1",
    "tokensUsed": 1250
  },
  "fromCache": false,
  "status": "success",
  "message": "RCA generated successfully"
}
```

## Generate Implementation Plan

### Request
```bash
curl -X POST http://localhost:8080/api/trace/TRACE-001/implementation-plan \
  -H "Content-Type: application/json" \
  -d '{
    "traceId": "TRACE-001",
    "enableAI": true
  }'
```

### Response
```json
{
  "implementationPlan": {
    "traceId": "TRACE-001",
    "planSummary": "Add defensive null checks and proper configuration validation in PaymentService. Implement fallback mechanisms and comprehensive error handling.",
    "codeLocations": [
      {
        "filePath": "src/main/java/com/example/payment/PaymentService.java",
        "repository": "payment-service",
        "startLine": 145,
        "endLine": 160,
        "codeSnippet": "public void processPayment(PaymentRequest request) {\\n    String gatewayUrl = getConfig();\\n    // Missing null check\\n    processWithGateway(gatewayUrl, request);\\n}",
        "issueDescription": "Missing null pointer check for configuration value",
        "relevanceScore": 0.95
      }
    ],
    "implementationSteps": [
      {
        "stepNumber": 1,
        "description": "Fix issue in PaymentService.java",
        "actionType": "MODIFY",
        "filesToModify": ["src/main/java/com/example/payment/PaymentService.java"],
        "suggestedChange": "Missing null pointer check for configuration value",
        "copilotPrompt": "Add null check before using configuration value"
      }
    ],
    "copilotPrompts": [
      "// COPILOT PROMPT - Use in IDE at PaymentService.java (line 145)\\n// Context: Fixing RCA issue - NullPointerException due to missing configuration\\n// Task: Add null check before using gatewayUrl\\n// Generate production-ready fix with proper error handling"
    ],
    "testingStrategy": "Add unit tests for null checks and configuration validation",
    "rollbackPlan": "Revert changes and ensure backward compatibility",
    "generatedAt": "2024-01-15T10:36:00.000Z",
    "codeSearchModel": "vector-llm-v1",
    "tokensUsed": 2100
  },
  "fromCache": false,
  "status": "success",
  "message": "Implementation plan generated successfully"
}
```

## God Mode

### Request
```bash
curl -X POST http://localhost:8080/api/trace/TRACE-001/god-mode \
  -H "Content-Type: application/json"
```

### Response
```json
{
  "rcaResult": {
    // ... same as RCA response
  },
  "implementationPlan": {
    // ... same as Implementation Plan response
  },
  "fromCache": false,
  "status": "success",
  "message": "God Mode analysis completed successfully"
}
```

## List Errors

### Request
```bash
curl -X GET "http://localhost:8080/api/errors?page=0&size=20" \
  -H "Content-Type: application/json"
```

### Response
```json
{
  "errors": [
    {
      "traceId": "TRACE-001",
      "message": "Sample error message 1",
      "serviceName": "service-1",
      "microserviceTeam": "team-1",
      "level": "ERROR",
      "timestamp": "2024-01-15T10:30:00.000Z",
      "count": 1
    }
  ],
  "totalCount": 10,
  "pageNumber": 0,
  "pageSize": 20,
  "status": "success"
}
```

## List Jobs

### Request
```bash
curl -X GET http://localhost:8080/api/jobs \
  -H "Content-Type: application/json"
```

### Response
```json
{
  "jobs": [
    {
      "jobId": "elk-ingest-job",
      "jobName": "ELK Nightly Ingest",
      "jobType": "SCHEDULED",
      "schedule": "0 0 2 * * ?",
      "status": "ACTIVE",
      "lastRunTime": "2024-01-15T02:00:00.000Z",
      "nextRunTime": "2024-01-16T02:00:00.000Z",
      "recentExecutions": [
        {
          "executionId": "exec-001",
          "startTime": "2024-01-15T02:00:00.000Z",
          "endTime": "2024-01-15T02:05:00.000Z",
          "status": "SUCCESS",
          "message": "Ingested 1523 records",
          "recordsProcessed": 1523,
          "errorCount": 0
        }
      ]
    }
  ],
  "status": "success"
}
```

## Health Check

### Request
```bash
curl -X GET http://localhost:8080/api/health
```

### Response
```json
{
  "status": "UP",
  "timestamp": "2024-01-15T10:40:00.000Z",
  "service": "traceiq-core"
}
```

