# TraceIQ Architecture

## System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                        TraceIQ System                            │
│                                                                   │
│  ┌────────────┐         ┌─────────────┐                         │
│  │  Vue.js    │────────▶│ Spring Boot │                         │
│  │  Frontend  │         │   Backend   │                         │
│  │  (Port     │◀────────│  (Port      │                         │
│  │   3000)    │         │   8080)     │                         │
│  └────────────┘         └──────┬──────┘                         │
│                                │                                  │
│                                │                                  │
│                  ┌─────────────┴─────────────┐                  │
│                  │   LangGraph4j Orchestration│                  │
│                  │   (RCA Flow & Plan Flow)  │                  │
│                  └─────────────┬─────────────┘                  │
│                                │                                  │
│           ┌────────────────────┼────────────────────┐           │
│           │                    │                    │           │
│           ▼                    ▼                    ▼           │
│    ┌──────────┐        ┌──────────┐        ┌──────────┐       │
│    │   ELK    │        │   LLM    │        │  Vector  │       │
│    │ Adapter  │        │ Adapter  │        │  Search  │       │
│    └────┬─────┘        └────┬─────┘        └────┬─────┘       │
│         │                   │                    │              │
│         ▼                   ▼                    ▼              │
│  ┌───────────┐       ┌───────────┐      ┌───────────┐         │
│  │    ELK    │       │  Internal │      │  Internal │         │
│  │   /Kibana │       │  GPT 4.1  │      │ Code LLM  │         │
│  └───────────┘       └───────────┘      └───────────┘         │
│                                                                  │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐      │
│  │  Jira    │  │Dynatrace │  │  GitHub  │  │ Jenkins  │      │
│  │ Adapter  │  │ Adapter  │  │ Adapter  │  │ Adapter  │      │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘      │
│       │             │             │             │              │
│       ▼             ▼             ▼             ▼              │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐          │
│  │  Jira   │  │Dynatrace│  │ GitHub  │  │ Jenkins │          │
│  │   API   │  │   API   │  │   API   │  │   API   │          │
│  └─────────┘  └─────────┘  └─────────┘  └─────────┘          │
│                                                                  │
│           ┌──────────────────────────────────┐                 │
│           │      Cassandra Database          │                 │
│           │  (Stores ingested error logs)    │                 │
│           └──────────────────────────────────┘                 │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Component Details

### Frontend (Vue.js)
- **Port**: 3000
- **Screens**: TraceSearch, ErrorsList, Jobs, Help
- **State Management**: Pinia
- **HTTP Client**: Axios
- **Styling**: TailwindCSS

### Backend (Spring Boot)
- **Port**: 8080
- **API**: REST with OpenAPI/Swagger docs
- **Orchestration**: LangGraph4j-based workflows
- **Database**: Cassandra (with mock mode)

### LangGraph4j Flows

#### RCA Flow
1. **ElkNode** → Fetch logs by traceID
2. **DynatraceNode** → Enrich with metrics
3. **RcaLLMNode** → Call LLM for analysis
4. **NotifyNode** → Tag owner

#### Implementation Plan Flow
1. Get RCA context
2. **CodeSearchNode** → Vector search
3. **CodeLLMNode** → Generate plan + Copilot prompts

### External Integrations
- **ELK**: Error log retrieval
- **Jira**: Ticket creation/retrieval
- **Dynatrace**: APM metrics and traces
- **GitHub**: Repository integration
- **Jenkins**: Build/job status
- **Kubernetes**: Pod/service information

## Data Flow

### Trace Search Flow
```
User → Frontend → GET /api/trace/{traceId}
         ↓
    TraceService → CassandraRepository
         ↓           (or ElkAdapter fallback)
    TraceSearchResponse → Frontend
```

### RCA Generation Flow
```
User → Frontend → POST /api/trace/{traceId}/rca
         ↓
    TraceService → RCAOrchestrator
         ↓
    [ElkNode] → Fetch logs
         ↓
    [DynatraceNode] → Enrich metrics
         ↓
    [RcaLLMNode] → LLM API call
         ↓
    RCAResult → Frontend
```

### God Mode Flow
```
User → Frontend → POST /api/trace/{traceId}/god-mode
         ↓
    TraceService → RCAOrchestrator
         ↓
    [Complete RCA Flow]
         ↓
    [CodeSearchNode] → Vector search
         ↓
    [CodeLLMNode] → Generate plan
         ↓
    RCAResult + ImplementationPlan → Frontend
```

## Deployment Architecture

### Development
```
localhost:3000 (Frontend) → localhost:8080 (Backend) → Mock Data
```

### Production
```
Load Balancer
     │
     ├─▶ Nginx (Frontend) :80
     │         ↓
     ├─▶ K8s Pods (Backend) :8080
             ↓
     ELK, Cassandra, LLM APIs
```

## Security

- All API tokens stored as environment variables
- No hardcoded secrets
- Bearer token authentication for LLM APIs
- Basic auth for Jenkins/Jira
- K8s service accounts for cluster access

## Scalability

- Stateless backend (can scale horizontally)
- Cassandra for distributed storage
- LLM calls with configurable rate limiting
- Async job processing for ingest (cron-based)

## Monitoring

- Spring Boot Actuator health endpoints
- Prometheus metrics exposure
- SLF4J logging to stdout/files
- Correlation IDs for tracing

