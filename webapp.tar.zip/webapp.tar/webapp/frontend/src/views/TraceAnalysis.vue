<template>
  <div>
    <!-- Header -->
    <div class="mb-8">
      <h1 class="text-3xl font-bold text-gray-900 mb-2">
        <i class="fas fa-microscope text-blue-600 mr-3"></i>
        Trace Analysis
      </h1>
      <p class="text-gray-600">Enter a trace ID or error details to get AI-powered insights</p>
    </div>

    <!-- Analysis Form -->
    <div class="bg-white rounded-lg shadow p-6 mb-8">
      <form @submit.prevent="performAnalysis">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <!-- Trace ID -->
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">
              Trace ID
            </label>
            <input
              v-model="analysisRequest.traceId"
              type="text"
              placeholder="e.g., 1234-5678-9012-3456"
              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <!-- Microservice Name -->
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">
              Microservice Name
            </label>
            <input
              v-model="analysisRequest.microserviceName"
              type="text"
              placeholder="e.g., user-service"
              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <!-- Environment -->
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">
              Environment *
            </label>
            <select
              v-model="analysisRequest.environment"
              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="test">Test</option>
              <option value="prod">Production</option>
            </select>
          </div>

          <!-- Priority -->
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">
              Priority
            </label>
            <select
              v-model="analysisRequest.priority"
              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="LOW">Low</option>
              <option value="MEDIUM">Medium</option>
              <option value="HIGH">High</option>
              <option value="CRITICAL">Critical</option>
            </select>
          </div>

          <!-- Time Range -->
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">
              Time Range (minutes)
            </label>
            <input
              v-model.number="analysisRequest.timeRangeMinutes"
              type="number"
              placeholder="60"
              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <!-- Auto Create Jira -->
          <div class="flex items-center">
            <input
              v-model="analysisRequest.autoCreateJiraTicket"
              type="checkbox"
              id="autoJira"
              class="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
            />
            <label for="autoJira" class="ml-2 text-sm font-medium text-gray-700">
              Auto-create Jira Ticket
            </label>
          </div>
        </div>

        <!-- Error Details (Optional) -->
        <div class="mt-6">
          <label class="block text-sm font-medium text-gray-700 mb-2">
            Error Details (Optional - if no Trace ID)
          </label>
          <textarea
            v-model="analysisRequest.errorDetails"
            rows="3"
            placeholder="Paste error message or stack trace..."
            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          ></textarea>
        </div>

        <!-- Submit Button -->
        <div class="mt-6 flex space-x-4">
          <button
            type="submit"
            :disabled="loading"
            class="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition disabled:bg-gray-400 disabled:cursor-not-allowed"
          >
            <i class="fas fa-play mr-2" v-if="!loading"></i>
            <i class="fas fa-spinner fa-spin mr-2" v-if="loading"></i>
            {{ loading ? 'Analyzing...' : 'Start Analysis' }}
          </button>
          <button
            type="button"
            @click="clearForm"
            class="bg-gray-200 text-gray-700 px-8 py-3 rounded-lg hover:bg-gray-300 transition"
          >
            Clear
          </button>
        </div>
      </form>
    </div>

    <!-- Analysis Results -->
    <div v-if="analysisResult" class="space-y-6">
      <!-- Summary Card -->
      <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-2xl font-semibold text-gray-900 mb-4">
          <i class="fas fa-file-alt text-blue-600 mr-2"></i>
          Analysis Summary
        </h2>
        <div class="bg-blue-50 border-l-4 border-blue-600 p-4 mb-4">
          <p class="text-gray-800">{{ analysisResult.summary }}</p>
        </div>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <p class="text-sm text-gray-600">Status</p>
            <p class="font-semibold" :class="statusColor(analysisResult.status)">
              {{ analysisResult.status }}
            </p>
          </div>
          <div>
            <p class="text-sm text-gray-600">Processing Time</p>
            <p class="font-semibold">{{ analysisResult.processingTimeMs }}ms</p>
          </div>
          <div>
            <p class="text-sm text-gray-600">Tools Invoked</p>
            <p class="font-semibold">{{ analysisResult.toolsInvoked?.length || 0 }}</p>
          </div>
          <div>
            <p class="text-sm text-gray-600">Analysis ID</p>
            <p class="font-semibold text-xs">{{ analysisResult.analysisId }}</p>
          </div>
        </div>
      </div>

      <!-- Root Cause Analysis -->
      <div v-if="analysisResult.rootCause" class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-semibold text-gray-900 mb-4">
          <i class="fas fa-bullseye text-red-600 mr-2"></i>
          Root Cause Analysis
        </h2>
        <div class="space-y-3">
          <div>
            <span class="text-sm font-medium text-gray-600">Category:</span>
            <span class="ml-2 px-3 py-1 bg-red-100 text-red-800 rounded text-sm">
              {{ analysisResult.rootCause.category }}
            </span>
          </div>
          <div>
            <span class="text-sm font-medium text-gray-600">Description:</span>
            <p class="mt-1 text-gray-800">{{ analysisResult.rootCause.description }}</p>
          </div>
          <div>
            <span class="text-sm font-medium text-gray-600">Root Cause:</span>
            <p class="mt-1 text-gray-800 font-medium">{{ analysisResult.rootCause.rootCause }}</p>
          </div>
          <div>
            <span class="text-sm font-medium text-gray-600">Confidence:</span>
            <span class="ml-2 px-3 py-1 bg-green-100 text-green-800 rounded text-sm">
              {{ analysisResult.rootCause.confidence }}
            </span>
          </div>
        </div>
      </div>

      <!-- Code Location -->
      <div v-if="analysisResult.codeLocation" class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-semibold text-gray-900 mb-4">
          <i class="fas fa-code text-green-600 mr-2"></i>
          Code Location
        </h2>
        <div class="space-y-3">
          <div class="flex items-center space-x-4">
            <div>
              <span class="text-sm font-medium text-gray-600">Repository:</span>
              <span class="ml-2 font-mono text-sm">{{ analysisResult.codeLocation.repositoryName }}</span>
            </div>
            <div>
              <span class="text-sm font-medium text-gray-600">Line:</span>
              <span class="ml-2 font-mono text-sm">{{ analysisResult.codeLocation.lineNumber }}</span>
            </div>
          </div>
          <div>
            <span class="text-sm font-medium text-gray-600">File Path:</span>
            <p class="font-mono text-sm mt-1 bg-gray-100 p-2 rounded">
              {{ analysisResult.codeLocation.filePath }}
            </p>
          </div>
          <div>
            <span class="text-sm font-medium text-gray-600">Suggested Fix:</span>
            <p class="mt-1 text-gray-800">{{ analysisResult.codeLocation.suggestedFix }}</p>
          </div>
        </div>
      </div>

      <!-- ELK Analysis -->
      <div v-if="analysisResult.elkAnalysis" class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-semibold text-gray-900 mb-4">
          <i class="fas fa-database text-purple-600 mr-2"></i>
          Log Analysis
        </h2>
        <div class="grid grid-cols-3 gap-4 mb-4">
          <div class="bg-red-50 p-4 rounded">
            <p class="text-sm text-gray-600">Errors</p>
            <p class="text-2xl font-bold text-red-600">{{ analysisResult.elkAnalysis.errorCount }}</p>
          </div>
          <div class="bg-yellow-50 p-4 rounded">
            <p class="text-sm text-gray-600">Warnings</p>
            <p class="text-2xl font-bold text-yellow-600">{{ analysisResult.elkAnalysis.warnCount }}</p>
          </div>
          <div class="bg-blue-50 p-4 rounded">
            <p class="text-sm text-gray-600">Info</p>
            <p class="text-2xl font-bold text-blue-600">{{ analysisResult.elkAnalysis.infoCount }}</p>
          </div>
        </div>
        <div v-if="analysisResult.elkAnalysis.flowDiagram" class="mt-4">
          <span class="text-sm font-medium text-gray-600">Service Flow:</span>
          <p class="mt-1 text-gray-800">{{ analysisResult.elkAnalysis.flowDiagram.join(' → ') }}</p>
        </div>
      </div>

      <!-- Recommended Actions -->
      <div v-if="analysisResult.recommendedActions" class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-semibold text-gray-900 mb-4">
          <i class="fas fa-lightbulb text-yellow-600 mr-2"></i>
          Recommended Actions
        </h2>
        <ul class="space-y-2">
          <li v-for="(action, index) in analysisResult.recommendedActions" :key="index" class="flex items-start">
            <i class="fas fa-check-circle text-green-600 mt-1 mr-3"></i>
            <span class="text-gray-800">{{ action }}</span>
          </li>
        </ul>
      </div>

      <!-- Jira Ticket -->
      <div v-if="analysisResult.jiraTicket" class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-semibold text-gray-900 mb-4">
          <i class="fas fa-ticket-alt text-blue-600 mr-2"></i>
          Jira Ticket Created
        </h2>
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm text-gray-600">Ticket Key</p>
            <p class="font-semibold text-lg">{{ analysisResult.jiraTicket.ticketKey }}</p>
          </div>
          <a :href="analysisResult.jiraTicket.ticketUrl" target="_blank" 
             class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
            View in Jira <i class="fas fa-external-link-alt ml-2"></i>
          </a>
        </div>
      </div>
    </div>

    <!-- Error Display -->
    <div v-if="error" class="bg-red-50 border-l-4 border-red-600 p-4 rounded">
      <div class="flex">
        <i class="fas fa-exclamation-circle text-red-600 mt-1 mr-3"></i>
        <div>
          <h3 class="text-red-800 font-semibold">Analysis Error</h3>
          <p class="text-red-700">{{ error }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { analysisApi } from '../services/api'

const loading = ref(false)
const error = ref(null)
const analysisResult = ref(null)

const analysisRequest = reactive({
  traceId: '',
  microserviceName: '',
  environment: 'test',
  timeRangeMinutes: 60,
  autoCreateJiraTicket: false,
  errorDetails: '',
  priority: 'MEDIUM'
})

const performAnalysis = async () => {
  loading.value = true
  error.value = null
  analysisResult.value = null

  try {
    const response = await analysisApi.analyzeTrace(analysisRequest)
    analysisResult.value = response
  } catch (err) {
    error.value = err.response?.data?.message || 'Failed to perform analysis'
  } finally {
    loading.value = false
  }
}

const clearForm = () => {
  analysisRequest.traceId = ''
  analysisRequest.microserviceName = ''
  analysisRequest.errorDetails = ''
  analysisRequest.timeRangeMinutes = 60
  analysisRequest.autoCreateJiraTicket = false
  analysisRequest.priority = 'MEDIUM'
  analysisResult.value = null
  error.value = null
}

const statusColor = (status) => {
  return status === 'SUCCESS' ? 'text-green-600' : 
         status === 'FAILED' ? 'text-red-600' : 
         'text-yellow-600'
}
</script>
