package com.traceiq.core.controller;

import com.traceiq.ingest.repository.CassandraRepository;
import com.traceiq.ingest.service.IngestService;
import com.traceiq.models.domain.JobRun;
import com.traceiq.models.dto.JobListResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/jobs")
@Tag(name = "Jobs API", description = "Job management and execution")
public class JobsController {

    private final CassandraRepository cassandraRepository;
    private final IngestService ingestService;

    public JobsController(CassandraRepository cassandraRepository, IngestService ingestService) {
        this.cassandraRepository = cassandraRepository;
        this.ingestService = ingestService;
    }

    @GetMapping
    @Operation(summary = "List all job runs")
    public ResponseEntity<JobListResponse> getAllJobs() {
        List<JobRun> jobs = cassandraRepository.getAllJobRuns();
        
        JobListResponse response = JobListResponse.builder()
                .jobs(jobs)
                .totalCount(jobs.size())
                .build();

        return ResponseEntity.ok(response);
    }

    @PostMapping("/ingest/run")
    @Operation(summary = "Manually trigger ingest job")
    public ResponseEntity<JobRun> runIngestJob(@RequestParam(defaultValue = "now-24h") String timeRange) {
        JobRun jobRun = ingestService.ingestErrors(timeRange);
        return ResponseEntity.ok(jobRun);
    }
}
