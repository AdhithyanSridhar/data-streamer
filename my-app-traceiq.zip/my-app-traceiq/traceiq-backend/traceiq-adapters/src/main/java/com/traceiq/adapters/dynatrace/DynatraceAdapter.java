package com.traceiq.adapters.dynatrace;

import com.traceiq.adapters.config.AdapterConfiguration;
import com.traceiq.utils.RetryUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class DynatraceAdapter {
    private static final Logger logger = LoggerFactory.getLogger(DynatraceAdapter.class);
    private final RestTemplate restTemplate;
    private final AdapterConfiguration config;
    
    public DynatraceAdapter(RestTemplate restTemplate, AdapterConfiguration config) {
        this.restTemplate = restTemplate;
        this.config = config;
    }
    
    public String getTraceMetrics(String traceId) {
        return RetryUtils.executeWithRetry(() -> {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Api-Token " + config.getDynatraceApiToken());
            HttpEntity<Void> request = new HttpEntity<>(headers);
            
            logger.info("Fetching Dynatrace metrics for traceId: {}", traceId);
            ResponseEntity<String> response = restTemplate.exchange(
                config.getDynatraceApiUrl() + "/api/v2/traces/" + traceId,
                HttpMethod.GET,
                request,
                String.class
            );
            return response.getBody();
        }, "Dynatrace Get Trace Metrics");
    }
    
    public String getServiceFlow(String traceId) {
        logger.info("Getting service flow for trace: {}", traceId);
        return "{\"services\": [\"api-gateway\", \"payment-service\", \"notification-service\"]}";
    }
}
