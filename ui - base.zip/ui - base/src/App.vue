<template>
  <v-app>
    <!-- Top App Bar with Navigation -->
    <v-app-bar class="app-bar" elevation="0">
      <!-- Logo and Brand -->
      <div class="brand-section">
        <v-icon icon="mdi-brain" size="32" class="brand-icon"></v-icon>
        <div class="brand-text">
          <span class="brand-name">TraceIQ</span>
          <span class="brand-tagline">Trusted Insights</span>
        </div>
      </div>

      <v-divider vertical class="mx-4 my-3"></v-divider>

      <!-- Navigation Menu -->
      <div class="nav-menu">
        <v-btn
          v-for="item in navItems"
          :key="item.path"
          :to="item.path"
          variant="text"
          :class="{ 'nav-btn--active': $route.path === item.path }"
          class="nav-btn"
        >
          <v-icon :icon="item.icon" size="18" class="mr-1"></v-icon>
          {{ item.title }}
        </v-btn>
      </div>
      
      <v-spacer></v-spacer>
      
      <v-avatar size="36" class="user-avatar">
        <span class="text-caption font-weight-bold">AI</span>
      </v-avatar>
    </v-app-bar>

    <!-- Main Content -->
    <v-main class="main-content">
      <router-view v-slot="{ Component }">
        <transition name="fade" mode="out-in">
          <component :is="Component" />
        </transition>
      </router-view>
    </v-main>
  </v-app>
</template>

<script setup>
import { ref } from 'vue'
import { useRoute } from 'vue-router'

const route = useRoute()

const navItems = [
  { path: '/app-errors', title: 'App Errors', icon: 'mdi-alert-circle-outline' },
  { path: '/trace-lookup', title: 'Trace Lookup', icon: 'mdi-magnify' },
  { path: '/agent-view', title: 'Agent View', icon: 'mdi-robot-outline' },
  { path: '/batch-job', title: 'Batch Jobs', icon: 'mdi-calendar-clock-outline' },
  { path: '/batch-run', title: 'Batch Runs', icon: 'mdi-play-circle-outline' },
  { path: '/faq', title: 'FAQ', icon: 'mdi-help-circle-outline' },
  { path: '/feedback', title: 'Feedback', icon: 'mdi-message-outline' }
]
</script>

<style scoped>
.app-bar {
  background: #ffffff !important;
  border-bottom: 1px solid #e5e5e5;
}

.brand-section {
  display: flex;
  align-items: center;
  gap: 10px;
  padding-left: 16px;
}

.brand-icon {
  color: #1a1a1a;
}

.brand-text {
  display: flex;
  flex-direction: column;
  line-height: 1.2;
}

.brand-name {
  font-size: 1.25rem;
  font-weight: 700;
  color: #1a1a1a;
  letter-spacing: -0.02em;
}

.brand-tagline {
  font-size: 0.65rem;
  color: #666666;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.nav-menu {
  display: flex;
  gap: 4px;
}

.nav-btn {
  text-transform: none;
  font-weight: 500;
  font-size: 0.875rem;
  color: #666666;
  letter-spacing: 0;
  padding: 0 12px;
}

.nav-btn:hover {
  background: #f5f5f5 !important;
  color: #1a1a1a;
}

.nav-btn--active {
  background: #f0f0f0 !important;
  color: #1a1a1a !important;
}

.user-avatar {
  background: #1a1a1a;
  color: #ffffff;
  margin-right: 16px;
}

.main-content {
  background: #fafafa;
  min-height: 100vh;
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.2s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

@media (max-width: 1200px) {
  .nav-btn {
    padding: 0 8px;
    font-size: 0.8rem;
  }
}
</style>
