package com.example.demo.graph;

import com.example.demo.tools.JaegerTool;
import org.springframework.stereotype.Component;

@Component
public class CaptureMicroserviceFlow implements Node {

  public static final String NAME = "captureMicroserviceFlow";
  private final JaegerTool jaegerTool;

  public CaptureMicroserviceFlow(JaegerTool jaegerTool) {
    this.jaegerTool = jaegerTool;
  }

  @Override
  public String getName() {
    return NAME;
  }

  @Override
  public GraphState apply(GraphState state) {
    try {
      String traceId = state.get("traceId");
      JaegerTool.MicroserviceFlowResponse response =
          jaegerTool.captureMicroserviceFlow(new JaegerTool.MicroserviceFlowRequest(traceId));
      state.set("microserviceFlow", response.flow());
    } catch (Exception e) {
      state.set(NAME + "_error", "Failed to capture microservice flow: " + e.getMessage());
    }
    return state;
  }
}
