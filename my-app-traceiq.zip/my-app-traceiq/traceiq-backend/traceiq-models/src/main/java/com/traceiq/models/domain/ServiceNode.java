package com.traceiq.models.domain;

/**
 * Represents a service node in the trace flow diagram.
 */
public record ServiceNode(
    String serviceName,
    String serviceType,
    int errorCount,
    double latencyMs,
    String status
) {
    public static class Builder {
        private String serviceName;
        private String serviceType;
        private int errorCount;
        private double latencyMs;
        private String status;

        public Builder serviceName(String serviceName) {
            this.serviceName = serviceName;
            return this;
        }

        public Builder serviceType(String serviceType) {
            this.serviceType = serviceType;
            return this;
        }

        public Builder errorCount(int errorCount) {
            this.errorCount = errorCount;
            return this;
        }

        public Builder latencyMs(double latencyMs) {
            this.latencyMs = latencyMs;
            return this;
        }

        public Builder status(String status) {
            this.status = status;
            return this;
        }

        public ServiceNode build() {
            return new ServiceNode(serviceName, serviceType, errorCount, latencyMs, status);
        }
    }

    public static Builder builder() {
        return new Builder();
    }
}
