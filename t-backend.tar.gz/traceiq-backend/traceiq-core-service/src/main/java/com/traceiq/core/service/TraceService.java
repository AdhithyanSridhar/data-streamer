package com.traceiq.core.service;

import com.traceiq.core.orchestration.RcaGraphBuilder;
import com.traceiq.ingest.repository.CassandraRepository;
import com.traceiq.models.domain.ErrorRecord;
import com.traceiq.models.dto.TraceSearchResponse;
import com.traceiq.models.dto.graph.CodeSearchNodeOutput;
import com.traceiq.models.dto.graph.RcaNodeOutput;
import com.traceiq.utils.CorrelationIdUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class TraceService {
    private static final Logger logger = LoggerFactory.getLogger(TraceService.class);

    private final CassandraRepository cassandraRepository;
    private final RcaGraphBuilder rcaGraphBuilder;

    public TraceService(CassandraRepository cassandraRepository, RcaGraphBuilder rcaGraphBuilder) {
        this.cassandraRepository = cassandraRepository;
        this.rcaGraphBuilder = rcaGraphBuilder;
    }

    public TraceSearchResponse searchByTraceId(String traceId, boolean includeRca, boolean includeCodeSpot, boolean godMode) {
        String correlationId = CorrelationIdUtil.getOrGenerate();
        logger.info("[{}] Searching for trace: {}", correlationId, traceId);

        // Get errors from Cassandra
        List<ErrorRecord> errors = cassandraRepository.getErrorsByTraceId(traceId);
        
        // Calculate confidence score
        double confidenceScore = calculateConfidenceScore(errors);

        // Build timeline
        List<TraceSearchResponse.TimelineEvent> timeline = buildTimeline(errors);

        // Build flow diagram
        TraceSearchResponse.FlowDiagram flowDiagram = buildFlowDiagram(errors);

        TraceSearchResponse.RcaResult rcaResult = null;
        TraceSearchResponse.CodeSpotResult codeSpotResult = null;

        // Execute RCA flow if requested or in GodMode
        if (includeRca || godMode) {
            Map<String, Object> rcaContext = rcaGraphBuilder.executeRcaFlow(traceId, correlationId, includeCodeSpot || godMode);
            
            if (rcaContext.containsKey("rcaResult")) {
                RcaNodeOutput rcaOutput = (RcaNodeOutput) rcaContext.get("rcaResult");
                rcaResult = new TraceSearchResponse.RcaResult(
                        rcaOutput.rootCauseAnalysis(),
                        rcaOutput.rootCauseAnalysis(),
                        rcaOutput.impactedServices(),
                        rcaOutput.recommendations(),
                        "gpt-4.1",
                        rcaOutput.confidence()
                );
            }

            if ((includeCodeSpot || godMode) && rcaContext.containsKey("codeSearchResult")) {
                CodeSearchNodeOutput codeOutput = (CodeSearchNodeOutput) rcaContext.get("codeSearchResult");
                
                List<TraceSearchResponse.CodeLocation> locations = codeOutput.codeLocations().stream()
                        .map(loc -> new TraceSearchResponse.CodeLocation(
                                loc.repository(),
                                loc.filePath(),
                                loc.lineNumber(),
                                loc.snippet(),
                                loc.reason()
                        ))
                        .collect(Collectors.toList());

                codeSpotResult = new TraceSearchResponse.CodeSpotResult(
                        locations,
                        codeOutput.implementationPlan(),
                        List.of()
                );
            }
        }

        return TraceSearchResponse.builder()
                .traceId(traceId)
                .confidenceScore(confidenceScore)
                .errorCount(errors.size())
                .errors(errors)
                .timeline(timeline)
                .flowDiagram(flowDiagram)
                .rcaResult(rcaResult)
                .codeSpotResult(codeSpotResult)
                .build();
    }

    private double calculateConfidenceScore(List<ErrorRecord> errors) {
        if (errors.isEmpty()) return 0.0;
        return Math.min(0.5 + (errors.size() * 0.1), 1.0);
    }

    private List<TraceSearchResponse.TimelineEvent> buildTimeline(List<ErrorRecord> errors) {
        return errors.stream()
                .sorted(Comparator.comparing(ErrorRecord::timestamp))
                .map(error -> new TraceSearchResponse.TimelineEvent(
                        error.timestamp().toString(),
                        error.service(),
                        error.message(),
                        error.metadata()
                ))
                .collect(Collectors.toList());
    }

    private TraceSearchResponse.FlowDiagram buildFlowDiagram(List<ErrorRecord> errors) {
        Set<String> services = errors.stream()
                .map(ErrorRecord::service)
                .collect(Collectors.toSet());

        List<TraceSearchResponse.ServiceNode> nodes = services.stream()
                .map(service -> new TraceSearchResponse.ServiceNode(service, service, "service"))
                .collect(Collectors.toList());

        List<TraceSearchResponse.ServiceEdge> edges = new ArrayList<>();
        List<String> serviceList = new ArrayList<>(services);
        for (int i = 0; i < serviceList.size() - 1; i++) {
            edges.add(new TraceSearchResponse.ServiceEdge(
                    serviceList.get(i),
                    serviceList.get(i + 1),
                    "calls"
            ));
        }

        return new TraceSearchResponse.FlowDiagram(nodes, edges);
    }
}
