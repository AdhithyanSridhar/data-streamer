<template>
  <Teleport to="body">
    <div class="toast-container">
      <TransitionGroup name="toast">
        <div
          v-for="toast in toasts"
          :key="toast.id"
          class="toast"
          :class="`toast--${toast.type}`"
        >
          <v-icon :icon="getIcon(toast.type)" size="20" class="toast-icon"></v-icon>
          <div class="toast-content">
            <span class="toast-title">{{ toast.title }}</span>
            <span class="toast-message" v-if="toast.message">{{ toast.message }}</span>
          </div>
          <v-btn icon variant="text" size="x-small" @click="removeToast(toast.id)">
            <v-icon icon="mdi-close" size="16"></v-icon>
          </v-btn>
        </div>
      </TransitionGroup>
    </div>
  </Teleport>
</template>

<script setup>
import { ref } from 'vue'

const toasts = ref([])
let toastId = 0

const getIcon = (type) => {
  const icons = {
    success: 'mdi-check-circle-outline',
    error: 'mdi-alert-circle-outline',
    warning: 'mdi-alert-outline',
    info: 'mdi-information-outline'
  }
  return icons[type] || icons.info
}

const addToast = (options) => {
  const toast = {
    id: ++toastId,
    type: options.type || 'info',
    title: options.title,
    message: options.message,
    duration: options.duration || 4000
  }
  toasts.value.push(toast)
  
  if (toast.duration > 0) {
    setTimeout(() => removeToast(toast.id), toast.duration)
  }
  
  return toast.id
}

const removeToast = (id) => {
  const idx = toasts.value.findIndex(t => t.id === id)
  if (idx > -1) toasts.value.splice(idx, 1)
}

// Expose methods globally
defineExpose({ addToast, removeToast })
</script>

<style scoped>
.toast-container {
  position: fixed;
  bottom: 24px;
  right: 24px;
  z-index: 9999;
  display: flex;
  flex-direction: column;
  gap: 8px;
  max-width: 400px;
}

.toast {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  padding: 14px 16px;
  background: #ffffff;
  border-radius: 10px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
  border-left: 4px solid;
}

.toast--success {
  border-color: #10b981;
}

.toast--error {
  border-color: #ef4444;
}

.toast--warning {
  border-color: #f59e0b;
}

.toast--info {
  border-color: #3b82f6;
}

.toast-icon {
  flex-shrink: 0;
  margin-top: 2px;
}

.toast--success .toast-icon { color: #10b981; }
.toast--error .toast-icon { color: #ef4444; }
.toast--warning .toast-icon { color: #f59e0b; }
.toast--info .toast-icon { color: #3b82f6; }

.toast-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.toast-title {
  font-size: 0.9rem;
  font-weight: 600;
  color: #1a1a1a;
}

.toast-message {
  font-size: 0.8rem;
  color: #666666;
}

/* Transitions */
.toast-enter-active {
  animation: slideIn 0.3s ease;
}

.toast-leave-active {
  animation: slideOut 0.3s ease;
}

@keyframes slideIn {
  from {
    transform: translateX(100%);
    opacity: 0;
  }
  to {
    transform: translateX(0);
    opacity: 1;
  }
}

@keyframes slideOut {
  from {
    transform: translateX(0);
    opacity: 1;
  }
  to {
    transform: translateX(100%);
    opacity: 0;
  }
}
</style>
