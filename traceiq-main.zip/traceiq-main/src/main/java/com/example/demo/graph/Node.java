package com.example.demo.graph;

/**
 * Represents a single node in the diagnostic graph. Each node performs a specific action and
 * updates the graph's state.
 */
public interface Node {

  /**
   * Returns the unique name of the node, used for identification and routing.
   *
   * @return The name of the node.
   */
  String getName();

  /**
   * Executes the node's logic on the given graph state.
   *
   * @param state The current state of the graph.
   * @return The updated state after the node has executed.
   */
  GraphState apply(GraphState state);
}
