package com.traceiq.tool;

import com.traceiq.model.DeploymentInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.time.Instant;
import java.util.Map;
import java.util.function.Function;

/**
 * Spring AI Tool for Jenkins API integration.
 * Provides build and deployment status information.
 */
@Component
public class JenkinsTool implements Function<JenkinsTool.JenkinsRequest, DeploymentInfo> {
    
    private static final Logger logger = LoggerFactory.getLogger(JenkinsTool.class);
    
    private final WebClient webClient;
    
    public JenkinsTool(
        @Value("${jenkins.base-url}") String jenkinsBaseUrl,
        @Value("${jenkins.api-token}") String jenkinsApiToken,
        @Value("${jenkins.username}") String jenkinsUsername,
        WebClient.Builder webClientBuilder
    ) {
        String auth = jenkinsUsername + ":" + jenkinsApiToken;
        String encodedAuth = java.util.Base64.getEncoder().encodeToString(auth.getBytes());
        
        this.webClient = webClientBuilder
            .baseUrl(jenkinsBaseUrl)
            .defaultHeader("Authorization", "Basic " + encodedAuth)
            .build();
        
        logger.info("JenkinsTool initialized with base URL: {}", jenkinsBaseUrl);
    }
    
    @Override
    public DeploymentInfo apply(JenkinsRequest request) {
        logger.info("Fetching Jenkins build info for job: {}", request.jobName());
        
        return getBuildInfo(request);
    }
    
    /**
     * Get build and deployment information from Jenkins.
     */
    private DeploymentInfo getBuildInfo(JenkinsRequest request) {
        logger.info("Fetching build info for job: {}, build: {}", 
            request.jobName(), request.buildNumber());
        
        try {
            String buildNumber = request.buildNumber() != null ? 
                request.buildNumber() : "lastBuild";
            
            Map<String, Object> response = webClient.get()
                .uri("/job/{jobName}/{buildNumber}/api/json",
                    request.jobName(), buildNumber)
                .retrieve()
                .bodyToMono(Map.class)
                .block();
            
            return parseBuildInfo(response);
            
        } catch (Exception e) {
            logger.error("Error fetching Jenkins build info", e);
            return createErrorDeploymentInfo(e.getMessage());
        }
    }
    
    // Helper methods
    
    @SuppressWarnings("unchecked")
    private DeploymentInfo parseBuildInfo(Map<String, Object> response) {
        String buildNumber = String.valueOf(response.get("number"));
        String result = (String) response.get("result");
        String buildStatus = result != null ? result : "IN_PROGRESS";
        
        Long timestamp = (Long) response.get("timestamp");
        Instant buildTime = timestamp != null ? 
            Instant.ofEpochMilli(timestamp) : Instant.now();
        
        // Parse additional data from build parameters/environment
        String sonarStatus = extractSonarStatus(response);
        String compTestStatus = extractComponentTestStatus(response);
        
        return new DeploymentInfo(
            buildNumber,
            buildStatus,
            buildTime,
            "SUCCESS".equals(buildStatus) ? "Deployed" : "Pending",
            buildTime,
            "production",
            "Unknown",
            0,
            sonarStatus,
            compTestStatus
        );
    }
    
    @SuppressWarnings("unchecked")
    private String extractSonarStatus(Map<String, Object> response) {
        try {
            List<Map<String, Object>> actions = 
                (List<Map<String, Object>>) response.get("actions");
            
            if (actions != null) {
                for (Map<String, Object> action : actions) {
                    if (action.containsKey("sonarqube")) {
                        Map<String, Object> sonar = 
                            (Map<String, Object>) action.get("sonarqube");
                        return (String) sonar.getOrDefault("status", "Unknown");
                    }
                }
            }
        } catch (Exception e) {
            logger.debug("Could not extract Sonar status", e);
        }
        
        return "Not Available";
    }
    
    @SuppressWarnings("unchecked")
    private String extractComponentTestStatus(Map<String, Object> response) {
        try {
            List<Map<String, Object>> actions = 
                (List<Map<String, Object>>) response.get("actions");
            
            if (actions != null) {
                for (Map<String, Object> action : actions) {
                    if (action.containsKey("testResultAction")) {
                        Map<String, Object> testResult = 
                            (Map<String, Object>) action.get("testResultAction");
                        int failCount = (int) testResult.getOrDefault("failCount", 0);
                        return failCount == 0 ? "Passed" : "Failed";
                    }
                }
            }
        } catch (Exception e) {
            logger.debug("Could not extract component test status", e);
        }
        
        return "Not Available";
    }
    
    private DeploymentInfo createErrorDeploymentInfo(String error) {
        return new DeploymentInfo(
            "Unknown",
            "Error: " + error,
            Instant.now(),
            "Unknown",
            Instant.now(),
            "Unknown",
            "Unknown",
            0,
            "Unknown",
            "Unknown"
        );
    }
    
    /**
     * Request model for Jenkins tool.
     */
    public record JenkinsRequest(
        String jobName,
        String buildNumber
    ) {
        public static Builder builder() {
            return new Builder();
        }
        
        public static class Builder {
            private String jobName;
            private String buildNumber;
            
            public Builder jobName(String jobName) {
                this.jobName = jobName;
                return this;
            }
            
            public Builder buildNumber(String buildNumber) {
                this.buildNumber = buildNumber;
                return this;
            }
            
            public JenkinsRequest build() {
                return new JenkinsRequest(jobName, buildNumber);
            }
        }
    }
}
