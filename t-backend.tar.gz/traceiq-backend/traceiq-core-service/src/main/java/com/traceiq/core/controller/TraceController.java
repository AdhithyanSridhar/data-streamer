package com.traceiq.core.controller;

import com.traceiq.core.service.TraceService;
import com.traceiq.models.dto.TraceSearchRequest;
import com.traceiq.models.dto.TraceSearchResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/trace")
@Tag(name = "Trace API", description = "Trace search and RCA operations")
public class TraceController {

    private final TraceService traceService;

    public TraceController(TraceService traceService) {
        this.traceService = traceService;
    }

    @PostMapping("/search")
    @Operation(summary = "Search by trace ID and optionally perform RCA")
    public ResponseEntity<TraceSearchResponse> searchTrace(@Valid @RequestBody TraceSearchRequest request) {
        TraceSearchResponse response = traceService.searchByTraceId(
                request.traceId(),
                Boolean.TRUE.equals(request.includeRca()),
                Boolean.TRUE.equals(request.includeCodeSpot()),
                Boolean.TRUE.equals(request.godMode())
        );
        return ResponseEntity.ok(response);
    }

    @GetMapping("/{traceId}")
    @Operation(summary = "Get trace details by ID")
    public ResponseEntity<TraceSearchResponse> getTrace(@PathVariable String traceId) {
        TraceSearchResponse response = traceService.searchByTraceId(traceId, false, false, false);
        return ResponseEntity.ok(response);
    }
}
