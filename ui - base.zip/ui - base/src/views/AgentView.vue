<template>
  <v-container fluid class="pa-6">
    <!-- Hero Section -->
    <div class="hero-section mb-8">
      <h1 class="hero-title">Agent Workflow Summary</h1>
      <p class="hero-subtitle">Automated issue resolution powered by intelligent AI agents</p>
    </div>

    <!-- Stats Overview -->
    <StatsOverview :workflowData="workflowData" class="mb-8" />

    <!-- Main Grid -->
    <v-row>
      <!-- Left Column -->
      <v-col cols="12" lg="8">
        <IssueContext :issueData="workflowData.issueContext" class="mb-6" />
        <AgentTasks :tasks="workflowData.selectedTasks" class="mb-6" />
        <GitHubIssue :issue="workflowData.githubIssue" class="mb-6" />
        <RcaSection title="Brief RCA" icon="mdi-lightning-bolt-outline" :content="workflowData.briefRca" variant="brief" class="mb-6" />
        <RcaSection title="Deep RCA (Agent Reasoning)" icon="mdi-magnify" :content="workflowData.deepRca" variant="deep" class="mb-6" />
        <ImplementationPlan :plan="workflowData.implementationPlan" class="mb-6" />
        <PullRequestSection :pr="workflowData.pullRequest" class="mb-6" />
        <UnitTestsSection :tests="workflowData.unitTests" class="mb-6" />
      </v-col>
      
      <!-- Right Column -->
      <v-col cols="12" lg="4">
        <ExecutionStatus :status="workflowData.executionStatus" class="mb-6" />
        <FinalStatus :finalStatus="workflowData.finalStatus" class="mb-6" />
        <WorkflowCharts :chartData="workflowData.chartData" class="mb-6" />
        <LogsSection :logs="workflowData.logs" />
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import StatsOverview from '../components/StatsOverview.vue'
import IssueContext from '../components/IssueContext.vue'
import AgentTasks from '../components/AgentTasks.vue'
import GitHubIssue from '../components/GitHubIssue.vue'
import RcaSection from '../components/RcaSection.vue'
import ImplementationPlan from '../components/ImplementationPlan.vue'
import PullRequestSection from '../components/PullRequestSection.vue'
import UnitTestsSection from '../components/UnitTestsSection.vue'
import ExecutionStatus from '../components/ExecutionStatus.vue'
import FinalStatus from '../components/FinalStatus.vue'
import WorkflowCharts from '../components/WorkflowCharts.vue'
import LogsSection from '../components/LogsSection.vue'

const route = useRoute()

onMounted(() => {
  if (route.query.traceId || route.query.errorId) {
    console.log('Agent assigned for:', route.query)
  }
})

const workflowData = ref({
  issueContext: {
    traceId: 'trace-abc123-def456-789xyz',
    serviceName: 'payment-service',
    cluster: 'prod-us-east-1',
    errorSummary: 'NullPointerException in PaymentProcessor.processTransaction()',
    timestamp: '2024-12-10T14:30:00Z'
  },
  selectedTasks: [
    { name: 'Root Cause Analysis', completed: true },
    { name: 'Generate Implementation Plan', completed: true },
    { name: 'Create Pull Request', completed: true },
    { name: 'Generate Unit Tests', completed: true },
    { name: 'Auto-merge PR', completed: false },
    { name: 'Close Issue', completed: false }
  ],
  githubIssue: {
    issueNumber: 1234,
    title: '[TraceIQ] NullPointerException in PaymentProcessor - Automated Fix',
    repoName: 'acme-corp/payment-service',
    agentName: 'ai-agent-bot',
    status: 'open',
    labels: ['bug', 'ai-generated', 'high-priority'],
    url: 'https://github.com/acme-corp/payment-service/issues/1234'
  },
  briefRca: `## Summary\nThe error originates from a missing null check in the \`PaymentProcessor.processTransaction()\` method.\n\n### Impact\n- **Severity:** High\n- **Affected Users:** ~2,500 transactions failed`,
  deepRca: `## Detailed Root Cause Analysis\n\n### 1. Error Stack Trace Analysis\n\`\`\`java\njava.lang.NullPointerException\n  at com.acme.payment.PaymentProcessor.processTransaction(PaymentProcessor.java:142)\n\`\`\`\n\n### 2. Code Flow Analysis\nThe issue stems from missing input validation at controller level.`,
  implementationPlan: `## Implementation Steps\n\n### Phase 1: Immediate Fix\n1. Add null validation in \`PaymentProcessor.java\`\n2. Implement \`Optional<>\` wrapper\n\n### Phase 2: Testing\n1. Add unit tests for null scenarios`,
  pullRequest: {
    prNumber: 567,
    title: 'fix: Add null validation for transaction context',
    branchName: 'fix/traceiq-null-check-1234',
    agentName: 'ai-agent-bot',
    status: 'open',
    url: 'https://github.com/acme-corp/payment-service/pull/567',
    codeDiff: `@@ -140,6 +140,10 @@ public class PaymentProcessor {\n     public TransactionResult processTransaction(TransactionContext context) {\n+        if (context == null) {\n+            throw new IllegalArgumentException("Transaction context cannot be null");\n+        }\n         String transactionId = context.getTransactionId();`
  },
  unitTests: {
    testFileCount: 2,
    testCount: 8,
    status: 'passed',
    testCode: `@Test\nvoid processTransaction_WithNullContext_ThrowsException() {\n    assertThrows(IllegalArgumentException.class, \n        () -> processor.processTransaction(null));\n}`
  },
  executionStatus: {
    completedActions: ['Fetched trace details from Dynatrace', 'Analyzed error patterns in ELK stack', 'Identified root cause via LLM reasoning', 'Generated implementation plan', 'Created GitHub issue #1234', 'Generated code fix', 'Created pull request #567', 'Generated unit tests'],
    pendingActions: ['Waiting for CI pipeline to complete', 'Awaiting PR review approval'],
    failedActions: []
  },
  finalStatus: {
    issueStatus: 'open',
    prStatus: 'awaiting_review',
    autoClosePerformed: false,
    issueNumber: 1234,
    prNumber: 567
  },
  chartData: {
    taskCompletion: { completed: 6, pending: 2, failed: 0 },
    timeSpent: [{ task: 'RCA', minutes: 2 }, { task: 'Planning', minutes: 1 }, { task: 'Code Gen', minutes: 3 }, { task: 'Testing', minutes: 4 }, { task: 'PR', minutes: 1 }]
  },
  logs: `[2024-12-10 14:30:05] INFO  Starting agent workflow\n[2024-12-10 14:30:08] INFO  Trace data retrieved\n[2024-12-10 14:30:18] INFO  Root cause identified\n[2024-12-10 14:30:38] INFO  PR #567 created`
})
</script>

<style scoped>
.hero-section { text-align: center; padding: 20px 0 40px; }
.hero-title { font-size: 1.75rem; font-weight: 700; letter-spacing: -0.02em; margin-bottom: 12px; color: #1a1a1a; }
.hero-subtitle { font-size: 0.95rem; color: #666666; max-width: 500px; margin: 0 auto; }
@media (max-width: 960px) { .hero-title { font-size: 1.5rem; } .hero-subtitle { font-size: 0.9rem; } }
</style>
