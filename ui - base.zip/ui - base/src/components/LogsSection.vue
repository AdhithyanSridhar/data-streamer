<template>
  <div class="glass-card pa-5">
    <div class="section-header" @click="isExpanded = !isExpanded" style="cursor: pointer;">
      <div class="section-header__icon">
        <v-icon icon="mdi-text-box-outline" size="20"></v-icon>
      </div>
      <h2 class="section-header__title">Logs</h2>
      <v-spacer></v-spacer>
      <v-icon :icon="isExpanded ? 'mdi-chevron-up' : 'mdi-chevron-down'" size="20"></v-icon>
    </div>
    
    <v-expand-transition>
      <div v-show="isExpanded" class="logs-container">
        <pre class="logs-content">{{ logs }}</pre>
        <div class="logs-actions">
          <v-btn variant="outlined" size="small" @click="copyLogs">
            <v-icon icon="mdi-content-copy" class="mr-1" size="16"></v-icon>
            Copy
          </v-btn>
          <v-btn variant="outlined" size="small" @click="downloadLogs">
            <v-icon icon="mdi-download-outline" class="mr-1" size="16"></v-icon>
            Download
          </v-btn>
        </div>
      </div>
    </v-expand-transition>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const props = defineProps({
  logs: { type: String, required: true }
})

const isExpanded = ref(false)

const copyLogs = () => {
  navigator.clipboard.writeText(props.logs)
}

const downloadLogs = () => {
  const blob = new Blob([props.logs], { type: 'text/plain' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = 'agent-logs.txt'
  a.click()
  URL.revokeObjectURL(url)
}
</script>

<style scoped>
.logs-container {
  margin-top: 16px;
}

.logs-content {
  background: #1a1a1a;
  border-radius: 8px;
  padding: 16px;
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.75rem;
  line-height: 1.6;
  color: #e5e5e5;
  overflow-x: auto;
  max-height: 300px;
  margin-bottom: 12px;
}

.logs-actions {
  display: flex;
  gap: 8px;
}
</style>
