<template>
  <v-app>
    <!-- Top App Bar with Navigation -->
    <v-app-bar class="app-bar" elevation="0">
      <!-- Logo and Brand -->
      <div class="brand-section">
        <v-icon icon="mdi-brain" size="32" class="brand-icon"></v-icon>
        <div class="brand-text">
          <span class="brand-name">TraceIQ</span>
          <span class="brand-tagline">Trusted Insights</span>
        </div>
      </div>

      <v-divider vertical class="mx-4 my-3"></v-divider>

      <!-- Navigation Menu -->
      <div class="nav-menu">
        <v-btn
          v-for="item in navItems"
          :key="item.path"
          :to="item.path"
          variant="text"
          :class="{ 'nav-btn--active': isActiveRoute(item.path) }"
          class="nav-btn"
        >
          <v-icon :icon="item.icon" size="18" class="mr-1"></v-icon>
          {{ item.title }}
        </v-btn>
      </div>
      
      <v-spacer></v-spacer>
      
      <!-- Keyboard Shortcut Hint -->
      <div class="shortcut-hint" @click="showCommandPalette = true">
        <v-icon icon="mdi-magnify" size="16"></v-icon>
        <span>Search</span>
        <kbd>⌘K</kbd>
      </div>
      
      <v-avatar size="36" class="user-avatar">
        <span class="text-caption font-weight-bold">AI</span>
      </v-avatar>
    </v-app-bar>

    <!-- Breadcrumbs -->
    <div class="breadcrumbs-container" v-if="breadcrumbs.length > 1">
      <v-breadcrumbs :items="breadcrumbs" density="compact">
        <template v-slot:prepend>
          <v-icon icon="mdi-home-outline" size="16"></v-icon>
        </template>
        <template v-slot:divider>
          <v-icon icon="mdi-chevron-right" size="14"></v-icon>
        </template>
      </v-breadcrumbs>
    </div>

    <!-- Main Content -->
    <v-main class="main-content">
      <router-view v-slot="{ Component, route }">
        <transition :name="transitionName" mode="out-in">
          <component :is="Component" :key="route.path" />
        </transition>
      </router-view>
    </v-main>

    <!-- Global Components -->
    <CommandPalette v-model="showCommandPalette" />
    <ToastNotification ref="toastRef" />
    <AIChat />
    
    <!-- Keyboard Shortcuts Modal -->
    <v-dialog v-model="showShortcuts" max-width="500">
      <v-card class="shortcuts-card">
        <v-card-title class="shortcuts-title">
          <v-icon icon="mdi-keyboard-outline" class="mr-2"></v-icon>
          Keyboard Shortcuts
          <v-spacer></v-spacer>
          <v-btn icon variant="text" size="small" @click="showShortcuts = false">
            <v-icon icon="mdi-close"></v-icon>
          </v-btn>
        </v-card-title>
        <v-card-text>
          <div class="shortcuts-grid">
            <div v-for="shortcut in keyboardShortcuts" :key="shortcut.key" class="shortcut-row">
              <span class="shortcut-action">{{ shortcut.action }}</span>
              <div class="shortcut-keys">
                <kbd v-for="k in shortcut.keys" :key="k">{{ k }}</kbd>
              </div>
            </div>
          </div>
        </v-card-text>
      </v-card>
    </v-dialog>
  </v-app>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, provide } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import CommandPalette from './components/CommandPalette.vue'
import ToastNotification from './components/ToastNotification.vue'
import AIChat from './components/AIChat.vue'

const route = useRoute()
const router = useRouter()

const showCommandPalette = ref(false)
const showShortcuts = ref(false)
const toastRef = ref(null)
const transitionName = ref('fade')

// Provide toast globally
provide('toast', {
  success: (title, message) => toastRef.value?.addToast({ type: 'success', title, message }),
  error: (title, message) => toastRef.value?.addToast({ type: 'error', title, message }),
  warning: (title, message) => toastRef.value?.addToast({ type: 'warning', title, message }),
  info: (title, message) => toastRef.value?.addToast({ type: 'info', title, message })
})

const navItems = [
  { path: '/dashboard', title: 'Dashboard', icon: 'mdi-view-dashboard-outline' },
  { path: '/app-errors', title: 'Errors', icon: 'mdi-alert-circle-outline' },
  { path: '/trace-lookup', title: 'Traces', icon: 'mdi-magnify' },
  { path: '/incidents', title: 'Incidents', icon: 'mdi-alert-octagon-outline' },
  { path: '/agent-view', title: 'Agent', icon: 'mdi-robot-outline' },
  { path: '/batch-job', title: 'Jobs', icon: 'mdi-calendar-clock-outline' },
  { path: '/settings', title: 'Settings', icon: 'mdi-cog-outline' }
]

const keyboardShortcuts = [
  { action: 'Open Command Palette', keys: ['⌘', 'K'] },
  { action: 'Go to Dashboard', keys: ['G', 'D'] },
  { action: 'Go to Errors', keys: ['G', 'E'] },
  { action: 'Go to Trace Lookup', keys: ['G', 'T'] },
  { action: 'Go to Incidents', keys: ['G', 'I'] },
  { action: 'Go to Settings', keys: ['G', 'S'] },
  { action: 'Focus Search', keys: ['/'] },
  { action: 'Show Shortcuts', keys: ['?'] },
  { action: 'Close', keys: ['Esc'] }
]

const isActiveRoute = (path) => route.path === path || route.path.startsWith(path + '/')

const breadcrumbs = computed(() => {
  const items = [{ title: 'Home', to: '/dashboard' }]
  const currentRoute = navItems.find(item => isActiveRoute(item.path))
  if (currentRoute && currentRoute.path !== '/dashboard') {
    items.push({ title: currentRoute.title, to: currentRoute.path })
  }
  return items
})

// Keyboard shortcuts handler
let pendingKey = null
let pendingTimeout = null

const handleKeydown = (e) => {
  // Ignore if typing in input
  if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return
  
  // Command palette: Cmd/Ctrl + K
  if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
    e.preventDefault()
    showCommandPalette.value = true
    return
  }
  
  // Show shortcuts: ?
  if (e.key === '?' && !e.metaKey && !e.ctrlKey) {
    e.preventDefault()
    showShortcuts.value = true
    return
  }
  
  // Focus search: /
  if (e.key === '/' && !e.metaKey && !e.ctrlKey) {
    e.preventDefault()
    showCommandPalette.value = true
    return
  }
  
  // Two-key shortcuts (G + letter)
  if (e.key.toLowerCase() === 'g' && !e.metaKey && !e.ctrlKey) {
    pendingKey = 'g'
    clearTimeout(pendingTimeout)
    pendingTimeout = setTimeout(() => { pendingKey = null }, 500)
    return
  }
  
  if (pendingKey === 'g') {
    clearTimeout(pendingTimeout)
    pendingKey = null
    
    const shortcuts = {
      'd': '/dashboard',
      'e': '/app-errors',
      't': '/trace-lookup',
      'i': '/incidents',
      's': '/settings'
    }
    
    const path = shortcuts[e.key.toLowerCase()]
    if (path) {
      e.preventDefault()
      router.push(path)
    }
  }
}

onMounted(() => {
  window.addEventListener('keydown', handleKeydown)
})

onUnmounted(() => {
  window.removeEventListener('keydown', handleKeydown)
})
</script>

<style scoped>
.app-bar {
  background: #ffffff !important;
  border-bottom: 1px solid #e5e5e5;
}

.brand-section {
  display: flex;
  align-items: center;
  gap: 10px;
  padding-left: 16px;
}

.brand-icon {
  color: #1a1a1a;
}

.brand-text {
  display: flex;
  flex-direction: column;
  line-height: 1.2;
}

.brand-name {
  font-size: 1.25rem;
  font-weight: 700;
  color: #1a1a1a;
  letter-spacing: -0.02em;
}

.brand-tagline {
  font-size: 0.65rem;
  color: #666666;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.nav-menu {
  display: flex;
  gap: 4px;
}

.nav-btn {
  text-transform: none;
  font-weight: 500;
  font-size: 0.85rem;
  color: #666666;
  letter-spacing: 0;
  padding: 0 12px;
}

.nav-btn:hover {
  background: #f5f5f5 !important;
  color: #1a1a1a;
}

.nav-btn--active {
  background: #f0f0f0 !important;
  color: #1a1a1a !important;
}

.shortcut-hint {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 12px;
  background: #f5f5f5;
  border-radius: 8px;
  font-size: 0.8rem;
  color: #666666;
  cursor: pointer;
  margin-right: 16px;
  transition: all 0.2s;
}

.shortcut-hint:hover {
  background: #e5e5e5;
  color: #1a1a1a;
}

.shortcut-hint kbd {
  background: #ffffff;
  border: 1px solid #e5e5e5;
  border-radius: 4px;
  padding: 2px 6px;
  font-size: 0.7rem;
  font-family: monospace;
}

.user-avatar {
  background: #1a1a1a;
  color: #ffffff;
  margin-right: 16px;
}

.breadcrumbs-container {
  background: #fafafa;
  padding: 8px 24px;
  border-bottom: 1px solid #e5e5e5;
}

.main-content {
  background: #fafafa;
  min-height: 100vh;
}

/* Page Transitions */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.2s ease, transform 0.2s ease;
}

.fade-enter-from {
  opacity: 0;
  transform: translateY(10px);
}

.fade-leave-to {
  opacity: 0;
  transform: translateY(-10px);
}

.slide-enter-active,
.slide-leave-active {
  transition: all 0.3s ease;
}

.slide-enter-from {
  opacity: 0;
  transform: translateX(30px);
}

.slide-leave-to {
  opacity: 0;
  transform: translateX(-30px);
}

/* Shortcuts Modal */
.shortcuts-card {
  background: #ffffff !important;
}

.shortcuts-title {
  display: flex;
  align-items: center;
  background: #f5f5f5;
  padding: 16px 20px !important;
  font-size: 1rem;
}

.shortcuts-grid {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.shortcut-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 12px;
  background: #f5f5f5;
  border-radius: 6px;
}

.shortcut-action {
  font-size: 0.9rem;
  color: #1a1a1a;
}

.shortcut-keys {
  display: flex;
  gap: 4px;
}

.shortcut-keys kbd {
  background: #ffffff;
  border: 1px solid #e5e5e5;
  border-radius: 4px;
  padding: 4px 8px;
  font-size: 0.75rem;
  font-family: monospace;
  color: #666666;
  min-width: 24px;
  text-align: center;
}

@media (max-width: 1200px) {
  .nav-btn {
    padding: 0 8px;
    font-size: 0.8rem;
  }
  
  .shortcut-hint span {
    display: none;
  }
}
</style>
