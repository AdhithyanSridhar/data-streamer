package com.traceiq.adapters.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

/**
 * Configuration class for adapters.
 * Provides beans and configuration for external API integrations.
 */
@Configuration
public class AdapterConfiguration {
    
    private static final Logger logger = LoggerFactory.getLogger(AdapterConfiguration.class);
    
    @Value("${elk.api.url:http://localhost:9200}")
    private String elkApiUrl;
    
    @Value("${elk.api.token:}")
    private String elkApiToken;
    
    @Value("${jira.api.url:https://jira.example.com}")
    private String jiraApiUrl;
    
    @Value("${jira.api.token:}")
    private String jiraApiToken;
    
    @Value("${dynatrace.api.url:https://dynatrace.example.com}")
    private String dynatraceApiUrl;
    
    @Value("${dynatrace.api.token:}")
    private String dynatraceApiToken;
    
    @Value("${github.api.url:https://api.github.com}")
    private String githubApiUrl;
    
    @Value("${github.api.token:}")
    private String githubApiToken;
    
    @Value("${jenkins.api.url:http://jenkins.example.com}")
    private String jenkinsApiUrl;
    
    @Value("${jenkins.api.token:}")
    private String jenkinsApiToken;
    
    @Value("${k8s.api.url:https://kubernetes.default.svc}")
    private String k8sApiUrl;
    
    @Value("${k8s.api.token:}")
    private String k8sApiToken;
    
    @Value("${llm.api.url:https://llm.example.com}")
    private String llmApiUrl;
    
    @Value("${llm.api.token:}")
    private String llmApiToken;
    
    @Value("${vector.api.url:https://vector.example.com}")
    private String vectorApiUrl;
    
    @Value("${vector.api.token:}")
    private String vectorApiToken;
    
    @Value("${cassandra.url:localhost}")
    private String cassandraUrl;
    
    @Value("${cassandra.datacenter:datacenter1}")
    private String cassandraDatacenter;
    
    @Value("${cassandra.keyspace:traceiq}")
    private String cassandraKeyspace;
    
    @Value("${cassandra.mock.enabled:true}")
    private boolean cassandraMockEnabled;
    
    @Value("${jtoon.enabled:false}")
    private boolean jtoonEnabled;
    
    @Value("${ai.enabled:true}")
    private boolean aiEnabled;
    
    /**
     * Creates a RestTemplate bean for HTTP calls.
     */
    @Bean
    public RestTemplate restTemplate() {
        logger.info("Creating RestTemplate bean for HTTP calls");
        return new RestTemplate();
    }
    
    // Getter methods for configuration values
    
    public String getElkApiUrl() {
        return elkApiUrl;
    }
    
    public String getElkApiToken() {
        return elkApiToken;
    }
    
    public String getJiraApiUrl() {
        return jiraApiUrl;
    }
    
    public String getJiraApiToken() {
        return jiraApiToken;
    }
    
    public String getDynatraceApiUrl() {
        return dynatraceApiUrl;
    }
    
    public String getDynatraceApiToken() {
        return dynatraceApiToken;
    }
    
    public String getGithubApiUrl() {
        return githubApiUrl;
    }
    
    public String getGithubApiToken() {
        return githubApiToken;
    }
    
    public String getJenkinsApiUrl() {
        return jenkinsApiUrl;
    }
    
    public String getJenkinsApiToken() {
        return jenkinsApiToken;
    }
    
    public String getK8sApiUrl() {
        return k8sApiUrl;
    }
    
    public String getK8sApiToken() {
        return k8sApiToken;
    }
    
    public String getLlmApiUrl() {
        return llmApiUrl;
    }
    
    public String getLlmApiToken() {
        return llmApiToken;
    }
    
    public String getVectorApiUrl() {
        return vectorApiUrl;
    }
    
    public String getVectorApiToken() {
        return vectorApiToken;
    }
    
    public String getCassandraUrl() {
        return cassandraUrl;
    }
    
    public String getCassandraDatacenter() {
        return cassandraDatacenter;
    }
    
    public String getCassandraKeyspace() {
        return cassandraKeyspace;
    }
    
    public boolean isCassandraMockEnabled() {
        return cassandraMockEnabled;
    }
    
    public boolean isJtoonEnabled() {
        return jtoonEnabled;
    }
    
    public boolean isAiEnabled() {
        return aiEnabled;
    }
}
