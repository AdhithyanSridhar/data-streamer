package com.example.demo.tools;

import dev.langchain4j.agent.tool.Tool;
import org.springframework.stereotype.Component;

@Component
public class JenkinsTool {

  @Tool("Get build and deployment status for a microservice")
  public BuildStatusResponse getBuildStatus(BuildStatusRequest buildStatusRequest) {
    System.out.println("Fetching build status for: " + buildStatusRequest.microservice);
    return new BuildStatusResponse(
        "Simulated build status for "
            + buildStatusRequest.microservice
            + ": Build #123 - SUCCESS, Deployed to test environment at 2024-01-01 10:00:00.",
        "SonarQube: PASSED, Component Tests: 95% PASSED.");
  }

  public record BuildStatusRequest(String microservice) {}

  public record BuildStatusResponse(String status, String testStatus) {}
}
