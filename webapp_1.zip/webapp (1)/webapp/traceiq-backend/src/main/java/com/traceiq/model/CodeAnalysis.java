package com.traceiq.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.List;

/**
 * Code analysis results from vectorized codebase LLM.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record CodeAnalysis(
    String filePath,
    String className,
    String methodName,
    int lineNumber,
    String problematicCode,
    String suggestedFix,
    String explanation,
    List<String> relatedFiles,
    String productionReadinessScore
) {}
