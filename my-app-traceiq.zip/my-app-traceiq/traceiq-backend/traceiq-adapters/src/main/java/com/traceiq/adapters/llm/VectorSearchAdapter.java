package com.traceiq.adapters.llm;

import com.traceiq.adapters.config.AdapterConfiguration;
import com.traceiq.models.domain.ImplementationPlan;
import com.traceiq.utils.RetryUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Adapter for vectorized code search LLM.
 * Searches internal codebase using vector embeddings.
 */
@Component
public class VectorSearchAdapter {
    
    private static final Logger logger = LoggerFactory.getLogger(VectorSearchAdapter.class);
    
    private final RestTemplate restTemplate;
    private final AdapterConfiguration config;
    
    public VectorSearchAdapter(RestTemplate restTemplate, AdapterConfiguration config) {
        this.restTemplate = restTemplate;
        this.config = config;
    }
    
    /**
     * Searches codebase for relevant code locations based on RCA context.
     *
     * @param rcaContext RCA analysis context
     * @param traceId trace identifier
     * @return list of code locations
     */
    public List<ImplementationPlan.CodeLocation> searchCode(String rcaContext, String traceId) {
        if (!config.isAiEnabled()) {
            logger.info("AI is disabled, returning mock code locations");
            return getMockCodeLocations();
        }
        
        return RetryUtils.executeWithRetry(() -> {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBearerAuth(config.getVectorApiToken());
            
            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("query", rcaContext);
            requestBody.put("trace_id", traceId);
            requestBody.put("top_k", 5);
            
            HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);
            
            logger.info("Calling Vector Search API: {}", config.getVectorApiUrl());
            ResponseEntity<String> response = restTemplate.exchange(
                config.getVectorApiUrl() + "/search",
                HttpMethod.POST,
                request,
                String.class
            );
            
            return parseCodeLocations(response.getBody());
        }, "Vector Search API Call");
    }
    
    /**
     * Parses code locations from API response.
     *
     * @param responseBody raw response
     * @return list of code locations
     */
    private List<ImplementationPlan.CodeLocation> parseCodeLocations(String responseBody) {
        // Placeholder - in production, parse actual API response
        return getMockCodeLocations();
    }
    
    /**
     * Returns mock code locations for testing.
     *
     * @return list of mock code locations
     */
    private List<ImplementationPlan.CodeLocation> getMockCodeLocations() {
        List<ImplementationPlan.CodeLocation> locations = new ArrayList<>();
        
        locations.add(new ImplementationPlan.CodeLocation(
            "src/main/java/com/example/payment/PaymentService.java",
            "payment-service",
            145,
            160,
            "public void processPayment(PaymentRequest request) {\n    // Missing null check\n    String configValue = getConfig();\n    ...\n}",
            "Missing null pointer check for configuration value",
            0.95
        ));
        
        locations.add(new ImplementationPlan.CodeLocation(
            "src/main/java/com/example/payment/ConfigManager.java",
            "payment-service",
            67,
            80,
            "public String getConfig() {\n    return configMap.get(key);\n}",
            "Configuration map can return null",
            0.87
        ));
        
        return locations;
    }
}
