package com.traceiq.tools;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.traceiq.client.LlmRcaClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.function.Function;

/**
 * Spring AI Function Tool for Internal GPT-4 LLM RCA Analysis
 * Provides intelligent root cause analysis, fix suggestions, and guardrails
 */
@Component("llmRcaTool")
public class LlmRcaTool implements Function<LlmRcaTool.LlmRcaRequest, LlmRcaTool.LlmRcaResponse> {
    public static final Logger log = LoggerFactory.getLogger(LlmRcaTool.class);

    private final LlmRcaClient llmRcaClient;

    public LlmRcaTool(LlmRcaClient llmRcaClient) {
        this.llmRcaClient = llmRcaClient;
    }

    @Override
    public LlmRcaResponse apply(LlmRcaRequest request) {
        log.info("Executing LLM RCA tool with use case: {}", request.useCase);

        try {
            return switch (request.useCase.toUpperCase()) {
                case "ROOT_CAUSE_ANALYSIS" -> performRootCauseAnalysis(request);
                case "FIX_SUGGESTION" -> generateFixSuggestion(request);
                case "FUTURE_GUARDRAILS" -> recommendGuardrails(request);
                case "PRODUCTION_READINESS" -> assessProductionReadiness(request);
                case "SUMMARY" -> generateSummary(request);
                case "IMPACT_ANALYSIS" -> analyzeImpact(request);
                default -> LlmRcaResponse.builder()
                        .success(false)
                        .message("Unknown use case: " + request.useCase)
                        .build();
            };
        } catch (Exception e) {
            log.error("Error executing LLM RCA tool: {}", request.useCase, e);
            return LlmRcaResponse.builder()
                    .success(false)
                    .message("Error: " + e.getMessage())
                    .build();
        }
    }

    private LlmRcaResponse performRootCauseAnalysis(LlmRcaRequest request) {
        String prompt = buildPrompt(
                "Analyze the following error details and logs to identify the root cause. " +
                        "Provide a detailed analysis including category, description, root cause, " +
                        "impact analysis, confidence level, and contributing factors.",
                request.context,
                request.elkLogs,
                request.errorDetails
        );

        Map<String, Object> analysis = llmRcaClient.analyze(prompt, "rca");

        return LlmRcaResponse.builder()
                .success(true)
                .data(analysis)
                .message("Root cause analysis completed")
                .build();
    }

    private LlmRcaResponse generateFixSuggestion(LlmRcaRequest request) {
        String prompt = buildPrompt(
                "Based on the root cause analysis, provide specific fix suggestions. " +
                        "Include code changes, configuration updates, and implementation steps.",
                request.context,
                request.rootCauseAnalysis,
                request.codeContext
        );

        Map<String, Object> suggestions = llmRcaClient.analyze(prompt, "fix_suggestion");

        return LlmRcaResponse.builder()
                .success(true)
                .data(suggestions)
                .message("Fix suggestions generated")
                .build();
    }

    private LlmRcaResponse recommendGuardrails(LlmRcaRequest request) {
        String prompt = buildPrompt(
                "Based on this incident, recommend future guardrails, monitoring, " +
                        "alerts, and preventive measures to avoid similar issues.",
                request.context,
                request.rootCauseAnalysis
        );

        Map<String, Object> guardrails = llmRcaClient.analyze(prompt, "guardrails");

        return LlmRcaResponse.builder()
                .success(true)
                .data(guardrails)
                .message("Guardrails recommended")
                .build();
    }

    private LlmRcaResponse assessProductionReadiness(LlmRcaRequest request) {
        String prompt = buildPrompt(
                "Assess the production readiness of the proposed fix. " +
                        "Evaluate test coverage, rollback strategy, monitoring, and deployment risks.",
                request.context,
                request.fixSuggestion
        );

        Map<String, Object> readiness = llmRcaClient.analyze(prompt, "production_readiness");

        return LlmRcaResponse.builder()
                .success(true)
                .data(readiness)
                .message("Production readiness assessed")
                .build();
    }

    private LlmRcaResponse generateSummary(LlmRcaRequest request) {
        String prompt = buildPrompt(
                "Generate an executive summary of the entire analysis. " +
                        "Include key findings, impact, recommended actions, and timeline.",
                request.context
        );

        Map<String, Object> summary = llmRcaClient.analyze(prompt, "summary");

        return LlmRcaResponse.builder()
                .success(true)
                .data(summary)
                .message("Summary generated")
                .build();
    }

    private LlmRcaResponse analyzeImpact(LlmRcaRequest request) {
        String prompt = buildPrompt(
                "Analyze the impact of this issue on users, services, and business. " +
                        "Include severity, affected services, user impact, and business implications.",
                request.context,
                request.errorDetails,
                request.elkLogs
        );

        Map<String, Object> impact = llmRcaClient.analyze(prompt, "impact_analysis");

        return LlmRcaResponse.builder()
                .success(true)
                .data(impact)
                .message("Impact analysis completed")
                .build();
    }

    /**
     * Builds a comprehensive prompt from various context pieces
     */
    private String buildPrompt(String instruction, Object... contextPieces) {
        StringBuilder prompt = new StringBuilder(instruction);
        prompt.append("\n\n");

        for (Object context : contextPieces) {
            if (context != null) {
                prompt.append(context.toString()).append("\n\n");
            }
        }

        return prompt.toString();
    }

    /**
     * Request object for LLM RCA operations
     */
    public record LlmRcaRequest(
            @JsonProperty(required = true)
            @JsonPropertyDescription("Use case: ROOT_CAUSE_ANALYSIS, FIX_SUGGESTION, FUTURE_GUARDRAILS, PRODUCTION_READINESS, SUMMARY, IMPACT_ANALYSIS")
            String useCase,

            @JsonPropertyDescription("General context and background")
            String context,

            @JsonPropertyDescription("Error details from the system")
            String errorDetails,

            @JsonPropertyDescription("ELK logs related to the issue")
            String elkLogs,

            @JsonPropertyDescription("Previous root cause analysis results")
            String rootCauseAnalysis,

            @JsonPropertyDescription("Code context and snippets")
            String codeContext,

            @JsonPropertyDescription("Fix suggestion to evaluate")
            String fixSuggestion
    ) {
    }

    /**
     * Response object for LLM RCA operations
     */
    public record LlmRcaResponse(
            boolean success,
            String message,
            Map<String, Object> data
    ) {
        public static LlmRcaResponseBuilder builder() {
            return new LlmRcaResponseBuilder();
        }

        public static class LlmRcaResponseBuilder {
            private boolean success;
            private String message;
            private Map<String, Object> data;

            public LlmRcaResponseBuilder success(boolean success) {
                this.success = success;
                return this;
            }

            public LlmRcaResponseBuilder message(String message) {
                this.message = message;
                return this;
            }

            public LlmRcaResponseBuilder data(Map<String, Object> data) {
                this.data = data;
                return this;
            }

            public LlmRcaResponse build() {
                return new LlmRcaResponse(success, message, data);
            }
        }
    }
}
