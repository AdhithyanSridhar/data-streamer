<template>
  <div class="space-y-6">
    <div class="bg-white rounded-lg shadow-md p-6">
      <h2 class="text-2xl font-bold text-gray-800 mb-4">
        <i class="fas fa-search text-indigo-600 mr-2"></i>
        Trace ID Search
      </h2>
      
      <div class="flex space-x-4">
        <input
          v-model="traceId"
          type="text"
          placeholder="Enter Trace ID (e.g., TRACE-001)"
          class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
          @keyup.enter="searchTrace"
        />
        <button
          @click="searchTrace"
          class="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition"
        >
          <i class="fas fa-search mr-2"></i>Search
        </button>
        <button
          v-if="traceData"
          @click="godMode"
          class="bg-purple-600 text-white px-6 py-2 rounded-lg hover:bg-purple-700 transition"
          title="Run complete RCA + Implementation Plan"
        >
          <i class="fas fa-magic mr-2"></i>God Mode
        </button>
      </div>
    </div>

    <!-- Trace Results -->
    <div v-if="traceData" class="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <!-- Stats Cards -->
      <div class="bg-white rounded-lg shadow-md p-6">
        <h3 class="text-lg font-semibold text-gray-700 mb-2">Confidence Score</h3>
        <div class="text-4xl font-bold text-indigo-600">
          {{ (traceData.confidenceScore * 100).toFixed(0) }}%
        </div>
      </div>
      
      <div class="bg-white rounded-lg shadow-md p-6">
        <h3 class="text-lg font-semibold text-gray-700 mb-2">Error Count</h3>
        <div class="text-4xl font-bold text-red-600">
          {{ traceData.errorCount }}
        </div>
      </div>
      
      <div class="bg-white rounded-lg shadow-md p-6">
        <h3 class="text-lg font-semibold text-gray-700 mb-2">Services Involved</h3>
        <div class="text-4xl font-bold text-blue-600">
          {{ traceData.servicesInvolved?.length || 0 }}
        </div>
      </div>
    </div>

    <!-- Error List -->
    <div v-if="traceData?.errors" class="bg-white rounded-lg shadow-md p-6">
      <h3 class="text-xl font-bold text-gray-800 mb-4">
        <i class="fas fa-list mr-2"></i>Error Log Details
      </h3>
      <div class="space-y-3">
        <div
          v-for="(error, idx) in traceData.errors"
          :key="idx"
          class="border-l-4 border-red-500 bg-red-50 p-4 rounded"
        >
          <div class="flex justify-between items-start">
            <div class="flex-1">
              <p class="font-semibold text-gray-800">{{ error.message }}</p>
              <p class="text-sm text-gray-600 mt-1">
                <i class="fas fa-server mr-1"></i>{{ error.serviceName }}
                <span class="mx-2">•</span>
                <i class="fas fa-clock mr-1"></i>{{ new Date(error.timestamp).toLocaleString() }}
              </p>
              <p class="text-sm text-gray-500 mt-2">
                <i class="fas fa-users mr-1"></i>Team: {{ error.microserviceTeam }}
                <span class="mx-2">•</span>
                <i class="fas fa-envelope mr-1"></i>{{ error.ownerEmail }}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Action Buttons -->
    <div v-if="traceData" class="bg-white rounded-lg shadow-md p-6">
      <h3 class="text-xl font-bold text-gray-800 mb-4">
        <i class="fas fa-bolt mr-2"></i>AI Analysis Actions
      </h3>
      <div class="flex space-x-4">
        <button
          @click="getRCA"
          class="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition"
          :disabled="loading"
        >
          <i class="fas fa-brain mr-2"></i>
          {{ loading ? 'Analyzing...' : 'Get RCA Analysis' }}
        </button>
        <button
          @click="getImplementationPlan"
          class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition"
          :disabled="loading"
        >
          <i class="fas fa-code mr-2"></i>
          {{ loading ? 'Generating...' : 'Get Implementation Plan' }}
        </button>
      </div>
    </div>

    <!-- RCA Results -->
    <div v-if="rcaResult" class="bg-white rounded-lg shadow-md p-6">
      <h3 class="text-xl font-bold text-gray-800 mb-4">
        <i class="fas fa-microscope mr-2 text-green-600"></i>Root Cause Analysis
      </h3>
      <div class="space-y-4">
        <div>
          <p class="font-semibold text-gray-700">Root Cause:</p>
          <p class="text-gray-800 mt-1">{{ rcaResult.rootCause }}</p>
        </div>
        <div>
          <p class="font-semibold text-gray-700">Analysis:</p>
          <p class="text-gray-800 mt-1 whitespace-pre-wrap">{{ rcaResult.analysisText }}</p>
        </div>
        <div>
          <p class="font-semibold text-gray-700">Severity:</p>
          <span class="inline-block px-3 py-1 rounded-full text-white text-sm" 
                :class="{
                  'bg-red-600': rcaResult.severity === 'HIGH',
                  'bg-orange-500': rcaResult.severity === 'MEDIUM',
                  'bg-yellow-500': rcaResult.severity === 'LOW'
                }">
            {{ rcaResult.severity }}
          </span>
        </div>
      </div>
    </div>

    <!-- Implementation Plan -->
    <div v-if="implementationPlan" class="bg-white rounded-lg shadow-md p-6">
      <h3 class="text-xl font-bold text-gray-800 mb-4">
        <i class="fas fa-tasks mr-2 text-blue-600"></i>Implementation Plan
      </h3>
      <div class="space-y-6">
        <div>
          <p class="font-semibold text-gray-700">Plan Summary:</p>
          <p class="text-gray-800 mt-1">{{ implementationPlan.planSummary }}</p>
        </div>

        <!-- Code Locations -->
        <div v-if="implementationPlan.codeLocations?.length">
          <p class="font-semibold text-gray-700 mb-2">Code Locations to Fix:</p>
          <div class="space-y-3">
            <div
              v-for="(loc, idx) in implementationPlan.codeLocations"
              :key="idx"
              class="border border-gray-300 rounded-lg p-4 bg-gray-50"
            >
              <p class="font-mono text-sm text-indigo-600">{{ loc.filePath }}</p>
              <p class="text-sm text-gray-600 mt-1">Lines {{ loc.startLine }}-{{ loc.endLine }}</p>
              <p class="text-sm text-gray-800 mt-2">{{ loc.issueDescription }}</p>
              <pre class="mt-3 p-3 bg-white rounded border text-xs overflow-x-auto">{{ loc.codeSnippet }}</pre>
            </div>
          </div>
        </div>

        <!-- Copilot Prompts -->
        <div v-if="implementationPlan.copilotPrompts?.length">
          <p class="font-semibold text-gray-700 mb-2">
            <i class="fas fa-robot mr-2"></i>GitHub Copilot Prompts:
          </p>
          <div class="space-y-2">
            <div
              v-for="(prompt, idx) in implementationPlan.copilotPrompts"
              :key="idx"
              class="border-l-4 border-indigo-500 bg-indigo-50 p-3 rounded"
            >
              <pre class="text-sm whitespace-pre-wrap font-mono">{{ prompt }}</pre>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Loading -->
    <div v-if="loading" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div class="bg-white rounded-lg p-8 text-center">
        <i class="fas fa-spinner fa-spin text-4xl text-indigo-600 mb-4"></i>
        <p class="text-lg text-gray-800">Processing...</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import axios from 'axios'

const traceId = ref('TRACE-001')
const traceData = ref(null)
const rcaResult = ref(null)
const implementationPlan = ref(null)
const loading = ref(false)

const searchTrace = async () => {
  loading.value = true
  try {
    const response = await axios.get(`/api/trace/${traceId.value}`)
    traceData.value = response.data
    rcaResult.value = null
    implementationPlan.value = null
  } catch (error) {
    console.error('Error searching trace:', error)
    alert('Error searching trace. Please try again.')
  } finally {
    loading.value = false
  }
}

const getRCA = async () => {
  loading.value = true
  try {
    const response = await axios.post(`/api/trace/${traceId.value}/rca`, {
      traceId: traceId.value,
      enableAI: true
    })
    rcaResult.value = response.data.rcaResult
  } catch (error) {
    console.error('Error getting RCA:', error)
    alert('Error getting RCA. Please try again.')
  } finally {
    loading.value = false
  }
}

const getImplementationPlan = async () => {
  loading.value = true
  try {
    const response = await axios.post(`/api/trace/${traceId.value}/implementation-plan`)
    implementationPlan.value = response.data.implementationPlan
  } catch (error) {
    console.error('Error getting implementation plan:', error)
    alert('Error getting implementation plan. Please try again.')
  } finally {
    loading.value = false
  }
}

const godMode = async () => {
  loading.value = true
  try {
    const response = await axios.post(`/api/trace/${traceId.value}/god-mode`)
    rcaResult.value = response.data.rcaResult
    implementationPlan.value = response.data.implementationPlan
  } catch (error) {
    console.error('Error running god mode:', error)
    alert('Error running god mode. Please try again.')
  } finally {
    loading.value = false
  }
}
</script>
