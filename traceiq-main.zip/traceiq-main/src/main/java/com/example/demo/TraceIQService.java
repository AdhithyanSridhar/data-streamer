package com.example.demo;

import com.example.demo.graph.GraphState;
import com.example.demo.graph.TraceIQGraph;
import org.springframework.stereotype.Service;

@Service
public class TraceIQService {

  private final TraceIQGraph traceIQGraph;

  public TraceIQService(TraceIQGraph traceIQGraph) {
    this.traceIQGraph = traceIQGraph;
  }

  public String trace(String traceId) {
    GraphState finalState = traceIQGraph.run(traceId);
    return finalState.toString();
  }
}
