package com.traceiq.models.dto;

import java.time.Instant;
import java.util.List;

/**
 * Response DTO for jobs list API.
 */
public record JobListResponse(
    List<JobInfo> jobs,
    String status
) {
    /**
     * Information about a configured job.
     */
    public record JobInfo(
        String jobId,
        String jobName,
        String jobType,
        String schedule,
        String status,
        Instant lastRunTime,
        Instant nextRunTime,
        List<JobExecution> recentExecutions
    ) {}

    /**
     * Details of a job execution.
     */
    public record JobExecution(
        String executionId,
        Instant startTime,
        Instant endTime,
        String status,
        String message,
        int recordsProcessed,
        int errorCount
    ) {}

    public static class Builder {
        private List<JobInfo> jobs;
        private String status;

        public Builder jobs(List<JobInfo> jobs) {
            this.jobs = jobs;
            return this;
        }

        public Builder status(String status) {
            this.status = status;
            return this;
        }

        public JobListResponse build() {
            return new JobListResponse(jobs, status);
        }
    }

    public static Builder builder() {
        return new Builder();
    }
}
