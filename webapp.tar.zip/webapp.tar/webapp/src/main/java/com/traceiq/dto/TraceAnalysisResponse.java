package com.traceiq.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * Response DTO containing comprehensive trace analysis results
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TraceAnalysisResponse {

    /**
     * Unique analysis ID
     */
    private String analysisId;

    /**
     * Trace ID analyzed
     */
    private String traceId;

    /**
     * Overall status (SUCCESS, PARTIAL, FAILED)
     */
    private String status;

    /**
     * Executive summary of the analysis
     */
    private String summary;

    /**
     * Root cause analysis
     */
    private RootCauseAnalysis rootCause;

    /**
     * Code location details
     */
    private CodeLocationDetails codeLocation;

    /**
     * ELK log analysis results
     */
    private ElkAnalysisResult elkAnalysis;

    /**
     * Jira ticket information (if created)
     */
    private JiraTicketInfo jiraTicket;

    /**
     * GitHub related information
     */
    private GitHubInfo githubInfo;

    /**
     * Dynatrace metrics
     */
    private DynatraceMetrics dynatraceMetrics;

    /**
     * Jenkins/Build information
     */
    private BuildInfo buildInfo;

    /**
     * Kubernetes pod status
     */
    private KubernetesInfo kubernetesInfo;

    /**
     * Team and owner information
     */
    private TeamInfo teamInfo;

    /**
     * Recommended actions
     */
    private List<String> recommendedActions;

    /**
     * Fix suggestions
     */
    private List<String> fixSuggestions;

    /**
     * Future guardrails
     */
    private List<String> futureGuardrails;

    /**
     * Production readiness checklist
     */
    private Map<String, Boolean> productionReadiness;

    /**
     * Execution timeline
     */
    private ExecutionTimeline timeline;

    /**
     * Analysis timestamp
     */
    private LocalDateTime analyzedAt;

    /**
     * Processing time in milliseconds
     */
    private Long processingTimeMs;

    /**
     * Tools invoked during analysis
     */
    private List<String> toolsInvoked;

    /**
     * Any warnings or errors during analysis
     */
    private List<String> warnings;

    public String getAnalysisId() {
        return analysisId;
    }

    public void setAnalysisId(String analysisId) {
        this.analysisId = analysisId;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public RootCauseAnalysis getRootCause() {
        return rootCause;
    }

    public void setRootCause(RootCauseAnalysis rootCause) {
        this.rootCause = rootCause;
    }

    public CodeLocationDetails getCodeLocation() {
        return codeLocation;
    }

    public void setCodeLocation(CodeLocationDetails codeLocation) {
        this.codeLocation = codeLocation;
    }

    public ElkAnalysisResult getElkAnalysis() {
        return elkAnalysis;
    }

    public void setElkAnalysis(ElkAnalysisResult elkAnalysis) {
        this.elkAnalysis = elkAnalysis;
    }

    public JiraTicketInfo getJiraTicket() {
        return jiraTicket;
    }

    public void setJiraTicket(JiraTicketInfo jiraTicket) {
        this.jiraTicket = jiraTicket;
    }

    public GitHubInfo getGithubInfo() {
        return githubInfo;
    }

    public void setGithubInfo(GitHubInfo githubInfo) {
        this.githubInfo = githubInfo;
    }

    public DynatraceMetrics getDynatraceMetrics() {
        return dynatraceMetrics;
    }

    public void setDynatraceMetrics(DynatraceMetrics dynatraceMetrics) {
        this.dynatraceMetrics = dynatraceMetrics;
    }

    public BuildInfo getBuildInfo() {
        return buildInfo;
    }

    public void setBuildInfo(BuildInfo buildInfo) {
        this.buildInfo = buildInfo;
    }

    public KubernetesInfo getKubernetesInfo() {
        return kubernetesInfo;
    }

    public void setKubernetesInfo(KubernetesInfo kubernetesInfo) {
        this.kubernetesInfo = kubernetesInfo;
    }

    public TeamInfo getTeamInfo() {
        return teamInfo;
    }

    public void setTeamInfo(TeamInfo teamInfo) {
        this.teamInfo = teamInfo;
    }

    public List<String> getRecommendedActions() {
        return recommendedActions;
    }

    public void setRecommendedActions(List<String> recommendedActions) {
        this.recommendedActions = recommendedActions;
    }

    public List<String> getFixSuggestions() {
        return fixSuggestions;
    }

    public void setFixSuggestions(List<String> fixSuggestions) {
        this.fixSuggestions = fixSuggestions;
    }

    public List<String> getFutureGuardrails() {
        return futureGuardrails;
    }

    public void setFutureGuardrails(List<String> futureGuardrails) {
        this.futureGuardrails = futureGuardrails;
    }

    public Map<String, Boolean> getProductionReadiness() {
        return productionReadiness;
    }

    public void setProductionReadiness(Map<String, Boolean> productionReadiness) {
        this.productionReadiness = productionReadiness;
    }

    public ExecutionTimeline getTimeline() {
        return timeline;
    }

    public void setTimeline(ExecutionTimeline timeline) {
        this.timeline = timeline;
    }

    public LocalDateTime getAnalyzedAt() {
        return analyzedAt;
    }

    public void setAnalyzedAt(LocalDateTime analyzedAt) {
        this.analyzedAt = analyzedAt;
    }

    public Long getProcessingTimeMs() {
        return processingTimeMs;
    }

    public void setProcessingTimeMs(Long processingTimeMs) {
        this.processingTimeMs = processingTimeMs;
    }

    public List<String> getToolsInvoked() {
        return toolsInvoked;
    }

    public void setToolsInvoked(List<String> toolsInvoked) {
        this.toolsInvoked = toolsInvoked;
    }

    public List<String> getWarnings() {
        return warnings;
    }

    public void setWarnings(List<String> warnings) {
        this.warnings = warnings;
    }

    /**
     * Nested class for root cause analysis details
     */
    public static class RootCauseAnalysis {
        private String category;
        private String description;
        private String rootCause;
        private String impactAnalysis;
        private String confidence;
        private List<String> contributingFactors;

        public String getCategory() {
            return category;
        }

        public void setCategory(String category) {
            this.category = category;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getRootCause() {
            return rootCause;
        }

        public void setRootCause(String rootCause) {
            this.rootCause = rootCause;
        }

        public String getImpactAnalysis() {
            return impactAnalysis;
        }

        public void setImpactAnalysis(String impactAnalysis) {
            this.impactAnalysis = impactAnalysis;
        }

        public String getConfidence() {
            return confidence;
        }

        public void setConfidence(String confidence) {
            this.confidence = confidence;
        }

        public List<String> getContributingFactors() {
            return contributingFactors;
        }

        public void setContributingFactors(List<String> contributingFactors) {
            this.contributingFactors = contributingFactors;
        }
    }

    /**
     * Nested class for code location details
     */
    public static class CodeLocationDetails {
        private String repositoryName;
        private String filePath;
        private Integer lineNumber;
        private String codeSnippet;
        private String problematicCode;
        private String suggestedFix;
        private List<String> relatedFiles;

        public String getRepositoryName() {
            return repositoryName;
        }

        public void setRepositoryName(String repositoryName) {
            this.repositoryName = repositoryName;
        }

        public String getFilePath() {
            return filePath;
        }

        public void setFilePath(String filePath) {
            this.filePath = filePath;
        }

        public Integer getLineNumber() {
            return lineNumber;
        }

        public void setLineNumber(Integer lineNumber) {
            this.lineNumber = lineNumber;
        }

        public String getCodeSnippet() {
            return codeSnippet;
        }

        public void setCodeSnippet(String codeSnippet) {
            this.codeSnippet = codeSnippet;
        }

        public String getProblematicCode() {
            return problematicCode;
        }

        public void setProblematicCode(String problematicCode) {
            this.problematicCode = problematicCode;
        }

        public String getSuggestedFix() {
            return suggestedFix;
        }

        public void setSuggestedFix(String suggestedFix) {
            this.suggestedFix = suggestedFix;
        }

        public List<String> getRelatedFiles() {
            return relatedFiles;
        }

        public void setRelatedFiles(List<String> relatedFiles) {
            this.relatedFiles = relatedFiles;
        }
    }

    /**
     * Nested class for ELK analysis results
     */
    public static class ElkAnalysisResult {
        private Integer errorCount;
        private Integer warnCount;
        private Integer infoCount;
        private List<String> errorMessages;
        private Map<String, Object> latencyAnalysis;
        private List<String> flowDiagram;
        private Boolean alertsFound;

        public Integer getErrorCount() {
            return errorCount;
        }

        public void setErrorCount(Integer errorCount) {
            this.errorCount = errorCount;
        }

        public Integer getWarnCount() {
            return warnCount;
        }

        public void setWarnCount(Integer warnCount) {
            this.warnCount = warnCount;
        }

        public Integer getInfoCount() {
            return infoCount;
        }

        public void setInfoCount(Integer infoCount) {
            this.infoCount = infoCount;
        }

        public List<String> getErrorMessages() {
            return errorMessages;
        }

        public void setErrorMessages(List<String> errorMessages) {
            this.errorMessages = errorMessages;
        }

        public Map<String, Object> getLatencyAnalysis() {
            return latencyAnalysis;
        }

        public void setLatencyAnalysis(Map<String, Object> latencyAnalysis) {
            this.latencyAnalysis = latencyAnalysis;
        }

        public List<String> getFlowDiagram() {
            return flowDiagram;
        }

        public void setFlowDiagram(List<String> flowDiagram) {
            this.flowDiagram = flowDiagram;
        }

        public Boolean getAlertsFound() {
            return alertsFound;
        }

        public void setAlertsFound(Boolean alertsFound) {
            this.alertsFound = alertsFound;
        }
    }

    /**
     * Nested class for Jira ticket information
     */
    public static class JiraTicketInfo {
        private String ticketKey;
        private String ticketUrl;
        private String status;
        private String assignee;
        private LocalDateTime createdAt;

        public String getTicketKey() {
            return ticketKey;
        }

        public void setTicketKey(String ticketKey) {
            this.ticketKey = ticketKey;
        }

        public String getTicketUrl() {
            return ticketUrl;
        }

        public void setTicketUrl(String ticketUrl) {
            this.ticketUrl = ticketUrl;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getAssignee() {
            return assignee;
        }

        public void setAssignee(String assignee) {
            this.assignee = assignee;
        }

        public LocalDateTime getCreatedAt() {
            return createdAt;
        }

        public void setCreatedAt(LocalDateTime createdAt) {
            this.createdAt = createdAt;
        }
    }

    /**
     * Nested class for GitHub information
     */
    public static class GitHubInfo {
        private List<String> recentPRs;
        private List<String> codeOwners;
        private String repositoryOverview;
        private String lastCommit;

        public List<String> getRecentPRs() {
            return recentPRs;
        }

        public void setRecentPRs(List<String> recentPRs) {
            this.recentPRs = recentPRs;
        }

        public List<String> getCodeOwners() {
            return codeOwners;
        }

        public void setCodeOwners(List<String> codeOwners) {
            this.codeOwners = codeOwners;
        }

        public String getRepositoryOverview() {
            return repositoryOverview;
        }

        public void setRepositoryOverview(String repositoryOverview) {
            this.repositoryOverview = repositoryOverview;
        }

        public String getLastCommit() {
            return lastCommit;
        }

        public void setLastCommit(String lastCommit) {
            this.lastCommit = lastCommit;
        }
    }

    /**
     * Nested class for Dynatrace metrics
     */
    public static class DynatraceMetrics {
        private Double cpuUsage;
        private Double memoryUsage;
        private Double responseTime;
        private Integer errorRate;
        private List<String> anomalies;

        public Double getCpuUsage() {
            return cpuUsage;
        }

        public void setCpuUsage(Double cpuUsage) {
            this.cpuUsage = cpuUsage;
        }

        public Double getMemoryUsage() {
            return memoryUsage;
        }

        public void setMemoryUsage(Double memoryUsage) {
            this.memoryUsage = memoryUsage;
        }

        public Double getResponseTime() {
            return responseTime;
        }

        public void setResponseTime(Double responseTime) {
            this.responseTime = responseTime;
        }

        public Integer getErrorRate() {
            return errorRate;
        }

        public void setErrorRate(Integer errorRate) {
            this.errorRate = errorRate;
        }

        public List<String> getAnomalies() {
            return anomalies;
        }

        public void setAnomalies(List<String> anomalies) {
            this.anomalies = anomalies;
        }
    }

    /**
     * Nested class for build information
     */
    public static class BuildInfo {
        private String buildNumber;
        private String buildStatus;
        private LocalDateTime buildTime;
        private Boolean sonarCheckPassed;
        private Boolean componentTestsPassed;

        public String getBuildNumber() {
            return buildNumber;
        }

        public void setBuildNumber(String buildNumber) {
            this.buildNumber = buildNumber;
        }

        public String getBuildStatus() {
            return buildStatus;
        }

        public void setBuildStatus(String buildStatus) {
            this.buildStatus = buildStatus;
        }

        public LocalDateTime getBuildTime() {
            return buildTime;
        }

        public void setBuildTime(LocalDateTime buildTime) {
            this.buildTime = buildTime;
        }

        public Boolean getSonarCheckPassed() {
            return sonarCheckPassed;
        }

        public void setSonarCheckPassed(Boolean sonarCheckPassed) {
            this.sonarCheckPassed = sonarCheckPassed;
        }

        public Boolean getComponentTestsPassed() {
            return componentTestsPassed;
        }

        public void setComponentTestsPassed(Boolean componentTestsPassed) {
            this.componentTestsPassed = componentTestsPassed;
        }
    }

    /**
     * Nested class for Kubernetes information
     */
    public static class KubernetesInfo {
        private String podName;
        private String podStatus;
        private Integer restartCount;
        private String namespace;
        private Map<String, String> podLabels;

        public String getPodName() {
            return podName;
        }

        public void setPodName(String podName) {
            this.podName = podName;
        }

        public String getPodStatus() {
            return podStatus;
        }

        public void setPodStatus(String podStatus) {
            this.podStatus = podStatus;
        }

        public Integer getRestartCount() {
            return restartCount;
        }

        public void setRestartCount(Integer restartCount) {
            this.restartCount = restartCount;
        }

        public String getNamespace() {
            return namespace;
        }

        public void setNamespace(String namespace) {
            this.namespace = namespace;
        }

        public Map<String, String> getPodLabels() {
            return podLabels;
        }

        public void setPodLabels(Map<String, String> podLabels) {
            this.podLabels = podLabels;
        }
    }

    /**
     * Nested class for team information
     */
    public static class TeamInfo {
        private String teamName;
        private String ownerEmail;
        private List<String> teamMembers;

        public String getTeamName() {
            return teamName;
        }

        public void setTeamName(String teamName) {
            this.teamName = teamName;
        }

        public String getOwnerEmail() {
            return ownerEmail;
        }

        public void setOwnerEmail(String ownerEmail) {
            this.ownerEmail = ownerEmail;
        }

        public List<String> getTeamMembers() {
            return teamMembers;
        }

        public void setTeamMembers(List<String> teamMembers) {
            this.teamMembers = teamMembers;
        }
    }

    /**
     * Nested class for execution timeline
     */
    public static class ExecutionTimeline {
        private LocalDateTime startTime;
        private LocalDateTime endTime;
        private Map<String, Long> toolExecutionTimes;

        public LocalDateTime getStartTime() {
            return startTime;
        }

        public void setStartTime(LocalDateTime startTime) {
            this.startTime = startTime;
        }

        public LocalDateTime getEndTime() {
            return endTime;
        }

        public void setEndTime(LocalDateTime endTime) {
            this.endTime = endTime;
        }

        public Map<String, Long> getToolExecutionTimes() {
            return toolExecutionTimes;
        }

        public void setToolExecutionTimes(Map<String, Long> toolExecutionTimes) {
            this.toolExecutionTimes = toolExecutionTimes;
        }
    }
}
