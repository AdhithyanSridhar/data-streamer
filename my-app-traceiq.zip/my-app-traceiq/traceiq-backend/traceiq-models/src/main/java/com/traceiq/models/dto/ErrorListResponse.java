package com.traceiq.models.dto;

import com.traceiq.models.domain.ErrorLog;
import java.util.List;

/**
 * Response DTO for errors list API.
 */
public record ErrorListResponse(
    List<ErrorSummary> errors,
    int totalCount,
    int pageNumber,
    int pageSize,
    String status
) {
    /**
     * Summary view of an error for list display.
     */
    public record ErrorSummary(
        String traceId,
        String message,
        String serviceName,
        String microserviceTeam,
        String level,
        String timestamp,
        int count
    ) {}

    public static class Builder {
        private List<ErrorSummary> errors;
        private int totalCount;
        private int pageNumber;
        private int pageSize;
        private String status;

        public Builder errors(List<ErrorSummary> errors) {
            this.errors = errors;
            return this;
        }

        public Builder totalCount(int totalCount) {
            this.totalCount = totalCount;
            return this;
        }

        public Builder pageNumber(int pageNumber) {
            this.pageNumber = pageNumber;
            return this;
        }

        public Builder pageSize(int pageSize) {
            this.pageSize = pageSize;
            return this;
        }

        public Builder status(String status) {
            this.status = status;
            return this;
        }

        public ErrorListResponse build() {
            return new ErrorListResponse(errors, totalCount, pageNumber, pageSize, status);
        }
    }

    public static Builder builder() {
        return new Builder();
    }
}
