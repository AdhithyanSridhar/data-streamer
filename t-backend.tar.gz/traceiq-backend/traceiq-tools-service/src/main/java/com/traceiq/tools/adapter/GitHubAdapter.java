package com.traceiq.tools.adapter;

import com.traceiq.tools.config.ToolsConfig;
import com.traceiq.utils.JsonUtil;
import com.traceiq.utils.RetryUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

/**
 * Adapter for GitHub API integration
 * Link repositories and create PR suggestions
 */
@Component
public class GitHubAdapter {
    private static final Logger logger = LoggerFactory.getLogger(GitHubAdapter.class);

    private final RestTemplate restTemplate;
    private final ToolsConfig toolsConfig;

    public GitHubAdapter(RestTemplate restTemplate, ToolsConfig toolsConfig) {
        this.restTemplate = restTemplate;
        this.toolsConfig = toolsConfig;
    }

    /**
     * Get repository information
     */
    public Map<String, Object> getRepository(String owner, String repo, String correlationId) {
        return RetryUtil.executeWithDefaultRetry(() -> {
            logger.info("[{}] Fetching GitHub repository: {}/{}", correlationId, owner, repo);

            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + toolsConfig.getGithubToken());
            headers.set("Accept", "application/vnd.github+json");
            headers.set("X-Correlation-Id", correlationId);

            HttpEntity<Void> entity = new HttpEntity<>(headers);

            ResponseEntity<String> response = restTemplate.exchange(
                    toolsConfig.getGithubApiUrl() + "/repos/" + owner + "/" + repo,
                    HttpMethod.GET,
                    entity,
                    String.class
            );

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                logger.info("[{}] Repository info fetched successfully", correlationId);
                return JsonUtil.fromJson(response.getBody(), Map.class);
            }

            throw new RuntimeException("Failed to fetch repository");

        }, "GitHub-Get-Repository");
    }

    /**
     * Search code in repository
     */
    public Map<String, Object> searchCode(String query, String correlationId) {
        return RetryUtil.executeWithDefaultRetry(() -> {
            logger.info("[{}] Searching code in GitHub: {}", correlationId, query);

            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + toolsConfig.getGithubToken());
            headers.set("Accept", "application/vnd.github+json");
            headers.set("X-Correlation-Id", correlationId);

            HttpEntity<Void> entity = new HttpEntity<>(headers);

            ResponseEntity<String> response = restTemplate.exchange(
                    toolsConfig.getGithubApiUrl() + "/search/code?q=" + query,
                    HttpMethod.GET,
                    entity,
                    String.class
            );

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                logger.info("[{}] Code search completed successfully", correlationId);
                return JsonUtil.fromJson(response.getBody(), Map.class);
            }

            throw new RuntimeException("Failed to search code");

        }, "GitHub-Search-Code");
    }
}
