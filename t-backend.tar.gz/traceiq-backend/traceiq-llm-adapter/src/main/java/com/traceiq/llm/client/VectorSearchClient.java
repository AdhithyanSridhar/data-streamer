package com.traceiq.llm.client;

import com.traceiq.llm.config.LlmConfig;
import com.traceiq.utils.JsonUtil;
import com.traceiq.utils.RetryUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

/**
 * Client for vectorized codebase LLM API
 * Searches code repository using vector embeddings
 */
@Component
public class VectorSearchClient {
    private static final Logger logger = LoggerFactory.getLogger(VectorSearchClient.class);

    private final RestTemplate restTemplate;
    private final LlmConfig llmConfig;

    public VectorSearchClient(RestTemplate restTemplate, LlmConfig llmConfig) {
        this.restTemplate = restTemplate;
        this.llmConfig = llmConfig;
    }

    /**
     * Search codebase using vector similarity
     *
     * @param query Search query (error message, stack trace, etc.)
     * @param context Additional context for search
     * @param topK Number of results to return
     * @param correlationId Correlation ID for tracking
     * @return Search results with code locations
     */
    public Map<String, Object> searchCode(String query, String context, int topK, String correlationId) {
        return RetryUtil.executeWithDefaultRetry(() -> {
            logger.info("[{}] Searching codebase with vector search", correlationId);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "Bearer " + llmConfig.getVectorApiToken());
            headers.set("X-Correlation-Id", correlationId);

            Map<String, Object> request = Map.of(
                    "query", query,
                    "context", context,
                    "top_k", topK,
                    "include_snippets", true
            );

            HttpEntity<String> entity = new HttpEntity<>(JsonUtil.toJson(request), headers);

            ResponseEntity<String> response = restTemplate.exchange(
                    llmConfig.getVectorApiUrl() + "/api/v1/search",
                    HttpMethod.POST,
                    entity,
                    String.class
            );

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                logger.info("[{}] Vector search completed successfully", correlationId);
                return JsonUtil.fromJson(response.getBody(), Map.class);
            }

            throw new RuntimeException("Invalid response from vector search API");

        }, "Vector-Search-API-Call");
    }

    /**
     * Get code implementation plan from vector LLM
     *
     * @param rcaContext RCA analysis context
     * @param codeLocations Identified code locations
     * @param correlationId Correlation ID for tracking
     * @return Implementation plan with curated prompt
     */
    public Map<String, Object> getImplementationPlan(
            String rcaContext,
            List<Map<String, Object>> codeLocations,
            String correlationId
    ) {
        return RetryUtil.executeWithDefaultRetry(() -> {
            logger.info("[{}] Generating implementation plan from vector LLM", correlationId);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "Bearer " + llmConfig.getVectorApiToken());
            headers.set("X-Correlation-Id", correlationId);

            Map<String, Object> request = Map.of(
                    "rca_context", rcaContext,
                    "code_locations", codeLocations,
                    "generate_curated_prompt", true
            );

            HttpEntity<String> entity = new HttpEntity<>(JsonUtil.toJson(request), headers);

            ResponseEntity<String> response = restTemplate.exchange(
                    llmConfig.getVectorApiUrl() + "/api/v1/implementation-plan",
                    HttpMethod.POST,
                    entity,
                    String.class
            );

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                logger.info("[{}] Implementation plan generated successfully", correlationId);
                return JsonUtil.fromJson(response.getBody(), Map.class);
            }

            throw new RuntimeException("Invalid response from vector LLM API");

        }, "Implementation-Plan-API-Call");
    }
}
