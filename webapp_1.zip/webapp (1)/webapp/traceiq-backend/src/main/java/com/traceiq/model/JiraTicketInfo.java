package com.traceiq.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.List;

/**
 * Jira ticket information.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record JiraTicketInfo(
    String ticketId,
    String title,
    String description,
    String status,
    String priority,
    String assignee,
    List<String> comments,
    List<AttachmentInfo> attachments,
    String url
) {}

@JsonInclude(JsonInclude.Include.NON_NULL)
record AttachmentInfo(
    String filename,
    String url,
    long sizeBytes
) {}
