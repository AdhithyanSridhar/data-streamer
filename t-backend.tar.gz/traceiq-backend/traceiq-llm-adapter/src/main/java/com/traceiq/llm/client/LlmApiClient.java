package com.traceiq.llm.client;

import com.traceiq.llm.config.LlmConfig;
import com.traceiq.utils.JsonUtil;
import com.traceiq.utils.RetryUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

/**
 * Client for making API calls to internal LLM (GPT 4.1)
 * All LLM interactions are plain REST API calls
 */
@Component
public class LlmApiClient {
    private static final Logger logger = LoggerFactory.getLogger(LlmApiClient.class);

    private final RestTemplate restTemplate;
    private final LlmConfig llmConfig;
    private final JtoonClient jtoonClient;

    public LlmApiClient(RestTemplate restTemplate, LlmConfig llmConfig, JtoonClient jtoonClient) {
        this.restTemplate = restTemplate;
        this.llmConfig = llmConfig;
        this.jtoonClient = jtoonClient;
    }

    /**
     * Generate completion from LLM
     *
     * @param prompt The prompt to send
     * @param systemPrompt System prompt for context
     * @param correlationId Correlation ID for tracking
     * @return LLM response
     */
    public String generateCompletion(String prompt, String systemPrompt, String correlationId) {
        return RetryUtil.executeWithDefaultRetry(() -> {
            logger.info("[{}] Generating LLM completion", correlationId);

            // Optimize prompt through jtoon if enabled
            String optimizedPrompt = jtoonClient.optimize(prompt, "rca-analysis");

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "Bearer " + llmConfig.getLlmApiToken());
            headers.set("X-Correlation-Id", correlationId);

            Map<String, Object> request = Map.of(
                    "model", llmConfig.getDefaultModel(),
                    "messages", List.of(
                            Map.of("role", "system", "content", systemPrompt),
                            Map.of("role", "user", "content", optimizedPrompt)
                    ),
                    "max_tokens", llmConfig.getMaxTokens(),
                    "temperature", llmConfig.getTemperature()
            );

            HttpEntity<String> entity = new HttpEntity<>(JsonUtil.toJson(request), headers);

            logger.debug("[{}] Sending request to LLM API: {}", correlationId, llmConfig.getLlmApiUrl());

            ResponseEntity<String> response = restTemplate.exchange(
                    llmConfig.getLlmApiUrl() + "/v1/chat/completions",
                    HttpMethod.POST,
                    entity,
                    String.class
            );

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                Map<String, Object> result = JsonUtil.fromJson(response.getBody(), Map.class);
                List<Map<String, Object>> choices = (List<Map<String, Object>>) result.get("choices");
                if (choices != null && !choices.isEmpty()) {
                    Map<String, Object> message = (Map<String, Object>) choices.get(0).get("message");
                    String content = (String) message.get("content");
                    logger.info("[{}] LLM completion generated successfully", correlationId);
                    return content;
                }
            }

            throw new RuntimeException("Invalid response from LLM API");

        }, "LLM-API-Call");
    }

    /**
     * Generate embedding for text (for vector search)
     */
    public List<Double> generateEmbedding(String text, String correlationId) {
        return RetryUtil.executeWithDefaultRetry(() -> {
            logger.info("[{}] Generating embedding", correlationId);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "Bearer " + llmConfig.getLlmApiToken());
            headers.set("X-Correlation-Id", correlationId);

            Map<String, Object> request = Map.of(
                    "model", "text-embedding-ada-002",
                    "input", text
            );

            HttpEntity<String> entity = new HttpEntity<>(JsonUtil.toJson(request), headers);

            ResponseEntity<String> response = restTemplate.exchange(
                    llmConfig.getLlmApiUrl() + "/v1/embeddings",
                    HttpMethod.POST,
                    entity,
                    String.class
            );

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                Map<String, Object> result = JsonUtil.fromJson(response.getBody(), Map.class);
                List<Map<String, Object>> data = (List<Map<String, Object>>) result.get("data");
                if (data != null && !data.isEmpty()) {
                    return (List<Double>) data.get(0).get("embedding");
                }
            }

            throw new RuntimeException("Invalid response from embedding API");

        }, "Embedding-API-Call");
    }
}
