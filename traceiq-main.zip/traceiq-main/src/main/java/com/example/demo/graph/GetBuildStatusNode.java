package com.example.demo.graph;

import com.example.demo.tools.JenkinsTool;
import org.springframework.stereotype.Component;

@Component
public class GetBuildStatusNode implements Node {

    public static final String NAME = "getBuildStatus";
    private final JenkinsTool jenkinsTool;

    public GetBuildStatusNode(JenkinsTool jenkinsTool) {
        this.jenkinsTool = jenkinsTool;
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public GraphState apply(GraphState state) {
        try {
            // Assuming a relevant pipeline name can be inferred or is provided.
            String pipelineName = state.get("pipelineName");
            if (pipelineName != null) {
                JenkinsTool.BuildStatusResponse response = jenkinsTool.getBuildStatus(new JenkinsTool.BuildStatusRequest(pipelineName));
                state.set("buildStatus", response.status());
            } else {
                state.set(NAME + "_info", "No pipeline name found to get build status.");
            }
        } catch (Exception e) {
            state.set(NAME + "_error", "Failed to get build status: " + e.getMessage());
        }
        return state;
    }
}
