<template>
  <v-row class="stats-overview">
    <v-col v-for="stat in stats" :key="stat.title" cols="6" md="3">
      <div class="stat-card glass-card pa-4">
        <div class="stat-icon">
          <v-icon :icon="stat.icon" size="24"></v-icon>
        </div>
        <div class="stat-content">
          <span class="stat-value">{{ stat.value }}</span>
          <span class="stat-label">{{ stat.title }}</span>
        </div>
        <div class="stat-trend" :class="stat.trendClass">
          <v-icon :icon="stat.trendIcon" size="14"></v-icon>
          <span>{{ stat.trend }}</span>
        </div>
      </div>
    </v-col>
  </v-row>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  workflowData: {
    type: Object,
    required: true
  }
})

const stats = computed(() => {
  const completedTasks = props.workflowData.selectedTasks?.filter(t => t.completed).length || 0
  const totalTasks = props.workflowData.selectedTasks?.length || 0
  
  return [
    {
      title: 'Tasks Completed',
      value: `${completedTasks}/${totalTasks}`,
      icon: 'mdi-check-circle-outline',
      trend: '100%',
      trendIcon: 'mdi-trending-up',
      trendClass: 'trend-up'
    },
    {
      title: 'PR Status',
      value: props.workflowData.pullRequest?.status === 'open' ? 'Open' : 'Merged',
      icon: 'mdi-source-pull',
      trend: 'Active',
      trendIcon: 'mdi-circle',
      trendClass: 'trend-neutral'
    },
    {
      title: 'Tests Passed',
      value: props.workflowData.unitTests?.testCount || 0,
      icon: 'mdi-test-tube',
      trend: '100%',
      trendIcon: 'mdi-check',
      trendClass: 'trend-up'
    },
    {
      title: 'Execution Time',
      value: '2m 43s',
      icon: 'mdi-timer-outline',
      trend: 'Fast',
      trendIcon: 'mdi-lightning-bolt-outline',
      trendClass: 'trend-neutral'
    }
  ]
})
</script>

<style scoped>
.stat-card {
  display: flex;
  flex-direction: column;
  gap: 12px;
  position: relative;
  overflow: hidden;
}

.stat-icon {
  width: 44px;
  height: 44px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f5f5;
  color: #1a1a1a;
}

.stat-content {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.stat-value {
  font-size: 1.5rem;
  font-weight: 700;
  color: #1a1a1a;
  letter-spacing: -0.02em;
}

.stat-label {
  font-size: 0.8rem;
  color: #666666;
  font-weight: 500;
}

.stat-trend {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 0.7rem;
  font-weight: 600;
  padding: 4px 8px;
  border-radius: 12px;
  width: fit-content;
}

.trend-up {
  background: rgba(16, 185, 129, 0.1);
  color: #059669;
}

.trend-down {
  background: rgba(239, 68, 68, 0.1);
  color: #dc2626;
}

.trend-neutral {
  background: #f0f0f0;
  color: #666666;
}

@media (max-width: 600px) {
  .stat-value {
    font-size: 1.25rem;
  }
}
</style>
