package com.traceiq.models.domain;

import java.time.Instant;
import java.util.List;

/**
 * Domain model representing comprehensive trace information.
 * Aggregates multiple error logs and metadata for a single traceId.
 */
public record TraceInfo(
    String traceId,
    double confidenceScore,
    int errorCount,
    List<ErrorLog> errors,
    List<ServiceNode> servicesInvolved,
    TimelineEvent timeline,
    Instant firstOccurrence,
    Instant lastOccurrence,
    String environment
) {
    public static class Builder {
        private String traceId;
        private double confidenceScore;
        private int errorCount;
        private List<ErrorLog> errors;
        private List<ServiceNode> servicesInvolved;
        private TimelineEvent timeline;
        private Instant firstOccurrence;
        private Instant lastOccurrence;
        private String environment;

        public Builder traceId(String traceId) {
            this.traceId = traceId;
            return this;
        }

        public Builder confidenceScore(double confidenceScore) {
            this.confidenceScore = confidenceScore;
            return this;
        }

        public Builder errorCount(int errorCount) {
            this.errorCount = errorCount;
            return this;
        }

        public Builder errors(List<ErrorLog> errors) {
            this.errors = errors;
            return this;
        }

        public Builder servicesInvolved(List<ServiceNode> servicesInvolved) {
            this.servicesInvolved = servicesInvolved;
            return this;
        }

        public Builder timeline(TimelineEvent timeline) {
            this.timeline = timeline;
            return this;
        }

        public Builder firstOccurrence(Instant firstOccurrence) {
            this.firstOccurrence = firstOccurrence;
            return this;
        }

        public Builder lastOccurrence(Instant lastOccurrence) {
            this.lastOccurrence = lastOccurrence;
            return this;
        }

        public Builder environment(String environment) {
            this.environment = environment;
            return this;
        }

        public TraceInfo build() {
            return new TraceInfo(
                traceId, confidenceScore, errorCount, errors,
                servicesInvolved, timeline, firstOccurrence,
                lastOccurrence, environment
            );
        }
    }

    public static Builder builder() {
        return new Builder();
    }
}
