# TraceIQ Backend

AI-powered Root Cause Analysis (RCA) and Error Analysis Platform - Backend Services

## Overview

TraceIQ is a production-grade enterprise application that provides:
- **Automated RCA**: AI-powered root cause analysis using internal LLM (GPT 4.1)
- **Code Location Detection**: Vector search-based code spotting
- **Implementation Plans**: Curated GitHub Copilot prompts for developers
- **Multi-Tool Integration**: ELK, Jira, Dynatrace, GitHub, Jenkins, Kubernetes

## Architecture

### Modules
- **traceiq-models**: Domain models and DTOs (Java 17 records)
- **traceiq-utils**: Shared utilities (JSON, Retry, etc.)
- **traceiq-adapters**: External API adapters (ELK, Jira, Dynatrace, LLM, etc.)
- **traceiq-core**: Main orchestration engine with LangGraph4j flows
- **traceiq-ingest**: Nightly ELK to Cassandra ingestion job

### Tech Stack
- **Java 17** (no Lombok, record classes for DTOs)
- **Spring Boot 3.2.1** (blocking I/O, synchronous)
- **LangChain4j / LangGraph4j** for orchestration
- **Spring AI** for tool calling
- **Cassandra** for error log persistence (with mock mode)
- **Maven 3.8+** for build
- **OpenAPI/Swagger** for API documentation

## Quick Start

### Prerequisites
- Java 17 or higher
- Maven 3.8+
- (Optional) Cassandra 4.x (mock mode available)

### Environment Variables

Copy `.env.dev.example` to `.env.dev` and configure:

```bash
# Core Services
ELK_API_URL=http://localhost:9200
ELK_API_TOKEN=your-elk-token

# LLM Configuration
LLM_API_URL=https://llm-internal.example.com
LLM_API_TOKEN=your-llm-token
VECTOR_API_URL=https://vector-internal.example.com
VECTOR_API_TOKEN=your-vector-token

# External Tools
JIRA_API_URL=https://jira.example.com
JIRA_API_TOKEN=your-jira-token
DYNATRACE_API_URL=https://dynatrace.example.com
DYNATRACE_API_TOKEN=your-dynatrace-token
GITHUB_API_TOKEN=your-github-token
JENKINS_API_URL=http://jenkins.example.com
JENKINS_API_TOKEN=your-jenkins-token
K8S_API_URL=https://kubernetes.default.svc
K8S_API_TOKEN=your-k8s-token

# Database
CASSANDRA_URL=localhost
CASSANDRA_MOCK_ENABLED=true

# Feature Flags
AI_ENABLED=true
JTOON_ENABLED=false
```

### Build

```bash
# Build all modules
cd traceiq-backend
mvn clean install -DskipTests

# Build specific module
cd traceiq-core
mvn clean package
```

### Run

#### Core Service (Port 8080)
```bash
cd traceiq-core
mvn spring-boot:run

# With environment variables
export ELK_API_URL=http://localhost:9200
mvn spring-boot:run
```

#### Ingest Service (Port 8081)
```bash
cd traceiq-ingest
mvn spring-boot:run
```

### API Documentation

Once running, access:
- **Swagger UI**: http://localhost:8080/swagger-ui.html
- **API Docs**: http://localhost:8080/api-docs
- **Health**: http://localhost:8080/api/health

## API Endpoints

### Trace Analysis
- `GET /api/trace/{traceId}` - Search trace by ID
- `POST /api/trace/{traceId}/rca` - Generate RCA
- `POST /api/trace/{traceId}/implementation-plan` - Generate implementation plan
- `POST /api/trace/{traceId}/god-mode` - Run complete analysis (RCA + Plan)

### Error Management
- `GET /api/errors?page=0&size=20` - List all errors (paginated)

### Jobs
- `GET /api/jobs` - List scheduled jobs and execution history

### Health
- `GET /api/health` - Health check
- `GET /api/info` - System information

## LangGraph4j Orchestration

TraceIQ uses LangGraph4j for workflow orchestration:

### RCA Flow
1. **ElkNode**: Fetch error logs by traceID
2. **DynatraceNode**: Enrich with metrics/traces
3. **RcaLLMNode**: Call LLM for root cause analysis
4. **NotifyNode**: Tag owner via email

### Implementation Plan Flow
1. **Get RCA Context**
2. **CodeSearchNode**: Vector search codebase
3. **CodeLLMNode**: Generate implementation plan with GitHub Copilot prompts

## Configuration

### Mock Mode (Default)
```properties
cassandra.mock.enabled=true
ai.enabled=true
```
System returns mock data without external dependencies.

### Production Mode
```properties
cassandra.mock.enabled=false
cassandra.url=cassandra-prod.example.com
ai.enabled=true
jtoon.enabled=true
```

### Disable AI
```properties
ai.enabled=false
```
Returns mock AI responses without LLM calls.

## Prompt Engineering

Located in `PromptTemplates.java`:
- **RCA System Prompt**: Expert SRE persona
- **Implementation Plan Prompt**: Curated for GitHub Copilot
- **Copilot Prompts**: High-quality, reusable prompts for code fixes

Example Copilot prompt structure:
```java
// Context: Fixing RCA issue - NullPointerException
// Task: Add null check before using configuration value
// Requirements: Defensive programming, logging, error handling
```

## Deployment

### Local Development
```bash
mvn spring-boot:run
```

### Production (JAR)
```bash
mvn clean package
java -jar traceiq-core/target/traceiq-core-1.0.0.jar
```

### Docker
```dockerfile
FROM openjdk:17-slim
COPY traceiq-core/target/traceiq-core-1.0.0.jar app.jar
ENTRYPOINT ["java","-jar","/app.jar"]
```

### Kubernetes
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: traceiq-core
spec:
  replicas: 3
  selector:
    matchLabels:
      app: traceiq-core
  template:
    metadata:
      labels:
        app: traceiq-core
    spec:
      containers:
      - name: traceiq-core
        image: traceiq-core:1.0.0
        ports:
        - containerPort: 8080
        env:
        - name: ELK_API_URL
          valueFrom:
            secretKeyRef:
              name: traceiq-secrets
              key: elk-api-url
```

## Monitoring

### Health Endpoints
- `/actuator/health` - Application health
- `/actuator/metrics` - Prometheus metrics
- `/actuator/info` - Application info

### Logging
SLF4J with Logback:
```properties
logging.level.com.traceiq=DEBUG
logging.level.root=INFO
```

## Development Guidelines

- **No Lombok**: Use Java record classes for DTOs
- **Java 17**: Use modern Java features (records, pattern matching)
- **Blocking I/O**: No reactive/WebFlux initially
- **Comprehensive Comments**: Document all public methods
- **Builder Pattern**: For complex object construction
- **Retry Logic**: Use RetryUtils for external calls

## Project Structure
```
traceiq-backend/
├── traceiq-models/          # Domain models (records)
│   └── src/main/java/com/traceiq/models/
├── traceiq-utils/           # Utilities
│   └── src/main/java/com/traceiq/utils/
├── traceiq-adapters/        # External API adapters
│   └── src/main/java/com/traceiq/adapters/
│       ├── elk/
│       ├── jira/
│       ├── llm/
│       └── ...
├── traceiq-core/            # Main application
│   └── src/main/java/com/traceiq/core/
│       ├── controller/
│       ├── service/
│       ├── orchestration/
│       └── prompts/
└── traceiq-ingest/          # Ingest job
    └── src/main/java/com/traceiq/ingest/
```

## Support

For issues or questions:
- Email: support@traceiq.example.com
- Internal Wiki: https://wiki.example.com/traceiq

## License

Internal use only - Proprietary
