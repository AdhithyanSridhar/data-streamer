<template>
  <div>
    <h2 class="text-3xl font-bold mb-6">Trace Search & RCA</h2>
    
    <div class="bg-white p-6 rounded-lg shadow mb-6">
      <div class="mb-4">
        <label class="block text-sm font-medium mb-2">Trace ID</label>
        <input v-model="traceId" type="text" placeholder="Enter trace ID (e.g., abc123-def456)"
               class="w-full px-4 py-2 border rounded focus:ring-2 focus:ring-blue-500">
      </div>
      
      <div class="flex space-x-4 mb-4">
        <button @click="searchBasic" class="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
          <i class="fas fa-search mr-2"></i>Search
        </button>
        <button @click="searchWithRca" class="px-6 py-2 bg-purple-600 text-white rounded hover:bg-purple-700">
          <i class="fas fa-brain mr-2"></i>RCA Analysis
        </button>
        <button @click="searchWithCodeSpot" class="px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700">
          <i class="fas fa-code mr-2"></i>Code Spot
        </button>
        <button @click="searchGodMode" class="px-6 py-2 bg-red-600 text-white rounded hover:bg-red-700">
          <i class="fas fa-bolt mr-2"></i>GodMode
        </button>
      </div>
      
      <div v-if="loading" class="text-center py-8">
        <i class="fas fa-spinner fa-spin text-4xl text-blue-600"></i>
        <p class="mt-4">Analyzing trace...</p>
      </div>
    </div>
    
    <div v-if="result && !loading" class="space-y-6">
      <div class="bg-white p-6 rounded-lg shadow">
        <h3 class="text-xl font-bold mb-4">Trace Summary</h3>
        <div class="grid grid-cols-3 gap-4">
          <div>
            <p class="text-sm text-gray-600">Trace ID</p>
            <p class="font-semibold">{{ result.traceId }}</p>
          </div>
          <div>
            <p class="text-sm text-gray-600">Error Count</p>
            <p class="font-semibold text-red-600">{{ result.errorCount }}</p>
          </div>
          <div>
            <p class="text-sm text-gray-600">Confidence Score</p>
            <p class="font-semibold text-green-600">{{ (result.confidenceScore * 100).toFixed(0) }}%</p>
          </div>
        </div>
      </div>
      
      <div v-if="result.rcaResult" class="bg-white p-6 rounded-lg shadow">
        <h3 class="text-xl font-bold mb-4">
          <i class="fas fa-brain text-purple-600 mr-2"></i>Root Cause Analysis
        </h3>
        <div class="bg-purple-50 p-4 rounded mb-4">
          <p class="whitespace-pre-wrap">{{ result.rcaResult.analysis }}</p>
        </div>
        <div v-if="result.rcaResult.recommendations?.length" class="mb-4">
          <h4 class="font-semibold mb-2">Recommendations:</h4>
          <ul class="list-disc list-inside space-y-1">
            <li v-for="rec in result.rcaResult.recommendations" :key="rec">{{ rec }}</li>
          </ul>
        </div>
      </div>
      
      <div v-if="result.codeSpotResult" class="bg-white p-6 rounded-lg shadow">
        <h3 class="text-xl font-bold mb-4">
          <i class="fas fa-code text-green-600 mr-2"></i>Code Locations
        </h3>
        <div v-for="loc in result.codeSpotResult.codeLocations" :key="loc.filePath" class="mb-4 p-4 bg-gray-50 rounded">
          <p class="font-semibold">{{ loc.repository }} / {{ loc.filePath }}</p>
          <p class="text-sm text-gray-600">Line {{ loc.lineNumber }}: {{ loc.reason }}</p>
          <pre class="mt-2 p-2 bg-gray-800 text-green-400 rounded text-sm">{{ loc.snippet }}</pre>
        </div>
        <div v-if="result.codeSpotResult.implementationPlan" class="mt-4 p-4 bg-blue-50 rounded">
          <h4 class="font-semibold mb-2">Implementation Plan:</h4>
          <p class="whitespace-pre-wrap">{{ result.codeSpotResult.implementationPlan }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import api from '../api/traceiq'

const traceId = ref('')
const loading = ref(false)
const result = ref(null)

const search = async (includeRca, includeCodeSpot, godMode) => {
  if (!traceId.value) return
  loading.value = true
  result.value = null
  try {
    const res = await api.searchTrace(traceId.value, includeRca, includeCodeSpot, godMode)
    result.value = res.data
  } catch (error) {
    console.error('Search failed:', error)
  } finally {
    loading.value = false
  }
}

const searchBasic = () => search(false, false, false)
const searchWithRca = () => search(true, false, false)
const searchWithCodeSpot = () => search(false, true, false)
const searchGodMode = () => search(false, false, true)
</script>
