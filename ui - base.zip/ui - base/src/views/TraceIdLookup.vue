<template>
  <v-container fluid class="pa-6">
    <!-- Page Header -->
    <div class="page-header mb-6">
      <h1 class="page-title">Trace ID Lookup</h1>
      <p class="page-subtitle">Search and analyze distributed traces across your microservices</p>
    </div>

    <!-- Search Box -->
    <div class="glass-card pa-5 mb-6">
      <v-row align="center">
        <v-col cols="12" md="6">
          <v-text-field
            v-model="traceId"
            label="Enter Trace ID"
            variant="outlined"
            density="comfortable"
            prepend-inner-icon="mdi-identifier"
            placeholder="e.g., trace-abc123-def456-789xyz"
            clearable
            @keyup.enter="searchTrace"
          ></v-text-field>
        </v-col>
        <v-col cols="12" md="3">
          <v-checkbox
            v-model="forceRefresh"
            label="Force Refresh (bypass cache)"
            density="compact"
            hide-details
          ></v-checkbox>
        </v-col>
        <v-col cols="12" md="3">
          <v-btn
            color="primary"
            size="large"
            :disabled="!traceId"
            :loading="isLoading"
            @click="searchTrace"
            rounded="lg"
            block
          >
            <v-icon icon="mdi-magnify" class="mr-2"></v-icon>
            Search Trace
          </v-btn>
        </v-col>
      </v-row>
    </div>

    <!-- Results Section -->
    <div v-if="traceData">
      <!-- Timeseries Charts -->
      <v-row class="mb-6">
        <v-col cols="12">
          <div class="glass-card pa-5">
            <div class="section-header mb-4">
              <div class="section-header__icon">
                <v-icon icon="mdi-chart-line" size="20"></v-icon>
              </div>
              <span class="section-header__title">Error Timeline by Microservice</span>
            </div>
            <div class="chart-container">
              <Line :data="timeseriesData" :options="timeseriesOptions" />
            </div>
          </div>
        </v-col>
      </v-row>

      <!-- LLM Reasoning Panel -->
      <div class="glass-card pa-5 mb-6">
        <div class="section-header mb-4">
          <div class="section-header__icon">
            <v-icon icon="mdi-robot-outline" size="20"></v-icon>
          </div>
          <span class="section-header__title">LLM Reasoning & Analysis</span>
          <v-chip variant="outlined" size="small" class="ml-2">AI Generated</v-chip>
        </div>
        
        <v-row>
          <v-col cols="12" md="6">
            <div class="reasoning-card">
              <div class="reasoning-header">
                <v-icon icon="mdi-account-outline"></v-icon>
                <span>RCA Owner</span>
              </div>
              <p class="reasoning-value">{{ traceData.reasoning.rcaOwner }}</p>
            </div>
          </v-col>
          <v-col cols="12" md="3">
            <div class="reasoning-card">
              <div class="reasoning-header">
                <v-icon icon="mdi-clock-outline"></v-icon>
                <span>First Occurred</span>
              </div>
              <p class="reasoning-value">{{ formatDate(traceData.reasoning.firstOccurred) }}</p>
            </div>
          </v-col>
          <v-col cols="12" md="3">
            <div class="reasoning-card">
              <div class="reasoning-header">
                <v-icon icon="mdi-clock-outline"></v-icon>
                <span>Last Occurred</span>
              </div>
              <p class="reasoning-value">{{ formatDate(traceData.reasoning.lastOccurred) }}</p>
            </div>
          </v-col>
        </v-row>
        
        <v-divider class="my-4"></v-divider>
        
        <v-row>
          <v-col cols="12" md="6">
            <div class="reasoning-section">
              <h4><v-icon icon="mdi-magnify" class="mr-1"></v-icon>Probable Root Cause</h4>
              <p>{{ traceData.reasoning.probableRca }}</p>
            </div>
          </v-col>
          <v-col cols="12" md="6">
            <div class="reasoning-section">
              <h4><v-icon icon="mdi-lightbulb-outline" class="mr-1"></v-icon>Top Solution Suggestions</h4>
              <ol class="suggestions-list">
                <li v-for="(suggestion, idx) in traceData.reasoning.suggestions" :key="idx">{{ suggestion }}</li>
              </ol>
            </div>
          </v-col>
        </v-row>
        
        <v-divider class="my-4"></v-divider>
        
        <div class="reasoning-section">
          <h4><v-icon icon="mdi-arrow-right" class="mr-1"></v-icon>Next Steps</h4>
          <div class="next-steps">
            <v-chip v-for="(step, idx) in traceData.reasoning.nextSteps" :key="idx" variant="outlined" class="mr-2 mb-2">
              {{ idx + 1 }}. {{ step }}
            </v-chip>
          </div>
        </div>
      </div>

      <!-- Trace Metadata Section -->
      <div class="glass-card pa-5 mb-6">
        <div class="section-header mb-4">
          <div class="section-header__icon">
            <v-icon icon="mdi-information-outline" size="20"></v-icon>
          </div>
          <span class="section-header__title">Trace Metadata (Kibana Log Fields)</span>
        </div>
        
        <v-row>
          <v-col cols="12" md="3" v-for="(field, idx) in metadataFields" :key="idx">
            <div class="metadata-field">
              <span class="metadata-label">{{ field.label }}</span>
              <span class="metadata-value" :class="{ 'metadata-code': field.isCode }">{{ field.value }}</span>
            </div>
          </v-col>
        </v-row>
      </div>

      <!-- Vertical Timeline View -->
      <div class="glass-card pa-5 mb-6">
        <div class="section-header mb-4">
          <div class="section-header__icon">
            <v-icon icon="mdi-timeline" size="20"></v-icon>
          </div>
          <span class="section-header__title">Trace Timeline</span>
          <v-spacer></v-spacer>
          <span class="timeline-hint">Click on an entry to view details below</span>
        </div>
        <div class="vertical-timeline">
          <div 
            v-for="(span, idx) in traceData.spans" 
            :key="span.id" 
            class="timeline-entry"
            :class="{ 'timeline-entry--selected': selectedSpanId === span.id, 'timeline-entry--error': span.status === 'error' }"
            @click="selectSpan(span)"
          >
            <div class="timeline-line" v-if="idx < traceData.spans.length - 1"></div>
            <div class="timeline-marker">
              <v-icon :icon="span.status === 'error' ? 'mdi-close' : 'mdi-check'" size="14"></v-icon>
            </div>
            <div class="timeline-content">
              <div class="timeline-header">
                <span class="timeline-service">{{ span.service }}</span>
                <span class="timeline-duration">{{ span.duration }}ms</span>
              </div>
              <div class="timeline-operation">{{ span.operation }}</div>
              <div class="timeline-timestamp">{{ span.timestamp }}</div>
            </div>
            <div class="timeline-bar" :style="{ width: `${Math.min(span.duration / 2, 100)}%` }"></div>
          </div>
        </div>
      </div>

      <!-- Detailed Trace Entries Table -->
      <div class="glass-card pa-5" ref="detailsSection">
        <div class="section-header mb-4">
          <div class="section-header__icon">
            <v-icon icon="mdi-table" size="20"></v-icon>
          </div>
          <span class="section-header__title">Detailed Trace Entries</span>
          <v-spacer></v-spacer>
          <v-chip variant="outlined" size="small">{{ traceData.entries.length }} entries</v-chip>
        </div>
        
        <v-data-table :headers="entryHeaders" :items="traceData.entries" class="trace-table" density="comfortable">
          <template v-slot:item.service="{ item }">
            <v-chip variant="outlined" size="small">{{ item.service }}</v-chip>
          </template>
          <template v-slot:item.status="{ item }">
            <v-chip :color="item.status === 'error' ? 'error' : 'success'" variant="flat" size="small">{{ item.status }}</v-chip>
          </template>
          <template v-slot:item.stackTrace="{ item }">
            <v-btn icon variant="text" size="small" @click="openStackTrace(item)" :disabled="!item.stackTrace">
              <v-icon icon="mdi-code-braces"></v-icon>
            </v-btn>
          </template>
          <template v-slot:item.assignAgent="{ item }">
            <v-btn variant="outlined" size="small" rounded="lg" @click="openAssignDialog(item)" :disabled="item.status !== 'error'">
              <v-icon icon="mdi-robot-outline" class="mr-1" size="16"></v-icon>
              Assign
            </v-btn>
          </template>
        </v-data-table>
      </div>
    </div>

    <!-- Empty State -->
    <div v-else class="empty-state glass-card pa-10">
      <v-icon icon="mdi-magnify" size="64" color="grey"></v-icon>
      <h3>Enter a Trace ID to search</h3>
      <p>Search for distributed traces to analyze errors across your microservices</p>
    </div>

    <!-- Stack Trace Dialog -->
    <v-dialog v-model="stackTraceDialog" max-width="900">
      <v-card class="dialog-card">
        <v-card-title class="dialog-title">
          <v-icon icon="mdi-code-braces" class="mr-2"></v-icon>
          Stack Trace - {{ selectedEntry?.service }}
          <v-spacer></v-spacer>
          <v-btn icon variant="text" @click="stackTraceDialog = false"><v-icon icon="mdi-close"></v-icon></v-btn>
        </v-card-title>
        <v-card-text>
          <pre class="stack-trace-content">{{ selectedEntry?.stackTrace }}</pre>
        </v-card-text>
      </v-card>
    </v-dialog>

    <!-- Assign Agent Dialog -->
    <v-dialog v-model="assignDialog" max-width="600">
      <v-card class="dialog-card">
        <v-card-title class="dialog-title">
          <v-icon icon="mdi-robot-outline" class="mr-2"></v-icon>
          Assign Agent
          <v-spacer></v-spacer>
          <v-btn icon variant="text" @click="assignDialog = false"><v-icon icon="mdi-close"></v-icon></v-btn>
        </v-card-title>
        <v-card-text>
          <v-alert type="info" variant="tonal" class="mb-4">Select the agent tasks for this trace entry.</v-alert>
          <v-checkbox v-for="task in agentTasks" :key="task.id" v-model="selectedTasks" :label="task.label" :value="task.id" density="compact" hide-details class="mb-2"></v-checkbox>
        </v-card-text>
        <v-card-actions class="pa-4">
          <v-spacer></v-spacer>
          <v-btn variant="text" @click="assignDialog = false">Cancel</v-btn>
          <v-btn color="primary" variant="flat" @click="assignAgent" :disabled="!selectedTasks.length">
            <v-icon icon="mdi-check" class="mr-1"></v-icon>Assign Agent
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script setup>
import { ref, computed, onMounted, nextTick } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js'
import { Line } from 'vue-chartjs'

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend)

const router = useRouter()
const route = useRoute()
const traceId = ref('')
const forceRefresh = ref(false)
const isLoading = ref(false)
const traceData = ref(null)
const stackTraceDialog = ref(false)
const assignDialog = ref(false)
const selectedEntry = ref(null)
const selectedTasks = ref([])
const selectedSpanId = ref(null)
const detailsSection = ref(null)

const agentTasks = [
  { id: 'rca', label: 'Root Cause Analysis' },
  { id: 'plan', label: 'Generate Implementation Plan' },
  { id: 'pr', label: 'Create Pull Request' },
  { id: 'tests', label: 'Generate Unit Tests' },
  { id: 'merge', label: 'Auto-merge PR' },
  { id: 'close', label: 'Close Issue' }
]

const entryHeaders = [
  { title: 'Service', key: 'service' },
  { title: 'Operation', key: 'operation' },
  { title: 'Status', key: 'status', align: 'center' },
  { title: 'Duration', key: 'duration' },
  { title: 'Error', key: 'error' },
  { title: 'Stack', key: 'stackTrace', align: 'center', sortable: false },
  { title: 'Action', key: 'assignAgent', align: 'center', sortable: false }
]

const metadataFields = computed(() => {
  if (!traceData.value) return []
  return [
    { label: 'Application Name', value: 'payment-service', isCode: false },
    { label: 'Environment', value: 'production', isCode: false },
    { label: 'Cluster', value: 'prod-us-east-1', isCode: false },
    { label: 'Team', value: 'Payments Team', isCode: false },
    { label: 'Owner', value: 'John Doe', isCode: false },
    { label: 'Email', value: 'john.doe@acme.com', isCode: false },
    { label: 'Trace ID', value: traceId.value, isCode: true },
    { label: 'Span ID', value: 'span-142857', isCode: true },
    { label: 'Parent Span ID', value: 'span-142856', isCode: true },
    { label: 'K8s Namespace', value: 'payments-prod', isCode: true },
    { label: 'K8s Container', value: 'payment-service-container', isCode: true },
    { label: 'K8s Pod', value: 'payment-service-7b9d8c', isCode: true },
    { label: 'Log Level', value: 'ERROR', isCode: false },
    { label: 'Timestamp', value: '2024-12-10T14:30:00.123Z', isCode: true },
    { label: 'Host', value: 'ip-10-0-1-142.ec2.internal', isCode: true },
    { label: 'HTTP Method', value: 'POST', isCode: false },
    { label: 'HTTP Path', value: '/api/v1/payments/process', isCode: true },
    { label: 'HTTP Status', value: '500', isCode: false },
    { label: 'User ID', value: 'usr-8374562', isCode: true },
    { label: 'Request ID', value: 'req-9a8b7c6d', isCode: true },
    { label: 'sMsg', value: 'NullPointerException in processTransaction', isCode: false },
    { label: 'Error Type', value: 'java.lang.NullPointerException', isCode: true },
    { label: 'Version', value: 'v2.4.1', isCode: false },
    { label: 'Region', value: 'us-east-1', isCode: false }
  ]
})

onMounted(() => {
  if (route.query.traceId) {
    traceId.value = route.query.traceId
    if (route.query.autoSearch === 'true') {
      searchTrace()
    }
  }
})

const searchTrace = () => {
  isLoading.value = true
  setTimeout(() => {
    traceData.value = {
      reasoning: {
        rcaOwner: 'Payments Team - John Doe',
        firstOccurred: '2024-12-08T10:15:00Z',
        lastOccurred: '2024-12-10T14:30:00Z',
        probableRca: 'The NullPointerException originates from missing null validation in PaymentProcessor.processTransaction() when the transaction context is not properly initialized by upstream services.',
        suggestions: ['Add null check and Optional wrapper for transaction context', 'Implement circuit breaker pattern for upstream service failures'],
        nextSteps: ['Create hotfix PR', 'Add unit tests', 'Deploy to staging', 'Monitor for 24h']
      },
      spans: [
        { id: 1, service: 'api-gateway', operation: 'POST /api/payments', status: 'success', duration: 15, timestamp: '14:30:00.000' },
        { id: 2, service: 'auth-service', operation: 'validateToken', status: 'success', duration: 25, timestamp: '14:30:00.015' },
        { id: 3, service: 'payment-service', operation: 'processTransaction', status: 'error', duration: 142, timestamp: '14:30:00.040' },
        { id: 4, service: 'billing-service', operation: 'createInvoice', status: 'error', duration: 0, timestamp: '14:30:00.182' }
      ],
      entries: [
        { id: 1, service: 'api-gateway', operation: 'POST /api/payments', status: 'success', duration: '15ms', error: '-', stackTrace: null },
        { id: 2, service: 'auth-service', operation: 'validateToken', status: 'success', duration: '25ms', error: '-', stackTrace: null },
        { id: 3, service: 'payment-service', operation: 'processTransaction', status: 'error', duration: '142ms', error: 'NullPointerException', stackTrace: 'java.lang.NullPointerException\n  at com.acme.payment.PaymentProcessor.processTransaction(PaymentProcessor.java:142)\n  at com.acme.payment.PaymentController.handlePayment(PaymentController.java:58)' },
        { id: 4, service: 'billing-service', operation: 'createInvoice', status: 'error', duration: '0ms', error: 'Upstream failure', stackTrace: 'com.acme.billing.UpstreamException: Payment service unavailable\n  at com.acme.billing.PaymentClient.getTransaction(PaymentClient.java:45)' }
      ]
    }
    isLoading.value = false
  }, 1000)
}

const timeseriesData = computed(() => ({
  labels: ['00:00', '04:00', '08:00', '12:00', '14:30', '16:00', '20:00'],
  datasets: [
    { label: 'payment-service', data: [2, 5, 12, 45, 156, 89, 34], borderColor: '#ef4444', backgroundColor: 'rgba(239, 68, 68, 0.1)', tension: 0.3, fill: true },
    { label: 'billing-service', data: [1, 3, 8, 25, 89, 56, 23], borderColor: '#f59e0b', backgroundColor: 'rgba(245, 158, 11, 0.1)', tension: 0.3, fill: true },
    { label: 'api-gateway', data: [0, 1, 3, 12, 23, 15, 8], borderColor: '#3b82f6', backgroundColor: 'rgba(59, 130, 246, 0.1)', tension: 0.3, fill: true },
    { label: 'auth-service', data: [0, 0, 2, 5, 12, 8, 4], borderColor: '#10b981', backgroundColor: 'rgba(16, 185, 129, 0.1)', tension: 0.3, fill: true }
  ]
}))

const timeseriesOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: { position: 'bottom', labels: { color: '#666666', usePointStyle: true } }
  },
  scales: {
    x: { title: { display: true, text: 'Timestamp', color: '#666666' }, grid: { color: '#e5e5e5' }, ticks: { color: '#666666' } },
    y: { title: { display: true, text: 'Error Count', color: '#666666' }, grid: { color: '#e5e5e5' }, ticks: { color: '#666666' } }
  }
}

const selectSpan = async (span) => {
  selectedSpanId.value = span.id
  await nextTick()
  detailsSection.value?.scrollIntoView({ behavior: 'smooth', block: 'start' })
}

const formatDate = (date) => new Date(date).toLocaleString()
const openStackTrace = (entry) => { selectedEntry.value = entry; stackTraceDialog.value = true }
const openAssignDialog = (entry) => { selectedEntry.value = entry; selectedTasks.value = []; assignDialog.value = true }
const assignAgent = () => { assignDialog.value = false; router.push({ path: '/agent-view', query: { traceId: traceId.value, entryId: selectedEntry.value?.id, tasks: selectedTasks.value.join(',') } }) }
</script>

<style scoped>
.page-header { text-align: center; padding: 20px 0; }
.page-title { font-size: 1.75rem; font-weight: 700; color: #1a1a1a; margin-bottom: 8px; }
.page-subtitle { font-size: 0.95rem; color: #666666; }
.chart-container { height: 300px; }

.reasoning-card { background: #f5f5f5; border-radius: 8px; padding: 16px; height: 100%; }
.reasoning-header { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; font-size: 0.8rem; color: #666666; }
.reasoning-value { font-size: 0.95rem; font-weight: 600; color: #1a1a1a; margin: 0; }
.reasoning-section h4 { font-size: 0.9rem; color: #1a1a1a; margin-bottom: 10px; display: flex; align-items: center; }
.reasoning-section p, .reasoning-section ol { color: #666666; line-height: 1.6; margin: 0; }
.suggestions-list { padding-left: 20px; margin: 0; }
.suggestions-list li { margin-bottom: 6px; }
.next-steps { display: flex; flex-wrap: wrap; }

.metadata-field { display: flex; flex-direction: column; gap: 4px; padding: 8px 0; border-bottom: 1px solid #e5e5e5; }
.metadata-label { font-size: 0.7rem; color: #999999; text-transform: uppercase; letter-spacing: 0.5px; }
.metadata-value { font-size: 0.85rem; color: #1a1a1a; font-weight: 500; }
.metadata-code { font-family: monospace; background: #f5f5f5; padding: 2px 6px; border-radius: 4px; font-size: 0.8rem; }

.vertical-timeline { display: flex; flex-direction: column; }
.timeline-entry { display: flex; align-items: flex-start; gap: 16px; padding: 16px; border-radius: 8px; cursor: pointer; position: relative; transition: background 0.2s; }
.timeline-entry:hover { background: #f5f5f5; }
.timeline-entry--selected { background: #f0f0f0 !important; border: 1px solid #1a1a1a; }
.timeline-entry--error .timeline-marker { background: rgba(239, 68, 68, 0.1); border-color: #ef4444; color: #ef4444; }
.timeline-line { position: absolute; left: 27px; top: 48px; bottom: -16px; width: 2px; background: #e5e5e5; }
.timeline-marker { width: 28px; height: 28px; border-radius: 50%; border: 2px solid #10b981; background: rgba(16, 185, 129, 0.1); display: flex; align-items: center; justify-content: center; color: #10b981; flex-shrink: 0; z-index: 1; }
.timeline-content { flex: 1; }
.timeline-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; }
.timeline-service { font-weight: 600; color: #1a1a1a; }
.timeline-duration { font-family: monospace; font-size: 0.8rem; color: #666666; }
.timeline-operation { font-size: 0.85rem; color: #666666; }
.timeline-timestamp { font-size: 0.75rem; color: #999999; margin-top: 4px; }
.timeline-bar { height: 3px; background: #1a1a1a; border-radius: 2px; margin-top: 8px; opacity: 0.2; }
.timeline-hint { font-size: 0.75rem; color: #999999; }

.empty-state { display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 16px; text-align: center; min-height: 300px; }
.empty-state h3 { color: #1a1a1a; font-weight: 600; }
.empty-state p { color: #666666; }

.trace-table { background: transparent !important; }
.dialog-card { background: #ffffff !important; }
.dialog-title { display: flex; align-items: center; background: #f5f5f5; padding: 16px 20px !important; color: #1a1a1a; }
.stack-trace-content { background: #1a1a1a; padding: 16px; border-radius: 8px; font-family: monospace; font-size: 0.75rem; color: #e5e5e5; overflow-x: auto; white-space: pre-wrap; max-height: 400px; }
</style>
