<template>
  <div class="skeleton-loader" :class="`skeleton-loader--${type}`">
    <template v-if="type === 'card'">
      <div class="skeleton-header">
        <div class="skeleton-avatar skeleton"></div>
        <div class="skeleton-title skeleton"></div>
      </div>
      <div class="skeleton-body">
        <div class="skeleton-line skeleton" style="width: 100%"></div>
        <div class="skeleton-line skeleton" style="width: 80%"></div>
        <div class="skeleton-line skeleton" style="width: 60%"></div>
      </div>
    </template>
    
    <template v-else-if="type === 'table'">
      <div class="skeleton-table-row" v-for="i in rows" :key="i">
        <div class="skeleton-cell skeleton" v-for="j in cols" :key="j"></div>
      </div>
    </template>
    
    <template v-else-if="type === 'chart'">
      <div class="skeleton-chart skeleton"></div>
    </template>
    
    <template v-else-if="type === 'stats'">
      <div class="skeleton-stat" v-for="i in 4" :key="i">
        <div class="skeleton-stat-icon skeleton"></div>
        <div class="skeleton-stat-content">
          <div class="skeleton-stat-value skeleton"></div>
          <div class="skeleton-stat-label skeleton"></div>
        </div>
      </div>
    </template>
    
    <template v-else>
      <div class="skeleton-block skeleton"></div>
    </template>
  </div>
</template>

<script setup>
defineProps({
  type: {
    type: String,
    default: 'block' // card, table, chart, stats, block
  },
  rows: {
    type: Number,
    default: 5
  },
  cols: {
    type: Number,
    default: 4
  }
})
</script>

<style scoped>
.skeleton-loader {
  width: 100%;
}

@keyframes shimmer {
  0% { background-position: -200% 0; }
  100% { background-position: 200% 0; }
}

.skeleton {
  background: linear-gradient(90deg, #f0f0f0 25%, #e5e5e5 50%, #f0f0f0 75%);
  background-size: 200% 100%;
  animation: shimmer 1.5s infinite;
  border-radius: 6px;
}

/* Card Skeleton */
.skeleton-header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
}

.skeleton-avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  flex-shrink: 0;
}

.skeleton-title {
  height: 20px;
  flex: 1;
}

.skeleton-body {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.skeleton-line {
  height: 14px;
}

/* Table Skeleton */
.skeleton-table-row {
  display: flex;
  gap: 16px;
  padding: 12px 0;
  border-bottom: 1px solid #f0f0f0;
}

.skeleton-cell {
  flex: 1;
  height: 18px;
}

/* Chart Skeleton */
.skeleton-chart {
  height: 250px;
  border-radius: 8px;
}

/* Stats Skeleton */
.skeleton-loader--stats {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
}

.skeleton-stat {
  background: #ffffff;
  padding: 16px;
  border-radius: 12px;
  border: 1px solid #e5e5e5;
}

.skeleton-stat-icon {
  width: 40px;
  height: 40px;
  border-radius: 8px;
  margin-bottom: 12px;
}

.skeleton-stat-content {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.skeleton-stat-value {
  height: 28px;
  width: 60%;
}

.skeleton-stat-label {
  height: 14px;
  width: 80%;
}

/* Block Skeleton */
.skeleton-block {
  height: 200px;
  border-radius: 8px;
}

@media (max-width: 960px) {
  .skeleton-loader--stats {
    grid-template-columns: repeat(2, 1fr);
  }
}
</style>
