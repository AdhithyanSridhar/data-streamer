package com.att.traceiq.model;

import jakarta.validation.constraints.NotBlank;

public record TraceRequest(
    @NotBlank(message = "TraceID is required")
    String traceId,

    String environment,
    boolean createJiraIfError,
    boolean skipAIAnalysis
) {
    public TraceRequest {
        environment = environment != null ? environment : "prod";
    }
}
