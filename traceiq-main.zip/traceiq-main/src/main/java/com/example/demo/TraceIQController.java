package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TraceIQController {

  private final TraceIQService traceIQService;

  @Autowired
  public TraceIQController(TraceIQService traceIQService) {
    this.traceIQService = traceIQService;
  }

  @GetMapping("/trace")
  public String trace(@RequestParam String traceId) {
    return traceIQService.trace(traceId);
  }
}
