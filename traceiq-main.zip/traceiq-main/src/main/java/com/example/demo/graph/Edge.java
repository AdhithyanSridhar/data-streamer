package com.example.demo.graph;

/**
 * Represents a directed edge in the graph, connecting a `from` node to a `to` node.
 *
 * @param from The name of the source node.
 * @param to The name of the destination node.
 */
public record Edge(String from, String to) {}
