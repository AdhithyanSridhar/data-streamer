package com.traceiq.service;

import com.traceiq.dto.TraceAnalysisRequest;
import com.traceiq.dto.TraceAnalysisResponse;
import com.traceiq.orchestrator.TraceAnalysisOrchestrator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Service layer for trace analysis operations
 * Provides caching and async execution capabilities
 */
@Service
@Validated
public class TraceAnalysisService {
    public static final Logger log = LoggerFactory.getLogger(TraceAnalysisService.class);

    private final TraceAnalysisOrchestrator orchestrator;

    public TraceAnalysisService(TraceAnalysisOrchestrator orchestrator) {
        this.orchestrator = orchestrator;
    }

    /**
     * Performs synchronous trace analysis
     * Results are cached for 1 hour
     */
    @Cacheable(value = "traceAnalysis", key = "#request.traceId + '-' + #request.environment")
    public TraceAnalysisResponse analyzeTrace(TraceAnalysisRequest request) {
        log.info("Starting trace analysis for: {}", request.getTraceId());

        // Validate request
        validateRequest(request);

        // Execute orchestrated analysis
        TraceAnalysisResponse response = orchestrator.orchestrateAnalysis(request);

        log.info("Trace analysis completed. Status: {}", response.getStatus());
        return response;
    }

    /**
     * Performs asynchronous trace analysis
     * Returns CompletableFuture for non-blocking execution
     */
    public CompletableFuture<TraceAnalysisResponse> analyzeTraceAsync(TraceAnalysisRequest request) {
        log.info("Starting async trace analysis for: {}", request.getTraceId());

        return CompletableFuture.supplyAsync(() -> analyzeTrace(request));
    }

    /**
     * Batch analysis for multiple traces
     */
    public List<TraceAnalysisResponse> analyzeBatch(List<TraceAnalysisRequest> requests) {
        log.info("Starting batch analysis for {} traces", requests.size());

        return requests.stream()
                .map(this::analyzeTrace)
                .toList();
    }

    /**
     * Validates the analysis request
     */
    private void validateRequest(TraceAnalysisRequest request) {
        if (request.getTraceId() == null && request.getErrorDetails() == null) {
            throw new IllegalArgumentException("Either traceId or errorDetails must be provided");
        }

        if (request.getEnvironment() == null ||
                (!request.getEnvironment().equalsIgnoreCase("test") &&
                        !request.getEnvironment().equalsIgnoreCase("prod"))) {
            throw new IllegalArgumentException("Environment must be 'test' or 'prod'");
        }
    }
}
