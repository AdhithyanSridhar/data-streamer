package com.traceiq.controller;

import com.traceiq.dto.TraceAnalysisRequest;
import com.traceiq.dto.TraceAnalysisResponse;
import com.traceiq.service.TraceAnalysisService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * REST Controller for Trace Analysis operations
 * Provides endpoints for trace analysis, RCA, and insights
 */
@RestController
@RequestMapping("/v1/analysis")
@Tag(name = "Trace Analysis", description = "AI-Powered Trace Analysis and RCA APIs")
public class TraceAnalysisController {
    public static final Logger log = LoggerFactory.getLogger(TraceAnalysisController.class);

    private final TraceAnalysisService analysisService;

    public TraceAnalysisController(TraceAnalysisService analysisService) {
        this.analysisService = analysisService;
    }

    /**
     * POST /v1/analysis/trace
     * Performs comprehensive trace analysis
     */
    @PostMapping("/trace")
    @Operation(summary = "Analyze Trace", description = "Performs AI-powered trace analysis with RCA")
    public ResponseEntity<TraceAnalysisResponse> analyzeTrace(
            @Valid @RequestBody TraceAnalysisRequest request) {

        log.info("Received trace analysis request for trace: {}", request.getTraceId());

        try {
            TraceAnalysisResponse response = analysisService.analyzeTrace(request);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            log.error("Invalid request: {}", e.getMessage());
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            log.error("Error analyzing trace", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * POST /v1/analysis/trace/async
     * Performs asynchronous trace analysis
     */
    @PostMapping("/trace/async")
    @Operation(summary = "Analyze Trace (Async)", description = "Performs async trace analysis")
    public CompletableFuture<ResponseEntity<TraceAnalysisResponse>> analyzeTraceAsync(
            @Valid @RequestBody TraceAnalysisRequest request) {

        log.info("Received async trace analysis request for trace: {}", request.getTraceId());

        return analysisService.analyzeTraceAsync(request)
                .thenApply(ResponseEntity::ok)
                .exceptionally(e -> {
                    log.error("Error in async analysis", e);
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
                });
    }

    /**
     * POST /v1/analysis/batch
     * Performs batch analysis for multiple traces
     */
    @PostMapping("/batch")
    @Operation(summary = "Batch Analysis", description = "Analyzes multiple traces in parallel")
    public ResponseEntity<List<TraceAnalysisResponse>> analyzeBatch(
            @Valid @RequestBody List<TraceAnalysisRequest> requests) {

        log.info("Received batch analysis request for {} traces", requests.size());

        try {
            List<TraceAnalysisResponse> responses = analysisService.analyzeBatch(requests);
            return ResponseEntity.ok(responses);
        } catch (Exception e) {
            log.error("Error in batch analysis", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * GET /v1/analysis/health
     * Health check endpoint
     */
    @GetMapping("/health")
    @Operation(summary = "Health Check", description = "Checks if the analysis service is healthy")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("TraceIQ Analysis Service is running");
    }
}
