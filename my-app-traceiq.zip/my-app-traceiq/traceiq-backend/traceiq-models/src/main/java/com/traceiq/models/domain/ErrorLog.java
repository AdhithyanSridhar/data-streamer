package com.traceiq.models.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * Domain model representing an error log entry from ELK.
 * Stored in Cassandra after nightly ingestion.
 */
public record ErrorLog(
    String traceId,
    String message,
    String level,
    String serviceName,
    String microserviceTeam,
    String ownerEmail,
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = "UTC")
    Instant timestamp,
    String environment,
    String stackTrace,
    Map<String, Object> additionalFields,
    List<String> tags
) {
    /**
     * Builder for ErrorLog to facilitate construction.
     */
    public static class Builder {
        private String traceId;
        private String message;
        private String level;
        private String serviceName;
        private String microserviceTeam;
        private String ownerEmail;
        private Instant timestamp;
        private String environment;
        private String stackTrace;
        private Map<String, Object> additionalFields;
        private List<String> tags;

        public Builder traceId(String traceId) {
            this.traceId = traceId;
            return this;
        }

        public Builder message(String message) {
            this.message = message;
            return this;
        }

        public Builder level(String level) {
            this.level = level;
            return this;
        }

        public Builder serviceName(String serviceName) {
            this.serviceName = serviceName;
            return this;
        }

        public Builder microserviceTeam(String microserviceTeam) {
            this.microserviceTeam = microserviceTeam;
            return this;
        }

        public Builder ownerEmail(String ownerEmail) {
            this.ownerEmail = ownerEmail;
            return this;
        }

        public Builder timestamp(Instant timestamp) {
            this.timestamp = timestamp;
            return this;
        }

        public Builder environment(String environment) {
            this.environment = environment;
            return this;
        }

        public Builder stackTrace(String stackTrace) {
            this.stackTrace = stackTrace;
            return this;
        }

        public Builder additionalFields(Map<String, Object> additionalFields) {
            this.additionalFields = additionalFields;
            return this;
        }

        public Builder tags(List<String> tags) {
            this.tags = tags;
            return this;
        }

        public ErrorLog build() {
            return new ErrorLog(
                traceId, message, level, serviceName, microserviceTeam,
                ownerEmail, timestamp, environment, stackTrace,
                additionalFields, tags
            );
        }
    }

    public static Builder builder() {
        return new Builder();
    }
}
