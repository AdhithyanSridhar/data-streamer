package com.traceiq.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Main Spring Boot application for TraceIQ
 * Combines all microservices into a single deployable application
 */
@SpringBootApplication
@EnableScheduling
@ComponentScan(basePackages = {
        "com.traceiq.app",
        "com.traceiq.core",
        "com.traceiq.ingest",
        "com.traceiq.tools",
        "com.traceiq.llm"
})
public class TraceIqApplication {
    public static void main(String[] args) {
        SpringApplication.run(TraceIqApplication.class, args);
    }
}
