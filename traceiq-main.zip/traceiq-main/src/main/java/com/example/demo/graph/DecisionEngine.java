package com.example.demo.graph;

import dev.langchain4j.model.chat.ChatLanguageModel;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class DecisionEngine {

  private final ChatLanguageModel chatLanguageModel;
  private final boolean jtoonEnabled;

  public DecisionEngine(
      ChatLanguageModel chatLanguageModel, @Value("${jtoon.enabled:false}") boolean jtoonEnabled) {
    this.chatLanguageModel = chatLanguageModel;
    this.jtoonEnabled = jtoonEnabled;
  }

  public String decideNextNode(GraphState state, Map<String, Node> nodes) {
    String availableNodes = String.join(", ", nodes.keySet());
    String prompt;

    if (jtoonEnabled) {
      prompt = createJtoonPrompt(state, availableNodes);
    } else {
      prompt = createPlaintextPrompt(state, availableNodes);
    }

    String decision = chatLanguageModel.generate(prompt);
    String nextNode = decision.trim().replaceAll("['\"`\\.\\s]", "");

    if (nodes.containsKey(nextNode) || "finish".equals(nextNode)) {
      return nextNode;
    } else {
      System.err.println(
          "LLM returned an invalid next node: '"
              + decision
              + "'. Valid options are: "
              + availableNodes
              + ", or 'finish'. Finishing workflow as a safeguard.");
      return "finish";
    }
  }

  private String createPlaintextPrompt(GraphState state, String availableNodes) {
    return String.format(
        "You are an expert at triaging software issues. "
            + "Based on the current state of the investigation, please decide the next best action to take. "
            + "The investigation is complete when you have gathered enough information to form a root cause analysis and suggest solutions. "
            + "Current state: %s. "
            + "Available tools: [%s]. "
            + "Your response MUST be a single word, choosing from the available tools or 'finish' if the investigation is complete or cannot proceed.",
        state.toString(), availableNodes);
  }

  private String createJtoonPrompt(GraphState state, String availableNodes) {
    // This is a simplified JTOON prompt. A real implementation would likely be more complex.
    return String.format(
        "{\n"
            + "  \"task\": \"triage_software_issue\",\n"
            + "  \"state\": %s,\n"
            + "  \"options\": [\"%s\", \"finish\"]\n"
            + "}",
        state.toJson(), availableNodes.replace(", ", "\", \""));
  }
}
