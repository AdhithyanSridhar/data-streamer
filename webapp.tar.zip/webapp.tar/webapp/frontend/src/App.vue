<template>
  <div id="app" class="min-h-screen bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg">
      <div class="max-w-7xl mx-auto px-4">
        <div class="flex justify-between h-16">
          <div class="flex items-center">
            <i class="fas fa-search-location text-blue-600 text-2xl mr-3"></i>
            <span class="text-xl font-bold text-gray-800">TraceIQ</span>
            <span class="ml-2 px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded">AI-Powered</span>
          </div>
          
          <div class="flex items-center space-x-8">
            <router-link to="/" class="text-gray-700 hover:text-blue-600 font-medium">
              <i class="fas fa-chart-line mr-2"></i>Dashboard
            </router-link>
            <router-link to="/analysis" class="text-gray-700 hover:text-blue-600 font-medium">
              <i class="fas fa-microscope mr-2"></i>Trace Analysis
            </router-link>
          </div>
        </div>
      </div>
    </nav>

    <!-- Main Content -->
    <main class="max-w-7xl mx-auto px-4 py-8">
      <router-view />
    </main>

    <!-- Footer -->
    <footer class="bg-white border-t mt-12">
      <div class="max-w-7xl mx-auto px-4 py-4 text-center text-gray-600 text-sm">
        <p>TraceIQ - Improving Developer & Tester Productivity | v1.0.0</p>
      </div>
    </footer>
  </div>
</template>

<script setup>
// App-level setup
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
</style>
