package com.traceiq.tools.adapter;

import com.traceiq.tools.config.ToolsConfig;
import com.traceiq.utils.JsonUtil;
import com.traceiq.utils.RetryUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

/**
 * Adapter for Jira API integration
 * Creates and updates Jira tickets via Spring AI tool calling
 */
@Component
public class JiraAdapter {
    private static final Logger logger = LoggerFactory.getLogger(JiraAdapter.class);

    private final RestTemplate restTemplate;
    private final ToolsConfig toolsConfig;

    public JiraAdapter(RestTemplate restTemplate, ToolsConfig toolsConfig) {
        this.restTemplate = restTemplate;
        this.toolsConfig = toolsConfig;
    }

    /**
     * Create Jira ticket for an issue
     */
    public Map<String, Object> createTicket(
            String summary,
            String description,
            String priority,
            String assignee,
            String correlationId
    ) {
        return RetryUtil.executeWithDefaultRetry(() -> {
            logger.info("[{}] Creating Jira ticket: {}", correlationId, summary);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "Bearer " + toolsConfig.getJiraApiToken());
            headers.set("X-Correlation-Id", correlationId);

            Map<String, Object> issueData = Map.of(
                    "fields", Map.of(
                            "project", Map.of("key", "TRACEIQ"),
                            "summary", summary,
                            "description", description,
                            "issuetype", Map.of("name", "Bug"),
                            "priority", Map.of("name", priority),
                            "assignee", Map.of("name", assignee),
                            "labels", List.of("auto-generated", "rca", "traceiq")
                    )
            );

            HttpEntity<String> entity = new HttpEntity<>(JsonUtil.toJson(issueData), headers);

            ResponseEntity<String> response = restTemplate.exchange(
                    toolsConfig.getJiraApiUrl() + "/rest/api/3/issue",
                    HttpMethod.POST,
                    entity,
                    String.class
            );

            if (response.getStatusCode() == HttpStatus.CREATED && response.getBody() != null) {
                Map<String, Object> result = JsonUtil.fromJson(response.getBody(), Map.class);
                logger.info("[{}] Jira ticket created: {}", correlationId, result.get("key"));
                return result;
            }

            throw new RuntimeException("Failed to create Jira ticket");

        }, "Jira-Create-Ticket");
    }

    /**
     * Update existing Jira ticket
     */
    public void updateTicket(String ticketKey, String comment, String correlationId) {
        RetryUtil.executeWithDefaultRetry(() -> {
            logger.info("[{}] Updating Jira ticket: {}", correlationId, ticketKey);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "Bearer " + toolsConfig.getJiraApiToken());
            headers.set("X-Correlation-Id", correlationId);

            Map<String, Object> commentData = Map.of(
                    "body", comment
            );

            HttpEntity<String> entity = new HttpEntity<>(JsonUtil.toJson(commentData), headers);

            restTemplate.exchange(
                    toolsConfig.getJiraApiUrl() + "/rest/api/3/issue/" + ticketKey + "/comment",
                    HttpMethod.POST,
                    entity,
                    String.class
            );

            logger.info("[{}] Jira ticket updated successfully", correlationId);
            return null;

        }, "Jira-Update-Ticket");
    }
}
