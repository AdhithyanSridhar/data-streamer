package com.traceiq.models.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.traceiq.models.enums.JobStatus;

import java.time.Instant;

/**
 * Domain model representing a job execution run
 */
public record JobRun(
        String jobId,
        String jobName,
        JobStatus status,
        @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = "UTC")
        Instant startTime,
        @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = "UTC")
        Instant endTime,
        Long recordsProcessed,
        String errorMessage
) {
    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String jobId;
        private String jobName;
        private JobStatus status;
        private Instant startTime;
        private Instant endTime;
        private Long recordsProcessed;
        private String errorMessage;

        public Builder jobId(String jobId) {
            this.jobId = jobId;
            return this;
        }

        public Builder jobName(String jobName) {
            this.jobName = jobName;
            return this;
        }

        public Builder status(JobStatus status) {
            this.status = status;
            return this;
        }

        public Builder startTime(Instant startTime) {
            this.startTime = startTime;
            return this;
        }

        public Builder endTime(Instant endTime) {
            this.endTime = endTime;
            return this;
        }

        public Builder recordsProcessed(Long recordsProcessed) {
            this.recordsProcessed = recordsProcessed;
            return this;
        }

        public Builder errorMessage(String errorMessage) {
            this.errorMessage = errorMessage;
            return this;
        }

        public JobRun build() {
            return new JobRun(
                    jobId,
                    jobName,
                    status,
                    startTime,
                    endTime,
                    recordsProcessed,
                    errorMessage
            );
        }
    }
}
