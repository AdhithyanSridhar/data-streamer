package com.att.traceiq.model;

import java.util.List;

public record ErrorContext(
    String errorType,
    String errorMessage,
    List<String> stackTrace,
    String affectedService,
    boolean isConfigIssue,
    List<String> relatedServices
) {}
