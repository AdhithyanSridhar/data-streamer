package com.traceiq.ingest.job;

import com.traceiq.adapters.cassandra.CassandraRepository;
import com.traceiq.adapters.elk.ElkAdapter;
import com.traceiq.models.domain.ErrorLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Component
public class ElkIngestJob {
    
    private static final Logger logger = LoggerFactory.getLogger(ElkIngestJob.class);
    
    private final ElkAdapter elkAdapter;
    private final CassandraRepository cassandraRepository;
    
    public ElkIngestJob(ElkAdapter elkAdapter, CassandraRepository cassandraRepository) {
        this.elkAdapter = elkAdapter;
        this.cassandraRepository = cassandraRepository;
    }
    
    @Scheduled(cron = "${ingest.schedule:0 0 2 * * ?}")
    public void ingestErrors() {
        logger.info("Starting ELK to Cassandra ingestion job");
        
        Instant now = Instant.now();
        Instant yesterday = now.minus(1, ChronoUnit.DAYS);
        
        try {
            List<ErrorLog> errors = elkAdapter.getAllErrors(yesterday, now);
            logger.info("Retrieved {} errors from ELK", errors.size());
            
            cassandraRepository.saveAll(errors);
            logger.info("Successfully saved {} errors to Cassandra", errors.size());
            
        } catch (Exception e) {
            logger.error("Ingestion job failed", e);
        }
        
        logger.info("ELK to Cassandra ingestion job completed");
    }
}
