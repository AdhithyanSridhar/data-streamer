package com.traceiq.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Client for Jira API operations
 */
@Component
public class JiraClient {
    public static final Logger log = LoggerFactory.getLogger(JiraClient.class);

    @Qualifier("jiraWebClient")
    private final WebClient jiraWebClient;

    public JiraClient(WebClient jiraWebClient) {
        this.jiraWebClient = jiraWebClient;
    }

    public Map<String, Object> createTicket(String projectKey, String summary, String description,
                                            String issueType, String priority, String assignee) {
        log.info("Creating Jira ticket in project: {}", projectKey);

        Map<String, Object> fields = new HashMap<>();
        fields.put("project", Map.of("key", projectKey));
        fields.put("summary", summary);
        fields.put("description", description);
        fields.put("issuetype", Map.of("name", issueType != null ? issueType : "Bug"));

        if (priority != null) {
            fields.put("priority", Map.of("name", priority));
        }
        if (assignee != null) {
            fields.put("assignee", Map.of("name", assignee));
        }

        Map<String, Object> request = Map.of("fields", fields);

        try {
            return jiraWebClient.post()
                    .uri("/rest/api/3/issue")
                    .bodyValue(request)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();
        } catch (Exception e) {
            log.error("Error creating Jira ticket", e);
            return Map.of("error", e.getMessage());
        }
    }

    public Map<String, Object> getTicketDetails(String ticketKey) {
        log.info("Fetching Jira ticket: {}", ticketKey);

        try {
            return jiraWebClient.get()
                    .uri("/rest/api/3/issue/" + ticketKey)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();
        } catch (Exception e) {
            log.error("Error fetching ticket details", e);
            return Map.of("error", e.getMessage());
        }
    }

    public List<Map<String, Object>> getComments(String ticketKey) {
        log.info("Fetching comments for ticket: {}", ticketKey);

        try {
            Map<String, Object> response = jiraWebClient.get()
                    .uri("/rest/api/3/issue/" + ticketKey + "/comment")
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();

            return (List<Map<String, Object>>) response.getOrDefault("comments", Collections.emptyList());
        } catch (Exception e) {
            log.error("Error fetching comments", e);
            return Collections.emptyList();
        }
    }

    public Map<String, Object> addComment(String ticketKey, String commentText) {
        log.info("Adding comment to ticket: {}", ticketKey);

        Map<String, Object> body = Map.of("body", commentText);

        try {
            return jiraWebClient.post()
                    .uri("/rest/api/3/issue/" + ticketKey + "/comment")
                    .bodyValue(body)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();
        } catch (Exception e) {
            log.error("Error adding comment", e);
            return Map.of("error", e.getMessage());
        }
    }

    public List<Map<String, Object>> getAttachments(String ticketKey) {
        log.info("Fetching attachments for ticket: {}", ticketKey);

        try {
            Map<String, Object> ticket = getTicketDetails(ticketKey);
            Map<String, Object> fields = (Map<String, Object>) ticket.get("fields");
            return (List<Map<String, Object>>) fields.getOrDefault("attachment", Collections.emptyList());
        } catch (Exception e) {
            log.error("Error fetching attachments", e);
            return Collections.emptyList();
        }
    }

    public Map<String, Object> updateTicket(String ticketKey, Map<String, Object> fieldsToUpdate) {
        log.info("Updating ticket: {}", ticketKey);

        Map<String, Object> update = Map.of("fields", fieldsToUpdate);

        try {
            jiraWebClient.put()
                    .uri("/rest/api/3/issue/" + ticketKey)
                    .bodyValue(update)
                    .retrieve()
                    .bodyToMono(Void.class)
                    .block();

            return Map.of("success", true, "ticketKey", ticketKey);
        } catch (Exception e) {
            log.error("Error updating ticket", e);
            return Map.of("error", e.getMessage());
        }
    }

    public List<Map<String, Object>> searchTickets(String jql, Integer maxResults) {
        log.info("Searching tickets with JQL: {}", jql);

        Map<String, Object> request = Map.of(
                "jql", jql,
                "maxResults", maxResults != null ? maxResults : 50
        );

        try {
            Map<String, Object> response = jiraWebClient.post()
                    .uri("/rest/api/3/search")
                    .bodyValue(request)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();

            return (List<Map<String, Object>>) response.getOrDefault("issues", Collections.emptyList());
        } catch (Exception e) {
            log.error("Error searching tickets", e);
            return Collections.emptyList();
        }
    }
}
