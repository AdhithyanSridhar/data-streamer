package com.traceiq.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.time.Instant;
import java.util.List;

/**
 * GitHub Pull Request information.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record GitHubPRInfo(
    String prNumber,
    String title,
    String author,
    String status,
    Instant mergedAt,
    String targetBranch,
    List<String> filesChanged,
    String url
) {}
