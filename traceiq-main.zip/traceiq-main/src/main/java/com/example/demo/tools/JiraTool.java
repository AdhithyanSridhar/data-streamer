package com.example.demo.tools;

import java.util.function.Function;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonClassDescription;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;

@Component
public class JiraTool implements Function<JiraTool.Request, JiraTool.Response> {

    @JsonInclude(Include.NON_NULL)
    @JsonClassDescription("Jira tool to view ticket details, get comments, attachment details, etc.")
    public record Request(
            @JsonProperty(required = true, value = "ticket_id") @JsonPropertyDescription("The Jira ticket ID") String ticketId) {
    }

    @JsonInclude(Include.NON_NULL)
    public record Response(String ticketDetails, String comments, String attachmentDetails) {
    }

    @Override
    public Response apply(Request request) {
        // Implement Jira API call here
        System.out.println("Fetching Jira ticket details for ticket ID: " + request.ticketId());
        return new Response("Ticket details for " + request.ticketId(), "Comments for " + request.ticketId(),
                "Attachment details for " + request.ticketId());
    }

}