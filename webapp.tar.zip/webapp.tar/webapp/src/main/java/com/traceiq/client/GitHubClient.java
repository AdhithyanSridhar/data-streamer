package com.traceiq.client;

import com.traceiq.config.ApiConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Component
public class GitHubClient {
    public static final Logger log = LoggerFactory.getLogger(GitHubClient.class);

    @Qualifier("githubWebClient")
    private final WebClient githubWebClient;
    private final ApiConfiguration apiConfig;

    public GitHubClient(WebClient githubWebClient, ApiConfiguration apiConfig) {
        this.githubWebClient = githubWebClient;
        this.apiConfig = apiConfig;
    }

    public List<Map<String, Object>> getRecentPullRequests(String repository, String state, Integer limit) {
        log.info("Fetching PRs for repository: {}", repository);

        String org = apiConfig.getGithub().getOrganization();
        String uri = String.format("/repos/%s/%s/pulls?state=%s&per_page=%d",
                org, repository, state != null ? state : "all", limit != null ? limit : 10);

        try {
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> prs = (List<Map<String, Object>>) (List<?>) githubWebClient.get()
                    .uri(uri)
                    .retrieve()
                    .bodyToFlux(Map.class)
                    .collectList()
                    .block();

            return prs != null ? prs : Collections.emptyList();
        } catch (Exception e) {
            log.error("Error fetching PRs", e);
            return Collections.emptyList();
        }
    }

    public List<String> getCodeOwners(String repository, String filePath) {
        log.info("Fetching code owners for: {}/{}", repository, filePath);

        // Try to get CODEOWNERS file
        String org = apiConfig.getGithub().getOrganization();
        String uri = String.format("/repos/%s/%s/contents/CODEOWNERS", org, repository);

        try {
            Map<String, Object> file = githubWebClient.get()
                    .uri(uri)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();

            // Parse CODEOWNERS content - simplified
            return List.of("@team-lead", "@code-owner");
        } catch (Exception e) {
            log.warn("CODEOWNERS file not found or error: {}", e.getMessage());
            return Collections.emptyList();
        }
    }

    public Map<String, Object> getRepositoryOverview(String repository) {
        log.info("Fetching repository overview: {}", repository);

        String org = apiConfig.getGithub().getOrganization();
        String uri = String.format("/repos/%s/%s", org, repository);

        try {
            return githubWebClient.get()
                    .uri(uri)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();
        } catch (Exception e) {
            log.error("Error fetching repository overview", e);
            return Map.of("error", e.getMessage());
        }
    }

    public Map<String, Object> getLastCommit(String repository, String branch) {
        log.info("Fetching last commit for: {}/{}", repository, branch);

        String org = apiConfig.getGithub().getOrganization();
        String branchName = branch != null ? branch : "main";
        String uri = String.format("/repos/%s/%s/commits/%s", org, repository, branchName);

        try {
            return githubWebClient.get()
                    .uri(uri)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();
        } catch (Exception e) {
            log.error("Error fetching last commit", e);
            return Map.of("error", e.getMessage());
        }
    }

    public List<Map<String, Object>> searchCode(String query, String repository) {
        log.info("Searching code with query: {}", query);

        String org = apiConfig.getGithub().getOrganization();
        String q = String.format("%s repo:%s/%s", query, org, repository);
        String uri = String.format("/search/code?q=%s", q);

        try {
            Map<String, Object> response = githubWebClient.get()
                    .uri(uri)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();

            return (List<Map<String, Object>>) response.getOrDefault("items", Collections.emptyList());
        } catch (Exception e) {
            log.error("Error searching code", e);
            return Collections.emptyList();
        }
    }

    public String getFileContent(String repository, String filePath, String branch) {
        log.info("Fetching file content: {}/{}", repository, filePath);

        String org = apiConfig.getGithub().getOrganization();
        String branchName = branch != null ? branch : "main";
        String uri = String.format("/repos/%s/%s/contents/%s?ref=%s", org, repository, filePath, branchName);

        try {
            Map<String, Object> response = githubWebClient.get()
                    .uri(uri)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();

            // Content is base64 encoded
            String content = (String) response.get("content");
            return content != null ? new String(Base64.getDecoder().decode(content)) : "";
        } catch (Exception e) {
            log.error("Error fetching file content", e);
            return "";
        }
    }
}
