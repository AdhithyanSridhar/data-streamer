<template>
  <div class="glass-card pa-5">
    <div class="section-header">
      <div class="section-header__icon">
        <v-icon icon="mdi-test-tube" size="20"></v-icon>
      </div>
      <h2 class="section-header__title">Unit Tests</h2>
    </div>
    
    <div class="tests-summary mb-4">
      <div class="summary-item">
        <span class="summary-value">{{ tests.testFileCount }}</span>
        <span class="summary-label">Files</span>
      </div>
      <div class="summary-item">
        <span class="summary-value">{{ tests.testCount }}</span>
        <span class="summary-label">Tests</span>
      </div>
      <div class="summary-item">
        <v-chip :color="tests.status === 'passed' ? 'success' : 'error'" size="small" variant="flat">
          {{ tests.status }}
        </v-chip>
      </div>
    </div>
    
    <div class="test-code">
      <div class="code-header">
        <v-icon icon="mdi-file-document-outline" size="16"></v-icon>
        <span>Test Code</span>
      </div>
      <pre class="code-content"><code>{{ tests.testCode }}</code></pre>
    </div>
  </div>
</template>

<script setup>
defineProps({
  tests: { type: Object, required: true }
})
</script>

<style scoped>
.tests-summary {
  display: flex;
  gap: 24px;
  align-items: center;
  padding: 16px;
  background: #f5f5f5;
  border-radius: 8px;
}

.summary-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
}

.summary-value {
  font-size: 1.5rem;
  font-weight: 700;
  color: #1a1a1a;
}

.summary-label {
  font-size: 0.75rem;
  color: #666666;
}

.test-code {
  margin-top: 16px;
}

.code-header {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 0.8rem;
  color: #666666;
  margin-bottom: 8px;
}

.code-content {
  background: #1a1a1a;
  border-radius: 8px;
  padding: 16px;
  overflow-x: auto;
  font-size: 0.75rem;
  line-height: 1.6;
}

.code-content code {
  color: #e5e5e5;
  font-family: 'JetBrains Mono', monospace;
}
</style>
