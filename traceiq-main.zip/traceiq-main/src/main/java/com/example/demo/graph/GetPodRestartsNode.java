package com.example.demo.graph;

import com.example.demo.tools.KubernetesTool;
import org.springframework.stereotype.Component;

@Component
public class GetPodRestartsNode implements Node {

    public static final String NAME = "getPodRestarts";
    private final KubernetesTool kubernetesTool;

    public GetPodRestartsNode(KubernetesTool kubernetesTool) {
        this.kubernetesTool = kubernetesTool;
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public GraphState apply(GraphState state) {
        try {
            // This node might need a way to identify the relevant service/deployment.
            String serviceName = state.get("serviceName");
            if (serviceName != null) {
                KubernetesTool.PodRestartsResponse response = kubernetesTool.getPodRestarts(new KubernetesTool.PodRestartsRequest(serviceName));
                state.set("restartingPods", response.restartingPods());
            } else {
                state.set(NAME + "_info", "No service name found to check for pod restarts.");
            }
        } catch (Exception e) {
            state.set(NAME + "_error", "Failed to get pod restarts: " + e.getMessage());
        }
        return state;
    }
}
