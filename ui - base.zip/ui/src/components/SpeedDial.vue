<template>
  <!-- Speed Dial Button -->
  <div class="speed-dial" :class="{ 'speed-dial--open': isOpen }">
    <div class="speed-dial-actions" v-show="isOpen">
      <div 
        v-for="(action, idx) in actions" 
        :key="action.id"
        class="speed-dial-action"
        :style="{ transitionDelay: `${idx * 50}ms` }"
        @click="handleAction(action)"
      >
        <span class="action-label">{{ action.label }}</span>
        <div class="action-button" :style="{ background: action.color }">
          <v-icon :icon="action.icon" size="20" color="white"></v-icon>
        </div>
      </div>
    </div>
    
    <div class="speed-dial-trigger" @click="toggle">
      <v-icon :icon="isOpen ? 'mdi-close' : 'mdi-lightning-bolt'" size="24"></v-icon>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const isOpen = ref(false)

const emit = defineEmits(['action'])

const actions = [
  { id: 'new-incident', label: 'New Incident', icon: 'mdi-alert-octagon-outline', color: '#ef4444', route: '/incidents?new=true' },
  { id: 'search-trace', label: 'Search Trace', icon: 'mdi-magnify', color: '#3b82f6', route: '/trace-lookup' },
  { id: 'view-errors', label: 'View Errors', icon: 'mdi-bug-outline', color: '#f59e0b', route: '/app-errors' },
  { id: 'run-agent', label: 'Run Agent', icon: 'mdi-robot-outline', color: '#8b5cf6', route: '/agent-view' },
  { id: 'generate-report', label: 'Generate Report', icon: 'mdi-file-document-outline', color: '#10b981', action: 'report' }
]

const toggle = () => {
  isOpen.value = !isOpen.value
}

const handleAction = (action) => {
  isOpen.value = false
  
  if (action.route) {
    router.push(action.route)
  } else if (action.action) {
    emit('action', action.action)
  }
}
</script>

<style scoped>
.speed-dial {
  position: fixed;
  bottom: 100px;
  right: 24px;
  z-index: 9997;
}

.speed-dial-trigger {
  width: 56px;
  height: 56px;
  border-radius: 50%;
  background: linear-gradient(135deg, #1a1a1a 0%, #333333 100%);
  color: #ffffff;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.speed-dial-trigger:hover {
  transform: scale(1.05);
  box-shadow: 0 6px 30px rgba(0, 0, 0, 0.4);
}

.speed-dial--open .speed-dial-trigger {
  transform: rotate(45deg);
}

.speed-dial-actions {
  position: absolute;
  bottom: 70px;
  right: 4px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.speed-dial-action {
  display: flex;
  align-items: center;
  gap: 12px;
  opacity: 0;
  transform: translateY(20px) scale(0.8);
  transition: all 0.3s ease;
}

.speed-dial--open .speed-dial-action {
  opacity: 1;
  transform: translateY(0) scale(1);
}

.action-label {
  background: #ffffff;
  padding: 6px 12px;
  border-radius: 6px;
  font-size: 0.8rem;
  font-weight: 500;
  color: #1a1a1a;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  white-space: nowrap;
}

.action-button {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.2);
  transition: transform 0.2s ease;
}

.action-button:hover {
  transform: scale(1.1);
}
</style>
