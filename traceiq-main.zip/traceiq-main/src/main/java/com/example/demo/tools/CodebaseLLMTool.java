package com.example.demo.tools;

import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;

@Component
public class CodebaseLLMTool {

    public static class CodebaseLLMRequest {
        private final String error;

        public CodebaseLLMRequest(String error) {
            this.error = error;
        }

        public String getError() {
            return error;
        }
    }

    public static class CodebaseLLMResponse {
        private final List<String> suggestions;

        public CodebaseLLMResponse(List<String> suggestions) {
            this.suggestions = suggestions;
        }

        public List<String> suggestions() {
            return suggestions;
        }
    }

    public CodebaseLLMResponse getSuggestions(CodebaseLLMRequest request) {
        // Mock implementation
        return new CodebaseLLMResponse(Collections.singletonList("Mock suggestion"));
    }
}
