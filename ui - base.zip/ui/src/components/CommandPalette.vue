<template>
  <v-dialog v-model="isOpen" max-width="600" content-class="command-palette-dialog">
    <v-card class="command-card">
      <div class="search-container">
        <v-icon icon="mdi-magnify" class="search-icon"></v-icon>
        <input 
          ref="searchInput"
          v-model="query" 
          type="text" 
          placeholder="Search commands, pages, errors, traces..." 
          class="search-input"
          @keydown="handleKeydown"
        />
        <kbd class="kbd">ESC</kbd>
      </div>
      
      <v-divider></v-divider>
      
      <div class="results-container">
        <!-- Quick Actions -->
        <div class="result-group" v-if="!query">
          <div class="group-label">Quick Actions</div>
          <div 
            v-for="(action, idx) in quickActions" 
            :key="action.id"
            class="result-item"
            :class="{ 'result-item--selected': selectedIndex === idx }"
            @click="executeAction(action)"
            @mouseenter="selectedIndex = idx"
          >
            <v-icon :icon="action.icon" size="18" class="result-icon"></v-icon>
            <div class="result-content">
              <span class="result-title">{{ action.title }}</span>
              <span class="result-subtitle">{{ action.subtitle }}</span>
            </div>
            <kbd class="kbd" v-if="action.shortcut">{{ action.shortcut }}</kbd>
          </div>
        </div>
        
        <!-- Search Results -->
        <div class="result-group" v-if="query && filteredResults.length">
          <div class="group-label">Results</div>
          <div 
            v-for="(result, idx) in filteredResults" 
            :key="result.id"
            class="result-item"
            :class="{ 'result-item--selected': selectedIndex === idx }"
            @click="executeAction(result)"
            @mouseenter="selectedIndex = idx"
          >
            <v-icon :icon="result.icon" size="18" class="result-icon"></v-icon>
            <div class="result-content">
              <span class="result-title">{{ result.title }}</span>
              <span class="result-subtitle">{{ result.subtitle }}</span>
            </div>
          </div>
        </div>
        
        <!-- No Results -->
        <div class="no-results" v-if="query && !filteredResults.length">
          <v-icon icon="mdi-magnify-close" size="48" color="grey"></v-icon>
          <p>No results for "{{ query }}"</p>
        </div>
        
        <!-- Recent Searches -->
        <div class="result-group" v-if="!query && recentSearches.length">
          <div class="group-label">Recent</div>
          <div 
            v-for="(search, idx) in recentSearches" 
            :key="search"
            class="result-item"
            @click="query = search"
          >
            <v-icon icon="mdi-history" size="18" class="result-icon"></v-icon>
            <span class="result-title">{{ search }}</span>
          </div>
        </div>
      </div>
      
      <v-divider></v-divider>
      
      <div class="footer">
        <span><kbd>↑↓</kbd> Navigate</span>
        <span><kbd>↵</kbd> Select</span>
        <span><kbd>ESC</kbd> Close</span>
      </div>
    </v-card>
  </v-dialog>
</template>

<script setup>
import { ref, computed, watch, nextTick } from 'vue'
import { useRouter } from 'vue-router'

const props = defineProps({
  modelValue: Boolean
})

const emit = defineEmits(['update:modelValue'])

const router = useRouter()
const query = ref('')
const selectedIndex = ref(0)
const searchInput = ref(null)
const recentSearches = ref(['NullPointerException', 'trace-abc123', 'payment-service'])

const isOpen = computed({
  get: () => props.modelValue,
  set: (val) => emit('update:modelValue', val)
})

watch(isOpen, (val) => {
  if (val) {
    query.value = ''
    selectedIndex.value = 0
    nextTick(() => searchInput.value?.focus())
  }
})

const quickActions = [
  { id: 'dashboard', title: 'Go to Dashboard', subtitle: 'Overview & Analytics', icon: 'mdi-view-dashboard-outline', shortcut: 'G D', action: () => router.push('/dashboard') },
  { id: 'errors', title: 'Go to App Errors', subtitle: 'View all errors', icon: 'mdi-alert-circle-outline', shortcut: 'G E', action: () => router.push('/app-errors') },
  { id: 'trace', title: 'Go to Trace Lookup', subtitle: 'Search traces', icon: 'mdi-magnify', shortcut: 'G T', action: () => router.push('/trace-lookup') },
  { id: 'incidents', title: 'Go to Incidents', subtitle: 'Active incidents', icon: 'mdi-alert-octagon-outline', shortcut: 'G I', action: () => router.push('/incidents') },
  { id: 'new-incident', title: 'Create New Incident', subtitle: 'Start incident workflow', icon: 'mdi-plus-circle-outline', action: () => router.push('/incidents?new=true') },
  { id: 'settings', title: 'Open Settings', subtitle: 'Preferences & integrations', icon: 'mdi-cog-outline', shortcut: 'G S', action: () => router.push('/settings') }
]

const allItems = [
  ...quickActions,
  { id: 'err1', title: 'NullPointerException in PaymentProcessor', subtitle: 'payment-service • 156 occurrences', icon: 'mdi-bug-outline', action: () => router.push('/app-errors') },
  { id: 'err2', title: 'ConnectionTimeout in OrderService', subtitle: 'order-service • 89 occurrences', icon: 'mdi-bug-outline', action: () => router.push('/app-errors') },
  { id: 'trace1', title: 'trace-abc123-def456', subtitle: 'payment-service • Error', icon: 'mdi-identifier', action: () => router.push({ path: '/trace-lookup', query: { traceId: 'trace-abc123-def456', autoSearch: 'true' }}) },
  { id: 'service1', title: 'payment-service', subtitle: 'Service Health: Good', icon: 'mdi-server-outline', action: () => router.push('/dashboard') },
  { id: 'service2', title: 'billing-service', subtitle: 'Service Health: Warning', icon: 'mdi-server-outline', action: () => router.push('/dashboard') }
]

const filteredResults = computed(() => {
  if (!query.value) return []
  const q = query.value.toLowerCase()
  return allItems.filter(item => 
    item.title.toLowerCase().includes(q) || 
    item.subtitle?.toLowerCase().includes(q)
  ).slice(0, 8)
})

const currentItems = computed(() => query.value ? filteredResults.value : quickActions)

const handleKeydown = (e) => {
  if (e.key === 'ArrowDown') {
    e.preventDefault()
    selectedIndex.value = Math.min(selectedIndex.value + 1, currentItems.value.length - 1)
  } else if (e.key === 'ArrowUp') {
    e.preventDefault()
    selectedIndex.value = Math.max(selectedIndex.value - 1, 0)
  } else if (e.key === 'Enter') {
    e.preventDefault()
    const item = currentItems.value[selectedIndex.value]
    if (item) executeAction(item)
  } else if (e.key === 'Escape') {
    isOpen.value = false
  }
}

const executeAction = (item) => {
  if (query.value && !recentSearches.value.includes(query.value)) {
    recentSearches.value.unshift(query.value)
    if (recentSearches.value.length > 5) recentSearches.value.pop()
  }
  isOpen.value = false
  item.action?.()
}
</script>

<style scoped>
.command-card {
  background: #ffffff !important;
  border-radius: 12px !important;
  overflow: hidden;
}

.search-container {
  display: flex;
  align-items: center;
  padding: 16px;
  gap: 12px;
}

.search-icon {
  color: #999999;
}

.search-input {
  flex: 1;
  border: none;
  outline: none;
  font-size: 1rem;
  color: #1a1a1a;
  background: transparent;
}

.search-input::placeholder {
  color: #999999;
}

.kbd {
  background: #f0f0f0;
  border: 1px solid #e5e5e5;
  border-radius: 4px;
  padding: 2px 6px;
  font-size: 0.7rem;
  color: #666666;
  font-family: monospace;
}

.results-container {
  max-height: 400px;
  overflow-y: auto;
  padding: 8px;
}

.result-group {
  margin-bottom: 16px;
}

.group-label {
  font-size: 0.7rem;
  font-weight: 600;
  color: #999999;
  text-transform: uppercase;
  padding: 8px 12px;
  letter-spacing: 0.5px;
}

.result-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 12px;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.15s;
}

.result-item:hover,
.result-item--selected {
  background: #f5f5f5;
}

.result-icon {
  color: #666666;
}

.result-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.result-title {
  font-size: 0.9rem;
  color: #1a1a1a;
  font-weight: 500;
}

.result-subtitle {
  font-size: 0.75rem;
  color: #999999;
}

.no-results {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 32px;
  gap: 12px;
  color: #999999;
}

.footer {
  display: flex;
  gap: 16px;
  padding: 12px 16px;
  font-size: 0.75rem;
  color: #999999;
}

.footer kbd {
  margin-right: 4px;
}
</style>
