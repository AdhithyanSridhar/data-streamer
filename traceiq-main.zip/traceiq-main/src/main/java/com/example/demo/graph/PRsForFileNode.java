package com.example.demo.graph;

import com.example.demo.tools.GitTool;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class PRsForFileNode implements Node {

    public static final String NAME = "prsForFile";
    private final GitTool gitTool;

    public PRsForFileNode(GitTool gitTool) {
        this.gitTool = gitTool;
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public GraphState apply(GraphState state) {
        try {
            List<String> files = state.get("relevantFiles"); // Assuming this is set by another node
            if (files != null && !files.isEmpty()) {
                // For simplicity, getting PRs for the first relevant file.
                GitTool.PRsForFileResponse response = gitTool.getPRsForFile(new GitTool.PRsForFileRequest(files.get(0)));
                state.set("prsForFile", response.prs());
            } else {
                state.set(NAME + "_info", "No relevant files found to get PRs for.");
            }
        } catch (Exception e) {
            state.set(NAME + "_error", "Failed to get PRs for file: " + e.getMessage());
        }
        return state;
    }
}
