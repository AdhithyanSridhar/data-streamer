package com.traceiq.core.controller;

import com.traceiq.ingest.repository.CassandraRepository;
import com.traceiq.models.domain.ErrorRecord;
import com.traceiq.models.dto.ErrorListResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/errors")
@Tag(name = "Errors API", description = "Error listing and management")
public class ErrorsController {

    private final CassandraRepository cassandraRepository;

    public ErrorsController(CassandraRepository cassandraRepository) {
        this.cassandraRepository = cassandraRepository;
    }

    @GetMapping
    @Operation(summary = "List all errors")
    public ResponseEntity<ErrorListResponse> getAllErrors(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size
    ) {
        List<ErrorRecord> errors = cassandraRepository.getAllErrors();
        
        ErrorListResponse response = ErrorListResponse.builder()
                .errors(errors)
                .totalCount(errors.size())
                .page(page)
                .pageSize(size)
                .build();

        return ResponseEntity.ok(response);
    }
}
