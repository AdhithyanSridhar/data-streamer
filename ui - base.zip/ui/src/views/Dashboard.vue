<template>
  <v-container fluid class="pa-6">
    <!-- Welcome Section -->
    <div class="welcome-section mb-6">
      <div class="welcome-content">
        <h1 class="welcome-title">Welcome back!</h1>
        <p class="welcome-subtitle">Here's what's happening across your services today</p>
      </div>
      <div class="welcome-actions">
        <v-btn variant="outlined" rounded="lg" @click="generateReport">
          <v-icon icon="mdi-file-document-outline" class="mr-2"></v-icon>
          Generate Report
        </v-btn>
        <v-btn color="primary" rounded="lg" @click="$router.push('/incidents?new=true')">
          <v-icon icon="mdi-plus" class="mr-2"></v-icon>
          New Incident
        </v-btn>
      </div>
    </div>

    <!-- KPI Cards -->
    <v-row class="mb-6">
      <v-col cols="12" sm="6" md="3" v-for="kpi in kpis" :key="kpi.title">
        <div class="glass-card pa-4 kpi-card">
          <div class="kpi-header">
            <div class="kpi-icon" :style="{ background: kpi.bg }">
              <v-icon :icon="kpi.icon" size="20" :color="kpi.color"></v-icon>
            </div>
            <div class="kpi-trend" :class="kpi.trendClass">
              <v-icon :icon="kpi.trendIcon" size="12"></v-icon>
              {{ kpi.trend }}
            </div>
          </div>
          <div class="kpi-value">{{ kpi.value }}</div>
          <div class="kpi-label">{{ kpi.title }}</div>
          <div class="kpi-sparkline">
            <svg viewBox="0 0 100 30" class="sparkline">
              <polyline :points="kpi.sparkline" fill="none" :stroke="kpi.color" stroke-width="2"/>
            </svg>
          </div>
        </div>
      </v-col>
    </v-row>

    <v-row class="mb-6">
      <!-- Service Health Grid -->
      <v-col cols="12" lg="8">
        <div class="glass-card pa-5">
          <div class="section-header mb-4">
            <div class="section-header__icon">
              <v-icon icon="mdi-heart-pulse" size="20"></v-icon>
            </div>
            <span class="section-header__title">Service Health</span>
            <v-spacer></v-spacer>
            <v-btn-toggle v-model="healthView" density="compact" variant="outlined">
              <v-btn value="grid" size="small"><v-icon icon="mdi-view-grid-outline"></v-icon></v-btn>
              <v-btn value="list" size="small"><v-icon icon="mdi-view-list-outline"></v-icon></v-btn>
            </v-btn-toggle>
          </div>
          
          <div class="service-grid" v-if="healthView === 'grid'">
            <div 
              v-for="service in services" 
              :key="service.name" 
              class="service-card"
              :class="`service-card--${service.status}`"
              @click="$router.push('/app-errors?service=' + service.name)"
            >
              <div class="service-status">
                <span class="status-dot"></span>
              </div>
              <div class="service-name">{{ service.name }}</div>
              <div class="service-metrics">
                <span class="metric">
                  <v-icon icon="mdi-alert-circle-outline" size="12"></v-icon>
                  {{ service.errors }}
                </span>
                <span class="metric">
                  <v-icon icon="mdi-clock-outline" size="12"></v-icon>
                  {{ service.latency }}ms
                </span>
              </div>
              <div class="service-trend">
                <svg viewBox="0 0 60 20" class="mini-chart">
                  <polyline :points="service.trend" fill="none" :stroke="service.status === 'healthy' ? '#10b981' : service.status === 'warning' ? '#f59e0b' : '#ef4444'" stroke-width="2"/>
                </svg>
              </div>
            </div>
          </div>
          
          <v-data-table v-else :headers="serviceHeaders" :items="services" density="compact" class="service-table">
            <template v-slot:item.status="{ item }">
              <v-chip :color="item.status === 'healthy' ? 'success' : item.status === 'warning' ? 'warning' : 'error'" size="x-small" variant="flat">
                {{ item.status }}
              </v-chip>
            </template>
          </v-data-table>
        </div>
      </v-col>
      
      <!-- Error Heatmap -->
      <v-col cols="12" lg="4">
        <div class="glass-card pa-5 h-100">
          <div class="section-header mb-4">
            <div class="section-header__icon">
              <v-icon icon="mdi-grid" size="20"></v-icon>
            </div>
            <span class="section-header__title">Error Heatmap</span>
          </div>
          
          <div class="heatmap">
            <div class="heatmap-row" v-for="service in heatmapServices" :key="service">
              <span class="heatmap-label">{{ service }}</span>
              <div class="heatmap-cells">
                <div 
                  v-for="(val, idx) in heatmapData[service]" 
                  :key="idx" 
                  class="heatmap-cell"
                  :style="{ background: getHeatmapColor(val) }"
                  :title="`${service} at ${heatmapHours[idx]}: ${val} errors`"
                ></div>
              </div>
            </div>
          </div>
          <div class="heatmap-legend">
            <span>Less</span>
            <div class="legend-scale">
              <div v-for="i in 5" :key="i" class="legend-cell" :style="{ background: getHeatmapColor((i-1) * 25) }"></div>
            </div>
            <span>More</span>
          </div>
        </div>
      </v-col>
    </v-row>

    <v-row>
      <!-- Recent Errors -->
      <v-col cols="12" lg="6">
        <div class="glass-card pa-5">
          <div class="section-header mb-4">
            <div class="section-header__icon">
              <v-icon icon="mdi-bug-outline" size="20"></v-icon>
            </div>
            <span class="section-header__title">Recent Errors</span>
            <v-spacer></v-spacer>
            <v-btn variant="text" size="small" @click="$router.push('/app-errors')">View all</v-btn>
          </div>
          
          <div class="error-list">
            <div v-for="error in recentErrors" :key="error.id" class="error-item" @click="$router.push('/app-errors')">
              <div class="error-indicator" :class="`error-indicator--${error.severity}`"></div>
              <div class="error-content">
                <div class="error-message">{{ error.message }}</div>
                <div class="error-meta">
                  <span>{{ error.service }}</span>
                  <span>•</span>
                  <span>{{ error.time }}</span>
                  <span>•</span>
                  <span>{{ error.count }}x</span>
                </div>
              </div>
              <v-btn icon variant="text" size="x-small">
                <v-icon icon="mdi-chevron-right"></v-icon>
              </v-btn>
            </div>
          </div>
        </div>
      </v-col>
      
      <!-- Correlation Graph -->
      <v-col cols="12" lg="6">
        <div class="glass-card pa-5">
          <div class="section-header mb-4">
            <div class="section-header__icon">
              <v-icon icon="mdi-graph-outline" size="20"></v-icon>
            </div>
            <span class="section-header__title">Error Correlation</span>
            <v-chip size="x-small" variant="outlined" class="ml-2">AI Analysis</v-chip>
          </div>
          
          <div class="correlation-graph">
            <svg viewBox="0 0 300 200" class="graph-svg">
              <!-- Nodes -->
              <g v-for="(node, idx) in correlationNodes" :key="node.id">
                <circle 
                  :cx="node.x" 
                  :cy="node.y" 
                  :r="node.size" 
                  :fill="node.color"
                  class="graph-node"
                />
                <text :x="node.x" :y="node.y + node.size + 12" text-anchor="middle" class="graph-label">{{ node.label }}</text>
              </g>
              <!-- Edges -->
              <line 
                v-for="edge in correlationEdges" 
                :key="edge.id"
                :x1="edge.x1" :y1="edge.y1" 
                :x2="edge.x2" :y2="edge.y2"
                :stroke-width="edge.weight"
                stroke="#e5e5e5"
                class="graph-edge"
              />
            </svg>
          </div>
          
          <div class="correlation-insight">
            <v-icon icon="mdi-lightbulb-outline" size="16"></v-icon>
            <span>Payment and Billing errors are highly correlated (87% of cases occur together)</span>
          </div>
        </div>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup>
import { ref } from 'vue'

const healthView = ref('grid')

const kpis = [
  { title: 'Total Errors', value: '1,247', icon: 'mdi-alert-circle-outline', color: '#ef4444', bg: 'rgba(239,68,68,0.1)', trend: '+12%', trendIcon: 'mdi-trending-up', trendClass: 'trend-up', sparkline: '0,20 20,18 40,25 60,15 80,22 100,20' },
  { title: 'Avg Resolution', value: '2h 15m', icon: 'mdi-clock-outline', color: '#3b82f6', bg: 'rgba(59,130,246,0.1)', trend: '-8%', trendIcon: 'mdi-trending-down', trendClass: 'trend-down', sparkline: '0,25 20,22 40,18 60,20 80,15 100,12' },
  { title: 'Agent Success', value: '94%', icon: 'mdi-robot-outline', color: '#10b981', bg: 'rgba(16,185,129,0.1)', trend: '+3%', trendIcon: 'mdi-trending-up', trendClass: 'trend-up', sparkline: '0,10 20,15 40,18 60,20 80,22 100,25' },
  { title: 'Active Incidents', value: '3', icon: 'mdi-alert-octagon-outline', color: '#f59e0b', bg: 'rgba(245,158,11,0.1)', trend: '0', trendIcon: 'mdi-minus', trendClass: 'trend-neutral', sparkline: '0,15 20,15 40,15 60,18 80,15 100,15' }
]

const services = [
  { name: 'api-gateway', status: 'healthy', errors: 12, latency: 45, trend: '0,15 15,12 30,14 45,10 60,8' },
  { name: 'payment-service', status: 'critical', errors: 156, latency: 320, trend: '0,5 15,10 30,15 45,18 60,20' },
  { name: 'billing-service', status: 'warning', errors: 89, latency: 180, trend: '0,8 15,12 30,15 45,14 60,16' },
  { name: 'order-service', status: 'healthy', errors: 8, latency: 65, trend: '0,10 15,8 30,9 45,7 60,5' },
  { name: 'auth-service', status: 'healthy', errors: 3, latency: 28, trend: '0,12 15,10 30,11 45,8 60,6' },
  { name: 'notification-service', status: 'healthy', errors: 5, latency: 52, trend: '0,8 15,9 30,7 45,6 60,5' }
]

const serviceHeaders = [
  { title: 'Service', key: 'name' },
  { title: 'Status', key: 'status' },
  { title: 'Errors', key: 'errors' },
  { title: 'Latency', key: 'latency' }
]

const heatmapServices = ['payment', 'billing', 'order', 'auth']
const heatmapHours = ['00', '04', '08', '12', '16', '20']
const heatmapData = {
  'payment': [5, 8, 45, 78, 156, 89],
  'billing': [3, 5, 25, 45, 89, 56],
  'order': [2, 3, 12, 18, 23, 15],
  'auth': [1, 1, 5, 8, 12, 6]
}

const getHeatmapColor = (val) => {
  if (val < 10) return '#f0fdf4'
  if (val < 30) return '#bbf7d0'
  if (val < 60) return '#fef08a'
  if (val < 100) return '#fed7aa'
  return '#fecaca'
}

const recentErrors = [
  { id: 1, message: 'NullPointerException in PaymentProcessor.process()', service: 'payment-service', time: '2 min ago', count: 156, severity: 'high' },
  { id: 2, message: 'ConnectionTimeout: Pool exhausted', service: 'billing-service', time: '15 min ago', count: 89, severity: 'medium' },
  { id: 3, message: 'InvalidCurrencyCode: XYZ', service: 'billing-service', time: '1 hour ago', count: 45, severity: 'low' },
  { id: 4, message: 'TokenExpiredException', service: 'auth-service', time: '2 hours ago', count: 12, severity: 'low' }
]

const correlationNodes = [
  { id: 1, label: 'Payment', x: 75, y: 80, size: 25, color: '#ef4444' },
  { id: 2, label: 'Billing', x: 150, y: 50, size: 20, color: '#f59e0b' },
  { id: 3, label: 'Order', x: 225, y: 80, size: 15, color: '#10b981' },
  { id: 4, label: 'Auth', x: 150, y: 130, size: 12, color: '#3b82f6' }
]

const correlationEdges = [
  { id: 1, x1: 75, y1: 80, x2: 150, y2: 50, weight: 4 },
  { id: 2, x1: 150, y1: 50, x2: 225, y2: 80, weight: 2 },
  { id: 3, x1: 75, y1: 80, x2: 150, y2: 130, weight: 1 }
]

const generateReport = () => {
  alert('Report generation would be implemented here')
}
</script>

<style scoped>
.welcome-section { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px; }
.welcome-title { font-size: 1.5rem; font-weight: 700; color: #1a1a1a; margin-bottom: 4px; }
.welcome-subtitle { font-size: 0.9rem; color: #666666; }
.welcome-actions { display: flex; gap: 12px; }

.kpi-card { position: relative; overflow: hidden; }
.kpi-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
.kpi-icon { width: 36px; height: 36px; border-radius: 8px; display: flex; align-items: center; justify-content: center; }
.kpi-trend { font-size: 0.7rem; font-weight: 600; padding: 2px 6px; border-radius: 4px; }
.trend-up { background: rgba(16,185,129,0.1); color: #059669; }
.trend-down { background: rgba(239,68,68,0.1); color: #dc2626; }
.trend-neutral { background: #f0f0f0; color: #666666; }
.kpi-value { font-size: 1.75rem; font-weight: 700; color: #1a1a1a; }
.kpi-label { font-size: 0.8rem; color: #666666; margin-bottom: 8px; }
.kpi-sparkline { height: 30px; }
.sparkline { width: 100%; height: 100%; }

.service-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 12px; }
.service-card { padding: 16px; border-radius: 10px; background: #f5f5f5; cursor: pointer; transition: all 0.2s; }
.service-card:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
.service-card--healthy .status-dot { background: #10b981; }
.service-card--warning .status-dot { background: #f59e0b; }
.service-card--critical .status-dot { background: #ef4444; }
.service-status { display: flex; align-items: center; gap: 6px; margin-bottom: 8px; }
.status-dot { width: 8px; height: 8px; border-radius: 50%; }
.service-name { font-size: 0.85rem; font-weight: 600; color: #1a1a1a; margin-bottom: 8px; }
.service-metrics { display: flex; gap: 12px; font-size: 0.7rem; color: #666666; margin-bottom: 8px; }
.metric { display: flex; align-items: center; gap: 4px; }
.service-trend { height: 20px; }
.mini-chart { width: 100%; height: 100%; }
.service-table { background: transparent !important; }

.heatmap { display: flex; flex-direction: column; gap: 6px; }
.heatmap-row { display: flex; align-items: center; gap: 8px; }
.heatmap-label { font-size: 0.7rem; color: #666666; width: 50px; text-align: right; }
.heatmap-cells { display: flex; gap: 3px; flex: 1; }
.heatmap-cell { flex: 1; height: 20px; border-radius: 3px; cursor: pointer; transition: transform 0.15s; }
.heatmap-cell:hover { transform: scale(1.1); }
.heatmap-legend { display: flex; align-items: center; gap: 8px; justify-content: center; margin-top: 12px; font-size: 0.7rem; color: #666666; }
.legend-scale { display: flex; gap: 2px; }
.legend-cell { width: 16px; height: 12px; border-radius: 2px; }

.error-list { display: flex; flex-direction: column; gap: 8px; }
.error-item { display: flex; align-items: center; gap: 12px; padding: 12px; border-radius: 8px; background: #f5f5f5; cursor: pointer; transition: background 0.2s; }
.error-item:hover { background: #e5e5e5; }
.error-indicator { width: 4px; height: 40px; border-radius: 2px; }
.error-indicator--high { background: #ef4444; }
.error-indicator--medium { background: #f59e0b; }
.error-indicator--low { background: #3b82f6; }
.error-content { flex: 1; }
.error-message { font-size: 0.85rem; font-weight: 500; color: #1a1a1a; margin-bottom: 4px; }
.error-meta { font-size: 0.7rem; color: #666666; display: flex; gap: 6px; }

.correlation-graph { height: 200px; display: flex; align-items: center; justify-content: center; }
.graph-svg { width: 100%; height: 100%; }
.graph-node { cursor: pointer; transition: r 0.2s; }
.graph-node:hover { r: 28; }
.graph-label { font-size: 10px; fill: #666666; }
.graph-edge { stroke-linecap: round; }
.correlation-insight { display: flex; align-items: flex-start; gap: 8px; padding: 12px; background: rgba(99,102,241,0.05); border-radius: 8px; font-size: 0.8rem; color: #666666; margin-top: 12px; }
</style>
