<template>
  <div class="space-y-6">
    <!-- Summary Card -->
    <div class="bg-white rounded-lg shadow p-6">
      <div class="flex items-center justify-between mb-4">
        <h2 class="text-xl font-semibold text-gray-800">
          <i class="fas fa-chart-line mr-2"></i>Analysis Summary
        </h2>
        <span 
          :class="statusClass"
          class="px-3 py-1 rounded-full text-sm font-medium"
        >
          {{ response.status }}
        </span>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
        <div class="p-4 bg-blue-50 rounded-lg">
          <div class="text-sm text-blue-600 font-medium">Trace ID</div>
          <div class="text-lg font-semibold text-gray-800 mt-1">{{ response.traceId }}</div>
        </div>

        <div class="p-4 bg-green-50 rounded-lg">
          <div class="text-sm text-green-600 font-medium">Team</div>
          <div class="text-lg font-semibold text-gray-800 mt-1">{{ response.teamName || 'N/A' }}</div>
        </div>

        <div class="p-4 bg-purple-50 rounded-lg">
          <div class="text-sm text-purple-600 font-medium">Owner</div>
          <div class="text-lg font-semibold text-gray-800 mt-1">{{ response.ownerEmail || 'N/A' }}</div>
        </div>
      </div>
    </div>

    <!-- Root Cause Analysis -->
    <div v-if="response.rootCauseAnalysis" class="bg-white rounded-lg shadow p-6">
      <h3 class="text-lg font-semibold text-gray-800 mb-4">
        <i class="fas fa-search-plus mr-2"></i>Root Cause Analysis
      </h3>
      
      <div class="space-y-3">
        <div class="flex items-start space-x-3">
          <span class="text-sm font-medium text-gray-600 min-w-32">Summary:</span>
          <span class="text-sm text-gray-800">{{ response.rootCauseAnalysis.summary }}</span>
        </div>

        <div class="flex items-start space-x-3">
          <span class="text-sm font-medium text-gray-600 min-w-32">Root Cause:</span>
          <span class="text-sm text-gray-800 font-medium">{{ response.rootCauseAnalysis.rootCause }}</span>
        </div>

        <div class="flex items-start space-x-3">
          <span class="text-sm font-medium text-gray-600 min-w-32">Category:</span>
          <span 
            :class="getCategoryClass(response.rootCauseAnalysis.category)"
            class="px-2 py-1 rounded text-xs font-medium"
          >
            {{ response.rootCauseAnalysis.category }}
          </span>
        </div>

        <div class="flex items-start space-x-3">
          <span class="text-sm font-medium text-gray-600 min-w-32">Severity:</span>
          <span 
            :class="getSeverityClass(response.rootCauseAnalysis.severity)"
            class="px-2 py-1 rounded text-xs font-medium"
          >
            {{ response.rootCauseAnalysis.severity }}
          </span>
        </div>

        <div class="flex items-start space-x-3">
          <span class="text-sm font-medium text-gray-600 min-w-32">Confidence:</span>
          <div class="flex items-center space-x-2">
            <div class="w-48 h-2 bg-gray-200 rounded-full overflow-hidden">
              <div 
                :style="{ width: (response.rootCauseAnalysis.confidenceScore * 100) + '%' }"
                class="h-full bg-green-500"
              ></div>
            </div>
            <span class="text-sm text-gray-700">{{ (response.rootCauseAnalysis.confidenceScore * 100).toFixed(0) }}%</span>
          </div>
        </div>

        <div class="mt-4 p-4 bg-gray-50 rounded-lg">
          <span class="text-sm font-medium text-gray-600 block mb-2">Detailed Explanation:</span>
          <p class="text-sm text-gray-700 leading-relaxed">{{ response.rootCauseAnalysis.detailedExplanation }}</p>
        </div>
      </div>
    </div>

    <!-- Code Analysis -->
    <div v-if="response.codeAnalysis" class="bg-white rounded-lg shadow p-6">
      <h3 class="text-lg font-semibold text-gray-800 mb-4">
        <i class="fas fa-code mr-2"></i>Code Analysis
      </h3>

      <div class="space-y-3">
        <div class="flex items-start space-x-3">
          <span class="text-sm font-medium text-gray-600 min-w-32">File Path:</span>
          <code class="text-sm text-blue-600">{{ response.codeAnalysis.filePath }}</code>
        </div>

        <div class="flex items-start space-x-3">
          <span class="text-sm font-medium text-gray-600 min-w-32">Class:</span>
          <code class="text-sm text-gray-800">{{ response.codeAnalysis.className }}</code>
        </div>

        <div class="flex items-start space-x-3">
          <span class="text-sm font-medium text-gray-600 min-w-32">Method:</span>
          <code class="text-sm text-gray-800">{{ response.codeAnalysis.methodName }}</code>
        </div>

        <div class="flex items-start space-x-3">
          <span class="text-sm font-medium text-gray-600 min-w-32">Line Number:</span>
          <span class="text-sm text-gray-800">{{ response.codeAnalysis.lineNumber }}</span>
        </div>

        <div class="mt-4">
          <span class="text-sm font-medium text-gray-600 block mb-2">Problematic Code:</span>
          <pre class="p-4 bg-red-50 border border-red-200 rounded-lg text-xs overflow-x-auto">{{ response.codeAnalysis.problematicCode }}</pre>
        </div>

        <div class="mt-4">
          <span class="text-sm font-medium text-gray-600 block mb-2">Suggested Fix:</span>
          <pre class="p-4 bg-green-50 border border-green-200 rounded-lg text-xs overflow-x-auto">{{ response.codeAnalysis.suggestedFix }}</pre>
        </div>
      </div>
    </div>

    <!-- Fix Suggestions -->
    <div v-if="response.fixSuggestions && response.fixSuggestions.length > 0" class="bg-white rounded-lg shadow p-6">
      <h3 class="text-lg font-semibold text-gray-800 mb-4">
        <i class="fas fa-tools mr-2"></i>Fix Suggestions
      </h3>
      <ul class="space-y-2">
        <li 
          v-for="(suggestion, index) in response.fixSuggestions" 
          :key="index"
          class="flex items-start space-x-3"
        >
          <span class="flex-shrink-0 w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-xs font-medium">
            {{ index + 1 }}
          </span>
          <span class="text-sm text-gray-700">{{ suggestion }}</span>
        </li>
      </ul>
    </div>

    <!-- Implementation Plan -->
    <div v-if="response.implementationPlan" class="bg-white rounded-lg shadow p-6">
      <h3 class="text-lg font-semibold text-gray-800 mb-4">
        <i class="fas fa-tasks mr-2"></i>Implementation Plan
      </h3>
      <div class="p-4 bg-blue-50 rounded-lg">
        <p class="text-sm text-gray-700 whitespace-pre-wrap">{{ response.implementationPlan }}</p>
      </div>
    </div>

    <!-- Performance Metrics -->
    <div v-if="response.performanceMetrics" class="bg-white rounded-lg shadow p-6">
      <h3 class="text-lg font-semibold text-gray-800 mb-4">
        <i class="fas fa-tachometer-alt mr-2"></i>Performance Metrics
      </h3>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div class="p-4 bg-purple-50 rounded-lg">
          <div class="text-sm text-purple-600 font-medium">Total Duration</div>
          <div class="text-2xl font-bold text-gray-800 mt-1">
            {{ response.performanceMetrics.totalDurationMs }}ms
          </div>
        </div>
        <div class="p-4 bg-orange-50 rounded-lg">
          <div class="text-sm text-orange-600 font-medium">Avg Response Time</div>
          <div class="text-2xl font-bold text-gray-800 mt-1">
            {{ response.performanceMetrics.avgResponseTimeMs }}ms
          </div>
        </div>
      </div>
    </div>

    <!-- Error Logs -->
    <div v-if="response.errorLogs && response.errorLogs.length > 0" class="bg-white rounded-lg shadow p-6">
      <h3 class="text-lg font-semibold text-gray-800 mb-4">
        <i class="fas fa-exclamation-triangle mr-2"></i>Error Logs ({{ response.errorLogs.length }})
      </h3>
      <div class="space-y-2 max-h-96 overflow-y-auto">
        <div 
          v-for="(log, index) in response.errorLogs.slice(0, 10)" 
          :key="index"
          class="p-3 bg-red-50 border-l-4 border-red-500 rounded"
        >
          <div class="flex items-start justify-between">
            <div class="flex-1">
              <div class="text-xs text-red-600 font-medium">
                {{ log.serviceName }} - {{ formatTimestamp(log.timestamp) }}
              </div>
              <div class="text-sm text-gray-800 mt-1">{{ log.message }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  response: {
    type: Object,
    required: true
  }
})

const statusClass = computed(() => {
  const status = props.response.status
  if (status === 'COMPLETED') return 'bg-green-100 text-green-800'
  if (status === 'ERROR') return 'bg-red-100 text-red-800'
  return 'bg-yellow-100 text-yellow-800'
})

const getCategoryClass = (category) => {
  const categories = {
    'Configuration': 'bg-yellow-100 text-yellow-800',
    'Code': 'bg-blue-100 text-blue-800',
    'Infrastructure': 'bg-purple-100 text-purple-800',
    'Integration': 'bg-green-100 text-green-800'
  }
  return categories[category] || 'bg-gray-100 text-gray-800'
}

const getSeverityClass = (severity) => {
  const severities = {
    'Critical': 'bg-red-100 text-red-800',
    'High': 'bg-orange-100 text-orange-800',
    'Medium': 'bg-yellow-100 text-yellow-800',
    'Low': 'bg-green-100 text-green-800'
  }
  return severities[severity] || 'bg-gray-100 text-gray-800'
}

const formatTimestamp = (timestamp) => {
  return new Date(timestamp).toLocaleString()
}
</script>
