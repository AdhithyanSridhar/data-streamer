<template>
  <v-container fluid class="pa-6">
    <!-- Page Header -->
    <div class="page-header mb-6">
      <h1 class="page-title">Application Errors</h1>
      <p class="page-subtitle">Monitor and analyze errors across your applications</p>
    </div>

    <!-- Analytics Panels -->
    <v-row class="mb-6">
      <v-col cols="12" sm="6" md="3" v-for="stat in analyticsStats" :key="stat.title">
        <div class="glass-card pa-4 stat-card">
          <div class="stat-icon">
            <v-icon :icon="stat.icon" size="24"></v-icon>
          </div>
          <div class="stat-content">
            <span class="stat-value">{{ stat.value }}</span>
            <span class="stat-label">{{ stat.title }}</span>
          </div>
          <div class="stat-trend" :class="stat.trendClass">
            <v-icon :icon="stat.trendIcon" size="14"></v-icon>
            <span>{{ stat.trend }}</span>
          </div>
        </div>
      </v-col>
    </v-row>

    <!-- Filters -->
    <div class="glass-card pa-5 mb-6">
      <div class="section-header mb-4">
        <div class="section-header__icon">
          <v-icon icon="mdi-filter-outline" size="20"></v-icon>
        </div>
        <span class="section-header__title">Filter Errors</span>
      </div>
      <v-row align="center">
        <v-col cols="12" md="4">
          <v-select v-model="selectedTeam" :items="teams" label="Team Name" variant="outlined" density="comfortable" prepend-inner-icon="mdi-account-group-outline" @update:model-value="onTeamChange"></v-select>
        </v-col>
        <v-col cols="12" md="4">
          <v-select v-model="selectedApp" :items="filteredApps" label="Application Name" variant="outlined" density="comfortable" prepend-inner-icon="mdi-application-outline" :disabled="!selectedTeam"></v-select>
        </v-col>
        <v-col cols="12" md="4">
          <v-btn color="primary" size="large" :disabled="!selectedTeam || !selectedApp" @click="showErrors" rounded="lg" class="px-8">
            <v-icon icon="mdi-magnify" class="mr-2"></v-icon>
            Show Errors
          </v-btn>
        </v-col>
      </v-row>
    </div>

    <!-- Errors Table with Advanced Features -->
    <div class="glass-card pa-5">
      <div class="section-header mb-4">
        <div class="section-header__icon">
          <v-icon icon="mdi-table" size="20"></v-icon>
        </div>
        <span class="section-header__title">Error Summary</span>
        <v-spacer></v-spacer>
        <v-chip variant="outlined" size="small">{{ filteredErrors.length }} errors</v-chip>
      </div>
      
      <!-- Table Toolbar -->
      <div class="table-toolbar mb-4">
        <v-text-field
          v-model="tableSearch"
          prepend-inner-icon="mdi-magnify"
          label="Search in table..."
          variant="outlined"
          density="compact"
          hide-details
          clearable
          class="search-field"
        ></v-text-field>
        
        <v-spacer></v-spacer>
        
        <!-- Column Toggle -->
        <v-menu>
          <template v-slot:activator="{ props }">
            <v-btn v-bind="props" variant="outlined" size="small" class="mr-2">
              <v-icon icon="mdi-view-column-outline" class="mr-1"></v-icon>
              Columns
            </v-btn>
          </template>
          <v-list density="compact">
            <v-list-item v-for="col in allColumns" :key="col.key">
              <v-checkbox v-model="visibleColumns" :label="col.title" :value="col.key" density="compact" hide-details></v-checkbox>
            </v-list-item>
          </v-list>
        </v-menu>
        
        <!-- Export Menu -->
        <v-menu>
          <template v-slot:activator="{ props }">
            <v-btn v-bind="props" variant="outlined" size="small">
              <v-icon icon="mdi-download-outline" class="mr-1"></v-icon>
              Export
            </v-btn>
          </template>
          <v-list density="compact">
            <v-list-item @click="exportJSON">
              <v-list-item-title>Export as JSON</v-list-item-title>
            </v-list-item>
            <v-list-item @click="exportExcel">
              <v-list-item-title>Export as Excel</v-list-item-title>
            </v-list-item>
          </v-list>
        </v-menu>
      </div>
      
      <v-data-table
        :headers="visibleHeaders"
        :items="filteredErrors"
        :search="tableSearch"
        :items-per-page="itemsPerPage"
        :sort-by="sortBy"
        class="error-table"
        density="comfortable"
      >
        <template v-slot:item.sMsg="{ item }">
          <div class="error-msg">
            <code>{{ item.sMsg }}</code>
          </div>
        </template>
        
        <template v-slot:item.traceId="{ item }">
          <a href="#" class="trace-link" @click.prevent="navigateToTrace(item.traceId)">
            {{ item.traceId }}
          </a>
        </template>
        
        <template v-slot:item.count="{ item }">
          <v-chip :color="getCountColor(item.count)" variant="flat" size="small">
            {{ item.count }}
          </v-chip>
        </template>
        
        <template v-slot:item.lastOccurred="{ item }">
          <span class="timestamp">{{ formatDate(item.lastOccurred) }}</span>
        </template>
        
        <template v-slot:item.insights="{ item }">
          <div class="insights-actions">
            <v-btn icon variant="text" size="small" @click="openDialog('stackTrace', item)" title="Stack Trace">
              <v-icon icon="mdi-code-braces"></v-icon>
            </v-btn>
            <v-btn icon variant="text" size="small" @click="openDialog('eventMetadata', item)" title="Event Metadata">
              <v-icon icon="mdi-database-outline"></v-icon>
            </v-btn>
            <v-btn icon variant="text" size="small" @click="openDialog('askATT', item)" title="AskATT - LLM Reasoning">
              <v-icon icon="mdi-robot-outline"></v-icon>
            </v-btn>
          </div>
        </template>
        
        <template v-slot:item.assignAgent="{ item }">
          <v-btn variant="outlined" size="small" rounded="lg" @click="openAssignDialog(item)">
            <v-icon icon="mdi-robot-outline" class="mr-1" size="16"></v-icon>
            Assign
          </v-btn>
        </template>
        
        <template v-slot:bottom>
          <div class="table-footer">
            <v-select
              v-model="itemsPerPage"
              :items="[5, 10, 25, 50, 100]"
              label="Rows per page"
              variant="outlined"
              density="compact"
              hide-details
              class="rows-select"
            ></v-select>
          </div>
        </template>
      </v-data-table>
    </div>

    <!-- Stack Trace Dialog -->
    <v-dialog v-model="dialogs.stackTrace" max-width="900">
      <v-card class="dialog-card">
        <v-card-title class="dialog-title">
          <v-icon icon="mdi-code-braces" class="mr-2"></v-icon>
          Stack Trace
          <v-spacer></v-spacer>
          <v-btn icon variant="text" @click="dialogs.stackTrace = false">
            <v-icon icon="mdi-close"></v-icon>
          </v-btn>
        </v-card-title>
        <v-card-text>
          <pre class="stack-trace-content">{{ selectedError?.stackTrace }}</pre>
        </v-card-text>
      </v-card>
    </v-dialog>

    <!-- Event Metadata Dialog -->
    <v-dialog v-model="dialogs.eventMetadata" max-width="700">
      <v-card class="dialog-card">
        <v-card-title class="dialog-title">
          <v-icon icon="mdi-database-outline" class="mr-2"></v-icon>
          Event Metadata
          <v-spacer></v-spacer>
          <v-btn icon variant="text" @click="dialogs.eventMetadata = false">
            <v-icon icon="mdi-close"></v-icon>
          </v-btn>
        </v-card-title>
        <v-card-text>
          <v-list density="compact" class="metadata-list">
            <v-list-item v-for="(value, key) in selectedError?.metadata" :key="key">
              <template v-slot:prepend><v-icon icon="mdi-tag-outline" size="small"></v-icon></template>
              <v-list-item-title>{{ key }}</v-list-item-title>
              <v-list-item-subtitle>{{ value }}</v-list-item-subtitle>
            </v-list-item>
          </v-list>
        </v-card-text>
      </v-card>
    </v-dialog>

    <!-- AskATT Dialog -->
    <v-dialog v-model="dialogs.askATT" max-width="800">
      <v-card class="dialog-card">
        <v-card-title class="dialog-title">
          <v-icon icon="mdi-robot-outline" class="mr-2"></v-icon>
          AskATT - LLM Reasoning
          <v-spacer></v-spacer>
          <v-btn icon variant="text" @click="dialogs.askATT = false">
            <v-icon icon="mdi-close"></v-icon>
          </v-btn>
        </v-card-title>
        <v-card-text>
          <div class="att-content">
            <div class="att-section">
              <h4><v-icon icon="mdi-lightbulb-outline" class="mr-1"></v-icon>Root Cause Analysis</h4>
              <p>{{ selectedError?.attReasoning?.rca }}</p>
            </div>
            <div class="att-section">
              <h4><v-icon icon="mdi-wrench-outline" class="mr-1"></v-icon>Suggested Fix</h4>
              <p>{{ selectedError?.attReasoning?.suggestedFix }}</p>
            </div>
            <div class="att-section">
              <h4><v-icon icon="mdi-chart-timeline-variant" class="mr-1"></v-icon>Impact Assessment</h4>
              <p>{{ selectedError?.attReasoning?.impact }}</p>
            </div>
          </div>
        </v-card-text>
      </v-card>
    </v-dialog>

    <!-- Assign Agent Dialog -->
    <v-dialog v-model="dialogs.assignAgent" max-width="600">
      <v-card class="dialog-card">
        <v-card-title class="dialog-title">
          <v-icon icon="mdi-robot-outline" class="mr-2"></v-icon>
          Assign Agent to Error
          <v-spacer></v-spacer>
          <v-btn icon variant="text" @click="dialogs.assignAgent = false">
            <v-icon icon="mdi-close"></v-icon>
          </v-btn>
        </v-card-title>
        <v-card-text>
          <v-alert type="info" variant="tonal" class="mb-4">
            Select the agent tasks you want to perform for this error.
          </v-alert>
          <v-checkbox v-for="task in agentTasks" :key="task.id" v-model="selectedTasks" :label="task.label" :value="task.id" density="compact" hide-details class="mb-2"></v-checkbox>
        </v-card-text>
        <v-card-actions class="pa-4">
          <v-spacer></v-spacer>
          <v-btn variant="text" @click="dialogs.assignAgent = false">Cancel</v-btn>
          <v-btn color="primary" variant="flat" @click="assignAgent" :disabled="!selectedTasks.length">
            <v-icon icon="mdi-check" class="mr-1"></v-icon>
            Assign Agent
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'
import * as XLSX from 'xlsx'
import { saveAs } from 'file-saver'

const router = useRouter()

const selectedTeam = ref(null)
const selectedApp = ref(null)
const selectedError = ref(null)
const selectedTasks = ref([])
const tableSearch = ref('')
const itemsPerPage = ref(10)
const sortBy = ref([{ key: 'count', order: 'desc' }])

const dialogs = ref({
  stackTrace: false,
  eventMetadata: false,
  askATT: false,
  assignAgent: false
})

const analyticsStats = [
  { title: 'Total Errors', value: '1,247', icon: 'mdi-alert-circle-outline', trend: '+12%', trendIcon: 'mdi-trending-up', trendClass: 'trend-up' },
  { title: 'Critical', value: '23', icon: 'mdi-alert-outline', trend: '-5%', trendIcon: 'mdi-trending-down', trendClass: 'trend-down' },
  { title: 'Resolved', value: '892', icon: 'mdi-check-circle-outline', trend: '+8%', trendIcon: 'mdi-trending-up', trendClass: 'trend-up' },
  { title: 'Pending RCA', value: '156', icon: 'mdi-clock-outline', trend: '0%', trendIcon: 'mdi-minus', trendClass: 'trend-neutral' }
]

const teams = ['Platform Team', 'Payments Team', 'Orders Team', 'Auth Team', 'Notifications Team']
const appsByTeam = {
  'Platform Team': ['api-gateway', 'config-service', 'discovery-service'],
  'Payments Team': ['payment-service', 'billing-service', 'invoice-service'],
  'Orders Team': ['order-service', 'cart-service', 'inventory-service'],
  'Auth Team': ['auth-service', 'user-service', 'oauth-service'],
  'Notifications Team': ['notification-service', 'email-service', 'sms-service']
}

const filteredApps = computed(() => selectedTeam.value ? appsByTeam[selectedTeam.value] || [] : [])
const onTeamChange = () => { selectedApp.value = null }

const allColumns = [
  { title: 'Error Message', key: 'sMsg', width: '30%' },
  { title: 'Trace ID', key: 'traceId', width: '15%' },
  { title: 'Count', key: 'count', width: '8%', align: 'center' },
  { title: 'Last Occurred', key: 'lastOccurred', width: '15%' },
  { title: 'Insights', key: 'insights', width: '12%', align: 'center', sortable: false },
  { title: 'Action', key: 'assignAgent', width: '12%', align: 'center', sortable: false }
]

const visibleColumns = ref(['sMsg', 'traceId', 'count', 'lastOccurred', 'insights', 'assignAgent'])

const visibleHeaders = computed(() => allColumns.filter(col => visibleColumns.value.includes(col.key)))

const errors = ref([
  { id: 1, sMsg: 'NullPointerException in PaymentProcessor.process()', traceId: 'trace-abc123-def456', count: 156, lastOccurred: '2024-12-10T14:30:00Z', stackTrace: 'java.lang.NullPointerException\n  at com.acme.payment.PaymentProcessor.process(PaymentProcessor.java:142)', metadata: { traceId: 'trace-abc123', spanId: 'span-456', cluster: 'prod-us-east-1', pod: 'payment-service-7b9d8c' }, attReasoning: { rca: 'Missing null check for transaction context before processing.', suggestedFix: 'Add Optional wrapper and null validation at entry point.', impact: 'High - affects 2,500+ transactions per hour.' } },
  { id: 2, sMsg: 'ConnectionTimeout: Database connection pool exhausted', traceId: 'trace-def456-ghi789', count: 89, lastOccurred: '2024-12-10T14:25:00Z', stackTrace: 'com.zaxxer.hikari.pool.HikariPool$PoolEntryCreator.call\n  at java.util.concurrent.FutureTask.run', metadata: { traceId: 'trace-def456', spanId: 'span-789', cluster: 'prod-us-east-1', pod: 'order-service-5c4d3b' }, attReasoning: { rca: 'Connection pool size too small for current load.', suggestedFix: 'Increase pool size from 10 to 25 and add connection timeout.', impact: 'Medium - causes 5% of requests to fail.' } },
  { id: 3, sMsg: 'IllegalArgumentException: Invalid currency code', traceId: 'trace-ghi789-jkl012', count: 45, lastOccurred: '2024-12-10T14:20:00Z', stackTrace: 'java.lang.IllegalArgumentException: Invalid currency code: XYZ\n  at com.acme.billing.CurrencyValidator.validate', metadata: { traceId: 'trace-ghi789', spanId: 'span-012', cluster: 'prod-eu-west-1', pod: 'billing-service-8e7f6a' }, attReasoning: { rca: 'Input validation missing for currency codes from external API.', suggestedFix: 'Add whitelist validation for ISO 4217 currency codes.', impact: 'Low - affects edge cases only.' } }
])

const filteredErrors = computed(() => errors.value)

const agentTasks = [
  { id: 'rca', label: 'Root Cause Analysis' },
  { id: 'plan', label: 'Generate Implementation Plan' },
  { id: 'pr', label: 'Create Pull Request' },
  { id: 'tests', label: 'Generate Unit Tests' },
  { id: 'merge', label: 'Auto-merge PR' },
  { id: 'close', label: 'Close Issue' }
]

const showErrors = () => { /* API call */ }
const formatDate = (date) => new Date(date).toLocaleString()
const getCountColor = (count) => count > 100 ? 'error' : count > 50 ? 'warning' : 'success'

const openDialog = (type, error) => {
  selectedError.value = error
  dialogs.value[type] = true
}

const openAssignDialog = (error) => {
  selectedError.value = error
  selectedTasks.value = []
  dialogs.value.assignAgent = true
}

const assignAgent = () => {
  dialogs.value.assignAgent = false
  router.push({ path: '/agent-view', query: { errorId: selectedError.value?.id, tasks: selectedTasks.value.join(',') } })
}

const navigateToTrace = (traceId) => {
  router.push({ path: '/trace-lookup', query: { traceId: traceId, autoSearch: 'true' } })
}

const exportJSON = () => {
  const data = JSON.stringify(filteredErrors.value, null, 2)
  const blob = new Blob([data], { type: 'application/json' })
  saveAs(blob, 'errors.json')
}

const exportExcel = () => {
  const ws = XLSX.utils.json_to_sheet(filteredErrors.value.map(e => ({
    'Error Message': e.sMsg,
    'Trace ID': e.traceId,
    'Count': e.count,
    'Last Occurred': e.lastOccurred
  })))
  const wb = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(wb, ws, 'Errors')
  XLSX.writeFile(wb, 'errors.xlsx')
}
</script>

<style scoped>
.page-header { text-align: center; padding: 20px 0; }
.page-title { font-size: 1.75rem; font-weight: 700; color: #1a1a1a; margin-bottom: 8px; }
.page-subtitle { font-size: 0.95rem; color: #666666; }

.stat-card { display: flex; flex-direction: column; gap: 12px; }
.stat-icon { width: 44px; height: 44px; border-radius: 10px; display: flex; align-items: center; justify-content: center; background: #f5f5f5; color: #1a1a1a; }
.stat-content { display: flex; flex-direction: column; gap: 4px; }
.stat-value { font-size: 1.5rem; font-weight: 700; color: #1a1a1a; }
.stat-label { font-size: 0.8rem; color: #666666; }
.stat-trend { display: inline-flex; align-items: center; gap: 4px; font-size: 0.7rem; font-weight: 600; padding: 4px 8px; border-radius: 12px; width: fit-content; }
.trend-up { background: rgba(16, 185, 129, 0.1); color: #059669; }
.trend-down { background: rgba(239, 68, 68, 0.1); color: #dc2626; }
.trend-neutral { background: #f0f0f0; color: #666666; }

.table-toolbar { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; }
.search-field { max-width: 300px; }
.rows-select { max-width: 120px; }
.table-footer { display: flex; justify-content: flex-end; padding: 16px; }

.error-table { background: transparent !important; }
.error-msg { max-width: 350px; }
.error-msg code { font-size: 0.75rem; color: #1a1a1a; background: #f5f5f5; padding: 4px 8px; border-radius: 4px; word-break: break-word; }
.trace-link { color: #6366f1; text-decoration: none; font-family: monospace; font-size: 0.8rem; }
.trace-link:hover { text-decoration: underline; }
.timestamp { font-size: 0.8rem; color: #666666; }
.insights-actions { display: flex; gap: 2px; }

.dialog-card { background: #ffffff !important; }
.dialog-title { display: flex; align-items: center; background: #f5f5f5; padding: 16px 20px !important; color: #1a1a1a; font-size: 1rem; }
.stack-trace-content { background: #1a1a1a; padding: 16px; border-radius: 8px; font-family: monospace; font-size: 0.75rem; color: #e5e5e5; overflow-x: auto; white-space: pre-wrap; max-height: 400px; }
.metadata-list { background: transparent !important; }
.att-content { display: flex; flex-direction: column; gap: 20px; }
.att-section h4 { font-size: 0.9rem; color: #1a1a1a; margin-bottom: 8px; display: flex; align-items: center; }
.att-section p { color: #666666; line-height: 1.6; padding-left: 28px; margin: 0; }
</style>
