package com.traceiq.client;

import com.traceiq.model.LogEntry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * Client adapter for ELK/Elasticsearch integration.
 * Assumes existing ELK query implementation from POC.
 */
@Component
public class ElkClient {
    
    private static final Logger logger = LoggerFactory.getLogger(ElkClient.class);
    
    private final WebClient webClient;
    
    public ElkClient(@Value("${elk.base-url}") String elkBaseUrl, WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.baseUrl(elkBaseUrl).build();
        logger.info("ElkClient initialized with base URL: {}", elkBaseUrl);
    }
    
    /**
     * Get all logs (error, warn, info) for a given traceId.
     * Results are cached to avoid redundant API calls.
     */
    @Cacheable(value = "elkLogs", key = "#traceId")
    public List<LogEntry> getLogsByTraceId(String traceId) {
        logger.info("Fetching logs for traceId: {}", traceId);
        
        try {
            // Delegate to existing POC implementation
            Map<String, Object> query = buildTraceIdQuery(traceId);
            
            List<Map<String, Object>> rawLogs = webClient.post()
                .uri("/elasticsearch/_search")
                .bodyValue(query)
                .retrieve()
                .bodyToMono(ElkResponse.class)
                .map(this::extractHits)
                .block();
            
            return convertToLogEntries(rawLogs);
            
        } catch (Exception e) {
            logger.error("Error fetching logs for traceId: {}", traceId, e);
            return List.of();
        }
    }
    
    /**
     * Get error logs for a specific microservice and group by error message.
     */
    @Cacheable(value = "elkErrors", key = "#serviceName")
    public Map<String, List<LogEntry>> getErrorLogsByService(String serviceName) {
        logger.info("Fetching error logs for service: {}", serviceName);
        
        try {
            Map<String, Object> query = buildServiceErrorQuery(serviceName);
            
            List<Map<String, Object>> rawLogs = webClient.post()
                .uri("/elasticsearch/_search")
                .bodyValue(query)
                .retrieve()
                .bodyToMono(ElkResponse.class)
                .map(this::extractHits)
                .block();
            
            List<LogEntry> logs = convertToLogEntries(rawLogs);
            return groupByErrorMessage(logs);
            
        } catch (Exception e) {
            logger.error("Error fetching error logs for service: {}", serviceName, e);
            return Map.of();
        }
    }
    
    /**
     * Perform latency analysis on provided logs.
     */
    public Map<String, Object> performLatencyAnalysis(List<LogEntry> logs) {
        logger.info("Performing latency analysis on {} logs", logs.size());
        
        if (logs.isEmpty()) {
            return Map.of("status", "no_logs");
        }
        
        long minTimestamp = logs.stream()
            .map(log -> log.timestamp().toEpochMilli())
            .min(Long::compare)
            .orElse(0L);
        
        long maxTimestamp = logs.stream()
            .map(log -> log.timestamp().toEpochMilli())
            .max(Long::compare)
            .orElse(0L);
        
        long totalDuration = maxTimestamp - minTimestamp;
        
        Map<String, Long> serviceLatencies = logs.stream()
            .filter(log -> log.serviceName() != null)
            .collect(java.util.stream.Collectors.groupingBy(
                LogEntry::serviceName,
                java.util.stream.Collectors.counting()
            ));
        
        return Map.of(
            "totalDurationMs", totalDuration,
            "logCount", logs.size(),
            "serviceLatencies", serviceLatencies,
            "startTime", Instant.ofEpochMilli(minTimestamp),
            "endTime", Instant.ofEpochMilli(maxTimestamp)
        );
    }
    
    // Private helper methods
    
    private Map<String, Object> buildTraceIdQuery(String traceId) {
        return Map.of(
            "query", Map.of(
                "bool", Map.of(
                    "must", List.of(
                        Map.of("match", Map.of("traceId", traceId))
                    )
                )
            ),
            "size", 1000,
            "sort", List.of(Map.of("@timestamp", "asc"))
        );
    }
    
    private Map<String, Object> buildServiceErrorQuery(String serviceName) {
        return Map.of(
            "query", Map.of(
                "bool", Map.of(
                    "must", List.of(
                        Map.of("match", Map.of("serviceName", serviceName)),
                        Map.of("match", Map.of("level", "ERROR"))
                    )
                )
            ),
            "size", 500,
            "sort", List.of(Map.of("@timestamp", "desc"))
        );
    }
    
    private List<Map<String, Object>> extractHits(ElkResponse response) {
        if (response != null && response.hits() != null) {
            return response.hits().hits();
        }
        return List.of();
    }
    
    private List<LogEntry> convertToLogEntries(List<Map<String, Object>> rawLogs) {
        return rawLogs.stream()
            .map(this::toLogEntry)
            .toList();
    }
    
    @SuppressWarnings("unchecked")
    private LogEntry toLogEntry(Map<String, Object> raw) {
        Map<String, Object> source = (Map<String, Object>) raw.getOrDefault("_source", Map.of());
        
        return new LogEntry(
            parseTimestamp(source.get("@timestamp")),
            (String) source.get("level"),
            (String) source.get("message"),
            (String) source.get("serviceName"),
            (String) source.get("traceId"),
            (String) source.get("spanId"),
            (String) source.get("logger"),
            (String) source.get("thread"),
            (String) source.get("stackTrace")
        );
    }
    
    private Instant parseTimestamp(Object timestamp) {
        if (timestamp instanceof String) {
            return Instant.parse((String) timestamp);
        }
        return Instant.now();
    }
    
    private Map<String, List<LogEntry>> groupByErrorMessage(List<LogEntry> logs) {
        return logs.stream()
            .filter(log -> log.message() != null)
            .collect(java.util.stream.Collectors.groupingBy(
                log -> extractErrorCategory(log.message())
            ));
    }
    
    private String extractErrorCategory(String message) {
        // Simple categorization - can be enhanced
        if (message.contains("NullPointerException")) return "NullPointerException";
        if (message.contains("TimeoutException")) return "TimeoutException";
        if (message.contains("ConnectionException")) return "ConnectionException";
        if (message.contains("Configuration")) return "ConfigurationError";
        return "OtherError";
    }
    
    // Inner record for ELK response structure
    private record ElkResponse(Hits hits) {}
    private record Hits(List<Map<String, Object>> hits) {}
}
