package com.traceiq.client;

import com.traceiq.config.ApiConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Date;
import java.util.Map;

/**
 * Client for Internal GPT-4 LLM RCA API
 */
@Component
public class LlmRcaClient {
    public static final Logger log = LoggerFactory.getLogger(LlmRcaClient.class);

    @Qualifier("llmRcaWebClient")
    private final WebClient llmRcaWebClient;
    private final ApiConfiguration apiConfig;

    public LlmRcaClient(WebClient llmRcaWebClient, ApiConfiguration apiConfig) {
        this.llmRcaWebClient = llmRcaWebClient;
        this.apiConfig = apiConfig;
    }

    public Map<String, Object> analyze(String prompt, String analysisType) {
        log.info("Performing LLM RCA analysis: {}", analysisType);

        Map<String, Object> request = Map.of(
                "model", apiConfig.getLlm().getRca().getModel(),
                "prompt", prompt,
                "temperature", apiConfig.getLlm().getRca().getTemperature(),
                "max_tokens", apiConfig.getLlm().getRca().getMaxTokens(),
                "analysis_type", analysisType
        );

        try {
            Map<String, Object> response = llmRcaWebClient.post()
                    .uri("/v1/analyze")
                    .bodyValue(request)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();

            return parseAnalysisResponse(response, analysisType);
        } catch (Exception e) {
            log.error("Error calling LLM RCA API", e);
            return Map.of(
                    "error", e.getMessage(),
                    "analysis_type", analysisType,
                    "fallback", generateFallbackAnalysis(analysisType)
            );
        }
    }

    private Map<String, Object> parseAnalysisResponse(Map<String, Object> response, String analysisType) {
        // Extract the analysis from response
        String content = (String) response.getOrDefault("content", "");

        return Map.of(
                "analysis_type", analysisType,
                "content", content,
                "confidence", response.getOrDefault("confidence", "medium"),
                "model_used", apiConfig.getLlm().getRca().getModel(),
                "timestamp", new Date()
        );
    }

    private Map<String, Object> generateFallbackAnalysis(String analysisType) {
        return Map.of(
                "message", "LLM service unavailable, using fallback analysis",
                "recommendation", "Please review logs and metrics manually",
                "analysis_type", analysisType
        );
    }
}
