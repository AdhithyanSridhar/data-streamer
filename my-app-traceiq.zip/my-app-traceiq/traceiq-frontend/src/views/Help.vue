<template>
  <div class="space-y-6">
    <div class="bg-white rounded-lg shadow-md p-6">
      <h2 class="text-2xl font-bold text-gray-800 mb-4">
        <i class="fas fa-info-circle text-indigo-600 mr-2"></i>
        About TraceIQ
      </h2>
      <p class="text-gray-700 leading-relaxed">
        TraceIQ is an AI-powered Root Cause Analysis platform that helps development teams
        quickly identify and resolve production issues. Using advanced LLM technology and 
        vectorized code search, TraceIQ provides actionable implementation plans with
        curated GitHub Copilot prompts.
      </p>
      <div class="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="text-center p-4 bg-indigo-50 rounded-lg">
          <div class="text-3xl font-bold text-indigo-600">1.0.0</div>
          <p class="text-sm text-gray-600 mt-2">Current Version</p>
        </div>
        <div class="text-center p-4 bg-green-50 rounded-lg">
          <div class="text-3xl font-bold text-green-600">24/7</div>
          <p class="text-sm text-gray-600 mt-2">Availability</p>
        </div>
        <div class="text-center p-4 bg-blue-50 rounded-lg">
          <div class="text-3xl font-bold text-blue-600">AI</div>
          <p class="text-sm text-gray-600 mt-2">Powered Analysis</p>
        </div>
      </div>
    </div>

    <div class="bg-white rounded-lg shadow-md p-6">
      <h3 class="text-xl font-bold text-gray-800 mb-4">
        <i class="fas fa-users mr-2"></i>Team Members
      </h3>
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div class="border border-gray-200 rounded-lg p-4 text-center">
          <div class="w-20 h-20 bg-indigo-100 rounded-full mx-auto mb-3 flex items-center justify-center">
            <i class="fas fa-user text-3xl text-indigo-600"></i>
          </div>
          <h4 class="font-semibold text-gray-800">John Doe</h4>
          <p class="text-sm text-gray-600">Tech Lead</p>
          <p class="text-xs text-gray-500 mt-1">john@example.com</p>
        </div>
        <div class="border border-gray-200 rounded-lg p-4 text-center">
          <div class="w-20 h-20 bg-green-100 rounded-full mx-auto mb-3 flex items-center justify-center">
            <i class="fas fa-user text-3xl text-green-600"></i>
          </div>
          <h4 class="font-semibold text-gray-800">Jane Smith</h4>
          <p class="text-sm text-gray-600">AI Engineer</p>
          <p class="text-xs text-gray-500 mt-1">jane@example.com</p>
        </div>
        <div class="border border-gray-200 rounded-lg p-4 text-center">
          <div class="w-20 h-20 bg-blue-100 rounded-full mx-auto mb-3 flex items-center justify-center">
            <i class="fas fa-user text-3xl text-blue-600"></i>
          </div>
          <h4 class="font-semibold text-gray-800">Bob Johnson</h4>
          <p class="text-sm text-gray-600">DevOps Engineer</p>
          <p class="text-xs text-gray-500 mt-1">bob@example.com</p>
        </div>
      </div>
    </div>

    <div class="bg-white rounded-lg shadow-md p-6">
      <h3 class="text-xl font-bold text-gray-800 mb-4">
        <i class="fas fa-link mr-2"></i>Useful Links
      </h3>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <a href="http://localhost:8080/swagger-ui.html" target="_blank" 
           class="flex items-center p-4 border border-gray-200 rounded-lg hover:shadow-md transition">
          <i class="fas fa-book text-2xl text-indigo-600 mr-3"></i>
          <div>
            <p class="font-semibold">API Documentation</p>
            <p class="text-sm text-gray-600">Swagger UI</p>
          </div>
        </a>
        <a href="https://github.com" target="_blank" 
           class="flex items-center p-4 border border-gray-200 rounded-lg hover:shadow-md transition">
          <i class="fab fa-github text-2xl text-gray-800 mr-3"></i>
          <div>
            <p class="font-semibold">GitHub</p>
            <p class="text-sm text-gray-600">Source Code</p>
          </div>
        </a>
        <a href="https://jenkins.example.com" target="_blank" 
           class="flex items-center p-4 border border-gray-200 rounded-lg hover:shadow-md transition">
          <i class="fas fa-cogs text-2xl text-orange-600 mr-3"></i>
          <div>
            <p class="font-semibold">Jenkins</p>
            <p class="text-sm text-gray-600">CI/CD Pipeline</p>
          </div>
        </a>
        <a href="https://dynatrace.example.com" target="_blank" 
           class="flex items-center p-4 border border-gray-200 rounded-lg hover:shadow-md transition">
          <i class="fas fa-chart-line text-2xl text-purple-600 mr-3"></i>
          <div>
            <p class="font-semibold">Dynatrace</p>
            <p class="text-sm text-gray-600">APM & Monitoring</p>
          </div>
        </a>
      </div>
    </div>

    <div class="bg-white rounded-lg shadow-md p-6">
      <h3 class="text-xl font-bold text-gray-800 mb-4">
        <i class="fas fa-question-circle mr-2"></i>FAQ
      </h3>
      <div class="space-y-4">
        <div class="border-l-4 border-indigo-500 pl-4">
          <p class="font-semibold text-gray-800">How does TraceIQ analyze errors?</p>
          <p class="text-sm text-gray-600 mt-1">
            TraceIQ uses advanced LLMs to analyze error logs, stack traces, and metrics from
            ELK, Dynatrace, and other sources to provide comprehensive root cause analysis.
          </p>
        </div>
        <div class="border-l-4 border-green-500 pl-4">
          <p class="font-semibold text-gray-800">What is God Mode?</p>
          <p class="text-sm text-gray-600 mt-1">
            God Mode runs a complete analysis pipeline: RCA analysis + Implementation Plan + 
            Code location detection + Copilot prompts generation - all in one click.
          </p>
        </div>
        <div class="border-l-4 border-blue-500 pl-4">
          <p class="font-semibold text-gray-800">How do I use Copilot prompts?</p>
          <p class="text-sm text-gray-600 mt-1">
            Copy the generated prompts and paste them into your IDE where GitHub Copilot is enabled.
            The prompts are crafted to help Copilot generate high-quality fixes.
          </p>
        </div>
      </div>
    </div>

    <div class="bg-indigo-50 rounded-lg p-6 text-center">
      <i class="fas fa-envelope text-4xl text-indigo-600 mb-3"></i>
      <h3 class="text-xl font-bold text-gray-800 mb-2">Need Help?</h3>
      <p class="text-gray-700 mb-4">Contact our support team</p>
      <a href="mailto:support@traceiq.example.com" 
         class="inline-block bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition">
        Send Feedback
      </a>
    </div>
  </div>
</template>

<script setup>
</script>
