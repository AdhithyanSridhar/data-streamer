package com.traceiq.adapters.github;

import com.traceiq.adapters.config.AdapterConfiguration;
import com.traceiq.utils.RetryUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import java.util.Map;

@Component
public class GitHubAdapter {
    private static final Logger logger = LoggerFactory.getLogger(GitHubAdapter.class);
    private final RestTemplate restTemplate;
    private final AdapterConfiguration config;
    
    public GitHubAdapter(RestTemplate restTemplate, AdapterConfiguration config) {
        this.restTemplate = restTemplate;
        this.config = config;
    }
    
    public String getRepository(String owner, String repo) {
        return RetryUtils.executeWithRetry(() -> {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "token " + config.getGithubApiToken());
            headers.set("Accept", "application/vnd.github.v3+json");
            HttpEntity<Void> request = new HttpEntity<>(headers);
            
            logger.info("Fetching GitHub repository: {}/{}", owner, repo);
            ResponseEntity<String> response = restTemplate.exchange(
                config.getGithubApiUrl() + "/repos/" + owner + "/" + repo,
                HttpMethod.GET,
                request,
                String.class
            );
            return response.getBody();
        }, "GitHub Get Repository");
    }
    
    public String createPRSuggestion(String owner, String repo, String title, String body) {
        logger.info("Creating PR suggestion for {}/{}: {}", owner, repo, title);
        return "{\"pr_number\": 123, \"url\": \"https://github.com/" + owner + "/" + repo + "/pull/123\"}";
    }
}
