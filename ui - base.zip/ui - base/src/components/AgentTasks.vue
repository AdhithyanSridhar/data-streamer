<template>
  <div class="glass-card pa-5">
    <div class="section-header">
      <div class="section-header__icon">
        <v-icon icon="mdi-check-circle-outline" size="20"></v-icon>
      </div>
      <h2 class="section-header__title">Selected Agent Tasks</h2>
    </div>
    
    <div class="tasks-progress mb-4">
      <div class="progress-label">
        <span>Progress</span>
        <span class="progress-value">{{ completedCount }}/{{ tasks.length }} tasks</span>
      </div>
      <v-progress-linear
        :model-value="progressPercent"
        height="6"
        rounded
        color="success"
        bg-color="#e5e5e5"
      ></v-progress-linear>
    </div>
    
    <div class="tasks-list">
      <div v-for="(task, index) in tasks" :key="index" class="task-item" :class="{ 'task-completed': task.completed }">
        <div class="task-status">
          <v-icon :icon="task.completed ? 'mdi-check-circle' : 'mdi-circle-outline'" :color="task.completed ? 'success' : 'grey'" size="20"></v-icon>
        </div>
        <div class="task-content">
          <span class="task-name">{{ task.name }}</span>
        </div>
        <div class="task-badge">
          <v-chip :variant="task.completed ? 'flat' : 'outlined'" :color="task.completed ? 'success' : 'default'" size="x-small">
            {{ task.completed ? 'Done' : 'Pending' }}
          </v-chip>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  tasks: {
    type: Array,
    required: true
  }
})

const completedCount = computed(() => props.tasks.filter(t => t.completed).length)
const progressPercent = computed(() => (completedCount.value / props.tasks.length) * 100)
</script>

<style scoped>
.tasks-progress {
  background: #f5f5f5;
  border-radius: 8px;
  padding: 12px 16px;
}

.progress-label {
  display: flex;
  justify-content: space-between;
  margin-bottom: 8px;
  font-size: 0.8rem;
  color: #666666;
}

.progress-value {
  font-weight: 600;
  color: #1a1a1a;
}

.tasks-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.task-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px;
  border-radius: 8px;
  background: #f5f5f5;
  transition: background 0.2s;
}

.task-item:hover {
  background: #f0f0f0;
}

.task-completed {
  background: rgba(16, 185, 129, 0.05);
}

.task-status {
  flex-shrink: 0;
}

.task-content {
  flex: 1;
}

.task-name {
  font-size: 0.9rem;
  font-weight: 500;
  color: #1a1a1a;
}

.task-badge {
  flex-shrink: 0;
}
</style>
