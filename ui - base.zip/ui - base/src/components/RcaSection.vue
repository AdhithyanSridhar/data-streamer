<template>
  <div class="glass-card pa-5">
    <div class="section-header">
      <div class="section-header__icon">
        <v-icon :icon="icon" size="20"></v-icon>
      </div>
      <h2 class="section-header__title">{{ title }}</h2>
      <v-chip v-if="variant === 'deep'" variant="outlined" size="x-small" class="ml-2">AI Reasoning</v-chip>
    </div>
    
    <div class="rca-content" :class="{ 'rca-expanded': isExpanded || variant === 'brief' }">
      <div class="markdown-content" v-html="renderedContent"></div>
    </div>
    
    <v-btn v-if="variant === 'deep'" variant="text" size="small" @click="isExpanded = !isExpanded" class="expand-btn">
      <v-icon :icon="isExpanded ? 'mdi-chevron-up' : 'mdi-chevron-down'" class="mr-1"></v-icon>
      {{ isExpanded ? 'Collapse' : 'Expand' }}
    </v-btn>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { marked } from 'marked'
import hljs from 'highlight.js'

const props = defineProps({
  title: { type: String, required: true },
  icon: { type: String, default: 'mdi-magnify' },
  content: { type: String, required: true },
  variant: { type: String, default: 'brief' }
})

const isExpanded = ref(false)

marked.setOptions({
  highlight: (code, lang) => {
    if (lang && hljs.getLanguage(lang)) {
      return hljs.highlight(code, { language: lang }).value
    }
    return code
  }
})

const renderedContent = computed(() => marked(props.content))
</script>

<style scoped>
.rca-content {
  max-height: 200px;
  overflow: hidden;
  transition: max-height 0.3s ease;
}

.rca-expanded {
  max-height: none;
}

.expand-btn {
  margin-top: 12px;
}

:deep(.markdown-content h2) {
  font-size: 1rem;
  font-weight: 600;
  color: #1a1a1a;
  margin-bottom: 12px;
}

:deep(.markdown-content h3) {
  font-size: 0.9rem;
  font-weight: 600;
  color: #1a1a1a;
  margin: 16px 0 8px;
}

:deep(.markdown-content p) {
  font-size: 0.875rem;
  color: #666666;
  line-height: 1.6;
  margin-bottom: 12px;
}

:deep(.markdown-content ul),
:deep(.markdown-content ol) {
  padding-left: 20px;
  margin-bottom: 12px;
}

:deep(.markdown-content li) {
  font-size: 0.875rem;
  color: #666666;
  margin-bottom: 6px;
}

:deep(.markdown-content code) {
  background: #f5f5f5;
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 0.8rem;
  color: #1a1a1a;
}

:deep(.markdown-content pre) {
  background: #1a1a1a;
  padding: 16px;
  border-radius: 8px;
  overflow-x: auto;
  margin: 12px 0;
}

:deep(.markdown-content pre code) {
  background: transparent;
  color: #e5e5e5;
  padding: 0;
}
</style>
