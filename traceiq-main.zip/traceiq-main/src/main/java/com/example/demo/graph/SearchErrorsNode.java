package com.example.demo.graph;

import com.example.demo.tools.ElkTool;
import org.springframework.stereotype.Component;

@Component
public class SearchErrorsNode implements Node {

    public static final String NAME = "searchErrors";
    private final ElkTool elkTool;

    public SearchErrorsNode(ElkTool elkTool) {
        this.elkTool = elkTool;
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public GraphState apply(GraphState state) {
        try {
            String traceId = state.get("traceId");
            ElkTool.ErrorSearchResponse response = elkTool.searchErrors(new ElkTool.ErrorSearchRequest(traceId));
            state.set("errors", response.errors());
        } catch (Exception e) {
            state.set(NAME + "_error", "Failed to search errors: " + e.getMessage());
        }
        return state;
    }
}
