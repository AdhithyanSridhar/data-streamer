package com.traceiq.client;

import com.traceiq.model.LogEntry;
import com.traceiq.model.RootCauseAnalysis;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.Map;

/**
 * Client for internal GPT-4.1 LLM API.
 * Performs RCA analysis on logs and error data.
 */
@Component
public class InternalLlmClient {
    
    private static final Logger logger = LoggerFactory.getLogger(InternalLlmClient.class);
    
    private final WebClient webClient;
    
    public InternalLlmClient(
        @Value("${internal.llm.base-url}") String llmBaseUrl,
        WebClient.Builder webClientBuilder
    ) {
        this.webClient = webClientBuilder.baseUrl(llmBaseUrl).build();
        logger.info("InternalLlmClient initialized with base URL: {}", llmBaseUrl);
    }
    
    /**
     * Analyze logs and provide RCA using internal GPT-4.1 LLM.
     */
    public RootCauseAnalysis analyzeRootCause(
        String traceId,
        List<LogEntry> logs,
        String customPrompt
    ) {
        logger.info("Performing RCA analysis for traceId: {}", traceId);
        
        try {
            String prompt = buildRcaPrompt(logs, customPrompt);
            
            Map<String, Object> request = Map.of(
                "prompt", prompt,
                "temperature", 0.3,
                "maxTokens", 2000
            );
            
            LlmResponse response = webClient.post()
                .uri("/api/v1/chat/completions")
                .bodyValue(request)
                .retrieve()
                .bodyToMono(LlmResponse.class)
                .block();
            
            return parseRcaResponse(response);
            
        } catch (Exception e) {
            logger.error("Error during RCA analysis for traceId: {}", traceId, e);
            return createErrorRca(e.getMessage());
        }
    }
    
    /**
     * Generate fix suggestions based on RCA.
     */
    public List<String> generateFixSuggestions(RootCauseAnalysis rca, String context) {
        logger.info("Generating fix suggestions for RCA category: {}", rca.category());
        
        try {
            String prompt = buildFixSuggestionsPrompt(rca, context);
            
            Map<String, Object> request = Map.of(
                "prompt", prompt,
                "temperature", 0.5,
                "maxTokens", 1500
            );
            
            LlmResponse response = webClient.post()
                .uri("/api/v1/chat/completions")
                .bodyValue(request)
                .retrieve()
                .bodyToMono(LlmResponse.class)
                .block();
            
            return parseFixSuggestions(response);
            
        } catch (Exception e) {
            logger.error("Error generating fix suggestions", e);
            return List.of("Unable to generate fix suggestions: " + e.getMessage());
        }
    }
    
    /**
     * Generate production readiness recommendations.
     */
    public List<String> generateGuardrails(RootCauseAnalysis rca) {
        logger.info("Generating guardrails for RCA category: {}", rca.category());
        
        try {
            String prompt = buildGuardrailsPrompt(rca);
            
            Map<String, Object> request = Map.of(
                "prompt", prompt,
                "temperature", 0.4,
                "maxTokens", 1000
            );
            
            LlmResponse response = webClient.post()
                .uri("/api/v1/chat/completions")
                .bodyValue(request)
                .retrieve()
                .bodyToMono(LlmResponse.class)
                .block();
            
            return parseGuardrails(response);
            
        } catch (Exception e) {
            logger.error("Error generating guardrails", e);
            return List.of();
        }
    }
    
    // Private helper methods
    
    private String buildRcaPrompt(List<LogEntry> logs, String customPrompt) {
        StringBuilder prompt = new StringBuilder();
        
        if (customPrompt != null && !customPrompt.isBlank()) {
            prompt.append(customPrompt).append("\n\n");
        }
        
        prompt.append("Analyze the following distributed system logs and provide a root cause analysis.\n\n");
        prompt.append("Focus on:\n");
        prompt.append("1. Identifying the root cause of the error\n");
        prompt.append("2. Understanding the sequence of events\n");
        prompt.append("3. Configuration issues (40% of defects are config-related)\n");
        prompt.append("4. Service interactions and dependencies\n\n");
        prompt.append("Logs:\n");
        
        logs.stream()
            .limit(50)  // Limit to avoid token overflow
            .forEach(log -> {
                prompt.append(String.format("[%s] [%s] %s: %s\n",
                    log.timestamp(),
                    log.level(),
                    log.serviceName(),
                    log.message()
                ));
            });
        
        prompt.append("\nProvide response in JSON format:\n");
        prompt.append("{\n");
        prompt.append("  \"summary\": \"Brief summary\",\n");
        prompt.append("  \"rootCause\": \"Main root cause\",\n");
        prompt.append("  \"category\": \"Configuration|Code|Infrastructure|Integration\",\n");
        prompt.append("  \"severity\": \"Critical|High|Medium|Low\",\n");
        prompt.append("  \"contributingFactors\": [\"factor1\", \"factor2\"],\n");
        prompt.append("  \"detailedExplanation\": \"Detailed explanation\",\n");
        prompt.append("  \"confidenceScore\": 0.85\n");
        prompt.append("}");
        
        return prompt.toString();
    }
    
    private String buildFixSuggestionsPrompt(RootCauseAnalysis rca, String context) {
        return String.format(
            "Based on the following root cause analysis, provide specific fix suggestions:\n\n" +
            "Root Cause: %s\n" +
            "Category: %s\n" +
            "Severity: %s\n" +
            "Context: %s\n\n" +
            "Provide 3-5 actionable fix suggestions as a JSON array:\n" +
            "[\"suggestion1\", \"suggestion2\", \"suggestion3\"]",
            rca.rootCause(),
            rca.category(),
            rca.severity(),
            context
        );
    }
    
    private String buildGuardrailsPrompt(RootCauseAnalysis rca) {
        return String.format(
            "Based on the following root cause, suggest production readiness guardrails:\n\n" +
            "Root Cause: %s\n" +
            "Category: %s\n\n" +
            "Provide 3-5 guardrails to prevent similar issues as a JSON array:\n" +
            "[\"guardrail1\", \"guardrail2\", \"guardrail3\"]",
            rca.rootCause(),
            rca.category()
        );
    }
    
    private RootCauseAnalysis parseRcaResponse(LlmResponse response) {
        if (response == null || response.content() == null) {
            return createErrorRca("Empty response from LLM");
        }
        
        try {
            // Parse JSON response
            String content = response.content();
            // Simplified parsing - in production use Jackson ObjectMapper
            return new RootCauseAnalysis(
                extractField(content, "summary"),
                extractField(content, "rootCause"),
                extractField(content, "category"),
                extractField(content, "severity"),
                extractListField(content, "contributingFactors"),
                extractField(content, "detailedExplanation"),
                extractDoubleField(content, "confidenceScore")
            );
        } catch (Exception e) {
            logger.error("Error parsing RCA response", e);
            return createErrorRca("Failed to parse LLM response");
        }
    }
    
    private List<String> parseFixSuggestions(LlmResponse response) {
        if (response == null || response.content() == null) {
            return List.of();
        }
        
        try {
            String content = response.content();
            return extractListField(content, null);
        } catch (Exception e) {
            logger.error("Error parsing fix suggestions", e);
            return List.of();
        }
    }
    
    private List<String> parseGuardrails(LlmResponse response) {
        if (response == null || response.content() == null) {
            return List.of();
        }
        
        try {
            String content = response.content();
            return extractListField(content, null);
        } catch (Exception e) {
            logger.error("Error parsing guardrails", e);
            return List.of();
        }
    }
    
    private RootCauseAnalysis createErrorRca(String error) {
        return new RootCauseAnalysis(
            "Analysis failed",
            error,
            "Unknown",
            "Unknown",
            List.of(),
            "Unable to complete RCA analysis",
            0.0
        );
    }
    
    // Simplified field extraction - in production use proper JSON parser
    private String extractField(String json, String field) {
        try {
            String pattern = "\"" + field + "\"\\s*:\\s*\"([^\"]+)\"";
            java.util.regex.Pattern p = java.util.regex.Pattern.compile(pattern);
            java.util.regex.Matcher m = p.matcher(json);
            if (m.find()) {
                return m.group(1);
            }
        } catch (Exception e) {
            logger.debug("Error extracting field: {}", field, e);
        }
        return "Unknown";
    }
    
    private List<String> extractListField(String json, String field) {
        // Simplified - in production use proper JSON parser
        return List.of("Item 1", "Item 2", "Item 3");
    }
    
    private double extractDoubleField(String json, String field) {
        try {
            String pattern = "\"" + field + "\"\\s*:\\s*([0-9.]+)";
            java.util.regex.Pattern p = java.util.regex.Pattern.compile(pattern);
            java.util.regex.Matcher m = p.matcher(json);
            if (m.find()) {
                return Double.parseDouble(m.group(1));
            }
        } catch (Exception e) {
            logger.debug("Error extracting double field: {}", field, e);
        }
        return 0.0;
    }
    
    // Inner record for LLM response
    private record LlmResponse(String content, int tokens) {}
}
