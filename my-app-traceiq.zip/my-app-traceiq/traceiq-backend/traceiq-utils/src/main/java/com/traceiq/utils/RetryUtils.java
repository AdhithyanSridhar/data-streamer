package com.traceiq.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Supplier;

/**
 * Utility class for retry logic with exponential backoff.
 */
public class RetryUtils {
    
    private static final Logger logger = LoggerFactory.getLogger(RetryUtils.class);
    
    /**
     * Executes a supplier with retry logic.
     *
     * @param supplier       the operation to execute
     * @param maxAttempts    maximum number of attempts
     * @param delayMs        initial delay in milliseconds
     * @param operationName  name of the operation for logging
     * @param <T>            return type
     * @return result of the operation
     * @throws RuntimeException if all retries fail
     */
    public static <T> T executeWithRetry(
            Supplier<T> supplier,
            int maxAttempts,
            long delayMs,
            String operationName) {
        
        int attempt = 0;
        long currentDelay = delayMs;
        
        while (attempt < maxAttempts) {
            try {
                attempt++;
                logger.debug("Executing {} - Attempt {}/{}", operationName, attempt, maxAttempts);
                return supplier.get();
            } catch (Exception e) {
                logger.warn("Attempt {}/{} failed for {}: {}", 
                    attempt, maxAttempts, operationName, e.getMessage());
                
                if (attempt >= maxAttempts) {
                    logger.error("All {} attempts failed for {}", maxAttempts, operationName);
                    throw new RuntimeException("Operation failed after " + maxAttempts + " attempts", e);
                }
                
                try {
                    logger.debug("Waiting {}ms before retry", currentDelay);
                    Thread.sleep(currentDelay);
                    currentDelay *= 2; // Exponential backoff
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new RuntimeException("Retry interrupted", ie);
                }
            }
        }
        
        throw new RuntimeException("Unexpected retry loop exit");
    }
    
    /**
     * Executes a supplier with default retry configuration (3 attempts, 1000ms delay).
     *
     * @param supplier       the operation to execute
     * @param operationName  name of the operation for logging
     * @param <T>            return type
     * @return result of the operation
     */
    public static <T> T executeWithRetry(Supplier<T> supplier, String operationName) {
        return executeWithRetry(supplier, 3, 1000L, operationName);
    }
}
