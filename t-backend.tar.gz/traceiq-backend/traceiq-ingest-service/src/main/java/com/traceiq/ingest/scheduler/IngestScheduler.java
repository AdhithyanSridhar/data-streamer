package com.traceiq.ingest.scheduler;

import com.traceiq.ingest.service.IngestService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class IngestScheduler {
    private static final Logger logger = LoggerFactory.getLogger(IngestScheduler.class);

    private final IngestService ingestService;

    public IngestScheduler(IngestService ingestService) {
        this.ingestService = ingestService;
    }

    @Scheduled(cron = "0 0 2 * * ?") // Run daily at 2 AM
    public void scheduledIngest() {
        logger.info("Starting scheduled ingest job");
        ingestService.ingestErrors("now-24h");
    }
}
