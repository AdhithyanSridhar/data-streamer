package com.traceiq.client;

import com.traceiq.model.CodeAnalysis;
import com.traceiq.model.RootCauseAnalysis;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.Map;

/**
 * Client for internal vectorized codebase LLM API.
 * Searches codebase and identifies problematic code locations.
 */
@Component
public class CodebaseLlmClient {
    
    private static final Logger logger = LoggerFactory.getLogger(CodebaseLlmClient.class);
    
    private final WebClient webClient;
    
    public CodebaseLlmClient(
        @Value("${codebase.llm.base-url}") String codebaseLlmBaseUrl,
        WebClient.Builder webClientBuilder
    ) {
        this.webClient = webClientBuilder.baseUrl(codebaseLlmBaseUrl).build();
        logger.info("CodebaseLlmClient initialized with base URL: {}", codebaseLlmBaseUrl);
    }
    
    /**
     * Search vectorized codebase to locate problematic code.
     */
    public CodeAnalysis locateProblematicCode(
        String microserviceName,
        RootCauseAnalysis rca,
        String errorStackTrace
    ) {
        logger.info("Locating problematic code for service: {}", microserviceName);
        
        try {
            String searchQuery = buildCodeSearchQuery(rca, errorStackTrace);
            
            Map<String, Object> request = Map.of(
                "query", searchQuery,
                "microservice", microserviceName,
                "maxResults", 5
            );
            
            CodeSearchResponse response = webClient.post()
                .uri("/api/v1/code/search")
                .bodyValue(request)
                .retrieve()
                .bodyToMono(CodeSearchResponse.class)
                .block();
            
            return parseCodeAnalysis(response);
            
        } catch (Exception e) {
            logger.error("Error locating code for service: {}", microserviceName, e);
            return createErrorCodeAnalysis(e.getMessage());
        }
    }
    
    /**
     * Generate implementation plan for GitHub Copilot.
     */
    public String generateImplementationPlan(CodeAnalysis codeAnalysis, RootCauseAnalysis rca) {
        logger.info("Generating implementation plan for file: {}", codeAnalysis.filePath());
        
        try {
            String prompt = buildImplementationPlanPrompt(codeAnalysis, rca);
            
            Map<String, Object> request = Map.of(
                "prompt", prompt,
                "codeContext", Map.of(
                    "file", codeAnalysis.filePath(),
                    "class", codeAnalysis.className(),
                    "method", codeAnalysis.methodName()
                )
            );
            
            ImplementationPlanResponse response = webClient.post()
                .uri("/api/v1/code/implementation-plan")
                .bodyValue(request)
                .retrieve()
                .bodyToMono(ImplementationPlanResponse.class)
                .block();
            
            return response != null ? response.plan() : "Unable to generate implementation plan";
            
        } catch (Exception e) {
            logger.error("Error generating implementation plan", e);
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Assess production readiness of suggested fix.
     */
    public String assessProductionReadiness(CodeAnalysis codeAnalysis) {
        logger.info("Assessing production readiness for fix");
        
        try {
            Map<String, Object> request = Map.of(
                "code", codeAnalysis.problematicCode(),
                "suggestedFix", codeAnalysis.suggestedFix(),
                "context", Map.of(
                    "file", codeAnalysis.filePath(),
                    "relatedFiles", codeAnalysis.relatedFiles()
                )
            );
            
            ProductionReadinessResponse response = webClient.post()
                .uri("/api/v1/code/production-readiness")
                .bodyValue(request)
                .retrieve()
                .bodyToMono(ProductionReadinessResponse.class)
                .block();
            
            return response != null ? response.score() : "Unknown";
            
        } catch (Exception e) {
            logger.error("Error assessing production readiness", e);
            return "Assessment failed";
        }
    }
    
    // Private helper methods
    
    private String buildCodeSearchQuery(RootCauseAnalysis rca, String stackTrace) {
        StringBuilder query = new StringBuilder();
        
        query.append("Root Cause: ").append(rca.rootCause()).append("\n");
        query.append("Category: ").append(rca.category()).append("\n");
        
        if (stackTrace != null && !stackTrace.isBlank()) {
            query.append("Stack Trace: ").append(stackTrace).append("\n");
        }
        
        if (rca.contributingFactors() != null) {
            query.append("Contributing Factors: ")
                .append(String.join( ", ", (Iterable<? extends CharSequence>) rca.contributingFactors()))
                .append("\n");
        }
        
        return query.toString();
    }
    
    private String buildImplementationPlanPrompt(CodeAnalysis codeAnalysis, RootCauseAnalysis rca) {
        return String.format(
            "Generate a detailed implementation plan for GitHub Copilot to fix the following issue:\n\n" +
            "File: %s\n" +
            "Class: %s\n" +
            "Method: %s\n" +
            "Line: %d\n\n" +
            "Problematic Code:\n%s\n\n" +
            "Suggested Fix:\n%s\n\n" +
            "Root Cause: %s\n\n" +
            "Provide step-by-step implementation instructions that can be used by developers with GitHub Copilot.",
            codeAnalysis.filePath(),
            codeAnalysis.className(),
            codeAnalysis.methodName(),
            codeAnalysis.lineNumber(),
            codeAnalysis.problematicCode(),
            codeAnalysis.suggestedFix(),
            rca.rootCause()
        );
    }
    
    private CodeAnalysis parseCodeAnalysis(CodeSearchResponse response) {
        if (response == null || response.results().isEmpty()) {
            return createErrorCodeAnalysis("No code found");
        }
        
        CodeResult result = response.results().get(0);
        
        return new CodeAnalysis(
            result.filePath(),
            result.className(),
            result.methodName(),
            result.lineNumber(),
            result.codeSnippet(),
            result.suggestedFix(),
            result.explanation(),
            result.relatedFiles(),
            "Pending"
        );
    }
    
    private CodeAnalysis createErrorCodeAnalysis(String error) {
        return new CodeAnalysis(
            "Unknown",
            "Unknown",
            "Unknown",
            0,
            error,
            "No fix available",
            "Unable to locate problematic code",
            List.of(),
            "N/A"
        );
    }
    
    // Inner records for API responses
    private record CodeSearchResponse(List<CodeResult> results) {}
    
    private record CodeResult(
        String filePath,
        String className,
        String methodName,
        int lineNumber,
        String codeSnippet,
        String suggestedFix,
        String explanation,
        List<String> relatedFiles
    ) {}
    
    private record ImplementationPlanResponse(String plan) {}
    
    private record ProductionReadinessResponse(String score, List<String> concerns) {}
}
