package com.traceiq.core.controller;

import com.traceiq.core.service.TraceService;
import com.traceiq.models.dto.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/trace")
@Tag(name = "Trace API", description = "TraceID search and analysis endpoints")
public class TraceController {
    
    private static final Logger logger = LoggerFactory.getLogger(TraceController.class);
    private final TraceService traceService;
    
    public TraceController(TraceService traceService) {
        this.traceService = traceService;
    }
    
    @GetMapping("/{traceId}")
    @Operation(summary = "Search by TraceID", description = "Get comprehensive trace information")
    public ResponseEntity<TraceSearchResponse> searchTrace(@PathVariable String traceId) {
        logger.info("Searching for traceId: {}", traceId);
        TraceSearchResponse response = traceService.searchTrace(traceId);
        return ResponseEntity.ok(response);
    }
    
    @PostMapping("/{traceId}/rca")
    @Operation(summary = "Get RCA", description = "Generate Root Cause Analysis")
    public ResponseEntity<RCAResponse> getRCA(
            @PathVariable String traceId,
            @RequestBody(required = false) RCARequest request) {
        logger.info("Generating RCA for traceId: {}", traceId);
        RCAResponse response = traceService.generateRCA(traceId, request);
        return ResponseEntity.ok(response);
    }
    
    @PostMapping("/{traceId}/implementation-plan")
    @Operation(summary = "Get Implementation Plan", description = "Generate implementation plan with code locations")
    public ResponseEntity<RCAResponse> getImplementationPlan(
            @PathVariable String traceId,
            @RequestBody(required = false) RCARequest request) {
        logger.info("Generating implementation plan for traceId: {}", traceId);
        RCAResponse response = traceService.generateImplementationPlan(traceId, request);
        return ResponseEntity.ok(response);
    }
    
    @PostMapping("/{traceId}/god-mode")
    @Operation(summary = "God Mode", description = "Run complete RCA and implementation plan analysis")
    public ResponseEntity<RCAResponse> godMode(@PathVariable String traceId) {
        logger.info("Running God Mode for traceId: {}", traceId);
        RCAResponse response = traceService.godMode(traceId);
        return ResponseEntity.ok(response);
    }
}
