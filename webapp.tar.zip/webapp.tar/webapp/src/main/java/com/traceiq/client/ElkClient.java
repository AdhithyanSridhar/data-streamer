package com.traceiq.client;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Client for Elasticsearch/ELK operations
 * Handles log retrieval, analysis, and aggregations
 */
@Component
public class ElkClient {

    public static final Logger log = LoggerFactory.getLogger(ElkClient.class);
    @Qualifier("elkWebClient")
    private final WebClient elkWebClient;
    private final ObjectMapper objectMapper;

    public ElkClient(WebClient elkWebClient, ObjectMapper objectMapper) {
        this.elkWebClient = elkWebClient;
        this.objectMapper = objectMapper;
    }

    /**
     * Retrieves logs by trace ID with optional filtering
     */
    public Map<String, Object> getLogsByTraceId(String traceId, String logLevel,
                                                String microserviceName, Integer timeRangeMinutes) {
        log.info("Fetching logs for traceId: {}, level: {}, service: {}", traceId, logLevel, microserviceName);

        Map<String, Object> query = buildTraceQuery(traceId, logLevel, microserviceName, timeRangeMinutes);

        try {
            Map<String, Object> response = elkWebClient.post()
                    .uri("/_search")
                    .bodyValue(query)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();

            return parseLogsResponse(response);
        } catch (Exception e) {
            log.error("Error fetching logs from ELK", e);
            return Map.of("error", e.getMessage(), "logs", Collections.emptyList());
        }
    }

    /**
     * Searches for errors in a microservice
     */
    public Map<String, Object> searchErrors(String microserviceName, Integer timeRangeMinutes) {
        log.info("Searching errors for microservice: {}", microserviceName);

        Map<String, Object> query = buildErrorQuery(microserviceName, timeRangeMinutes);

        try {
            Map<String, Object> response = elkWebClient.post()
                    .uri("/_search")
                    .bodyValue(query)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();

            return aggregateErrors(response);
        } catch (Exception e) {
            log.error("Error searching errors in ELK", e);
            return Map.of("error", e.getMessage(), "errors", Collections.emptyList());
        }
    }

    /**
     * Performs latency analysis on trace
     */
    public Map<String, Object> performLatencyAnalysis(String traceId, String microserviceName) {
        log.info("Performing latency analysis for traceId: {}", traceId);

        try {
            Map<String, Object> logs = getLogsByTraceId(traceId, null, microserviceName, 60);
            return calculateLatencyMetrics(logs);
        } catch (Exception e) {
            log.error("Error performing latency analysis", e);
            return Map.of("error", e.getMessage());
        }
    }

    /**
     * Captures service flow from logs
     */
    public List<String> captureServiceFlow(String traceId, String microserviceName) {
        log.info("Capturing service flow for traceId: {}", traceId);

        try {
            Map<String, Object> logs = getLogsByTraceId(traceId, null, microserviceName, 60);
            return extractServiceFlow(logs);
        } catch (Exception e) {
            log.error("Error capturing service flow", e);
            return Collections.emptyList();
        }
    }

    /**
     * Counts logs by level (INFO, WARN, ERROR)
     */
    public Map<String, Long> countLogsByLevel(String traceId, String microserviceName) {
        log.info("Counting logs by level for traceId: {}", traceId);

        Map<String, Object> query = buildLevelCountQuery(traceId, microserviceName);

        try {
            Map<String, Object> response = elkWebClient.post()
                    .uri("/_search")
                    .bodyValue(query)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();

            return extractLevelCounts(response);
        } catch (Exception e) {
            log.error("Error counting logs by level", e);
            return Map.of();
        }
    }

    /**
     * Searches for specific log patterns
     */
    public List<Map<String, Object>> searchLogPattern(String pattern, String microserviceName,
                                                      Integer timeRangeMinutes) {
        log.info("Searching log pattern: {} in service: {}", pattern, microserviceName);

        Map<String, Object> query = buildPatternQuery(pattern, microserviceName, timeRangeMinutes);

        try {
            Map<String, Object> response = elkWebClient.post()
                    .uri("/_search")
                    .bodyValue(query)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();

            return extractHits(response);
        } catch (Exception e) {
            log.error("Error searching log pattern", e);
            return Collections.emptyList();
        }
    }

    /**
     * Checks for alerts related to microservice
     */
    public List<Map<String, Object>> checkAlerts(String microserviceName, Integer timeRangeMinutes) {
        log.info("Checking alerts for microservice: {}", microserviceName);

        Map<String, Object> query = buildAlertQuery(microserviceName, timeRangeMinutes);

        try {
            Map<String, Object> response = elkWebClient.post()
                    .uri("/_search")
                    .bodyValue(query)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();

            return extractHits(response);
        } catch (Exception e) {
            log.error("Error checking alerts", e);
            return Collections.emptyList();
        }
    }

    // ========== Private Helper Methods ==========

    private Map<String, Object> buildTraceQuery(String traceId, String logLevel,
                                                String microserviceName, Integer timeRange) {
        List<Map<String, Object>> must = new ArrayList<>();
        must.add(Map.of("match", Map.of("traceId", traceId)));

        if (logLevel != null) {
            must.add(Map.of("match", Map.of("level", logLevel)));
        }

        if (microserviceName != null) {
            must.add(Map.of("match", Map.of("service.name", microserviceName)));
        }

        return Map.of(
                "query", Map.of(
                        "bool", Map.of(
                                "must", must,
                                "filter", Map.of(
                                        "range", Map.of(
                                                "@timestamp", Map.of(
                                                        "gte", "now-" + (timeRange != null ? timeRange : 60) + "m"
                                                )
                                        )
                                )
                        )
                ),
                "size", 1000,
                "sort", List.of(Map.of("@timestamp", "asc"))
        );
    }

    private Map<String, Object> buildErrorQuery(String microserviceName, Integer timeRange) {
        return Map.of(
                "query", Map.of(
                        "bool", Map.of(
                                "must", List.of(
                                        Map.of("match", Map.of("level", "ERROR")),
                                        Map.of("match", Map.of("service.name", microserviceName))
                                ),
                                "filter", Map.of(
                                        "range", Map.of(
                                                "@timestamp", Map.of("gte", "now-" + timeRange + "m")
                                        )
                                )
                        )
                ),
                "aggs", Map.of(
                        "error_groups", Map.of(
                                "terms", Map.of(
                                        "field", "message.keyword",
                                        "size", 50
                                )
                        )
                )
        );
    }

    private Map<String, Object> buildLevelCountQuery(String traceId, String microserviceName) {
        return Map.of(
                "query", Map.of(
                        "bool", Map.of(
                                "must", List.of(
                                        Map.of("match", Map.of("traceId", traceId))
                                )
                        )
                ),
                "aggs", Map.of(
                        "level_counts", Map.of(
                                "terms", Map.of("field", "level.keyword")
                        )
                ),
                "size", 0
        );
    }

    private Map<String, Object> buildPatternQuery(String pattern, String microserviceName, Integer timeRange) {
        return Map.of(
                "query", Map.of(
                        "bool", Map.of(
                                "must", List.of(
                                        Map.of("wildcard", Map.of("message", "*" + pattern + "*")),
                                        Map.of("match", Map.of("service.name", microserviceName))
                                ),
                                "filter", Map.of(
                                        "range", Map.of(
                                                "@timestamp", Map.of("gte", "now-" + timeRange + "m")
                                        )
                                )
                        )
                )
        );
    }

    private Map<String, Object> buildAlertQuery(String microserviceName, Integer timeRange) {
        return Map.of(
                "query", Map.of(
                        "bool", Map.of(
                                "must", List.of(
                                        Map.of("match", Map.of("alert", true)),
                                        Map.of("match", Map.of("service.name", microserviceName))
                                ),
                                "filter", Map.of(
                                        "range", Map.of(
                                                "@timestamp", Map.of("gte", "now-" + timeRange + "m")
                                        )
                                )
                        )
                )
        );
    }

    private Map<String, Object> parseLogsResponse(Map<String, Object> response) {
        List<Map<String, Object>> hits = extractHits(response);
        return Map.of(
                "total", hits.size(),
                "logs", hits
        );
    }

    private Map<String, Object> aggregateErrors(Map<String, Object> response) {
        List<Map<String, Object>> hits = extractHits(response);
        Map<String, List<Map<String, Object>>> grouped = hits.stream()
                .collect(Collectors.groupingBy(hit ->
                        (String) ((Map<String, Object>) hit.get("_source")).getOrDefault("message", "Unknown")));

        return Map.of(
                "total", hits.size(),
                "grouped", grouped,
                "uniqueErrors", grouped.size()
        );
    }

    private Map<String, Object> calculateLatencyMetrics(Map<String, Object> logs) {
        List<Map<String, Object>> logList = (List<Map<String, Object>>) logs.get("logs");

        if (logList.isEmpty()) {
            return Map.of("error", "No logs found");
        }

        // Mock latency calculation - in real scenario, parse timestamps
        return Map.of(
                "averageLatencyMs", 250,
                "maxLatencyMs", 500,
                "minLatencyMs", 100,
                "p95LatencyMs", 450,
                "p99LatencyMs", 490
        );
    }

    private List<String> extractServiceFlow(Map<String, Object> logs) {
        List<Map<String, Object>> logList = (List<Map<String, Object>>) logs.get("logs");

        return logList.stream()
                .map(log -> (Map<String, Object>) log.get("_source"))
                .map(source -> (String) source.getOrDefault("service.name", "unknown"))
                .distinct()
                .collect(Collectors.toList());
    }

    private Map<String, Long> extractLevelCounts(Map<String, Object> response) {
        try {
            Map<String, Object> aggs = (Map<String, Object>) response.get("aggregations");
            Map<String, Object> levelCounts = (Map<String, Object>) aggs.get("level_counts");
            List<Map<String, Object>> buckets = (List<Map<String, Object>>) levelCounts.get("buckets");

            return buckets.stream()
                    .collect(Collectors.toMap(
                            bucket -> (String) bucket.get("key"),
                            bucket -> ((Number) bucket.get("doc_count")).longValue()
                    ));
        } catch (Exception e) {
            log.error("Error extracting level counts", e);
            return Map.of();
        }
    }

    private List<Map<String, Object>> extractHits(Map<String, Object> response) {
        try {
            Map<String, Object> hits = (Map<String, Object>) response.get("hits");
            List<Map<String, Object>> hitsList = (List<Map<String, Object>>) hits.get("hits");
            return hitsList != null ? hitsList : Collections.emptyList();
        } catch (Exception e) {
            log.error("Error extracting hits", e);
            return Collections.emptyList();
        }
    }
}
