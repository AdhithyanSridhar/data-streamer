<template>
  <div class="min-h-screen bg-gray-100">
    <nav class="bg-indigo-600 text-white shadow-lg">
      <div class="container mx-auto px-4 py-4">
        <div class="flex items-center justify-between">
          <div class="flex items-center space-x-2">
            <i class="fas fa-chart-line text-2xl"></i>
            <h1 class="text-2xl font-bold">TraceIQ</h1>
            <span class="text-sm opacity-75">AI-powered RCA</span>
          </div>
          <div class="flex space-x-4">
            <router-link to="/" class="hover:text-indigo-200 px-3 py-2 rounded">
              <i class="fas fa-search mr-2"></i>Trace Search
            </router-link>
            <router-link to="/errors" class="hover:text-indigo-200 px-3 py-2 rounded">
              <i class="fas fa-exclamation-triangle mr-2"></i>Errors
            </router-link>
            <router-link to="/jobs" class="hover:text-indigo-200 px-3 py-2 rounded">
              <i class="fas fa-tasks mr-2"></i>Jobs
            </router-link>
            <router-link to="/help" class="hover:text-indigo-200 px-3 py-2 rounded">
              <i class="fas fa-question-circle mr-2"></i>Help
            </router-link>
          </div>
        </div>
      </div>
    </nav>
    <main class="container mx-auto px-4 py-8">
      <router-view />
    </main>
  </div>
</template>

<script setup>
</script>
