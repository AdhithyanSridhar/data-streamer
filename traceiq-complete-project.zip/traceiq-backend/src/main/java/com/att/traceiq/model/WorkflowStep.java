package com.att.traceiq.model;

public enum WorkflowStep {
    INIT,
    ELK_FETCH,
    AI_ANALYSIS,
    CODE_SEARCH,
    JIRA_CREATE,
    COMPLETE,
    ERROR
}
