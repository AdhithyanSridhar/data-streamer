package com.traceiq.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Supplier;

/**
 * Utility class for implementing retry logic with exponential backoff
 * for transient failures in external API calls
 */
public class RetryUtil {
    private static final Logger logger = LoggerFactory.getLogger(RetryUtil.class);

    private RetryUtil() {
        // Utility class
    }

    /**
     * Execute a supplier with retry logic
     *
     * @param supplier The operation to execute
     * @param maxRetries Maximum number of retry attempts
     * @param initialDelayMs Initial delay in milliseconds
     * @param maxDelayMs Maximum delay in milliseconds
     * @param operationName Name of the operation for logging
     * @return Result of the supplier
     * @throws RuntimeException if all retries are exhausted
     */
    public static <T> T executeWithRetry(
            Supplier<T> supplier,
            int maxRetries,
            long initialDelayMs,
            long maxDelayMs,
            String operationName
    ) {
        int attempt = 0;
        long delay = initialDelayMs;

        while (attempt < maxRetries) {
            try {
                logger.debug("Executing {} - Attempt {}/{}", operationName, attempt + 1, maxRetries);
                return supplier.get();
            } catch (Exception e) {
                attempt++;
                if (attempt >= maxRetries) {
                    logger.error("All retry attempts exhausted for {}", operationName, e);
                    throw new RuntimeException("Failed after " + maxRetries + " attempts: " + operationName, e);
                }

                logger.warn("Attempt {}/{} failed for {}. Retrying after {}ms. Error: {}",
                        attempt, maxRetries, operationName, delay, e.getMessage());

                try {
                    Thread.sleep(delay);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new RuntimeException("Retry interrupted for " + operationName, ie);
                }

                // Exponential backoff with cap
                delay = Math.min(delay * 2, maxDelayMs);
            }
        }

        throw new RuntimeException("Unexpected retry failure for " + operationName);
    }

    /**
     * Execute with default retry parameters (3 retries, 1s initial delay, 10s max)
     */
    public static <T> T executeWithDefaultRetry(Supplier<T> supplier, String operationName) {
        return executeWithRetry(supplier, 3, 1000, 10000, operationName);
    }
}
