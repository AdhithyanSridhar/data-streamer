<template>
  <v-container fluid class="pa-6">
    <!-- Page Header -->
    <div class="page-header mb-6">
      <div class="header-content">
        <h1 class="page-title">Incidents</h1>
        <p class="page-subtitle">Track and manage ongoing and past incidents</p>
      </div>
      <v-btn color="primary" rounded="lg" @click="createIncident">
        <v-icon icon="mdi-plus" class="mr-2"></v-icon>
        New Incident
      </v-btn>
    </div>

    <!-- Stats -->
    <v-row class="mb-6">
      <v-col cols="12" sm="6" md="3" v-for="stat in stats" :key="stat.title">
        <div class="glass-card pa-4 stat-card">
          <div class="stat-icon">
            <v-icon :icon="stat.icon" size="24"></v-icon>
          </div>
          <div class="stat-content">
            <span class="stat-value">{{ stat.value }}</span>
            <span class="stat-label">{{ stat.title }}</span>
          </div>
        </div>
      </v-col>
    </v-row>

    <!-- Incidents Tabs -->
    <v-tabs v-model="activeTab" class="mb-4">
      <v-tab value="active">Active ({{ activeIncidents.length }})</v-tab>
      <v-tab value="resolved">Resolved</v-tab>
      <v-tab value="all">All</v-tab>
    </v-tabs>

    <!-- Active Incidents -->
    <div v-if="activeTab === 'active'" class="incidents-list">
      <div v-for="incident in activeIncidents" :key="incident.id" class="glass-card incident-card">
        <div class="incident-header">
          <div class="incident-severity" :class="`severity--${incident.severity}`">
            <v-icon :icon="getSeverityIcon(incident.severity)" size="16"></v-icon>
            {{ incident.severity }}
          </div>
          <div class="incident-status">
            <v-chip :color="getStatusColor(incident.status)" size="small" variant="flat">
              {{ incident.status }}
            </v-chip>
          </div>
        </div>
        
        <h3 class="incident-title">{{ incident.title }}</h3>
        <p class="incident-description">{{ incident.description }}</p>
        
        <div class="incident-meta">
          <div class="meta-item">
            <v-icon icon="mdi-clock-outline" size="14"></v-icon>
            Started {{ incident.startTime }}
          </div>
          <div class="meta-item">
            <v-icon icon="mdi-server-outline" size="14"></v-icon>
            {{ incident.services.join(', ') }}
          </div>
          <div class="meta-item">
            <v-icon icon="mdi-account-outline" size="14"></v-icon>
            {{ incident.owner }}
          </div>
        </div>
        
        <!-- Timeline -->
        <div class="incident-timeline">
          <div class="timeline-header" @click="incident.expanded = !incident.expanded">
            <span>Timeline ({{ incident.timeline.length }} updates)</span>
            <v-icon :icon="incident.expanded ? 'mdi-chevron-up' : 'mdi-chevron-down'" size="18"></v-icon>
          </div>
          
          <v-expand-transition>
            <div v-show="incident.expanded" class="timeline-content">
              <div v-for="(event, idx) in incident.timeline" :key="idx" class="timeline-event">
                <div class="event-dot" :class="`event-dot--${event.type}`"></div>
                <div class="event-content">
                  <span class="event-time">{{ event.time }}</span>
                  <span class="event-text">{{ event.text }}</span>
                </div>
              </div>
            </div>
          </v-expand-transition>
        </div>
        
        <!-- Related Errors -->
        <div class="incident-errors" v-if="incident.errors.length">
          <div class="errors-header">Related Errors</div>
          <div class="error-chips">
            <v-chip v-for="error in incident.errors" :key="error" size="small" variant="outlined" class="mr-1 mb-1">
              {{ error }}
            </v-chip>
          </div>
        </div>
        
        <div class="incident-actions">
          <v-btn variant="outlined" size="small" rounded="lg">
            <v-icon icon="mdi-eye-outline" class="mr-1"></v-icon>
            View Details
          </v-btn>
          <v-btn variant="outlined" size="small" rounded="lg">
            <v-icon icon="mdi-robot-outline" class="mr-1"></v-icon>
            Assign Agent
          </v-btn>
          <v-btn variant="outlined" size="small" rounded="lg" color="success">
            <v-icon icon="mdi-check" class="mr-1"></v-icon>
            Resolve
          </v-btn>
          <v-btn variant="outlined" size="small" rounded="lg">
            <v-icon icon="mdi-file-document-outline" class="mr-1"></v-icon>
            Post-Mortem
          </v-btn>
        </div>
      </div>
    </div>
    
    <!-- Resolved Incidents -->
    <div v-else class="incidents-list">
      <div v-for="incident in resolvedIncidents" :key="incident.id" class="glass-card incident-card incident-card--resolved">
        <div class="incident-header">
          <div class="incident-severity" :class="`severity--${incident.severity}`">
            {{ incident.severity }}
          </div>
          <v-chip color="success" size="small" variant="flat">Resolved</v-chip>
        </div>
        <h3 class="incident-title">{{ incident.title }}</h3>
        <div class="incident-meta">
          <span>Duration: {{ incident.duration }}</span>
          <span>•</span>
          <span>Resolved by {{ incident.resolvedBy }}</span>
        </div>
      </div>
    </div>

    <!-- Create Incident Dialog -->
    <v-dialog v-model="showCreateDialog" max-width="600">
      <v-card class="dialog-card">
        <v-card-title class="dialog-title">
          <v-icon icon="mdi-alert-octagon-outline" class="mr-2"></v-icon>
          Create New Incident
        </v-card-title>
        <v-card-text>
          <v-text-field v-model="newIncident.title" label="Incident Title" variant="outlined" class="mb-4"></v-text-field>
          <v-textarea v-model="newIncident.description" label="Description" variant="outlined" rows="3" class="mb-4"></v-textarea>
          <v-select v-model="newIncident.severity" :items="['critical', 'high', 'medium', 'low']" label="Severity" variant="outlined" class="mb-4"></v-select>
          <v-select v-model="newIncident.services" :items="allServices" label="Affected Services" variant="outlined" multiple chips></v-select>
        </v-card-text>
        <v-card-actions class="pa-4">
          <v-spacer></v-spacer>
          <v-btn variant="text" @click="showCreateDialog = false">Cancel</v-btn>
          <v-btn color="primary" variant="flat" @click="saveIncident">Create Incident</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'

const route = useRoute()
const activeTab = ref('active')
const showCreateDialog = ref(false)

const stats = [
  { title: 'Active Incidents', value: '3', icon: 'mdi-alert-octagon-outline' },
  { title: 'MTTR', value: '2h 15m', icon: 'mdi-clock-outline' },
  { title: 'This Month', value: '12', icon: 'mdi-calendar-outline' },
  { title: 'Resolved Today', value: '4', icon: 'mdi-check-circle-outline' }
]

const allServices = ['payment-service', 'billing-service', 'order-service', 'auth-service', 'api-gateway', 'notification-service']

const newIncident = ref({
  title: '',
  description: '',
  severity: 'medium',
  services: []
})

const activeIncidents = ref([
  {
    id: 1,
    title: 'Payment Processing Failures',
    description: 'Multiple payment transactions failing due to NullPointerException in PaymentProcessor',
    severity: 'critical',
    status: 'investigating',
    startTime: '2 hours ago',
    services: ['payment-service', 'billing-service'],
    owner: 'John Doe',
    expanded: true,
    timeline: [
      { time: '14:30', text: 'Incident created - High error rate detected', type: 'created' },
      { time: '14:35', text: 'Assigned to John Doe', type: 'assigned' },
      { time: '14:45', text: 'Root cause identified: Missing null check', type: 'update' },
      { time: '15:00', text: 'Agent assigned to generate fix', type: 'agent' },
      { time: '15:15', text: 'PR #567 created with fix', type: 'fix' }
    ],
    errors: ['NullPointerException', 'ConnectionTimeout']
  },
  {
    id: 2,
    title: 'Increased Latency in Order Service',
    description: 'Order service experiencing 3x normal latency affecting checkout flow',
    severity: 'high',
    status: 'identified',
    startTime: '45 min ago',
    services: ['order-service'],
    owner: 'Jane Smith',
    expanded: false,
    timeline: [
      { time: '16:00', text: 'Latency alert triggered', type: 'created' },
      { time: '16:05', text: 'Investigation started', type: 'update' }
    ],
    errors: ['SlowQueryException']
  },
  {
    id: 3,
    title: 'Authentication Timeouts',
    description: 'Intermittent timeout errors in authentication flow',
    severity: 'medium',
    status: 'monitoring',
    startTime: '4 hours ago',
    services: ['auth-service'],
    owner: 'AI Agent',
    expanded: false,
    timeline: [
      { time: '12:30', text: 'Timeout alerts detected', type: 'created' },
      { time: '13:00', text: 'Issue auto-resolved', type: 'update' },
      { time: '13:30', text: 'Monitoring for recurrence', type: 'update' }
    ],
    errors: ['TimeoutException']
  }
])

const resolvedIncidents = ref([
  { id: 4, title: 'Database Connection Pool Exhausted', severity: 'high', duration: '1h 30m', resolvedBy: 'AI Agent' },
  { id: 5, title: 'Memory Leak in Notification Service', severity: 'medium', duration: '3h 45m', resolvedBy: 'John Doe' }
])

onMounted(() => {
  if (route.query.new === 'true') {
    showCreateDialog.value = true
  }
})

const getSeverityIcon = (severity) => {
  const icons = { critical: 'mdi-alert-octagon', high: 'mdi-alert', medium: 'mdi-alert-circle-outline', low: 'mdi-information-outline' }
  return icons[severity] || icons.medium
}

const getStatusColor = (status) => {
  const colors = { investigating: 'error', identified: 'warning', monitoring: 'info', resolved: 'success' }
  return colors[status] || 'grey'
}

const createIncident = () => {
  showCreateDialog.value = true
}

const saveIncident = () => {
  activeIncidents.value.unshift({
    id: Date.now(),
    title: newIncident.value.title,
    description: newIncident.value.description,
    severity: newIncident.value.severity,
    status: 'investigating',
    startTime: 'Just now',
    services: newIncident.value.services,
    owner: 'You',
    expanded: true,
    timeline: [{ time: 'Now', text: 'Incident created', type: 'created' }],
    errors: []
  })
  showCreateDialog.value = false
  newIncident.value = { title: '', description: '', severity: 'medium', services: [] }
}
</script>

<style scoped>
.page-header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px; }
.page-title { font-size: 1.5rem; font-weight: 700; color: #1a1a1a; margin-bottom: 4px; }
.page-subtitle { font-size: 0.9rem; color: #666666; }

.stat-card { display: flex; flex-direction: column; gap: 12px; }
.stat-icon { width: 44px; height: 44px; border-radius: 10px; display: flex; align-items: center; justify-content: center; background: #f5f5f5; color: #1a1a1a; }
.stat-content { display: flex; flex-direction: column; gap: 4px; }
.stat-value { font-size: 1.5rem; font-weight: 700; color: #1a1a1a; }
.stat-label { font-size: 0.8rem; color: #666666; }

.incidents-list { display: flex; flex-direction: column; gap: 16px; }
.incident-card { padding: 20px; }
.incident-card--resolved { opacity: 0.7; }

.incident-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
.incident-severity { display: flex; align-items: center; gap: 6px; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; padding: 4px 10px; border-radius: 4px; }
.severity--critical { background: rgba(239,68,68,0.1); color: #dc2626; }
.severity--high { background: rgba(245,158,11,0.1); color: #d97706; }
.severity--medium { background: rgba(59,130,246,0.1); color: #2563eb; }
.severity--low { background: #f0f0f0; color: #666666; }

.incident-title { font-size: 1.1rem; font-weight: 600; color: #1a1a1a; margin-bottom: 8px; }
.incident-description { font-size: 0.9rem; color: #666666; margin-bottom: 12px; line-height: 1.5; }
.incident-meta { display: flex; flex-wrap: wrap; gap: 16px; font-size: 0.8rem; color: #666666; margin-bottom: 16px; }
.meta-item { display: flex; align-items: center; gap: 4px; }

.incident-timeline { background: #f5f5f5; border-radius: 8px; padding: 12px; margin-bottom: 16px; }
.timeline-header { display: flex; justify-content: space-between; align-items: center; cursor: pointer; font-size: 0.85rem; font-weight: 500; color: #1a1a1a; }
.timeline-content { margin-top: 12px; }
.timeline-event { display: flex; gap: 12px; padding: 8px 0; }
.event-dot { width: 10px; height: 10px; border-radius: 50%; margin-top: 4px; flex-shrink: 0; }
.event-dot--created { background: #ef4444; }
.event-dot--assigned { background: #3b82f6; }
.event-dot--update { background: #f59e0b; }
.event-dot--agent { background: #8b5cf6; }
.event-dot--fix { background: #10b981; }
.event-content { display: flex; flex-direction: column; gap: 2px; }
.event-time { font-size: 0.7rem; color: #999999; }
.event-text { font-size: 0.8rem; color: #1a1a1a; }

.incident-errors { margin-bottom: 16px; }
.errors-header { font-size: 0.75rem; font-weight: 600; color: #666666; margin-bottom: 8px; text-transform: uppercase; }
.error-chips { display: flex; flex-wrap: wrap; }

.incident-actions { display: flex; flex-wrap: wrap; gap: 8px; }

.dialog-card { background: #ffffff !important; }
.dialog-title { display: flex; align-items: center; background: #f5f5f5; padding: 16px 20px !important; color: #1a1a1a; font-size: 1rem; }
</style>
